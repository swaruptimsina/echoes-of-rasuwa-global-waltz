import subprocess
import unittest
from pathlib import Path


class RunAllScriptTests(unittest.TestCase):
    def test_shell_script_is_valid_and_has_uv_fallback_for_pipless_venv(self):
        root = Path(__file__).resolve().parents[1]
        script = root / "scripts" / "run_all.sh"
        result = subprocess.run(["bash", "-n", str(script)], capture_output=True, text=True, check=False)
        self.assertEqual(result.returncode, 0, result.stderr)
        content = script.read_text()
        self.assertIn("uv pip install --python", content)
        self.assertIn("python -m pip", content)
        for command in (
            "scripts/scouting/inventory_stats.py",
            "scripts/scouting/build_coherence_mask.py",
            "scripts/scouting/build_impact_outputs.py",
            "scripts/scouting/build_screening_map.py",
            "scripts/scouting/build_game_manifest.py",
            "scripts/scouting/validate_release.py",
        ):
            self.assertIn(command, content)
        self.assertNotIn("submit_jobs.py", content)


if __name__ == "__main__":
    unittest.main()
