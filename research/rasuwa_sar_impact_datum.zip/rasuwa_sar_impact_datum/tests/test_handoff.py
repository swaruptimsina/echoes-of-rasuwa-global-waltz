import unittest

import numpy as np

from scripts.export_handoff import run_length_encode, timeline_handoff_rows


class HandoffTests(unittest.TestCase):
    def test_run_length_encode_flattens_rows_without_losing_values(self):
        mask = np.array([[0, 0, 1], [1, 0, 0]], dtype=np.uint8)
        self.assertEqual(run_length_encode(mask), [[0, 2], [1, 2], [0, 2]])

    def test_timeline_handoff_rows_preserves_exact_product_ids(self):
        rows = [
            {
                "mission": "Sentinel-1",
                "collection_short_name": "SENTINEL-1D_SLC",
                "producer_granule_id": "EXACT_ID",
                "granule_concept_id": "G1",
                "begin_datetime": "2026-08-28T12:21:40Z",
                "end_datetime": "2026-08-28T12:22:08Z",
                "event_role": "post_event",
                "acquisition_offset_days": "2.395",
                "provider_insert_datetime": "2026-08-29T08:58:32Z",
                "event_to_archive_days": "3.254",
                "track_path": "85",
                "direction": "ASCENDING",
            }
        ]
        result = timeline_handoff_rows(rows)
        self.assertEqual(result[0]["producer_granule_id"], "EXACT_ID")
        self.assertEqual(result[0]["acquisition_offset_days"], 2.395)
        self.assertEqual(result[0]["event_to_archive_days"], 3.254)


if __name__ == "__main__":
    unittest.main()
