import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from shapely.geometry import box

from scripts.scouting.inventory_stats import (
    build_outputs,
    cmr_spatial_geometry,
    geometry_key,
    observation_dates,
    summarize_rows,
)


class SpatialGeometryTests(unittest.TestCase):
    def test_parses_polygon_and_rectangle_spatial_extents(self):
        polygon_extent = {
            "HorizontalSpatialDomain": {
                "Geometry": {
                    "GPolygons": [
                        {
                            "Boundary": {
                                "Points": [
                                    {"Longitude": 85.0, "Latitude": 28.0},
                                    {"Longitude": 85.2, "Latitude": 28.0},
                                    {"Longitude": 85.2, "Latitude": 28.2},
                                    {"Longitude": 85.0, "Latitude": 28.2},
                                    {"Longitude": 85.0, "Latitude": 28.0},
                                ]
                            }
                        }
                    ]
                }
            }
        }
        rectangle_extent = {
            "HorizontalSpatialDomain": {
                "Geometry": {
                    "BoundingRectangles": [
                        {
                            "WestBoundingCoordinate": 84.8,
                            "SouthBoundingCoordinate": 27.8,
                            "EastBoundingCoordinate": 85.1,
                            "NorthBoundingCoordinate": 28.1,
                        }
                    ]
                }
            }
        }

        polygon = cmr_spatial_geometry(json.dumps(polygon_extent))
        rectangle = cmr_spatial_geometry(json.dumps(rectangle_extent))

        self.assertTrue(polygon.is_valid)
        self.assertAlmostEqual(polygon.area, 0.04, places=8)
        self.assertTrue(rectangle.equals(box(84.8, 27.8, 85.1, 28.1)))


class AcquisitionNormalizationTests(unittest.TestCase):
    def test_pair_products_contribute_both_observation_dates(self):
        row = {
            "acquisition_begin_utc": "2026-08-19T23:39:18Z",
            "reference_begin_utc": "2026-08-19T23:39:18Z",
            "secondary_begin_utc": "2026-08-31T23:39:18Z",
        }
        self.assertEqual(observation_dates(row), ["2026-08-19", "2026-08-31"])

    def test_single_epoch_product_contributes_acquisition_date_once(self):
        row = {
            "acquisition_begin_utc": "2026-08-19T23:39:18Z",
            "reference_begin_utc": "",
            "secondary_begin_utc": "",
        }
        self.assertEqual(observation_dates(row), ["2026-08-19"])

    def test_geometry_key_excludes_platform_but_preserves_track_frame_and_polarization(self):
        row_a = {
            "mission": "Sentinel-1",
            "product_type": "SLC",
            "platform": "SENTINEL-1A",
            "track_path": "85",
            "frame": "88",
            "direction": "ASCENDING",
            "beam_mode": "IW",
            "swath": "",
            "polarization": "VV|VH",
            "group_stack_burst_id": "S1A_IWDV_0082_0088_056580_085",
            "mgrs_tile_id": "",
            "range_bandwidth_mhz": "",
        }
        row_d = dict(
            row_a,
            platform="SENTINEL-1D",
            group_stack_burst_id="S1D_IWDV_0082_0088_004151_085",
        )
        row_other_track = dict(row_a, track_path="121")
        self.assertEqual(geometry_key(row_a), geometry_key(row_d))
        self.assertNotEqual(geometry_key(row_a), geometry_key(row_other_track))


class CoverageSummaryTests(unittest.TestCase):
    def test_reports_unique_dates_longest_geometry_and_monsoon_sides(self):
        base = {
            "mission": "NISAR",
            "product_type": "GCOV",
            "track_path": "98",
            "frame": "16",
            "direction": "ASCENDING",
            "beam_mode": "",
            "swath": "",
            "polarization": "HH|HV",
            "group_stack_burst_id": "",
            "mgrs_tile_id": "",
            "range_bandwidth_mhz": "40",
            "reference_begin_utc": "",
            "secondary_begin_utc": "",
        }
        rows = [
            dict(base, acquisition_begin_utc="2026-06-01T00:00:00Z"),
            dict(base, acquisition_begin_utc="2026-06-13T00:00:00Z"),
            dict(base, acquisition_begin_utc="2026-06-25T00:00:00Z"),
            dict(base, acquisition_begin_utc="2026-08-31T00:00:00Z"),
            dict(base, acquisition_begin_utc="2026-08-31T00:00:00Z", maturity="Beta"),
            dict(base, track_path="48", acquisition_begin_utc="2026-07-01T00:00:00Z"),
            dict(base, track_path="48", acquisition_begin_utc="2026-09-12T00:00:00Z"),
        ]

        summary = summarize_rows(rows, event_date="2026-08-26")

        self.assertEqual(summary["unique_observation_dates"], 6)
        self.assertEqual(summary["longest_same_geometry_chain_dates"], 4)
        self.assertEqual(summary["median_adjacent_baseline_days"], 12.0)
        self.assertEqual(summary["monsoon_dates_before_event"], 4)
        self.assertEqual(summary["monsoon_dates_after_event"], 2)


class OutputBuildTests(unittest.TestCase):
    def test_postfilters_to_aoi_assigns_subareas_and_writes_stats(self):
        extent_inside = json.dumps(
            {
                "HorizontalSpatialDomain": {
                    "Geometry": {
                        "BoundingRectangles": [
                            {
                                "WestBoundingCoordinate": 0.1,
                                "SouthBoundingCoordinate": 0.1,
                                "EastBoundingCoordinate": 0.2,
                                "NorthBoundingCoordinate": 0.2,
                            }
                        ]
                    }
                }
            }
        )
        extent_outside = json.dumps(
            {
                "HorizontalSpatialDomain": {
                    "Geometry": {
                        "BoundingRectangles": [
                            {
                                "WestBoundingCoordinate": 2.0,
                                "SouthBoundingCoordinate": 2.0,
                                "EastBoundingCoordinate": 2.1,
                                "NorthBoundingCoordinate": 2.1,
                            }
                        ]
                    }
                }
            }
        )
        fields = [
            "inventory_id",
            "mission",
            "product_type",
            "track_path",
            "frame",
            "direction",
            "beam_mode",
            "swath",
            "polarization",
            "group_stack_burst_id",
            "mgrs_tile_id",
            "range_bandwidth_mhz",
            "acquisition_begin_utc",
            "reference_begin_utc",
            "secondary_begin_utc",
            "spatial_extent_json",
        ]
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / "source.csv"
            with source.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=fields)
                writer.writeheader()
                writer.writerow(
                    {
                        "inventory_id": "inside",
                        "mission": "Sentinel-1",
                        "product_type": "SLC",
                        "track_path": "85",
                        "frame": "88",
                        "direction": "ASCENDING",
                        "beam_mode": "IW",
                        "polarization": "VV|VH",
                        "acquisition_begin_utc": "2026-08-28T00:00:00Z",
                        "spatial_extent_json": extent_inside,
                    }
                )
                writer.writerow(
                    {
                        "inventory_id": "outside",
                        "mission": "Sentinel-1",
                        "product_type": "SLC",
                        "acquisition_begin_utc": "2026-08-28T00:00:00Z",
                        "spatial_extent_json": extent_outside,
                    }
                )
            aoi = root / "aoi.geojson"
            aoi.write_text(
                json.dumps(
                    {
                        "type": "FeatureCollection",
                        "features": [
                            {
                                "type": "Feature",
                                "properties": {},
                                "geometry": {
                                    "type": "Polygon",
                                    "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 1], [0, 0]]],
                                },
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )
            subareas = root / "subareas.geojson"
            subareas.write_text(
                json.dumps(
                    {
                        "type": "FeatureCollection",
                        "features": [
                            {
                                "type": "Feature",
                                "properties": {"subarea_id": "upper"},
                                "geometry": {
                                    "type": "Polygon",
                                    "coordinates": [[[0, 0], [0.5, 0], [0.5, 1], [0, 1], [0, 0]]],
                                },
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )
            exact = root / "inventory.csv"
            stats = root / "stats.csv"
            result = build_outputs(source, aoi, subareas, exact, stats, "2026-08-26")

            with exact.open(newline="", encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))
            with stats.open(newline="", encoding="utf-8") as handle:
                stats_rows = list(csv.DictReader(handle))

            stats_by_subarea = {row["subarea_id"]: row for row in stats_rows}
            self.assertEqual(result["source_rows"], 2)
            self.assertEqual(result["exact_aoi_rows"], 1)
            self.assertEqual(rows[0]["subarea_ids"], "upper")
            self.assertEqual(stats_by_subarea["upper"]["unique_observation_dates"], "1")


class CliSmokeTests(unittest.TestCase):
    def test_documented_script_path_supports_help(self):
        result = subprocess.run(
            [sys.executable, "scripts/scouting/inventory_stats.py", "--help"],
            cwd=Path(__file__).resolve().parents[1],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("--source", result.stdout)
        self.assertIn("--stats", result.stdout)


if __name__ == "__main__":
    unittest.main()
