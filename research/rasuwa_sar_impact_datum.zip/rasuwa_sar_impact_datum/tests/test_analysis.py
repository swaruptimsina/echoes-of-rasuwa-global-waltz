import subprocess
import sys
import unittest
from pathlib import Path

import numpy as np

from scripts.analyze_opera_change import db_difference, evaluate_change, consensus_count


class ChangeAnalysisTests(unittest.TestCase):
    def test_db_difference_is_post_minus_pre_power_db(self):
        pre = np.array([[1.0, 1.0], [0.0, 2.0]])
        post = np.array([[10.0, 0.1], [1.0, 2.0]])
        valid = np.array([[1, 1], [1, 0]], dtype=bool)
        result = db_difference(pre, post, valid)
        self.assertAlmostEqual(result[0, 0], 10.0)
        self.assertAlmostEqual(result[0, 1], -10.0)
        self.assertTrue(np.isnan(result[1, 0]))
        self.assertTrue(np.isnan(result[1, 1]))

    def test_evaluate_change_reports_observed_overlap_and_outside_false_alarms(self):
        flags = np.array([[1, 1], [1, 0]], dtype=bool)
        observed = np.array([[1, 0], [0, 0]], dtype=bool)
        valid = np.ones((2, 2), dtype=bool)
        result = evaluate_change(flags, observed, valid, pixel_area=0.0009)
        self.assertEqual(result["counts"], {"tp": 1, "fp": 2, "fn": 0, "tn": 1})
        self.assertAlmostEqual(result["flagged_area_km2"], 0.0027)
        self.assertAlmostEqual(result["observed_valid_area_km2"], 0.0009)

    def test_consensus_count_ignores_invalid_tracks(self):
        flags = [np.array([[1, 0], [1, 1]], dtype=bool), np.array([[1, 1], [0, 1]], dtype=bool)]
        valid = [np.array([[1, 1], [0, 1]], dtype=bool), np.array([[1, 0], [1, 1]], dtype=bool)]
        counts, observations = consensus_count(flags, valid)
        np.testing.assert_array_equal(counts, np.array([[2, 0], [0, 2]], dtype=np.uint8))
        np.testing.assert_array_equal(observations, np.array([[2, 1], [1, 2]], dtype=np.uint8))

    def test_script_help_runs_by_path(self):
        root = Path(__file__).resolve().parents[1]
        result = subprocess.run(
            [sys.executable, str(root / "scripts" / "analyze_opera_change.py"), "--help"],
            cwd=root,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == "__main__":
    unittest.main()
