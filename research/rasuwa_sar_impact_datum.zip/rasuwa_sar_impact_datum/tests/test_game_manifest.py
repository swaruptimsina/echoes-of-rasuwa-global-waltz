import json
import tempfile
import unittest
from pathlib import Path

from scripts.scouting.build_game_manifest import build_manifest, classify_asset


class GameManifestTests(unittest.TestCase):
    def test_asset_labels_distinguish_observation_model_and_context(self):
        self.assertEqual(classify_asset(Path("acquisition_timeline.json")), "catalog observation")
        self.assertEqual(classify_asset(Path("coherence_loss_screening_mask.png")), "model output from observations")
        self.assertEqual(classify_asset(Path("connected_system_aoi.geojson")), "model/context geometry")
        self.assertEqual(classify_asset(Path("lband_coherence_comparison.png")), "observation-derived visualization")

    def test_manifest_hashes_assets_and_excludes_itself(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "a.json").write_text("{}", encoding="utf-8")
            (root / "provenance.json").write_text("stale", encoding="utf-8")

            result = build_manifest(root)

            self.assertEqual(result["asset_count"], 1)
            self.assertEqual(result["assets"][0]["file"], "a.json")
            self.assertEqual(len(result["assets"][0]["sha256"]), 64)
            written = json.loads((root / "provenance.json").read_text(encoding="utf-8"))
            self.assertEqual(written["asset_count"], 1)


if __name__ == "__main__":
    unittest.main()
