import unittest

from scripts.scouting.aoi import downstream_chain, upstream_ids


class HydroTopologyTests(unittest.TestCase):
    def setUp(self):
        self.next_down = {1: 3, 2: 3, 3: 4, 4: 5, 5: 0, 6: 5, 7: 6}

    def test_upstream_ids_includes_outlet_and_all_transitive_tributaries(self):
        self.assertEqual(upstream_ids(self.next_down, 4), {1, 2, 3, 4})

    def test_downstream_chain_stops_at_requested_basin(self):
        self.assertEqual(downstream_chain(self.next_down, 3, stop_id=5), [3, 4, 5])

    def test_downstream_chain_rejects_cycle(self):
        with self.assertRaisesRegex(ValueError, "cycle"):
            downstream_chain({1: 2, 2: 1}, 1)


if __name__ == "__main__":
    unittest.main()
