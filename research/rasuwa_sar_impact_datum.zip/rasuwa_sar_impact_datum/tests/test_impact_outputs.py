import subprocess
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path

from scripts.scouting.build_impact_outputs import (
    _first_post,
    build_timeline_rows,
    coherence_comparison,
    latency_values,
)


class ImpactMathTests(unittest.TestCase):
    def test_latency_separates_acquisition_and_archive_insertion(self):
        event = datetime(2026, 8, 26, 0, 0, tzinfo=timezone.utc)
        acquisition = datetime(2026, 8, 28, 12, 0, tzinfo=timezone.utc)
        production = datetime(2026, 8, 28, 18, 0, tzinfo=timezone.utc)
        insertion = datetime(2026, 8, 29, 0, 0, tzinfo=timezone.utc)

        result = latency_values(event, acquisition, insertion, production)

        self.assertEqual(result["acquisition_offset_days"], 2.5)
        self.assertEqual(result["product_generation_offset_days"], 2.75)
        self.assertEqual(result["archive_insertion_offset_days"], 3.0)
        self.assertEqual(result["processing_to_archive_days"], 0.25)

    def test_cross_band_summary_uses_within_sensor_target_control_contrasts(self):
        result = coherence_comparison(
            l_quiet_target=0.22,
            l_event_target=0.10,
            l_quiet_control=0.86,
            l_event_control=0.85,
            c_target_delta=-0.13,
            c_control_delta=0.18,
        )

        self.assertAlmostEqual(result["l_band_target_delta"], -0.12)
        self.assertAlmostEqual(result["l_band_control_delta"], -0.01)
        self.assertAlmostEqual(result["l_band_difference_of_changes"], -0.11)
        self.assertAlmostEqual(result["c_band_difference_of_changes"], -0.31)
        self.assertFalse(result["absolute_coherence_directly_comparable"])

    def test_first_post_can_require_the_processed_polarization(self):
        event = datetime(2026, 8, 26, 0, 0, tzinfo=timezone.utc)
        rows = [
            {
                "mission": "Sentinel-1",
                "product_type": "BURST",
                "polarization": "VH",
                "acquisition_begin_utc": "2026-08-28T12:00:00Z",
            },
            {
                "mission": "Sentinel-1",
                "product_type": "BURST",
                "polarization": "VV",
                "acquisition_begin_utc": "2026-08-28T12:00:00Z",
            },
        ]

        selected = _first_post(rows, event, "Sentinel-1", "BURST", preferred_polarization="VV")

        self.assertEqual(selected["polarization"], "VV")

    def test_timeline_deduplicates_product_geometry_dates(self):
        event = datetime(2026, 8, 26, 0, 0, tzinfo=timezone.utc)
        base = {
            "mission": "Sentinel-1",
            "platform": "SENTINEL-1D",
            "product_type": "SLC",
            "track_path": "85",
            "direction": "ASCENDING",
            "acquisition_begin_utc": "2026-08-28T12:00:00Z",
            "producer_granule_id": "scene-a",
        }
        rows = [base, dict(base, producer_granule_id="scene-revision"), dict(base, product_type="RTC", mission="OPERA")]

        timeline = build_timeline_rows(rows, event)

        self.assertEqual(len(timeline), 2)
        self.assertEqual({row["relation_to_event"] for row in timeline}, {"after"})


class CliSmokeTests(unittest.TestCase):
    def test_documented_script_path_supports_help(self):
        result = subprocess.run(
            [sys.executable, "scripts/scouting/build_impact_outputs.py", "--help"],
            cwd=Path(__file__).resolve().parents[1],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("--inventory", result.stdout)
        self.assertIn("--game-output", result.stdout)


if __name__ == "__main__":
    unittest.main()
