import subprocess
import sys
import unittest
from pathlib import Path

from scripts.fetch_opera_rtc import layer_url, select_opera_products


class OperaSelectionTests(unittest.TestCase):
    def setUp(self):
        self.features = [
            {
                "properties": {
                    "operaBurstID": "T019_039570_IW1",
                    "startTime": "2026-08-12T00:18:55Z",
                    "fileID": "p0",
                    "additionalUrls": ["https://example.test/p0_VV.tif", "https://example.test/p0_mask.tif"],
                }
            },
            {
                "properties": {
                    "operaBurstID": "T019_039570_IW1",
                    "startTime": "2026-08-24T00:18:55Z",
                    "fileID": "p1",
                    "additionalUrls": ["https://example.test/p1_VV.tif", "https://example.test/p1_mask.tif"],
                }
            },
        ]

    def test_select_opera_products_returns_exact_burst_dates(self):
        selected = select_opera_products(
            self.features,
            {"quiet_pre": ("T019_039570_IW1", "2026-08-12"), "event_pre": ("T019_039570_IW1", "2026-08-24")},
        )
        self.assertEqual(selected["quiet_pre"]["fileID"], "p0")
        self.assertEqual(selected["event_pre"]["fileID"], "p1")

    def test_select_opera_products_rejects_missing_date(self):
        with self.assertRaisesRegex(RuntimeError, "expected exactly one"):
            select_opera_products(self.features, {"missing": ("T019_039570_IW1", "2026-09-05")})

    def test_layer_url_returns_named_tiff_only(self):
        product = self.features[0]["properties"]
        self.assertEqual(layer_url(product, "VV"), "https://example.test/p0_VV.tif")
        with self.assertRaisesRegex(RuntimeError, "expected exactly one"):
            layer_url(product, "VH")

    def test_script_help_runs_when_invoked_by_path(self):
        root = Path(__file__).resolve().parents[1]
        result = subprocess.run(
            [sys.executable, str(root / "scripts" / "fetch_opera_rtc.py"), "--help"],
            cwd=root,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("usage:", result.stdout)


if __name__ == "__main__":
    unittest.main()
