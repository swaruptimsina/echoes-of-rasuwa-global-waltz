import unittest
from datetime import datetime, timezone

from scripts.catalog import classify_timeline, dswx_event_gap, same_geometry_pairs


EVENT = datetime(2026, 8, 26, 2, 52, 10, tzinfo=timezone.utc)


class TimelineTests(unittest.TestCase):
    def test_classify_timeline_marks_nearest_pre_post_and_event_spanning_pair(self):
        records = [
            {"id": "pre-old", "begin": "2026-08-10T00:00:00Z"},
            {"id": "pre-near", "begin": "2026-08-24T00:18:55Z"},
            {"id": "post-near", "begin": "2026-08-28T12:21:48Z"},
            {
                "id": "pair",
                "begin": "2026-08-16T12:58:12Z",
                "secondary_begin": "2026-08-28T12:58:12Z",
            },
        ]
        roles = classify_timeline(records, EVENT)
        self.assertEqual(roles["pre-near"], "nearest_pre")
        self.assertEqual(roles["post-near"], "nearest_post")
        self.assertEqual(roles["pair"], "spans_event")
        self.assertEqual(roles["pre-old"], "other_pre")

    def test_same_geometry_pairs_requires_track_direction_and_repeat(self):
        records = [
            {"id": "a", "begin": "2026-08-12T00:00:00Z", "track": 19, "direction": "DESCENDING"},
            {"id": "b", "begin": "2026-08-24T00:00:00Z", "track": 19, "direction": "DESCENDING"},
            {"id": "wrong", "begin": "2026-09-05T00:00:00Z", "track": 85, "direction": "ASCENDING"},
        ]
        pairs = same_geometry_pairs(records, repeat_days=12.0, tolerance_seconds=2.0)
        self.assertEqual([(p["pre_id"], p["post_id"]) for p in pairs], [("a", "b")])

    def test_dswx_event_gap_reports_straddling_catalog_gap(self):
        times = ["2026-06-25T00:11:06Z", "2026-09-12T00:10:29Z"]
        result = dswx_event_gap(times, EVENT)
        self.assertEqual(result["latest_pre"], times[0])
        self.assertEqual(result["first_post"], times[1])
        self.assertGreater(result["gap_days"], 78.9)
        self.assertEqual(result["event_window_count"], 0)


if __name__ == "__main__":
    unittest.main()
