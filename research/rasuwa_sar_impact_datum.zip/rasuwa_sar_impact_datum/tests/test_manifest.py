import json
import tempfile
import unittest
import warnings
from pathlib import Path

import numpy as np
import rasterio
from rasterio.transform import from_origin

from scripts.build_manifest import collect_manifest_files, describe_file, scientific_metadata_maps


class ManifestTests(unittest.TestCase):
    def test_describe_raster_captures_hash_grid_and_source_tags(self):
        warnings.filterwarnings("ignore", category=PendingDeprecationWarning, module="rasterio.transform")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.tif"
            with rasterio.open(
                path,
                "w",
                driver="GTiff",
                width=2,
                height=3,
                count=1,
                dtype="uint8",
                crs="EPSG:32645",
                transform=from_origin(100, 200, 30, 30),
                nodata=255,
            ) as dataset:
                dataset.write(np.ones((3, 2), dtype="uint8"), 1)
                dataset.update_tags(
                    source_product="EXACT_ID",
                    threshold_k="3.0",
                    threshold_rule="control_p05",
                    provenance_class="model_output",
                )
            row = describe_file(
                path,
                root=Path(directory),
                source_url_override="https://example.test/source",
                parameters_override="method=test",
            )
        self.assertEqual(row["path"], "sample.tif")
        self.assertEqual(row["source_granule_ids"], "EXACT_ID")
        self.assertEqual(row["crs"], "EPSG:32645")
        self.assertEqual(row["shape"], "3x2x1")
        self.assertEqual(row["provenance_label"], "model_output")
        self.assertEqual(row["source_url"], "https://example.test/source")
        self.assertIn("method=test", row["processing_parameters"])
        self.assertIn("threshold_k=3.0", row["processing_parameters"])
        self.assertIn("threshold_rule=control_p05", row["processing_parameters"])
        self.assertEqual(len(row["sha256"]), 64)

    def test_scientific_metadata_maps_nisar_subset_to_exact_product(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            summary_path = root / "processed/nisar_lband/outputs/subset_summary.json"
            summary_path.parent.mkdir(parents=True)
            summary_path.write_text(
                json.dumps(
                    {
                        "pairs": {
                            "quiet": {
                                "maturity": "PROVISIONAL",
                                "crid": "P05023",
                                "products": {
                                    "gunw": {
                                        "product_id": "GUNW_EXACT",
                                        "range_access": {"original_https_url": "https://example.test/gunw.h5"},
                                    },
                                    "goff": {
                                        "product_id": "GOFF_EXACT",
                                        "range_access": {"original_https_url": "https://example.test/goff.h5"},
                                    },
                                    "gcov_reference": {
                                        "product_id": "GCOV_REF",
                                        "range_access": {"original_https_url": "https://example.test/ref.h5"},
                                    },
                                    "gcov_secondary": {
                                        "product_id": "GCOV_SEC",
                                        "range_access": {"original_https_url": "https://example.test/sec.h5"},
                                    },
                                },
                            }
                        }
                    }
                ),
                encoding="utf-8",
            )

            sources, provenance, urls, parameters = scientific_metadata_maps(root)

        key = str(root / "processed/nisar_lband/subsets/quiet_source_gunw.tif")
        self.assertEqual(sources[key], "GUNW_EXACT")
        self.assertEqual(urls[key], "https://example.test/gunw.h5")
        self.assertIn("pair=quiet", parameters[key])
        self.assertEqual(provenance[key], "observation-derived NISAR range subset")

    def test_collection_includes_scientific_outputs_but_not_raw_cache(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            expected = {
                root / "inputs" / "a.txt",
                root / "processed" / "b.txt",
                root / "scouting" / "c.txt",
                root / "acquisition_timeline.csv",
            }
            for path in expected | {root / "raw" / "secret.bin"}:
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text("x", encoding="utf-8")

            collected = set(collect_manifest_files(root))

        self.assertEqual(collected, expected)


if __name__ == "__main__":
    unittest.main()
