import csv
import hashlib
import tempfile
import unittest
from pathlib import Path

from scripts.scouting.validate_release import verify_csv_manifest_hashes


class ReleaseValidationTests(unittest.TestCase):
    def test_manifest_hash_verifier_detects_changed_file(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            target = root / "file.txt"
            target.write_text("original", encoding="utf-8")
            digest = hashlib.sha256(target.read_bytes()).hexdigest()
            manifest = root / "manifest.csv"
            with manifest.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=["path", "sha256"])
                writer.writeheader()
                writer.writerow({"path": "file.txt", "sha256": digest})

            self.assertEqual(verify_csv_manifest_hashes(root, manifest), [])
            target.write_text("changed", encoding="utf-8")
            failures = verify_csv_manifest_hashes(root, manifest)

        self.assertEqual(len(failures), 1)
        self.assertIn("hash mismatch", failures[0])


if __name__ == "__main__":
    unittest.main()
