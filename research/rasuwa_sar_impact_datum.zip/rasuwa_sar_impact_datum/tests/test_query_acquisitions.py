import unittest

from scripts.query_acquisitions import dswx_gap_from_payloads, normalize_cmr_item


class CmrNormalizationTests(unittest.TestCase):
    def test_normalize_cmr_item_preserves_exact_ids_times_and_geometry_fields(self):
        item = {
            "meta": {"concept-id": "G1-TEST", "revision-date": "2026-09-01T00:00:00Z"},
            "umm": {
                "GranuleUR": "EXACT_GRANULE_ID",
                "TemporalExtent": {"RangeDateTime": {"BeginningDateTime": "2026-08-24T00:18:55Z", "EndingDateTime": "2026-08-24T00:19:00Z"}},
                "Platforms": [{"ShortName": "Sentinel-1D"}],
                "OrbitCalculatedSpatialDomains": [{"OrbitNumber": 4260}],
                "AdditionalAttributes": [
                    {"Name": "PATH_NUMBER", "Values": ["19"]},
                    {"Name": "ASCENDING_DESCENDING", "Values": ["DESCENDING"]},
                ],
                "ProviderDates": [{"Date": "2026-10-10T21:54:09Z", "Type": "Insert"}],
            },
        }
        row = normalize_cmr_item(item, mission="OPERA", collection_id="C1", short_name="OPERA_L2_RTC-S1_V1")
        self.assertEqual(row["producer_granule_id"], "EXACT_GRANULE_ID")
        self.assertEqual(row["granule_concept_id"], "G1-TEST")
        self.assertEqual(row["begin_datetime"], "2026-08-24T00:18:55Z")
        self.assertEqual(row["platforms"], "Sentinel-1D")
        self.assertEqual(row["orbit_number"], "4260")
        self.assertEqual(row["track_path"], "19")
        self.assertEqual(row["direction"], "DESCENDING")
        self.assertEqual(row["provider_insert_datetime"], "2026-10-10T21:54:09Z")

    def test_dswx_gap_from_history_uses_latest_pre_and_first_post(self):
        def item(begin):
            return {"umm": {"TemporalExtent": {"RangeDateTime": {"BeginningDateTime": begin}}}}

        result = dswx_gap_from_payloads(
            {"items": [item("2026-06-25T00:11:06Z"), item("2026-05-01T00:00:00Z")]},
            {"items": [item("2026-09-12T00:10:37Z"), item("2026-09-24T00:10:48Z")]},
        )
        self.assertEqual(result["latest_pre"], "2026-06-25T00:11:06Z")
        self.assertEqual(result["first_post"], "2026-09-12T00:10:37Z")
        self.assertGreater(result["gap_days"], 78.9)
        self.assertEqual(result["event_window_count"], 0)


if __name__ == "__main__":
    unittest.main()
