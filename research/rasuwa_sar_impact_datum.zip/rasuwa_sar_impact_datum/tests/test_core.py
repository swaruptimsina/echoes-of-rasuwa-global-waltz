import hashlib
import math
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

from scripts.core import (
    apply_mmu,
    binary_metrics,
    confusion_counts,
    latency_days,
    nanmedian_filter,
    pixel_area_km2,
    robust_change_score,
    robust_location_scale,
    sha256_file,
    slope_degrees,
)


class RobustStatisticsTests(unittest.TestCase):
    def test_robust_location_scale_ignores_nonfinite_values(self):
        values = np.array([1.0, 2.0, 3.0, np.nan, np.inf, 100.0])
        center, scale = robust_location_scale(values)
        self.assertEqual(center, 2.5)
        self.assertAlmostEqual(scale, 1.4826, places=4)

    def test_robust_location_scale_rejects_constant_reference(self):
        with self.assertRaisesRegex(ValueError, "zero robust scale"):
            robust_location_scale(np.ones(10))

    def test_robust_change_score_calibrates_each_channel_on_reference(self):
        vv = np.array([[0.0, 1.0, 2.0], [3.0, 4.0, 30.0]])
        vh = np.array([[0.0, -1.0, -2.0], [-3.0, -4.0, -30.0]])
        valid = np.ones(vv.shape, dtype=bool)
        reference = np.array([[True, True, True], [True, True, False]])
        result = robust_change_score(vv, vh, valid, reference)
        self.assertTrue(np.isfinite(result["score"][1, 2]))
        self.assertGreater(result["score"][1, 2], 10.0)
        self.assertAlmostEqual(result["centers"]["vv"], 2.0)
        self.assertAlmostEqual(result["centers"]["vh"], -2.0)


class RasterLogicTests(unittest.TestCase):
    def test_apply_mmu_uses_eight_connected_components(self):
        flags = np.array(
            [
                [1, 0, 0, 0, 1],
                [0, 1, 0, 0, 0],
                [0, 0, 1, 0, 0],
                [0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0],
            ],
            dtype=bool,
        )
        kept = apply_mmu(flags, minimum_pixels=3)
        expected = np.zeros_like(flags)
        expected[0, 0] = expected[1, 1] = expected[2, 2] = True
        np.testing.assert_array_equal(kept, expected)

    def test_confusion_counts_respects_evaluation_mask(self):
        predicted = np.array([[1, 1], [0, 0]], dtype=bool)
        observed = np.array([[1, 0], [1, 0]], dtype=bool)
        evaluate = np.array([[1, 1], [0, 1]], dtype=bool)
        counts = confusion_counts(predicted, observed, evaluate)
        self.assertEqual(counts, {"tp": 1, "fp": 1, "fn": 0, "tn": 1})

    def test_binary_metrics_handles_standard_confusion_counts(self):
        metrics = binary_metrics({"tp": 8, "fp": 2, "fn": 4, "tn": 6})
        self.assertAlmostEqual(metrics["precision"], 0.8)
        self.assertAlmostEqual(metrics["recall"], 8 / 12)
        self.assertAlmostEqual(metrics["iou"], 8 / 14)
        self.assertAlmostEqual(metrics["false_positive_rate"], 0.25)

    def test_nanmedian_filter_ignores_missing_neighbors(self):
        values = np.array([[1.0, np.nan, 3.0], [4.0, 100.0, 6.0], [7.0, 8.0, 9.0]])
        filtered = nanmedian_filter(values, size=3)
        self.assertEqual(filtered[1, 1], 6.5)

    def test_pixel_area_km2_uses_projected_resolution(self):
        self.assertAlmostEqual(pixel_area_km2(30.0, -30.0), 0.0009)

    def test_slope_degrees_matches_planar_rise(self):
        dem = np.tile(np.arange(5, dtype=float), (5, 1))
        slope = slope_degrees(dem, x_resolution=1.0, y_resolution=1.0)
        self.assertTrue(np.allclose(slope[:, 1:-1], 45.0, atol=1e-8))


class ProvenanceTests(unittest.TestCase):
    def test_latency_days_is_signed_fractional_days(self):
        event = datetime(2026, 8, 26, 2, 52, 10, tzinfo=timezone.utc)
        acquisition = datetime(2026, 8, 28, 12, 21, 40, tzinfo=timezone.utc)
        expected = (acquisition - event).total_seconds() / 86400.0
        self.assertAlmostEqual(latency_days(acquisition, event), expected)

    def test_sha256_file_hashes_exact_bytes(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.bin"
            payload = b"rasuwa-real-data\n"
            path.write_bytes(payload)
            self.assertEqual(sha256_file(path), hashlib.sha256(payload).hexdigest())


if __name__ == "__main__":
    unittest.main()
