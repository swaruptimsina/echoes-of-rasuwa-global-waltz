import subprocess
import sys
import unittest
from pathlib import Path

from scripts.scouting.build_screening_map import classify_osm_feature, distance_band


class ScreeningHelpersTests(unittest.TestCase):
    def test_distance_bands_are_explicit(self):
        self.assertEqual(distance_band(999), "0–1 km")
        self.assertEqual(distance_band(1000), "1–5 km")
        self.assertEqual(distance_band(5000), "5–20 km")
        self.assertEqual(distance_band(20000), ">20 km")

    def test_hydropower_name_is_preserved_as_infrastructure_context(self):
        properties = {"class": "named_waterway", "name": "Upper Trishuli Hydropower Project"}
        self.assertEqual(classify_osm_feature(properties), "hydropower_context")
        self.assertEqual(classify_osm_feature({"class": "bridge"}), "bridge")
        self.assertEqual(classify_osm_feature({"class": "settlement"}), "settlement")


class CliSmokeTests(unittest.TestCase):
    def test_documented_script_path_supports_help(self):
        result = subprocess.run(
            [sys.executable, "scripts/scouting/build_screening_map.py", "--help"],
            cwd=Path(__file__).resolve().parents[1],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("--osm-context", result.stdout)
        self.assertIn("--screening-output", result.stdout)


if __name__ == "__main__":
    unittest.main()
