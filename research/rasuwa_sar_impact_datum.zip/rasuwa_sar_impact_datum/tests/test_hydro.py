import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import h5py
import numpy as np

from scripts.fetch_hydro_context import extract_imerg_point, nearest_index


class HydroContextTests(unittest.TestCase):
    def test_nearest_index_returns_closest_coordinate(self):
        self.assertEqual(nearest_index(np.array([10.0, 20.0, 30.0]), 24.0), 1)

    def test_extract_imerg_point_handles_time_lon_lat_layout(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.h5"
            with h5py.File(path, "w") as handle:
                grid = handle.create_group("Grid")
                grid.create_dataset("lon", data=np.array([85.45, 85.55, 85.65]))
                grid.create_dataset("lat", data=np.array([28.25, 28.35]))
                precipitation = grid.create_dataset(
                    "precipitation",
                    data=np.array([[[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]]], dtype="float32"),
                )
                precipitation.attrs["units"] = np.bytes_("mm/hr")
                grid.create_dataset(
                    "randomError",
                    data=np.array([[[10.0, 20.0], [30.0, 40.0], [50.0, 60.0]]], dtype="float32"),
                )
            result = extract_imerg_point(path, latitude=28.29, longitude=85.53)
        self.assertEqual(result["grid_indices"], {"lon": 1, "lat": 0})
        self.assertEqual(result["grid_center"], {"longitude": 85.55, "latitude": 28.25})
        self.assertEqual(result["variables"]["precipitation"]["value"], 3.0)
        self.assertEqual(result["variables"]["precipitation"]["units"], "mm/hr")
        self.assertEqual(result["variables"]["randomError"]["value"], 30.0)

    def test_script_help_runs_by_path(self):
        root = Path(__file__).resolve().parents[1]
        result = subprocess.run(
            [sys.executable, str(root / "scripts" / "fetch_hydro_context.py"), "--help"],
            cwd=root,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)


if __name__ == "__main__":
    unittest.main()
