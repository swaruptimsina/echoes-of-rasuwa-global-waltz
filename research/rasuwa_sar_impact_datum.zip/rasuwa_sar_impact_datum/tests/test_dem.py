import unittest

from scripts.fetch_dem import copernicus_tile_id, copernicus_tile_url


class CopernicusDemTests(unittest.TestCase):
    def test_tile_id_uses_southwest_integer_degree(self):
        self.assertEqual(copernicus_tile_id(85.528, 28.291), "Copernicus_DSM_COG_10_N28_00_E085_00_DEM")
        self.assertEqual(copernicus_tile_id(-122.1, -45.2), "Copernicus_DSM_COG_10_S46_00_W123_00_DEM")

    def test_tile_url_embeds_exact_tile_id(self):
        tile = "Copernicus_DSM_COG_10_N28_00_E085_00_DEM"
        self.assertEqual(
            copernicus_tile_url(tile),
            f"https://copernicus-dem-30m.s3.amazonaws.com/{tile}/{tile}.tif",
        )


if __name__ == "__main__":
    unittest.main()
