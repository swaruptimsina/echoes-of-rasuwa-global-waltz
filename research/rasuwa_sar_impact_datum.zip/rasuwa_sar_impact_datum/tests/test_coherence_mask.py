import subprocess
import sys
import unittest
from pathlib import Path

import numpy as np

from scripts.scouting.build_coherence_mask import remove_small_components


class MinimumMappingUnitTests(unittest.TestCase):
    def test_removes_small_components_with_eight_neighbor_connectivity(self):
        mask = np.zeros((6, 7), dtype=bool)
        mask[0, 0] = True
        mask[2:4, 2:4] = True
        mask[4, 5] = True
        mask[5, 6] = True  # diagonal pair is one 8-neighbor component of size two

        result = remove_small_components(mask, min_pixels=4)

        expected = np.zeros_like(mask)
        expected[2:4, 2:4] = True
        np.testing.assert_array_equal(result, expected)


class CliSmokeTests(unittest.TestCase):
    def test_documented_script_path_supports_help(self):
        result = subprocess.run(
            [sys.executable, "scripts/scouting/build_coherence_mask.py", "--help"],
            cwd=Path(__file__).resolve().parents[1],
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("--delta", result.stdout)
        self.assertIn("--mmu-pixels", result.stdout)


if __name__ == "__main__":
    unittest.main()
