# Rasuwa–Bhotekoshi SAR Impact Datum Pack

Curated from `/home/safal0715/Documents/research/` for crucial scientific study and the NASA Space Apps Challenge (**"Dancing with the SARs" — Echoes of Rasuwa**).

- **Included files:** 418 (+ this `PACKAGE_INDEX.md`)
- **Uncompressed payload:** 106.50 MB
- **Scope:** Retrospective, reproducible analysis of the **26 August 2026 Langtang Lirung rock–ice collapse & Bhote Koshi–Trishuli cascade** (`2026-08-26T02:52:10Z`), NOT a forecast or operational warning system.

## What is included and why it is high-impact

| Group | Contents | Crucial Research & Hackathon Value |
|---|---|---|
| **Core Synthesis & Guardrails** (`README.md`, `FINDINGS.md`, `AGENCY_BRIEF.md`, `METHOD_CARD.md`, `00_event_facts.md`, `01_questions.md`, `methods.md`, `negative_results.md`, `limitations.md`, `expert_review_questions.md`, `site_selection.md`, `release_validation.json`) | Complete findings, agency brief, honest negative results, 24 limitations, 9-site scorecard (`R1–R6`, `A1–A3`) | Scientific rigor, non-operational Truth Layer guardrails, and exact citations for judges and decision-makers. |
| **Hackathon Web Assets** (`game_handoff/`) | 24 web-ready PNG/WebP/GeoJSON/JSON/CSV files + SHA-256 `provenance.json` + 3-sentence `story_hooks.json` | Drop-in assets for *Echoes of Rasuwa* (change masks, L-vs-C coherence charts, latency table, rainfall timeseries, 20 km exposure context). |
| **NISAR L-Band Range-Read Subsets** (`data/processed/nisar_lband/`) | `GUNW`, `GOFF`, `GCOV` GeoTIFF+NPZ subsets (quiet/event × source/null), QA summaries, pair graphs, `subset_findings.json` | Extracted via authenticated byte-range reads from 35.46 GB of provisional HDF5s; proves localized source decorrelation & honest 9/528 connected-phase failure. |
| **Sentinel-1D HyP3 Coherence** (`data/processed/s1d_hyp3/`) | 2 `INSAR_ISCE_BURST` products (4–16 Aug quiet, 16–28 Aug event) + control-calibrated coherence-loss screening mask (158/307 target pixels vs 1,225/30,161 control false alarms) | Verified Sentinel-1D InSAR workflow, full extracted GeoTIFFs (`corr`, `unw_phase`, `wrapped_phase`, `los_rdr`, `dem`), and explicit false-alarm accounting. |
| **OPERA RTC-S1 3-View Backscatter** (`data/processed/opera_change/` & `data/inputs/opera_rtc/`) | Paths 19, 85, 121 (ascending + descending) dB change, slope masks, consensus masks (`1.1871 km²` event vs `0.1080 km²` quiet null; `48.15%` 2-view observability) | Powers multi-view geometry/layover-shadow lessons and reproducible threshold sensitivity (`k=2.5–4.0`). |
| **Hydrology & Rainfall Context** (`data/processed/hydro_context/`, `data/scouting/aoi/`, `_subagents2/aoi/outputs/`) | 4,774.048 km² connected HydroBASINS AOI, 6 subareas, 272 glacial lakes (`glacial_lakes_glo_s2_2017_2024.geojson`), HydroRIVERS network, OSM named context, GPM IMERG `0.0 mm/h` + POWER | Refutes a localized rainstorm trigger at event time and supplies complete basin/corridor GIS layers. |
| **24-Month SAR Metadata Inventory** (`inventory.csv`, `data/acquisition_timeline.csv`, `data/scouting/inventory/`) | 6,803 exact-AOI CMR granule records, 175-row per-subarea sensor/baseline stats, 218-row event timeline, latency clock breakdown | Quantifies long 12-day S1/NISAR chains, 79-day DSWx gap, and acquisition vs archive-insertion latency. |
| **Independent Validation & Literature** (`evidence/text/`, `sources/`, `_subagents/literature/`, `_subagents/validation/`) | CHWRR/IHRR/NDRRMA sitreps, ICIMOD synthesis text, UNOSAT layers, 16 Sentinel-2 & Landsat-9 quicklooks, Himalayan SAR literature review | Independent optical & seismic/agency corroboration plus peer-reviewed context on Trishuli/Gorkha/Chamoli. |
| **Reproducible Code & Tests** (`scripts/`, `tests/`, `_subagents2/*/scripts/`) | Full Python pipeline + 58 passing unit tests | Allows researchers or judges to inspect, verify, and extend every calculation. |

## Intentionally Excluded Raw Caches (~2.9 GB saved)

To keep this bundle fast, portable, and focused on high-signal datum, large raw caches and duplicate archives were excluded:
- `.venv/` virtual environment
- `data/scouting/hydrography/raw/` (579 MB raw Asia-wide HydroRIVERS/HydroBASINS/NaturalEarth shapefiles & zips; clipped basin GeoJSONs are included)
- `_subagents2/aoi/raw/` (~1.3 GB raw 1°×1° DEM tiles and Asia-wide HydroBASINS/HydroRIVERS archives)
- `_subagents2/inventory/raw/` (~400 MB raw CMR/ASF pagination JSONs & 146 MB `granule_urls.csv`)
- `data/scouting/inventory/bbox_inventory.csv` (56 MB unclipped rectangular superset) & duplicate `data/scouting/inventory/inventory.csv` (canonical `inventory.csv` is included at root)
- `data/processed/s1d_hyp3/products/*.zip` (34 MB redundant zip copies; extracted GeoTIFFs are included under `products/extracted/`)
- `data/inputs/imerg/*.HDF5` (15.2 MB global 0.1° grids; extracted point/error/quality tables are in `data/processed/hydro_context/`)
- `data/raw/acquisitions/` (12 MB raw CMR JSON pages; distilled into `data/acquisition_timeline.csv`)
- `sources/documents/` & `_subagents/*/evidence/*.pdf` (>260 MB source PDFs; extracted plain texts are in `evidence/text/` and `sources/evidence/`)

> **Note on `scripts/run_all.sh`:** Because duplicate `data/scouting/inventory/inventory.csv` and `bbox_inventory.csv` were omitted to reduce archive size, copy root `inventory.csv` to `data/scouting/inventory/inventory.csv` if running `validate_release.py` directly.
