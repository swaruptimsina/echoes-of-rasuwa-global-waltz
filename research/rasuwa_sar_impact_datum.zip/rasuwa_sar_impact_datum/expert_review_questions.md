# Exact expert-review questions

## SAR/InSAR scientist

1. Is the use of OPERA per-acquisition mask class 0 plus a 70° slope ceiling defensible for this source, or should local-incidence and foreshortening layers impose a stricter view-specific mask?
2. Is `S = sqrt((zVV² + zVH²)/2)` with stable-reference median/MAD, `k=3.0`, a 3×3 median and 25-pixel MMU physically/statistically appropriate for these bursts?
3. Should consensus require two views, or should each look direction be interpreted separately because common visibility is only 48.15% of the reference polygon?
4. Which apparent flags outside the UNOSAT polygon are likely real event disturbance versus snow/moisture/speckle false alarms?
5. What effective spatial resolution should be reported after the 3×3 filter and connected-component MMU?
6. Can the exact Sentinel-1/NISAR IDs, reference area, LOS sign, coherence threshold, connected components, atmosphere/ionosphere corrections and DEM used for the published pre-event deformation be released?
7. Does the reported up-to-40 cm pattern survive ascending/descending inversion and terrain-/glacier-matched null slopes?
8. Which NISAR GUNW/GOFF quality layers and provisional-product issues are decisive before comparing the August products with Sentinel-1?
9. Does the track-98 encoded mask decoding used here correctly require valid reference/secondary subswaths, and should ionosphere-interpolated pixels be excluded from coherence as well as phase?
10. Is the 5th-percentile control threshold plus four-pixel MMU defensible for a descriptive C-band screen when the HyP3 burst package lacks an explicit layover/shadow layer?
11. What independent terrain-geometry product should be applied to the two S1D burst pairs, and how should full-footprint observability be reported after that mask?
12. Is the exploratory NISAR control window geologically and glaciologically stable, or should a preregistered bedrock control elsewhere be used?
13. Do the eight provisional NISAR QA identification-group failures affect science layers, metadata conformance only, or both?
14. Can a third identical 12-day S1D pair be processed to complete the preregistered three-pair coherence-quality score without introducing a seasonal mismatch?

## Mission archive/data steward

1. Which exact Bhoonidhi collections and API/STAC fields enumerate NISAR S-band products over this cross-border AOI, and are equivalent S-band GCOV/GUNW/GOFF products available?
2. Can RCM/EODMS and SAOCOM/SIASGE return machine-readable footprint, orbit, polarization and access metadata without an interactive account?
3. Are the 2026 OPERA RTC/DSWx archive insertion dates in CMR representative of production availability, or did a later backfill/reprocessing campaign control those timestamps?
4. Will August 2026 NISAR provisional products be reprocessed into validated collections, and will granule IDs/CRIDs remain traceable across maturity revisions?

## Nepal Department of Hydrology and Meteorology / CHWRR

1. Can the 1.5 mm six-hour Kyangjing total, station clock, gauge quality and exact accumulation window be confirmed?
2. Is 08:37 NPT the collapse time, dam-breach time, or only the strongest seismic/mass-movement signal?
3. What evidence supports or rejects the 25 August failure and 18–19 hour impoundment sequence?
4. Are the published source and flood-arrival coordinates/times final, and can their uncertainty be supplied?
5. Can gauge traces, station-failure times and quality flags be shared for Rasuwagadhi, Syabrubesi, Betrawati and downstream stations?
6. Which radar/optical products arrived soon enough to be seen by DHM during response, as distinct from products archived weeks later?
7. Which channel/deposit reaches would be most useful for retrospective satellite validation against field observations?

## ICIMOD / cryosphere and hazard team

1. Can the preliminary synthesis's exact 7 July–24 August Sentinel-1 network and processing configuration be released for independent reproduction?
2. What evidence separates bedrock deformation, glacier motion, atmospheric delay and unwrapping/geometry effects in the reported LOS signal?
3. Which high-resolution DEMs or optical feature tracks constrain the volume and source mechanics?
4. What is the current preferred sequence: 26 August collapse plus brief blockage, or 25 August collapse plus long impoundment?
5. Is the UNOSAT detachment polygon used here an appropriate validation reference, or is a revised source/deposit inventory available?
6. What parts of the source and upper gorge are fundamentally unobservable from current C-/L-band geometries?
7. Which locally governed data products and languages would make retrospective SAR layers useful without implying operational warning capability?

## Community/government data stewards

1. May anonymized, time-stamped ground photographs or drone orthomosaics be shared with explicit location/date licenses?
2. Which place names and Nepali/Tibetan transliterations should the handoff use consistently?
3. Which layers would be misleading or harmful in a public game even with non-operational labels?
4. Who should approve representation of damaged settlements, casualties and community decisions before public release?
