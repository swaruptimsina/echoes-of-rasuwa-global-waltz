# Data feasibility — Rasuwa–Bhote Koshi event

**Catalog/access test time:** 2026-11-15 04:27–05:01 UTC  
**Search point:** 85.528066°E, 28.291242°N  
**Search AOI:** west 85.45, south 28.24, east 85.62, north 28.38  
**Event time used:** 2026-08-26 08:37 NST = 2026-08-26 02:52 UTC

## Event/AOI check

This is the **26 August 2026** Rasuwa event, not the 8 July 2025 Lhende GLOF.[28][29]
USGS timestamps the mass-movement signal at `2026-08-26T02:52:10Z` (08:37:10 local) and estimates it at 28.271°N, 85.515°E; it reclassified the signal from an earthquake to a glacier-collapse/debris-flow source.[28][29]
The Government of Nepal report gives an approximate source at 28°17′14.8″N, 85°31′29.6″E and a hanging-glacier collapse point at 28.291242°N, 85.528066°E.[1]
The latter point was used for catalog intersection; the AOI contains all three positions.[1]

## Bottom line

1. **Best reproducible amplitude-change path now:** the archived **OPERA RTC-S1** same-burst pair `T019_039570_IW1`, acquired 24 August and 5 September 2026.[18] The data are 30 m gamma-0 COGs, already terrain corrected and exactly coregistered by burst; each VV/VH layer is only about 6.8 MB.[11][18] I streamed and differenced real subsets successfully.
2. **Best ready-made phase/offset path:** NISAR has exact 12-day **PROVISIONAL GUNW and GOFF products that straddle the event** on two tracks.[20][21] These avoid local interferometric processing. The HDF5 files are large: about 2.34 GB for GUNW and 1.08–1.10 GB for GOFF.[8][20][21]
3. **Sentinel-1 SLC is feasible but unnecessarily heavy for first-pass change detection:** three 12-day same-track pairs exist, with each SLC about 4.66–4.81 GB.[16] A pair is about 9.3–9.6 GB before processing.[16] Use SLC only for custom InSAR; use OPERA RTC for amplitude change.
4. **OPERA DSWx-S1 is a diagnosed event-time dead end:** CMR returns **zero acquisitions from 1 August through 11 September 2026** over this AOI.[23] The closest same-track pre/post products are separated by 79 or 91 days and switch from Sentinel-1A to Sentinel-1D, so they cannot cleanly isolate the 26 August event.[22][24]
5. **DEM access works:** the public Copernicus GLO-30 COG is anonymous; the NISAR processing DEM is EDL-protected but accessible.[10][14] The NISAR DEM is the safer input for local SAR processing because it is Copernicus GLO-30 re-referenced from EGM2008 geoid heights to WGS84 ellipsoid heights.[10]

## Access and quota results

| Service | Anonymous test | Authenticated test in this environment | Blocker/constraint |
|---|---:|---:|---|
| ASF catalog Search API | HTTP 200 | not needed | Search is public; rate limit applies.[2][3] |
| ASF Sentinel-1 SLC/GRD files | final HTTP 401 after EDL redirect | HTTP 206 one-byte range succeeded | Free EDL required; not anonymous.[2] |
| ASF OPERA RTC-S1 files | final HTTP 401 | HTTP 206 range succeeded | Free EDL required. |
| ASF NISAR GCOV/GUNW/GOFF | final HTTP 401 | HTTP 206 range succeeded | Free EDL required.[6] |
| PO.DAAC DSWx-S1 science TIFF | final HTTP 401 | HTTP 206 range succeeded | Free EDL required; browse PNG is anonymous. |
| HyP3 OpenAPI | HTTP 200 | — | Schema is public.[15] |
| HyP3 `/user` and `/jobs` | HTTP 401 | `/user` HTTP 200 | EDL bearer token required.[4] |
| HyP3 Basic account | — | `APPROVED`, **8,000 credits remaining** | No job was submitted; no credits were consumed. |
| Copernicus GLO-30 AWS COG | HTTP 206 | not needed | Anonymous range access works.[14] |
| NISAR DEM / NASADEM / SRTMGL1 | HTTP 302 to EDL | HTTP 206 range succeeded | EDL required. |

HyP3's live OpenAPI schema accepts `S1[ABCD]` names for `RTC_GAMMA`, so the catalogued S1D scenes pass the published request-name pattern.[15] HyP3 Basic currently charges 5 credits for a 30 m RTC, 15 for 20 m, and 60 for 10 m; a two-scene pair would therefore cost 10, 30, or 120 credits.[5] I did **not** submit a chargeable job. OPERA RTC already provides the needed 30 m products at no processing-credit cost.

Authenticated NISAR and PO.DAAC S3 credential brokers both returned temporary credentials (secret values were discarded). Direct S3 access is documented for AWS `us-west-2`; ordinary authenticated HTTPS downloads worked from this host.[6]

## 1. ASF Sentinel-1 SLC and GRD

The live point query returned **23 SLC and 23 GRD_HD scenes**, all Sentinel-1D, on relative orbits 19 descending, 85 ascending, and 121 descending.[16][17]

### Exact event-bracketing SLC pairs

| Track/direction | Pre acquisition and file | Post acquisition and file | Size (pre/post) |
|---|---|---|---:|
| 19 descending | `2026-08-24T00:18:43Z` — `S1D_IW_SLC__1SDV_20260824T001843_20260824T001910_004260_007D5D_98CC.zip` | `2026-09-05T00:18:43Z` — `S1D_IW_SLC__1SDV_20260905T001843_20260905T001910_004435_00837B_F6E1.zip` | 4,699,307,182 / 4,709,629,831 B |
| 85 ascending | `2026-08-16T12:21:39Z` — `S1D_IW_SLC__1SDV_20260816T122139_20260816T122207_004151_007980_0444.zip` | `2026-08-28T12:21:40Z` — `S1D_IW_SLC__1SDV_20260828T122140_20260828T122208_004326_007FA4_93F8.zip` | 4,814,033,095 / 4,801,400,291 B |
| 121 descending | `2026-08-19T00:10:36Z` — `S1D_IW_SLC__1SDV_20260819T001036_20260819T001102_004187_007ABD_A244.zip` | `2026-08-31T00:10:36Z` — `S1D_IW_SLC__1SDV_20260831T001036_20260831T001103_004362_0080EC_F814.zip` | 4,659,417,369 / 4,666,668,107 B |

All three pairs repeat after 12 days and retain the same relative orbit/frame.[16] Track 19 has the closest pre-event acquisition (2.106 days before); track 85 has the closest post-event acquisition (2.396 days after).[16] These are valid same-track choices, but SLC processing still requires orbit data, a correctly referenced DEM, burst/coregistration handling, and coherence checks.

### Exact event-bracketing GRD pairs

The matching GRD_HD files are about 1.02–1.04 GB each:

- Track 19: `S1D_IW_GRDH_1SDV_20260824T001844_20260824T001909_004260_007D5D_EDEC.zip` (1,038,354,969 B) and `S1D_IW_GRDH_1SDV_20260905T001844_20260905T001909_004435_00837B_2F0C.zip` (1,041,113,496 B).[17]
- Track 85: `S1D_IW_GRDH_1SDV_20260816T122141_20260816T122206_004151_007980_C3AB.zip` (1,026,672,678 B) and `S1D_IW_GRDH_1SDV_20260828T122141_20260828T122206_004326_007FA4_01B4.zip` (1,024,818,233 B).[17]
- Track 121: `S1D_IW_GRDH_1SDV_20260819T001036_20260819T001101_004187_007ABD_DC16.zip` (1,028,014,690 B) and `S1D_IW_GRDH_1SDV_20260831T001037_20260831T001102_004362_0080EC_2C5B.zip` (1,030,509,559 B).[17]

GRD can support amplitude change after terrain correction, but not interferometric phase.[3] Since validated OPERA RTC products already exist, downloading scene-wide GRD and rerunning RTC adds work without a clear benefit.[11][18]

## 2. OPERA RTC-S1 — tested working path

OPERA RTC-S1 is a 30 m, gamma-0, terrain-corrected Sentinel-1 product supplied as per-polarization COGs plus mask and HDF5 metadata.[11] The point query returned 23 products and exact same-burst pairs on all three Sentinel tracks.[18]

| Track / burst | Pair dates | VV bytes pre/post | VH bytes pre/post | Mask bytes pre/post |
|---|---|---:|---:|---:|
| 19 / `T019_039570_IW1` | 24 Aug / 5 Sep | 6,859,806 / 6,854,728 | 6,840,516 / 6,832,892 | 204,675 / 204,788 |
| 85 / `T085_180590_IW2` | 16 Aug / 28 Aug | 7,515,218 / 7,507,484 | 7,497,073 / 7,489,080 | 227,070 / 227,657 |
| 121 / `T121_258660_IW3` | 19 Aug / 31 Aug | 6,135,933 / 6,132,581 | 6,111,295 / 6,117,082 | 178,914 / 178,688 |

The exact executed pair was:

- `OPERA_L2_RTC-S1_T019-039570-IW1_20260824T001855Z_20261010T215409Z_S1D_30_v1.0`
- `OPERA_L2_RTC-S1_T019-039570-IW1_20260905T001855Z_20261011T061621Z_S1D_30_v1.0`

I streamed VV, VH, and mask windows for `85.50,28.27,85.56,28.32`, wrote a 198×187-pixel EPSG:32645 crop for each layer, required mask class 0 in both dates, and wrote post-minus-pre dB rasters. There were 22,352 common valid pixels. At the supplied event point, the RTC mask was class 0 on both dates; the single-pixel changes were −7.91 dB VV and −2.10 dB VH. These values prove that the data path and alignment work; they are **not** a validated avalanche/flood classification and single-pixel speckle must not be overinterpreted.

One operational caveat: these S1D RTC products were processed on 10–11 October, 47.90 and 36.25 days after their acquisitions.[18] They are available now but were not a rapid-response product immediately after this event.[18]

## 3. NISAR L2 GCOV, GUNW, and GOFF

NISAR GCOV is calibrated, terrain-corrected gamma-0 backscatter; GUNW is a geocoded nearest-neighbor 12-day interferogram with wrapped/unwrapped phase and coherence; GOFF is an 80 m geocoded pixel-offset product.[7][8][9]

The live ASF queries returned 23 GCOV, 24 GUNW, and 24 GOFF records when Urgent Response and duplicate releases are included.[19][20][21]
CMR found **zero VALIDATED and zero BETA** granules in the event search window, but 17 GCOV, 18 GUNW, and 18 GOFF **PROVISIONAL** granules.[19][20][21]
The exact stable `P05023` event products are:

| Product | Track/frame | Acquisition(s) | Exact file ID | HDF5 bytes |
|---|---|---|---|---:|
| GCOV pre | 48 D / 74 | 16 Aug | `NISAR_L2_PR_GCOV_028_048_D_074_4005_DHDH_A_20260816T125812_20260816T125846_P05023_N_F_J_001.h5` | 7,038,042,112 |
| GCOV post | 48 D / 74 | 28 Aug | `NISAR_L2_PR_GCOV_029_048_D_074_2005_QPDH_A_20260828T125812_20260828T125846_P05023_N_F_J_001.h5` | 7,969,177,600 |
| GUNW pair | 48 D / 74 | 16–28 Aug | `NISAR_L2_PR_GUNW_028_048_D_074_029_2000_SH_20260816T125812_20260816T125846_20260828T125812_20260828T125846_P05023_N_F_J_001.h5` | 2,336,227,328 |
| GOFF pair | 48 D / 74 | 16–28 Aug | `NISAR_L2_PR_GOFF_028_048_D_074_029_2000_SH_20260816T125812_20260816T125846_20260828T125812_20260828T125846_P05023_N_F_J_001.h5` | 1,077,936,128 |
| GCOV pre | 98 A / 16 | 19 Aug | `NISAR_L2_PR_GCOV_028_098_A_016_4005_DHDH_A_20260819T233918_20260819T233953_P05023_N_F_J_001.h5` | 7,243,563,008 |
| GCOV post | 98 A / 16 | 31 Aug | `NISAR_L2_PR_GCOV_029_098_A_016_4005_DHDH_A_20260831T233918_20260831T233952_P05023_N_F_J_001.h5` | 7,050,625,024 |
| GUNW pair | 98 A / 16 | 19–31 Aug | `NISAR_L2_PR_GUNW_028_098_A_016_029_4000_SH_20260819T233918_20260819T233953_20260831T233918_20260831T233952_P05023_N_F_J_001.h5` | 2,344,615,936 |
| GOFF pair | 98 A / 16 | 19–31 Aug | `NISAR_L2_PR_GOFF_028_098_A_016_029_4000_SH_20260819T233918_20260819T233953_20260831T233918_20260831T233952_P05023_N_F_J_001.h5` | 1,098,907,648 |

A GCOV compatibility caveat matters: track 48 changes from `4005_DHDH` (40+5 MHz; HH/HV) before the event to `2005_QPDH` (20+5 MHz; quad-pol main band) after it, so it is not a like-for-like backscatter pair.[19]
Track 98 stays `4005_DHDH` on both dates and is the preferred direct GCOV comparison.[19]
The mission-generated track-48 GUNW/GOFF products use the common 20 MHz HH channel, while track 98 uses 40 MHz HH; their quality layers still need inspection.[20][21]

Urgent Response GUNW/GOFF copies also exist for both event-straddling pairs, but the normal PROVISIONAL products above are preferable for a reproducible archive path.[20][21] Authenticated one-byte range reads returned HTTP 206 for GCOV, GUNW, and GOFF.
The practical order is: inspect GUNW coherence/wrapped phase first, then unwrapped phase where coherent; inspect GOFF for large displacement; use GCOV only if L-band amplitude/polarimetry justifies its 7–8 GB files.[7][8][9]
The disturbed source may decorrelate, so missing/low-quality unwrapped phase is an expected diagnostic rather than evidence of no change.[8]

## 4. OPERA DSWx-S1 — available, but not an event pair

DSWx-S1 is a 30 m MGRS-tiled surface-water classification derived from OPERA RTC-S1, distributed as four COG layers plus browse.[13] CMR contains 257 pre-event catalog granules (217 unique acquisition times) since September 2024 and 15 post-event granules in the first 60 days, but it has a catalog gap around this event.[22][24]

- `2026-08-01` through `2026-09-11`: **0 hits**.[23]
- Latest pre-event acquisition: `2026-06-25T00:11:13Z`, track 121, Sentinel-1A.[22]
- First post-event acquisition: `2026-09-12T00:10:37Z`, track 121, Sentinel-1D.[24]
- Same-track gaps: track 121 = 78.9996 days; tracks 12, 19, and 85 = 90.9996 days.[22][24]

Closest track-121 products:

- `OPERA_L3_DSWx-S1_T45RUM_20260625T001106Z_20260829T040758Z_S1A_30_v1.0`[22]
- `OPERA_L3_DSWx-S1_T45RUM_20260912T001029Z_20261012T060831Z_S1D_30_v1.0`[24]

The first post-event WTR COG is 660,909 B; all non-checksum files in that granule total 6,512,469 B.[24] It downloaded successfully with EDL. This can describe later surface water, but the long gap, seasonal change, spacecraft switch, HAND screening, and steep-terrain layover/shadow make it unsuitable as the primary 26 August source-change pair.[13][22][24]

## 5. DEMs

| DEM | Exact AOI tile | Catalog/download bytes | Access result |
|---|---|---:|---|
| Public Copernicus GLO-30 | `Copernicus_DSM_COG_10_N28_00_E085_00_DEM.tif` | 38,402,839 | Anonymous HTTP 206 |
| NISAR DEM v1.2 | `DEM_N28_00_E085_00_C01.tif` (`G3964019040-ASF`) | 38,493,209 | EDL HTTP 206[25] |
| NASADEM_HGT v001 | `NASADEM_HGT_n28e085.zip` (`G2816822050-LPCLOUD`) | 18,580,617 measured by Content-Range | EDL HTTP 206[26] |
| SRTMGL1 v003 | `N28E085.SRTMGL1.hgt.zip` (`G2821107190-LPCLOUD`) | 17,466,759 measured by Content-Range | EDL HTTP 206[27] |

Real AOI subsets were written for the first two DEMs:

- Public Copernicus: 612×504 float32 cells, 732,659 B, elevation range 2,514.38–7,216.16 m.
- NISAR DEM: 612×504 float32 cells, 732,959 B, elevation range 2,482.53–7,183.61 m.
- After bilinear alignment, `NISAR_DEM − public_Copernicus` has mean −31.312 m and median −31.279 m over 308,448 cells.[10][14] This is consistent with the documented vertical re-referencing; the two should not be substituted silently.[10]

The documented `s3://opera-dem/v1.1/EPSG4326/` bucket returned HTTP 403 to anonymous listing. That route is therefore not a reproducible public discovery path from this host. `NISAR_DEM` through CMR is the working equivalent and exposes exact tile metadata and authenticated HTTPS access.[10][12][25]

## Reproducible files and commands

All files are under this folder; no credentials or temporary AWS secrets were saved.

```bash
cd /home/safal0715/Documents/research/_subagents/data_feasibility
PY=/home/safal0715/Documents/research/.venv/bin/python
"$PY" scripts/probe_catalogs.py
"$PY" scripts/probe_access.py
"$PY" scripts/probe_authenticated_access.py   # read-only; uses existing EDL netrc
"$PY" scripts/probe_dems.py
"$PY" scripts/probe_dswx_history.py
"$PY" scripts/fetch_dem_subset.py
"$PY" scripts/fetch_nisar_dem_subset.py
"$PY" scripts/fetch_opera_rtc_pair.py
"$PY" scripts/summarize_results.py
```

The venv-relative command in this workspace is actually `/home/safal0715/Documents/research/.venv/bin/python`; the absolute path is safest.

Key outputs:

- `catalog_summary.json` — machine-checked aggregate.
- `pairs.csv` — all Sentinel-1 SLC/GRD and point-covering OPERA RTC pairs.
- `raw/` — exact ASF/CMR/API responses and safe HTTP status records.
- `rtc_pair/` — six real OPERA source crops, two dB-change rasters, and `pair_summary.json`.
- `dem/` — two real DEM subsets and metadata.
- `scripts/` — retrieval, access-test, subset, and summarization scripts.

## Diagnosed dead ends and limits

- **Anonymous NASA science-file download:** blocked by EDL (401); public catalog access does not imply anonymous file access.[2][6]
- **HyP3 product generation:** credentials and quota are available, and the schema accepts S1D, but no job was submitted because it would consume credits and duplicate archived OPERA RTC.[4][5][15]
- **Close DSWx event pair:** does not exist in CMR for this AOI; the nearest same-track pair is 79 days apart.[22][24]
- **Validated NISAR event products:** no hits; only PROVISIONAL and Urgent Response products are present in the tested window.[19][20][21]
- **Anonymous OPERA/NISAR processing-DEM bucket listing:** 403; use the discoverable `NISAR_DEM` collection instead.[10][12][25]
- **Scientific attribution:** the generated RTC difference is a calibrated observational change layer, not a debris-flow boundary, volume estimate, displacement vector, or causal proof. It still needs spatial aggregation, cross-track/optical corroboration, and expert interpretation.

## Sources

[1] https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR_hnmns6o.pdf — Government of Nepal CHWRR Assessment Report II: Rasuwa-Bhote Koshi Flood Event, 2026
[2] https://docs.asf.alaska.edu/api/basics — ASF Search API Basics
[3] https://docs.asf.alaska.edu/api/keywords — ASF Search API Keywords and Endpoints
[4] https://hyp3-docs.asf.alaska.edu/using/authentication — HyP3 Authentication
[5] https://hyp3-docs.asf.alaska.edu/using/credits — HyP3 Credits
[6] https://nisar-docs.asf.alaska.edu/access-overview — Accessing NISAR Data
[7] https://nisar-docs.asf.alaska.edu/gcov — NISAR GCOV User Guide
[8] https://nisar-docs.asf.alaska.edu/gunw — NISAR GUNW User Guide
[9] https://nisar-docs.asf.alaska.edu/goff — NISAR GOFF User Guide
[10] https://nisar-docs.asf.alaska.edu/nisar-dem — Modified Copernicus DEM for NISAR
[11] https://jpl.nasa.gov/go/opera/products/rtc-product — OPERA RTC-S1 Product
[12] https://earthdata.nasa.gov/data/projects/opera — NASA Earthdata OPERA Project and Products
[13] https://archive.podaac.earthdata.nasa.gov/podaac-ops-cumulus-docs/web-misc/opera/D-108761_OPERA_DSWx_S1AB_ProductSpec_Rev_A.pdf — OPERA DSWx-S1 Product Specification
[14] https://copernicus-dem-30m.s3.amazonaws.com/readme.html — Copernicus DEM Open S3 COG Readme
[15] https://hyp3-api.asf.alaska.edu/openapi.json — Live HyP3 OpenAPI Schema
[16] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.528066+28.291242%29&start=2026-07-15T00%3A00%3A00Z&end=2026-10-15T23%3A59%3A59Z&maxResults=500&output=geojson — Live ASF Sentinel-1 SLC query
[17] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=GRD_HD&intersectsWith=POINT%2885.528066+28.291242%29&start=2026-07-15T00%3A00%3A00Z&end=2026-10-15T23%3A59%3A59Z&maxResults=500&output=geojson — Live ASF Sentinel-1 GRD query
[18] https://api.daac.asf.alaska.edu/services/search/param?dataset=OPERA-S1&processingLevel=RTC&intersectsWith=POINT%2885.528066+28.291242%29&start=2026-07-15T00%3A00%3A00Z&end=2026-10-15T23%3A59%3A59Z&maxResults=500&output=geojson — Live ASF OPERA RTC-S1 query
[19] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=GCOV&intersectsWith=POINT%2885.528066+28.291242%29&start=2026-07-15T00%3A00%3A00Z&end=2026-10-15T23%3A59%3A59Z&maxResults=500&output=geojson — Live ASF NISAR GCOV query
[20] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=GUNW&intersectsWith=POINT%2885.528066+28.291242%29&start=2026-07-15T00%3A00%3A00Z&end=2026-10-15T23%3A59%3A59Z&maxResults=500&output=geojson — Live ASF NISAR GUNW query
[21] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=GOFF&intersectsWith=POINT%2885.528066+28.291242%29&start=2026-07-15T00%3A00%3A00Z&end=2026-10-15T23%3A59%3A59Z&maxResults=500&output=geojson — Live ASF NISAR GOFF query
[22] https://cmr.earthdata.nasa.gov/search/granules.umm_json?short_name=OPERA_L3_DSWX-S1_V1&bounding_box=85.45%2C28.24%2C85.62%2C28.38&temporal=2024-09-01T00%3A00%3A00Z%2C2026-08-26T02%3A52%3A00Z&page_size=500 — Live CMR DSWx-S1 pre-event history query
[23] https://cmr.earthdata.nasa.gov/search/granules.umm_json?short_name=OPERA_L3_DSWX-S1_V1&bounding_box=85.45%2C28.24%2C85.62%2C28.38&temporal=2026-08-01T00%3A00%3A00Z%2C2026-09-11T23%3A59%3A59Z&page_size=500 — Live CMR DSWx-S1 event-gap query
[24] https://cmr.earthdata.nasa.gov/search/granules.umm_json?short_name=OPERA_L3_DSWX-S1_V1&bounding_box=85.45%2C28.24%2C85.62%2C28.38&temporal=2026-08-26T02%3A52%3A00Z%2C2026-10-25T23%3A59%3A59Z&page_size=500 — Live CMR DSWx-S1 post-event query
[25] https://cmr.earthdata.nasa.gov/search/granules.umm_json?short_name=NISAR_DEM&bounding_box=85.45%2C28.24%2C85.62%2C28.38&page_size=100 — Live CMR NISAR DEM AOI query
[26] https://cmr.earthdata.nasa.gov/search/granules.umm_json?short_name=NASADEM_HGT&bounding_box=85.45%2C28.24%2C85.62%2C28.38&page_size=100 — Live CMR NASADEM AOI query
[27] https://cmr.earthdata.nasa.gov/search/granules.umm_json?short_name=SRTMGL1&bounding_box=85.45%2C28.24%2C85.62%2C28.38&page_size=100 — Live CMR SRTMGL1 AOI query
[28] https://earthquake.usgs.gov/earthquakes/eventpage/us7000tbwb — USGS M5.2 Landslide Event us7000tbwb
[29] https://www.usgs.gov/programs/landslide-hazards/science/2026-nepal-debris-avalanche-and-flash-flood — USGS 2026 Nepal Debris Avalanche and Flash Flood
