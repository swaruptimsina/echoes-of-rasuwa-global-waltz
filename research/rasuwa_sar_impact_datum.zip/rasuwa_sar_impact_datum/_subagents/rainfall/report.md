# NASA precipitation/context data for the 2026 Rasuwa–Bhote Koshi event

## Finding in brief

- **Verified event:** the relevant event occurred on **26 August 2026**, with the ice–rock avalanche/seismic signal at about **08:37 Nepal Standard Time (02:52 UTC)**. Two Government of Nepal reports independently identify the date, location, rapid flood, and non-rainfall primary mechanism.[1][2]
- **Test point:** `28.291242°N, 85.528066°E`, the hanging-glacier collapse location reported by CHWRR at approximately 5,200 m elevation.[1] The nearest 0.1° IMERG cell returned through POWER is centred at `28.25°N, 85.55°E`.[19]
- **Actual fetched context:** NASA POWER returned a real UTC daily IMERG series and meteorology/wetness series for 20 August–2 September 2026. On 26 August, fetched values were **IMERG_PRECTOT 4.50 mm/day**, **POWER PRECTOTCORR 1.17 mm/day**, and wetness fractions **GWETTOP 0.84, GWETROOT 0.77, GWETPROF 0.75**.[14][15][16]
- **Direct IMERG:** CMR discovery worked and returned the exact Early and Late V07C granules.[20][21] Raw HDF5/OPeNDAP/PPS value downloads required Earthdata or PPS authentication; no saved credentials were available.[24] I therefore do **not** report a native half-hourly IMERG rain-rate value. The daily `IMERG_PRECTOT` values below are the values actually returned by POWER's public API.
- **Soil moisture answer:** POWER is **not only meteorology**. The current catalog/API has fractional soil-wetness fields (`GWETTOP`, `GWETROOT`, `GWETPROF`) and volumetric moisture aliases (`SFMC`, `RZMC`, `PRMC`), with a high-resolution SMAP pathway. At this glacier point, wetness fractions were populated, but all three volumetric fields returned the documented `-999` fill value with an empty `sources` list.[7][16][17]
- **Rainfall interpretation:** all fetched and official context supports light—not extreme—rain near the failure time, but none of these coarse grids can identify a slope-scale trigger. CHWRR reports 1.5 mm at Kyangjing in the six hours before the avalanche, 27.0 mm in the prior 24 hours, and no concentrated FFGS/GHE rainfall over the source area.[1][14][18]

## 1. Event and sampling geometry

CHWRR's report places the source at `28.291242°N, 85.528066°E`; its event table gives an approximate source at `28°17'14.8"N, 85°31'29.6"E`. The report describes a hanging glacier/rock mass failure and gives the signal time as 08:37 NST.[1] NDRRMA independently states that the flood reached Rasuwagadhi around 08:45 and attributes it to an ice–rock avalanche rather than monsoon rainfall.[2]

The POWER response's geometry was `[85.528, 28.291, 4836.18]`.[14][15] Thus its supplied grid elevation was about **364 m below** the report's approximate 5,200 m source elevation—an immediate warning that a gridded point is not the physical slope.[1]

## 2. GPM IMERG products and variables

### Product characteristics

Native IMERG V07 merges microwave and infrared estimates into **0.1° × 0.1°**, **half-hourly** fields. Early is produced at roughly 4-hour latency, Late at roughly 14-hour latency, and Final after monthly gauge analysis at roughly 3.5–4 months.[3][4][30]

The Final V07 catalog identifies `GPM_3IMERGHH.07` as the post-real-time satellite-gauge collection.[31]

The principal V07 variable is `Grid/precipitation` in `mm/hr`; NASA recommends it for general use. Other useful fields are `Grid/randomError`, `Grid/precipitationQualityIndex`, `Grid/probabilityLiquidPrecipitation`, `Grid/Intermediate/MWprecipitation`, `MWprecipSource`, `MWobservationTime`, `IRprecipitation`, `IRinfluence`, and `precipitationUncal`.[3][4]

A half-hourly value represents the named UTC half hour and is best treated as the average rate over that half hour, not as a sub-half-hour instantaneous chronology.[4]

### Products/granules found for the event

| Run | Product short name | Collection concept ID | Event-half-hour granule (02:30–02:59:59 UTC) | Granule concept ID |
|---|---|---|---|---|
| Early | `GPM_3IMERGHHE.07` | `C2723758340-GES_DISC` | `3B-HHR-E.MS.MRG.3IMERG.20260826-S023000-E025959.0150.V07C.HDF5` | `G4288257564-GES_DISC` |
| Late | `GPM_3IMERGHHL.07` | `C2723754845-GES_DISC` | `3B-HHR-L.MS.MRG.3IMERG.20260826-S023000-E025959.0150.V07C.HDF5` | `G4288718397-GES_DISC` |
| Final V07 | `GPM_3IMERGHH.07` | `C2723754847-GES_DISC` | none returned | none |

The CMR window query returned **145 Early** and **145 Late** entries (the query is inclusive of the first 00:00 granule on 28 August), and **0 Final V07** entries.[20][21][22]

At the investigation date, the event was only 81 days old, still inside the normal Final latency.[4]

The matching event-day Late daily product is:[23]

- Product: `GPM_3IMERGDL.07`
- Collection: `C2723754859-GES_DISC`
- Granule: `3B-DAY-L.MS.MRG.3IMERG.20260826-S000000-E235959.V07C.nc4`
- Granule concept ID: `G4289602693-GES_DISC`.[23]

### Direct-download test result

- CMR search/download metadata: **HTTP 200**.[20][21]
- GES DISC cloud HDF5 without credentials: **HTTP 302** to Earthdata OAuth.[24]
- Cloud OPeNDAP without credentials: **HTTP 401**.[25]
- Legacy/on-prem OPeNDAP `.dds` and `.das` metadata: **HTTP 200**; the constrained `.ascii` data request: **HTTP 401**.[33][34]
- PPS Early/Late GIS GeoTIFF without PPS registration: **HTTP 401**.[26]
- EGIS ArcGIS ImageServer endpoint tested on 15 November 2026: **HTTP 404**.[32]

No credential was placed in a URL or file.[24][25][26]

Because the native data request did not return data, no half-hourly native IMERG numeric value is claimed.[25][34]

## 3. NASA POWER: resolution, variables, and live results

### What POWER serves

POWER's main meteorological stream is sourced from MERRA-2 and the near-real-time GEOS-IT continuation on a native **0.5° latitude × 0.625° longitude** grid. Hourly API fields are hourly means/rates, while daily values are aggregates; POWER supports UTC and local-solar-time output, and I explicitly requested UTC.[6][8][9]

POWER also exposes higher-resolution hydrology sources: **IMERG at 0.1° daily UTC** and **SMAP L4 soil moisture at about 9 km daily UTC**. The documented IMERG series splices Final Run to Late Run near real time and later replaces the Late tail with Final, so near-real-time values can change.[6][7]

The live Manager endpoint defines `IMERG_PRECTOT` as daily total precipitation available to POWER communities.[29]

Relevant variables tested:

| Variable | Meaning / unit | Effective source/resolution |
|---|---|---|
| `IMERG_PRECTOT` | Total precipitation, mm/day, daily UTC | IMERG, 0.1° |
| `PRECTOTCORR` | Corrected precipitation, mm/day or mm/hour | POWER meteorological stream, 0.5° × 0.625° |
| `T2M`, `RH2M` | 2-m temperature (°C), relative humidity (%) | POWER meteorological stream, 0.5° × 0.625° |
| `GWETTOP` | Wetness fraction, top 5 cm, 0–1 | MERRA-2 header in tested response |
| `GWETROOT` | Wetness fraction, roughly upper 1 m, 0–1 | MERRA-2 header in tested response |
| `GWETPROF` | Wetness fraction, surface to model bedrock, 0–1 | MERRA-2 header in tested response |
| `SFMC`, `RZMC`, `PRMC` | Volumetric surface/root-zone/profile moisture, m³/m³ | SMAP-capable catalog; fill at this point |

The manager API confirms that `GWETTOP` spans 0 (dry) to 1 (saturated), and POWER's current hydrology documentation explicitly lists both wetness fractions and volumetric moisture fields.[7][28]

### Fetched daily point series

All values below came from HTTP 200 JSON responses, at the stated point, with `time-standard=UTC`.[14][15][16]

| UTC date | POWER IMERG (mm/day) | POWER corrected precip. (mm/day) | GWETTOP | GWETROOT | GWETPROF |
|---|---:|---:|---:|---:|---:|
| 2026-08-23 | 1.47 | 1.42 | 0.85 | 0.78 | 0.76 |
| 2026-08-24 | 2.87 | 2.77 | 0.84 | 0.78 | 0.76 |
| 2026-08-25 | 3.97 | 0.35 | 0.84 | 0.77 | 0.75 |
| **2026-08-26** | **4.50** | **1.17** | **0.84** | **0.77** | **0.75** |
| 2026-08-27 | 3.33 | 2.23 | 0.84 | 0.77 | 0.75 |
| 2026-08-28 | 2.54 | 12.07 | 0.85 | 0.77 | 0.75 |
| 2026-08-29 | 9.49 | 4.23 | 0.85 | 0.78 | 0.75 |

The hourly POWER meteorology response returned corrected precipitation values of `0.03, 0.03, 0.04, 0.16, 0.12, 0.08 mm/hour` for the six start-hour bins from 21:00 UTC on 25 August through 02:00 UTC on 26 August, summing to **0.46 mm**. This is not an exact six-hour window ending at 02:52 UTC and is model context, not a rain gauge.[18]

The `SFMC`, `RZMC`, and `PRMC` request returned HTTP 200 but only `-999` fill values for every day and `sources: []`; these must be treated as missing, not zero.[17] POWER cautions that soil-moisture skill is reduced over frozen/snow-covered soils and that frozen-ground SMAP brightness temperatures are excluded from assimilation.[7]

### Regional test

A requested local box of `85.3–85.7°E, 28.1–28.5°N` failed with HTTP 422 because the POWER regional endpoint requires at least 2° in each dimension.[27] A valid `84.5–86.5°E, 27.3–29.3°N` query succeeded and returned 400 IMERG grid features for 25–27 August; the nearest feature was `85.55°E, 28.25°N` and matched the point series.[19]

## 4. Exact tested request URLs

### POWER point and regional APIs

```text
https://power.larc.nasa.gov/api/temporal/daily/point?parameters=IMERG_PRECTOT&community=AG&longitude=85.528066&latitude=28.291242&start=20260820&end=20260902&format=JSON&time-standard=UTC

https://power.larc.nasa.gov/api/temporal/daily/point?parameters=PRECTOTCORR,T2M,RH2M&community=AG&longitude=85.528066&latitude=28.291242&start=20260820&end=20260902&format=JSON&time-standard=UTC

https://power.larc.nasa.gov/api/temporal/daily/point?parameters=GWETTOP,GWETROOT,GWETPROF&community=AG&longitude=85.528066&latitude=28.291242&start=20260820&end=20260902&format=JSON&time-standard=UTC

https://power.larc.nasa.gov/api/temporal/daily/point?parameters=SFMC,RZMC,PRMC&community=AG&longitude=85.528066&latitude=28.291242&start=20260820&end=20260902&format=JSON&time-standard=UTC

https://power.larc.nasa.gov/api/temporal/hourly/point?parameters=PRECTOT,T2M,RH2M&community=AG&longitude=85.528066&latitude=28.291242&start=20260825&end=20260827&format=JSON&time-standard=UTC

https://power.larc.nasa.gov/api/temporal/daily/regional?latitude-min=27.3&latitude-max=29.3&longitude-min=84.5&longitude-max=86.5&parameters=IMERG_PRECTOT&community=AG&start=20260825&end=20260827&format=JSON&time-standard=UTC
```

### Earthdata CMR discovery

```text
https://cmr.earthdata.nasa.gov/search/granules.json?collection_concept_id=C2723758340-GES_DISC&temporal=2026-08-25T00:00:00Z,2026-08-28T00:00:00Z&page_size=200&sort_key=start_date

https://cmr.earthdata.nasa.gov/search/granules.json?collection_concept_id=C2723754845-GES_DISC&temporal=2026-08-25T00:00:00Z,2026-08-28T00:00:00Z&page_size=200&sort_key=start_date

https://cmr.earthdata.nasa.gov/search/granules.json?collection_concept_id=C2723754847-GES_DISC&temporal=2026-08-25T00:00:00Z,2026-08-28T00:00:00Z&page_size=200&sort_key=start_date
```

### Native event-half-hour data probes

```text
https://data.gesdisc.earthdata.nasa.gov/data/GPM_L3/GPM_3IMERGHHE.07/2026/238/3B-HHR-E.MS.MRG.3IMERG.20260826-S023000-E025959.0150.V07C.HDF5

https://opendap.earthdata.nasa.gov/collections/C2723758340-GES_DISC/granules/GPM_3IMERGHHE.07%3A3B-HHR-E.MS.MRG.3IMERG.20260826-S023000-E025959.0150.V07C.HDF5

https://jsimpsonhttps.pps.eosdis.nasa.gov/imerg/gis/early/2026/08/3B-HHR-E.MS.MRG.3IMERG.20260826-S233000-E235959.1410.V07C.1day.tif
```

The full encoded point-subset OPeNDAP URL and its HTTP 401 result are preserved in `data/imerg/event_late_point_data_probe.json`; it is too long to improve readability here.[34]

## 5. Steep-terrain limitations

1. **Orographic undercatch/uncertainty:** NASA states that IMERG uncertainty is greater near orography and may underestimate rates; GPROF V07 includes mountain classes, but morphing and infrared estimates do not directly account for orographic enhancement.[4]
2. **Snow/frozen surfaces:** frozen terrain can be confused with precipitation, snowfall calibration can be biased low, and quality indices should be consulted.[4]
3. **Scale mismatch:** a 0.1° IMERG cell averages roughly a 10 km footprint; POWER's meteorological/wetness fields are much coarser.[3][6] Neither resolves a hanging glacier, a narrow valley, slope aspect, rain/snow line, or short-lived warm-rain enhancement.[5]
4. **Sensor physics:** microwave retrievals over land depend strongly on frozen hydrometeors, while infrared sees cloud tops; near-surface warm orographic rain can be weakly related to either signal.[5]
5. **Model wetness is not observed slope saturation:** the high fractional `GWET*` values describe a coarse land-model grid.[7][16] They should not be interpreted as pore pressure, permafrost condition, fracture water, or evidence that rain triggered the failure.[7]
6. **POWER near-real-time revisions:** the documented meteorology stream transitions from GEOS-IT to MERRA-2, and IMERG transitions from Late to Final. Re-fetch before publication and record retrieval date/version.[6]

## 6. Independent rainfall context

- **Nepal CHWRR/DHM station and FFGS:** the strongest event-specific cross-check. CHWRR reports FFGS NOAA/NESDIS Global Hydro-Estimator six-hour rainfall generally below or around 10 mm over the affected area; Kyangjing recorded 1.5 mm in the six hours before the event, 12.6 mm on 26 August, and 27.0 mm in the preceding 24 hours.[1]
- **Nepal DHM daily weather summary:** the separately downloaded 26 August bulletin reports the national 24-hour maximum as 114.5 mm at Dhunge, Sindhupalchok, for the period ending 08:45 NST. That is national context, not a source-area gauge and should not be transplanted to Rasuwa.[13]
- **ERA5-Land:** independent reanalysis with hourly 0.1° fields, including total precipitation, snowfall, snow depth, temperature, and layered soil water. It is useful for consistent anomaly/thermal context, but remains a 9 km land model.[10]
- **JAXA GSMaP:** hourly 0.1° rainfall is an algorithmic alternative. It shares much of the GPM constellation, so it is not sensor-independent from IMERG.[12]
- **CHIRPS v3:** 0.05° station/IR-blended land precipitation is useful at pentadal/monthly scales. Its daily `sat` series uses IMERG Late and its daily `rnl` series uses ERA5 to disaggregate pentads, so neither daily timing series is fully independent of those inputs.[11]

## 7. Files produced

Key outputs under `/home/safal0715/Documents/research/_subagents/rainfall/`:

- `report.md` — this report.
- `data/power_event_point_daily_20260820_20260902.csv` — fetched daily IMERG, meteorology, and wetness series.
- `data/power_event_point_hourly_20260825_20260827.csv` — fetched hourly POWER meteorology.
- `data/imerg_event_time_granules.csv` — event-time Early/Late CMR IDs.
- `data/event_summary_from_fetched_data.json` — machine-readable event summary.
- `data/power/regional_imerg_aoi_2deg.json` — successful 400-cell regional response.
- `data/power/fetch_log.json` — exact POWER request/status log.
- `data/imerg/fetch_log.json` — CMR and download-probe log.
- `data/imerg/event_late_granule.dds`, `event_late_granule.das` — successfully fetched native metadata.
- `data/imerg/event_late_point_data_probe.json` — encoded data request and HTTP 401 result.
- `evidence/CHWRR_Rasuwa_Bhote_Koshi_2026_report.pdf`, `evidence/NDRRMA_SitRep19_2026-09-20.pdf`, `evidence/DHM_daily_weather_2026-08-26.pdf`, `evidence/IMERG_V07_FAQ_2025-02-24.pdf` — downloaded official evidence.
- `fetch_power.py`, `fetch_imerg.py`, `build_outputs.py` — reproducible fetch/processing scripts.

## Sources

[1] https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR_hnmns6o.pdf — CHWRR Assessment Report II: Rasuwa–Bhote Koshi Flood Event 2026
[2] https://ndrrma.gov.np/mediafiles/publications/SitRep_ENG_19_20092026.pdf — NDRRMA Rasuwa-Bhotekoshi Flood Situation Report 19
[3] https://www.earthdata.nasa.gov/data/catalog/ges-disc-gpm-3imerghhe-07 — NASA Earthdata GPM IMERG Early V07 catalog
[4] https://gpm.nasa.gov/sites/default/files/2025-02/FAQ%20for%20IMERG%20V07%20Applications%20Users_202502.pdf — NASA GPM IMERG V07 Applications FAQ
[5] https://gpm.nasa.gov/resources/faq/what-effect-do-mountainous-orographic-regions-have-measuring-precipitation — NASA GPM mountainous precipitation measurement FAQ
[6] https://power.larc.nasa.gov/docs/methodology/data/sources — NASA POWER data sources
[7] https://power.larc.nasa.gov/docs/methodology/data/sources_hydrology — NASA POWER hydrology sources and parameters
[8] https://power.larc.nasa.gov/docs/services/api/temporal/daily — NASA POWER Daily API documentation
[9] https://power.larc.nasa.gov/docs/services/api/temporal/hourly — NASA POWER Hourly API documentation
[10] https://cds.climate.copernicus.eu/datasets/reanalysis-era5-land-timeseries?tab=overview — Copernicus ERA5-Land hourly time-series
[11] https://www.chc.ucsb.edu/data/chirps3 — UCSB CHIRPS v3
[12] https://sharaku.eorc.jaxa.jp/GSMaP/guide.html — JAXA GSMaP User Guide
[13] https://dhm.gov.np/climate-services/daily%20weather%20summary/2026 — Nepal DHM 2026 Daily Weather Summaries
[14] https://power.larc.nasa.gov/api/temporal/daily/point?parameters=IMERG_PRECTOT&community=AG&longitude=85.528066&latitude=28.291242&start=20260820&end=20260902&format=JSON&time-standard=UTC — POWER daily IMERG point response at source
[15] https://power.larc.nasa.gov/api/temporal/daily/point?parameters=PRECTOTCORR,T2M,RH2M&community=AG&longitude=85.528066&latitude=28.291242&start=20260820&end=20260902&format=JSON&time-standard=UTC — POWER daily meteorology point response at source
[16] https://power.larc.nasa.gov/api/temporal/daily/point?parameters=GWETTOP,GWETROOT,GWETPROF&community=AG&longitude=85.528066&latitude=28.291242&start=20260820&end=20260902&format=JSON&time-standard=UTC — POWER daily soil wetness point response at source
[17] https://power.larc.nasa.gov/api/temporal/daily/point?parameters=SFMC,RZMC,PRMC&community=AG&longitude=85.528066&latitude=28.291242&start=20260820&end=20260902&format=JSON&time-standard=UTC — POWER daily volumetric soil moisture point response at source
[18] https://power.larc.nasa.gov/api/temporal/hourly/point?parameters=PRECTOT,T2M,RH2M&community=AG&longitude=85.528066&latitude=28.291242&start=20260825&end=20260827&format=JSON&time-standard=UTC — POWER hourly meteorology point response at source
[19] https://power.larc.nasa.gov/api/temporal/daily/regional?latitude-min=27.3&latitude-max=29.3&longitude-min=84.5&longitude-max=86.5&parameters=IMERG_PRECTOT&community=AG&start=20260825&end=20260827&format=JSON&time-standard=UTC — POWER daily IMERG valid 2 degree regional response
[20] https://cmr.earthdata.nasa.gov/search/granules.json?collection_concept_id=C2723758340-GES_DISC&temporal=2026-08-25T00:00:00Z,2026-08-28T00:00:00Z&page_size=200&sort_key=start_date — CMR Early IMERG event-window granule query
[21] https://cmr.earthdata.nasa.gov/search/granules.json?collection_concept_id=C2723754845-GES_DISC&temporal=2026-08-25T00:00:00Z,2026-08-28T00:00:00Z&page_size=200&sort_key=start_date — CMR Late IMERG event-window granule query
[22] https://cmr.earthdata.nasa.gov/search/granules.json?collection_concept_id=C2723754847-GES_DISC&temporal=2026-08-25T00:00:00Z,2026-08-28T00:00:00Z&page_size=200&sort_key=start_date — CMR Final IMERG event-window granule query
[23] https://cmr.earthdata.nasa.gov/search/granules.json?collection_concept_id=C2723754859-GES_DISC&temporal=2026-08-26T00:00:00Z,2026-08-27T00:00:00Z&page_size=20 — CMR Late daily IMERG event-day granule query
[24] https://data.gesdisc.earthdata.nasa.gov/data/GPM_L3/GPM_3IMERGHHE.07/2026/238/3B-HHR-E.MS.MRG.3IMERG.20260826-S023000-E025959.0150.V07C.HDF5 — Event-half-hour IMERG Early HDF5 download
[25] https://opendap.earthdata.nasa.gov/collections/C2723758340-GES_DISC/granules/GPM_3IMERGHHE.07%3A3B-HHR-E.MS.MRG.3IMERG.20260826-S023000-E025959.0150.V07C.HDF5 — Event-half-hour IMERG Early OPeNDAP
[26] https://jsimpsonhttps.pps.eosdis.nasa.gov/imerg/gis/early/2026/08/3B-HHR-E.MS.MRG.3IMERG.20260826-S233000-E235959.1410.V07C.1day.tif — IMERG Early event-day PPS GeoTIFF
[27] https://power.larc.nasa.gov/api/temporal/daily/regional?latitude-min=28.1&latitude-max=28.5&longitude-min=85.3&longitude-max=85.7&parameters=IMERG_PRECTOT&community=AG&start=20260820&end=20260902&format=JSON&time-standard=UTC — POWER rejected sub-2-degree regional request
[28] https://power.larc.nasa.gov/api/system/manager/parameters/GWETTOP — POWER GWETTOP parameter metadata
[29] https://power.larc.nasa.gov/api/system/manager/parameters/IMERG_PRECTOT — POWER IMERG_PRECTOT parameter metadata
[30] https://www.earthdata.nasa.gov/data/catalog/ges-disc-gpm-3imerghhl-07 — NASA Earthdata GPM IMERG Late V07 catalog
[31] https://www.earthdata.nasa.gov/data/catalog/ges-disc-gpm-3imerghh-07 — NASA Earthdata GPM IMERG Final V07 catalog
[32] https://gis.earthdata.nasa.gov/image/rest/services/GESDISC/GPM_3IMERGHHE/ImageServer?f=pjson — NASA EGIS IMERG Early ImageServer probe
[33] https://gpm1.gesdisc.eosdis.nasa.gov/opendap/GPM_L3/GPM_3IMERGHHL.07/2026/238/3B-HHR-L.MS.MRG.3IMERG.20260826-S023000-E025959.0150.V07C.HDF5.dds — Event-half-hour IMERG Late OPeNDAP metadata
[34] https://gpm1.gesdisc.eosdis.nasa.gov/opendap/GPM_L3/GPM_3IMERGHHL.07/2026/238/3B-HHR-L.MS.MRG.3IMERG.20260826-S023000-E025959.0150.V07C.HDF5.ascii?precipitation%5B0:1:0%5D%5B2655:1:2655%5D%5B1182:1:1182%5D,precipitationQualityIndex%5B0:1:0%5D%5B2655:1:2655%5D%5B1182:1:1182%5D,randomError%5B0:1:0%5D%5B2655:1:2655%5D%5B1182:1:1182%5D,probabilityLiquidPrecipitation%5B0:1:0%5D%5B2655:1:2655%5D%5B1182:1:1182%5D,lon%5B2655:1:2655%5D,lat%5B1182:1:1182%5D,time%5B0:1:0%5D — Event-half-hour IMERG Late point subset probe
