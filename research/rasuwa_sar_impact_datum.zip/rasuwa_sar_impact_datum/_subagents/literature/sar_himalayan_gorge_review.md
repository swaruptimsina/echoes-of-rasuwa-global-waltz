# SAR flood/debris mapping and InSAR/coherence in steep Himalayan gorges

**Focused literature and agency-document review**  
**Geographic priority:** Rasuwa–Lhende/Bhote Koshi–Trishuli, Nepal–China border  
**Review cutoff:** 15 November 2026  
**Scope:** scientific, retrospective, non-operational

## Bottom line

1. **Treat “observable” and “not observed” as different classes.** OPERA RTC-S1 corrects radiometric terrain effects, but it cannot recreate information lost to radar shadow or untangle layover’s many-to-one mapping. DSWx-S1 explicitly carries layover/shadow and no-data classes; those pixels must remain **unknown**, not “not flooded.”[15][16][17]
2. **DSWx-S1 is not a complete gorge-flood or debris map.** Its validated design target is open water at least 3 ha and 200 m wide at 30 m posting. Many narrow channels, short-lived flood tongues, debris-covered water, dry deposits, erosion scars, and bank failures fall outside that claim.[13][14]
3. **Sentinel-1 amplitude/coherence is defensible for large post-event change and low-resolution disturbance density, not automatically for exhaustive individual polygons, water depth, sediment thickness, or causal attribution.** Nepal tests show substantial terrain masking and false-change sources from snow, vegetation, soil moisture, and human activity.[32][33]
4. **Slow Trishuli landslides are measurable in favorable, coherent dry-season pixels, but published Sentinel-1 work did not solve monsoon monitoring.** The Trishuli study found six slow-moving landslides and 2.1–8.8 cm/yr dry-season rates, while low monsoon coherence forced exclusion of June–September.[10][11]
5. **The reported 2026 precursor is not settled.** ICIMOD’s preliminary synthesis reports up to 40 cm Sentinel-1 LOS displacement and about 30 cm from NISAR, but explicitly lists as unresolved whether the signal was failure precursory deformation, glacier motion, atmosphere, geometry, or a combination. A later reproducible EarthArXiv analysis places useful limits on routine 12-day products but is non-peer-reviewed and explicitly does not confirm or exclude the slower multi-epoch rate.[6][30]
6. **NISAR makes the strongest new comparison testable now.** L-band is intended to improve foliage penetration/interferometric coherence.[27]  
   GCOV provides 10–20 m terrain-corrected backscatter, whereas standard GUNW unwrapped phase is posted at 80 m with 12-day nearest-neighbor pairs.[24][25]  
   August 2026 products are **PROVISIONAL**, not the validated record that begins on 21 October 2026.[22]

## Geographic and event guardrails

- The **8 July 2025 Gyirong–Rasuwa event** is supported by a peer-reviewed remote-sensing reconstruction as drainage of the Purepu supraglacial lake system. The study reports a roughly 0.31 km² lake-area reduction and strong downstream amplification in confined V-shaped valleys.[7]
- The **26 August 2026 Rasuwa event should not be called a conventional GLOF without qualification.** USGS described a likely rapid slope failure involving a glacier and marked its response information preliminary/provisional; ICIMOD’s synthesis interprets a rock–ice/bedrock failure and debris-rich cascade, while retaining unresolved process questions.[3][6]
- **“Bhote Koshi” is not a unique study-area label.** Literature on Gongbatongshaco/Poiqu–Zhangzangbo, the Arniko Highway, and the Upper Bhote Koshi Hydropower Project concerns the eastern transboundary Bhote Koshi corridor. It is a useful process analogue, but it is not the Rasuwa–Trishuli catchment and should not be used as site validation there.[9]

## What each radar product can defensibly support

| Product/observable | Defensible use in a steep gorge | Do not infer without added evidence |
|---|---|---|
| **OPERA DSWx-S1, 30 m** | Open-water/inundated-vegetation classification at acquisition time, with HAND, layover/shadow, and fill masks preserved; best evaluated for features meeting the 3 ha/200 m design target.[13][14][15] | Complete flood footprint in sub-200 m channels; dry debris or erosion; depth, discharge, velocity, or sediment thickness. |
| **OPERA RTC-S1 VV/VH gamma-0, 30 m** | Same-orbit backscatter anomaly or log-ratio; surface-change screening; input to a classifier that explicitly uses the per-acquisition validity mask. No speckle filter is applied, so spatial/temporal filtering must be specified.[16][17] | “Water” from darkness alone; a measurement in shadow; unique separation of water, smooth bare sediment, road surfaces, wet snow, or sensor-facing geometry. |
| **Sentinel-1 coherence** | Pre-pre versus pre/post coherence change, matched by relative orbit, temporal baseline, polarization, and season; large-disturbance density or timing proxy where pre-event coherence is adequate.[20][32][33] | Cause of decorrelation; complete individual-landslide polygons; motion magnitude; reliable results under dense vegetation, snow/melt change, or low baseline coherence. |
| **Sentinel-1 unwrapped phase / LOS displacement** | Referenced LOS displacement on coherent, non-layover/non-shadow pixels, with connected components, atmosphere, DEM residual, and uncertainty reported.[11][20] | Downslope or vertical motion without projection/track geometry; acceleration or warning from two endpoints; displacement across decorrelated failure pixels. |
| **NISAR GCOV** | L-band terrain-corrected backscatter and polarimetry at usually 10–20 m; paired amplitude/disturbance/inundation experiments against Sentinel-1 RTC.[25][27] | Automatic improvement merely because wavelength is longer; equivalence across different polarization, incidence, look direction, time, or product maturity. |
| **NISAR GUNW** | 12-day L-band wrapped/unwrapped phase, coherence, connected components, and ionospheric information; standard geocoded unwrapped phase is 80 m.[24] | A fully corrected deformation field: documented external phase corrections are not removed by default; 80 m posting also limits narrow-gorge interpretation.[24] |

## Five candidate falsifiable questions

### Q1. Does OPERA DSWx-S1 recover event-time open-water extent better than a terrain-masked RTC change detector in the upper Lhende–Bhote Koshi–Trishuli corridor?

**Already well answered? — No, site-specific performance is open; product limits are well documented.** DSWx-S1’s claim is open water larger than 3 ha and 200 m wide, with 30 m posting and explicit invalid classes. That does not establish performance for narrow Himalayan channels.[13][15]

**Falsifiable prediction.** Within pixels that are geometrically observable and within the product’s feature-size domain, DSWx-S1 should have higher open-water precision/recall than a simple fixed RTC threshold and should add information beyond a pre/post RTC log-ratio. The hypothesis fails if the gain vanishes after stratifying by channel width, feature area, orbit geometry, and pre-event water occurrence.

**Defensible observable/method.** Use the DSWx WTR/CONF classes for **water at acquisition time**, not “maximum event inundation.” In parallel, build a custom RTC VV/VH change surface from the same relative orbit and label it **surface change**, not water. Preserve HAND, layover/shadow, and fill as separate unknown classes. Use each acquisition’s mask rather than only a static mask.[14][15][17]

**Confounders.** Layover, shadow, foreshortening, DEM error, sub-pixel channels, specular smooth sediment/roads, rough or debris-laden water, vertical structures/double bounce, vegetation canopy, snow/ice, different water stage at reference time, and speckle. DSWx is principally an ice-free, low-backscatter-water algorithm and does not estimate canopy-obscured water where the canopy hides most of a pixel.[14][16]

**Minimum validation.** One acquisition-matched reference map within 48 hours, independently labeling open water, inundated vegetation, wet sediment/debris, dry disturbance, and unchanged land. Planet/WorldView/UAV or field-supported interpretation is preferable to another 30 m product; ICIMOD’s event map used Landsat, Sentinel-2, and PlanetScope acquired on 26–28 August.[6][14] Report precision, recall, and IoU by geometry and width/area stratum; do not rely on overall accuracy alone because water/non-water is highly imbalanced.[14] Report **observable-area fraction** separately from classification accuracy.

### Q2. Can Sentinel-1 amplitude plus coherence delimit debris-flow, bank-failure, and landslide disturbance independently of open water?

**Already well answered? — Partly.** Gorkha tests show coherence methods can support lower-resolution landslide-density maps but were not suitable for pixel-by-pixel individual-landslide mapping. A later Nepal/Japan/Zimbabwe timing study reached about 80% correctness for at most 30% of inventoried landslides; 25–43% of Nepal landslides on each track were removed because of foreshortening or layover.[32][33]

**Falsifiable prediction.** A same-season, same-orbit pre-pre versus pre/post coherence-change statistic, augmented by RTC VV/VH change, should separate mapped event disturbance from terrain-matched unchanged controls. It fails if the event interval is not more separable than quiet intervals, or if apparent detections track snow/melt, vegetation, soil moisture, or acquisition geometry rather than independently mapped disturbance.

**Defensible observable/method.** Require at least two pre-event images and one post-event image to form a quiet baseline and a co-event pair; a second post-event image is preferable to test persistence. Match relative orbit, temporal baseline, polarization, multilooking, and season. Compare the unstable polygon to nearby controls matched on slope, aspect, elevation, local incidence angle, land cover, and pre-event coherence. Output a change probability or coarse density surface unless individual polygons pass independent validation.[20][32][33]

**Confounders.** Low pre-event coherence, vegetation removal, snowfall/snowmelt, wet snow, soil moisture/rainfall, agriculture, road clearing, sediment excavation, temporal-baseline differences, decorrelation from rapid motion, and layover/shadow. The Nepal timing study explicitly identifies snowfall/snowmelt, vegetation, soil moisture, and human activity as non-landslide changes.[32]

**Minimum validation.** An independent event inventory from high-resolution optical/UAV/field mapping, plus negative controls and stratification by area, aspect, land cover, and valid/invalid geometry. At minimum, report pixel- and object-level precision/recall, the fraction of the reference inventory outside the observable mask, and results on a withheld reach. A detected coherence loss alone is not validation of flood, debris flow, or landslide mechanism.

### Q3. Is the reported pre-26-August-2026 LOS signal real precursory bedrock–ice deformation rather than glacier motion, atmosphere, phase unwrapping, or geometry?

**Already well answered? — No; the principal agency report says it is unresolved.** ICIMOD reports up to 40 cm Sentinel-1 LOS displacement over 7 July–24 August and about 30 cm NISAR LOS displacement over 26 July–19 August, but the NISAR result is attributed to a LinkedIn analysis and is not shown. The same report explicitly asks whether the InSAR pattern is precursory deformation, glacier movement, atmosphere, geometry, or a combination.[6]

A September EarthArXiv study tests routine Sentinel-1 amplitude, coherence, and unwrapped phase against matched controls and the source’s own history. It reports no disturbance above about 2 ha and no LOS rate above about 13 mm/month in the stated pre-failure windows, but it is explicitly non-peer-reviewed and says its bounds neither confirm nor exclude the slower multi-epoch rate.[30] It therefore **does not validate or refute** the later ICIMOD 40 cm figure; it demonstrates that endpoint/routine-product and multi-epoch-stack claims are different tests.

**Falsifiable prediction.** A real precursor should be spatially tied to the eventual source, temporally progressive across multiple independent interferograms, coherent with the sign expected from the measured look/slope geometry, stable to atmospheric/DEM/reference choices, and independently present in another track or sensor within its detection limits. The claim fails if it disappears after re-unwrapping, tracks elevation/atmosphere, crosses connected-component boundaries, is confined to layover/shadow, or is indistinguishable from neighboring glaciated slopes and quiet intervals.

**Defensible observable/method.** Publish the exact Sentinel-1 and NISAR acquisition IDs, track/frame, perpendicular baselines, polarization, coherence threshold, wrapped phase, unwrapping connected components, reference point/area, LOS sign convention, DEM, tropospheric/ionospheric corrections, and uncertainty. Separate (a) glacier-surface velocity from feature tracking, (b) phase-derived LOS motion, and (c) geometry-projected downslope motion. Do not convert a 48-day endpoint difference into “48 days of warning.”[6][24]

**Confounders.** Layover/shadow, low or spatially variable coherence, phase-unwrapping and connected-component errors, DEM error, reference choice, tropospheric/ionospheric delay, LOS projection, glacier-surface flow, snow/melt change, and post hoc target selection can all alter the apparent signal.[6][11][20]  
NISAR event-period product maturity and the fact that documented GUNW phase corrections are not applied by default must also be controlled.[22][24]

**Minimum validation.** Reproduction by an independent processor from SLC/GSLC data; false-alarm testing on terrain- and season-matched neighboring slopes; sensitivity to reference/atmospheric model and unwrapping; an ascending/descending or Sentinel-1/NISAR cross-check where geometrically observable; and independent optical feature tracking or pre/post DEM differencing. If claiming hydraulic consequence rather than only slope motion, field high-water marks, channel geometry, sediment mapping, and hydraulic modeling are additionally required.[6]

### Q4. Can Sentinel-1 measure monsoon-season acceleration of slow landslides along the Trishuli/Bhote Koshi gorge, rather than only dry-season motion?

**Already well answered? — Dry-season feasibility: yes for large favorable slopes. Monsoon acceleration: no.** The Trishuli Sentinel-1 study identified at least six slow-moving landslides, 0.39–1.66 km² in area, with dry-season LOS rates of 2.1–8.8 cm/yr. Low coherence during June–September prevented equivalent monsoon time-series analysis.[10] The broader method literature identifies vegetation, geometry, atmosphere, and deformation rate as limiting factors, with steep-terrain shadow/layover restricting what can be observed.[11][20]

**Falsifiable prediction.** A monsoon-capable workflow should retain enough valid coherent area on known slopes to recover repeatable LOS changes that exceed stable-slope controls and agree in timing with independent displacement or feature-tracking evidence. It fails if usable area collapses, phase estimates vary with atmosphere/seasonal scattering rather than slope motion, or only dry-season persistent scatterers remain.

**Defensible observable/method.** Use phase time series only on coherent, geometry-valid pixels; use RTC amplitude/coherence change or optical feature tracking for decorrelated parts. Process ascending and descending tracks separately, then project only where geometry supports it. Treat missing pixels as censored observations rather than zero velocity.

**Confounders.** Dense vegetation and monsoon phenology, soil moisture, rainfall-linked atmosphere, snow at high elevations, rapid-motion decorrelation, changing river/road surfaces, topographic phase residuals, layover, shadow, and LOS insensitivity to motion direction.[11][20][32]

**Minimum validation.** At least one dry and one monsoon season on a pre-existing field/aerial/high-resolution-optical landslide inventory; stable reference zones spanning elevation; same-orbit rainfall/snow controls; and comparison with independent feature tracking, repeat GNSS/total-station measurements where available, or repeat DEMs. Report detected rate only over the valid mask and separately report spatial completeness.

### Q5. Does NISAR L-band materially improve usable coherence and flood/debris detectability over Sentinel-1 C-band in steep, vegetated Himalayan gorges?

**Already well answered? — No for this setting; now empirically testable.** NISAR’s handbook states the L-band design advantage as foliage penetration and interferometric coherence, but that mission-level expectation is not a Rasuwa validation result.[27] Standard GCOV and GUNW also answer different questions and have different postings: generally 10–20 m for GCOV backscatter versus 80 m for GUNW unwrapped phase.[24][25]

**Falsifiable prediction.** For matched AOIs, dates, temporal baselines, and geometry classes, NISAR should increase (a) valid coherent area in vegetated terrain, (b) stability of quiet-slope coherence, and/or (c) recall of independently mapped inundation/disturbance at fixed false-positive rate. It fails if any apparent gain disappears after harmonizing resolution, incidence angle, polarization, season, and product maturity.

**Defensible observable/method.** Compare NISAR GCOV to Sentinel-1 RTC for amplitude/polarimetric change and NISAR GUNW/GSLC-derived coherence to Sentinel-1 SLC coherence for deformation/change. Harmonize to a common grid and effective resolution; use per-sensor layover/shadow/quality masks; keep ascending/descending and left-/right-looking geometries separate. Apply documented phase corrections rather than assuming GUNW is fully corrected.[24][25]

**Confounders.** Different wavelengths, polarization modes, spatial resolution, noise floor, number of looks, incidence and look direction, acquisition time, vegetation moisture, snow/wet snow, river roughness, DEM error, ionosphere/troposphere, and processing maturity. The 26 July–19 August 2026 NISAR interval falls in the PROVISIONAL record, which was fully calibrated but only partially validated; fully validated L0–L2 forward products begin with acquisitions on 21 October 2026.[22]

**Minimum validation.** At least three matched pair windows spanning quiet, monsoon/snow-change, and event/disturbance conditions; independent high-resolution labels; geometry- and land-cover-stratified precision/recall and usable-area fraction; and a no-change control year or seasonal baseline. Report the NISAR product maturity/CRID and do not mix BETA, PROVISIONAL, and VALIDATED products without a processor-change control.[22]

## Recommended study design hierarchy

1. **Map observability first:** per acquisition and track, generate shadow/layover, local-incidence, valid-data, coherence, and snow/land-cover masks.
2. **Separate targets:** open water; inundated vegetation; wet sediment; dry debris/erosion; slope deformation; and infrastructure change are different labels and observables.
3. **Use matched temporal controls:** same orbit, temporal baseline, season, and processing version; include at least one quiet pre-pre interval.
4. **Use matched spatial controls:** similar slope, aspect, elevation, land cover, and local incidence; test whether the target is exceptional without knowing the failure location.
5. **Report two denominators:** accuracy over observable pixels and coverage of the full reference footprint. A high score over a small visible fraction is not a complete map.
6. **Keep products physically distinct:** RTC/GCOV amplitude, coherence, wrapped phase, unwrapped LOS, and optical feature-tracking displacement should not be merged into a single “deformation” variable.
7. **Validate the claimed quantity:** optical/UAV polygons for extent; GNSS/feature tracking for displacement; high-water marks/channel surveys for depth/discharge; repeat DEMs for volume.

## Evidence register: title, date, and verbatim support

Exact URLs are mechanically listed in **Sources** below.

**[3] _2026 Nepal Debris Avalanche and Flash Flood_ — USGS, 27 August 2026; last update 28 August 2026.**  
> “USGS geologists are mapping the inundation boundary of the debris flow and flood by using satellite imagery. By comparing images taken before and after the event, geologists can identify newly affected areas, trace the limits of inundation, and disturbed surfaces from undisturbed terrain.”[3]

**[6] _Understanding the Gyirong–Rasuwa disaster of 26 August 2026: A preliminary synthesis_ — ICIMOD, 13 October 2026.**  
> “Whether the pre-event InSAR displacement represented a precursory deformation of the failing bedrock–ice slope, glacier movement, an atmospheric or geometric effect, or a combination of these processes.”[6]

**[7] _Remote sensing interpretation of causes and dynamics of the Gyirong outburst flood disaster, Tibet, on July 8, 2025_ — Natural Hazards, 18 March 2026.**  
> “In narrow, V-shaped valleys downstream, however, extensive erosion and entrainment substantially amplified the flood, resulting in an approximately sixfold increase in peak discharge, reaching ~ 8,400 m3/s, and ultimately evolving into a debris flow.”[7]

**[9] _Glacial Lake Inventory and Lake Outburst Flood/Debris Flow Hazard Assessment after the Gorkha Earthquake in the Bhote Koshi Basin_ — Water, 10 February 2020.**  
> “The GLOF caused severe damage downstream of Bhote Koshi, damaging 77 houses, 3 bridges and the Araniko Highway, and destroying the intake dam of the Upper Bhote Koshi Hydropower Project in Nepal”[9]

**[10] _InSAR-based detection method for mapping and monitoring slow-moving landslides in remote regions with steep and mountainous terrain: An application to Nepal_ — NASA NTRS record, 5 August 2020; Remote Sensing of Environment issue date 1 November 2020.**  
> “Due to periods of low coherence during the monsoon season (June – September) each year, and following the 25 April 2015 Mw7.8 Gorkha earthquake, our time series analysis is limited to the 2014-2015 and 2016-2017 dry seasons (September - May).”[10]

**[11] Same Bekaert et al. article — publisher page, 2020.**  
> “In addition, the ability to observe landslides using InSAR is limited by shadow and layover effects in steep terrain, due to the one dimensional viewing geometry of the radar sensor, which restricts displacement measurements to the radar look direction, and by the large changes in the ground surface from landslide deformation.”[11]

**[13] _OPERA Dynamic Surface Water Extent from Sentinel-1 (Version 1)_ — PO.DAAC release date 19 August 2024; forward production began September 2024.**  
> “Using Sentinel-1 radar observations, DSWx-S1 maps open inland water bodies greater than 3 hectares and 200 meters in width, irrespective of cloud conditions and daylight illumination that often pose challenges to optical sensors.”[13]

**[14] _OPERA Algorithm Theoretical Basis Document for Dynamic Surface Water Extent from Sentinel-1 A/B and NISAR data_ — JPL D-108763 Rev A, 26 May 2024.**  
> “They specify that for 80% of the validation products considered, overall accuracy must be greater than or equal to 80% for open water given features with a minimum area of 3ha and minimum width of 200m.”[14]

**[15] _Product Specification Document for Dynamic Surface Water Extent from Sentinel-1_ — JPL D-108761 Rev A, 25 July 2024 revision.**  
> “Invalid data classes (HAND masked, layover/shadow masked and fill value) are also provided to indicate areas in which the binary classification does not provide water/not water classification.”[15]

**[16] _OPERA Algorithm Theoretical Basis Document for Radiometric Terrain-Corrected SAR Backscatter from Sentinel-1 Product_ — JPL D-107393, 25 June 2024.**  
> “However, areas with layover and foreshortening may include backscatter from targets at different positions on the ground, representing a ``many-to-one'' mapping.”[16]

**[17] _OPERA RTC for Sentinel-1 (RTC-S1) Product Guide_ — ASF HyP3, undated living guide; accessed 15 November 2026.**  
> “For investigating the layover/shadow impacts for a specific RTC product, users will generally be better served by using the validity mask delivered with that product rather than the mask available as a static layer.”[17]

**[20] _TOPS Interferometry Tutorial_ — ESA/SNAP, issued May 2015; updated June 2021.**  
> “Loss of coherence can produce poor interferometric results and is caused by temporal (over vegetation and water bodies), geometric (errors or inaccuracies in the orbit metadata) and volumetric decorrelation (potential scattering mechanisms of voluminous structures, such as complex vegetation or dry surfaces).”[20]

**[22] _Available NISAR Data_ — ASF NISAR Data User Guide, current November 2026; accessed 15 November 2026.**  
> “NISAR VALIDATED datasets were released November 6, 2026. These products are fully calibrated and validated, and collections are available for all mission products from Level 0 through Level 2.”[22]

**[24] _Geocoded Unwrapped Interferogram_ — ASF NISAR Data User Guide, undated living guide; accessed 15 November 2026.**  
> “The GUNW product is an L2 product derived from the RIFG and RUNW products by geocoding the unwrapped phase and associated data layers (i.e., coherence magnitude, ionospheric phase screen) on a geographical grid at 80 m posting.”[24]

**[25] _Geocoded Polarimetric Covariance (GCOV)_ — ASF NISAR Data User Guide, undated living guide; accessed 15 November 2026.**  
> “GCOV products are projected to the appropriate UTM zone for their location and have a pixel spacing of 10 or 20 meters, depending on the acquisition location.”[25]

**[27] _NASA-ISRO SAR (NISAR) Mission Science Users’ Handbook – second edition_ — NASA/JPL, published 22 October 2025.**  
> “L-band (24 cm wavelength) Foliage penetration and interferometric coherence”[27]

**[30] _Calibrated detection limits in routine Sentinel-1 products 50.6 hours before the Langtang Lirung rock–ice avalanche, Nepal_ — EarthArXiv, 9 September 2026; non-peer-reviewed.**  
> “This analysis therefore neither confirms nor excludes that rate, and the bound is a statement about what could have been ruled out, not about how fast the slope moved.”[30]

**[32] _Using Sentinel-1 radar amplitude time series to constrain the timings of individual landslides: a step towards understanding the controls on monsoon-triggered landsliding_ — NHESS, 17 August 2022.**  
> “There may be real changes in the time series that are not landslides, for example snowfall or snowmelt, change in vegetation, change in soil moisture, or human activity.”[32]

**[33] _A New Method for Large-Scale Landslide Classification from Satellite Radar_ — Remote Sensing, 23 January 2019.**  
> “Using Receiver Operating Characteristic analysis, we show that none of these three SAR-coherence-based landslide classification methods are suitable for mapping individual landslides on a pixel-by-pixel basis.”[33]

## Sources

[3] https://www.usgs.gov/programs/landslide-hazards/science/2026-nepal-debris-avalanche-and-flash-flood — 2026 Nepal Debris Avalanche and Flash Flood
[6] https://lib.icimod.org/records/r745z-mvm84 — Understanding the Gyirong–Rasuwa disaster of 26 August 2026: A preliminary synthesis
[7] https://link.springer.com/article/10.1007/s11069-026-08081-1 — Remote sensing interpretation of causes and dynamics of the Gyirong outburst flood disaster, Tibet, on July 8, 2025
[9] https://www.mdpi.com/2073-4441/12/2/464 — Glacial Lake Inventory and Lake Outburst Flood/Debris Flow Hazard Assessment after the Gorkha Earthquake in the Bhote Koshi Basin
[10] https://ntrs.nasa.gov/citations/20205004356 — InSAR-based detection method for mapping and monitoring slow-moving landslides in remote regions with steep and mountainous terrain: An application to Nepal
[11] https://www.sciencedirect.com/science/article/abs/pii/S0034425720303539 — InSAR-based detection method for mapping and monitoring slow-moving landslides in remote regions with steep and mountainous terrain: An application to Nepal
[13] https://podaac.jpl.nasa.gov/dataset/OPERA_L3_DSWX-S1_V1 — OPERA Dynamic Surface Water Extent from Sentinel-1 (Version 1)
[14] https://archive.podaac.earthdata.nasa.gov/podaac-ops-cumulus-docs/web-misc/opera/atbd/D-108763_Rev_A_OPERA_DSWx_S1_NI_ATBD_20240530_SIGNED.pdf — OPERA Algorithm Theoretical Basis Document for Dynamic Surface Water Extent from Sentinel-1 A/B and NISAR data
[15] https://archive.podaac.earthdata.nasa.gov/podaac-ops-cumulus-docs/web-misc/opera/D-108761_OPERA_DSWx_S1AB_ProductSpec_Rev_A.pdf — Product Specification Document for Dynamic Surface Water Extent from Sentinel-1
[16] https://earthdata.nasa.gov/s3fs-public/2026-02/D-107393_OPERA%20RTC-S1%20ATBD_Initial_2024-06-25_wsigs.pdf?VersionId=Jgd6hB7Ae_SUt_OrBZ8O57.nTWsY4ZSU — OPERA Algorithm Theoretical Basis Document for Radiometric Terrain-Corrected SAR Backscatter from Sentinel-1 Product
[17] https://hyp3-docs.asf.alaska.edu/guides/opera_rtc_product_guide — OPERA RTC for Sentinel-1 (RTC-S1) Product Guide
[20] https://step.esa.int/docs/tutorials/S1TBX%20TOPSAR%20Interferometry%20with%20Sentinel-1%20Tutorial_v2.pdf — TOPS Interferometry Tutorial
[22] https://nisar-docs.asf.alaska.edu/availability-overview — Available NISAR Data - NISAR Data User Guide
[24] https://nisar-docs.asf.alaska.edu/gunw — Geocoded Unwrapped Interferogram - NISAR Data User Guide
[25] https://nisar-docs.asf.alaska.edu/gcov — Geocoded Polarimetric Covariance (GCOV) - NISAR Data User Guide
[27] https://dataverse.jpl.nasa.gov/dataset.xhtml?persistentId=doi:10.48577/jpl.UD4HV3 — NASA-ISRO SAR (NISAR) Mission Science Users’ Handbook - second edition
[30] https://eartharxiv.org/repository/view/14902 — Calibrated detection limits in routine Sentinel-1 products 50.6 hours before the Langtang Lirung rock–ice avalanche, Nepal
[32] https://nhess.copernicus.org/articles/22/2637/2022/nhess-22-2637-2022.html — Using Sentinel-1 radar amplitude time series to constrain the timings of individual landslides: a step towards understanding the controls on monsoon-triggered landsliding
[33] https://www.mdpi.com/2072-4292/11/3/237 — A New Method for Large-Scale Landslide Classification from Satellite Radar
