# Nepal Rasuwa–Bhotekoshi event fact-check

## Verdict

**A real August 2026 event exists.** On 26 August 2026, a catastrophic rock–ice/debris avalanche and flood began on the north face of Langtang Lirung in Nepal’s Rasuwa district and propagated down the Lhende Khola–Bhotekoshi–Trishuli–Narayani/Gandak river system.[1][2][4] Confidence: **very high**.

It is **not merely a misdated reference to the 8 July 2025 Rasuwa flood**. The same upper river corridor was struck twice in about 13 months.

The 2025 event was a sudden drainage/outburst from a supraglacial lake on the Purepu Glacier in Tibet.[8][11][12]

The 2026 event began with failure of rock and glacier ice on Langtang Lirung in Nepal.[7][9]

Confidence: **high**.[7][8]

A brief that calls the 2026 event a **conventional glacial-lake outburst flood (GLOF)** is likely carrying forward the 2025 mechanism or the earliest 26 August reporting. A defensible short label for 2026 is **“flash flood/debris flow triggered by a Langtang Lirung rock–ice avalanche, with a possible temporary landslide/debris-dam outburst stage.”** The damming stage is plausible but its timing and duration are not settled.[2][7][8]

## Event identity, time, place, and drainage

### 26 August 2026 event

- **Origin time:** USGS gives **2026-08-26 02:52:10 UTC**, which is **08:37:10 Nepal Time (NPT, UTC+05:45)**. GFZ gives **02:52:23 UTC / 08:37:23 NPT**. The minute is secure; the two seismic solutions differ by about 13 seconds.[4][6]
- **First border impact:** Nepal’s NDRRMA reconstruction says the surge reached **Rasuwagadhi at 08:45 NPT**, about seven to eight minutes after the seismic onset; Syafrubesi’s gauge failed at 08:50 and Betrawati’s at 09:20.[1] GFZ independently says CCTV at Gyirong was time-stamped **10:59 China Standard Time**, equivalent to about **08:44 NPT**.[6]
- **Source place:** north face of **Langtang Lirung**, Rasuwa district, inside Nepal, close to the China border. USGS describes the source as a glacier-involving slope failure in **Langtang National Park**.[5][7]
- **Drainage/path:** source scar/Chhochen Khola or upper Lhende catchment → **Lhende Khola** → **Bhote Koshi/Bhotekoshi** at the Gyirong–Rasuwagadhi border corridor → **Trishuli** → **Narayani/Gandak**, through or past Timure, Syabrubesi, Betrawati, Galchhi, Malekhu, Mugling, and Devghat.[1][2][8]
- **Warning chronology:** local officials began relay calls at about 08:45; NDRRMA notified DHM at 08:59; mass SMS alerts went out at about 09:15, after the border corridor had already been hit.[1][7]

### Coordinate products and provenance

| Product | Coordinate | Provenance and interpretation |
|---|---:|---|
| 2026 collapse location | **28.291242° N, 85.528066° E**, ~5,200 m | Nepal CHWRR interpretation of Landsat 9 and Planet Labs imagery; this is the most specific published Nepal-government scar/source coordinate located.[2] |
| 2026 “approximate source area” | **28°17′14.8″ N, 85°31′29.6″ E** = **28.287444° N, 85.524889° E** | Nepal CHWRR table; decimal conversion performed here.[2] |
| 2026 USGS mass-movement solution | **28.271° N, 85.515° E**, depth 0 km | USGS reviewed landslide event; USGS explicitly says the location was estimated from satellite imagery, so it should not be treated as a survey-grade scar point.[4] |
| 2026 GFZ seismic solution | **28.30° N, 85.50° E**, depth 0 km | GEOFON/GFZ manually revised landslide solution; a seismic/mass-movement location, not a field-mapped scar.[6] |
| 2025 supraglacial-lake source | **28.4043° N, 85.6469° E**, ~5,150 m | Nepal DHM Sentinel-2 analysis; upper Lhende catchment about 36 km upstream of Rasuwagadhi. ICIMOD/Stimson identify the feature as the Purepu Glacier lake system in Tibet.[11][13][18] |

The several 2026 coordinates are not necessarily contradictory: CHWRR reports a mapped source/scar, while USGS and GFZ report broad mass-movement/seismic solutions. Confidence in the **north-Langtang-Lirung source zone is high**; confidence in any coordinate as an exact surveyed failure point is **moderate**.[2][4][6]

## What happened in 2026: observation versus interpretation

### Direct or comparatively strong observations

1. **A large rock-and-ice mass detached.** NDRRMA says a hanging glacier and rocky mass of roughly 2.0 km² broke away near 5,200 m and struck the lower glacier/valley near 3,800 m.[1] ICIMOD’s later preliminary synthesis estimates about 132 million m³ of material, but explicitly says volume and composition still require validation with high-resolution elevation models.[7]
2. **The M5-class signal was the mass movement, not a tectonic earthquake.** USGS reclassified the initially reported M4.4 earthquake as an M5.2 landslide/glacial-collapse and debris-flow signal and states that no earthquake had occurred.[4] GFZ classifies the signal as mass movement, Mw 5.2–5.7.[6]
3. **Immediate rainfall was too small to explain the flood pulse.** CHWRR reports 1.5 mm at Kyangjing in the six hours before 08:37, with a maximum ten-minute amount of 0.14 mm, and finds no source-area concentration capable of explaining the surge.[2] NDRRMA likewise says the flood was caused by an ice-and-rock avalanche “rather than monsoon rainfall.”[1]
4. **Two barrier lakes appeared after the collapse.** Nepal CHWRR mapped two new lakes downstream of/near the collapse, and China’s Ministry of Water Resources reported a roughly 2 million m³ barrier lake formed after the landslide near the Chhochen–Purepu Tsangpo confluence.[2][17] These post-event lakes were secondary hazards, not evidence that a pre-existing glacial lake initiated the disaster.

### Best-supported interpretation

ICIMOD’s 13 October synthesis says a **bedrock failure sheared away part of a hanging glacier**, producing a cascading cryospheric geohazard rather than a conventional GLOF.[7][9]

The falling rock and ice likely fragmented, melted some ice through impact/friction, entrained river water and loose sediment, and transformed into a debris-laden flood.[5][6][7]

The **dominant root trigger remains unresolved**. Candidate preconditions include fractured/foliated bedrock, possible long-lived damage from the 2015 Gorkha earthquake, permafrost degradation, progressive snow/ice loading, glacier change, and anomalously warm conditions; ICIMOD says no single factor can yet be identified as dominant.[7] The 2025 flood may have amplified the 2026 flow by leaving loose channel sediment, but this is an interpretation requiring a sediment-budget test, not an established cause.[7][8]

### Landslide/debris-dam stage: real possibility, unresolved sequence

CHWRR’s hydrological report states that the avalanche **temporarily blocked the river and subsequently released water and debris**.[2] ICIMOD’s public Q&A similarly says that, if pooled water broke through avalanche debris, the event included a **landslide-dam outburst stage**, which is not the same as a GLOF.[8]

The unresolved timing is important. Most USGS/ICIMOD interpretations associate the collapse itself with the **08:37 signal on 26 August**, perhaps followed by brief damming. ICIMOD also records a competing, rapid IRDR analysis that reads 25–26 August imagery as showing failure on the afternoon of **25 August**, an **18–19 hour impoundment**, and dam failure at 08:37. ICIMOD calls this an open question requiring better imagery and seismic reconciliation.[8] Confidence in **some short-lived blockage/impoundment: moderate**; confidence in an **18–19 hour dam: low at present**.

## Conflicts and how to resolve them

| Claim/report | What it said | Current weight |
|---|---|---|
| Early Copernicus EMS activation, 26 Aug | “reportedly triggered by a Glacial Lake Outburst Flood (GLOF)”[16] | **Superseded/low weight for mechanism.** It was live situational wording. Later USGS, Nepal government, and ICIMOD evidence identifies a rock–ice mass failure and no pre-existing lake at the origin.[1][4][7] |
| DHM preliminary meteorological report | In its concluding preliminary analysis, DHM said isolated heavy rainfall may have occurred at night/morning and may have caused the avalanche, while calling for detailed study.[3] | **Low-to-moderate and explicitly preliminary.** The same report lists only 1 mm at Kyangjing on the flood day; the later CHWRR analysis finds just 1.5 mm in the six hours before failure and insufficient rain to trigger the flood pulse.[2][3] Rain may have weakly conditioned an unstable slope, but evidence is insufficient.[2] |
| Initial “earthquake triggered avalanche” reports | Initial USGS M4.4 and local reports suggested an earthquake.[4][15] | **Rejected as the main sequence.** USGS says the collapse generated the seismic signal and “no earthquake had occurred.”[4] A separate small M2.6 signal reported around 08:20 and long-term 2015-earthquake damage remain research questions, not established triggers.[7] |
| Glacier collapse vs bedrock failure carrying glacier | USGS on 28 Aug said it was unclear whether a landslide incorporated glacier ice or the glacier itself collapsed.[5] | **Evolving terminology, not event doubt.** ICIMOD’s October synthesis gives greater weight to bedrock failure shearing off overlying ice, while still labeling the physical trigger preliminary.[7][9] |
| 25 Aug failure/long dam vs 26 Aug instantaneous collapse | IRDR rapid interpretation: failure visible 25 Aug, 18–19 h dam; most USGS/ICIMOD interpretation: 08:37 collapse on 26 Aug with at most brief damming.[8] | **Unresolved.** Do not state the 18–19 h debris dam as settled fact.[8] |
| Border arrival time | NDRRMA/CHWRR/GFZ support about 08:45; one ICIMOD formal-report table gives about 09:00–09:05 even though the same report’s summary gives about 08:44–08:50.[1][6][7] | **Use ~08:45 NPT**, with minute-level uncertainty. CCTV conversion and Nepal-government timing independently agree.[1][6] |

## The separate 8 July 2025 event

- **Date/time:** **8 July 2025**. Stimson reports the flood at **03:15 NPT / 05:30 Beijing time**; NDRRMA’s account reported through *The Himalayan Times* says Timure’s water level abruptly rose 3.5 m at about 03:15 and Syafrubesi rose 1.75 m at about 03:30.[13][19] Treat 03:15 as the first reported/gauged flood arrival, not a precisely observed lake-release time.
- **Source/place:** a supraglacial lake system on the **Purepu Glacier** (also rendered Puripu/Purugu/Pyurepu in reports), in Tibet/China’s upper Lhende catchment, roughly 35–36 km upstream of Rasuwagadhi, at about 5,150 m and **28.4043° N, 85.6469° E**.[11][12][13]
- **Drainage:** Purepu supraglacial lake → upper Lhende River/Khola → Rasuwagadhi border → Bhotekoshi/upper Trishuli downstream.[8][13]
- **Mechanism:** Sentinel-2 images showed the mapped lake area shrink from about **0.75 km² to 0.60 km²** between pre- and post-flood images; DHM reached the preliminary conclusion that lake outburst/drainage generated the flood.[11] ICIMOD’s 9 July release independently described drainage of a newly formed supraglacial ice-dammed lake.[12]
- **Rainfall:** contemporaneous NDRRMA reporting said no rain was evident in the upper Nepal/China area on 4–7 July; rainfall was not considered the immediate driver, although early Reuters coverage noted heavy rain elsewhere in Tibet and initially framed a lake overflow as a possibility.[19]
- **Impacts identifying the event:** the flood destroyed the Nepal–China Friendship Bridge and damaged border and hydropower infrastructure.[8][13][20]

Confidence that the **2025 event was a Purepu supraglacial-lake outburst/drainage flood is high**. Confidence in **03:15 as the source-release time is only moderate**, because it is a downstream observation/reporting time.[11][13][19]

## Exact supporting quotations from key opened sources

> “On 26 August 2026 (10 Bhadra 2083), a severe flash flood travelled through the Lhende Khola–Bhotekoshi–Trishuli–Narayani river system. It was caused by an ice and rock avalanche, rather than monsoon rainfall.” — NDRRMA.[1]

> “Study of available satellite images (Landsat 9, Planet Labs) shows that a hanging glacier located on the northern side of Langtang-Lirung mountain in Rasuwa district, at an elevation of approximately 5200 masl (approximately 28.291242°N, 85.528066°E), collapsed…” — Nepal CHWRR.[2]

> “This event was initially reported as a magnitude 4.4 earthquake. Additional analysis of long period seismic waves indicate that the seismic energy was instead generated by a glacial collapse and debris flow.” — USGS.[4]

> “The source of the event was a bedrock failure that sheared away part of a hanging glacier; this has been established through seismic, satellite, and drone evidence.” — ICIMOD preliminary synthesis.[7]

> “The event is best characterised as a cascading cryospheric geohazard rather than a glacial lake outburst flood (GLOF), as anticipated initially.” — ICIMOD preliminary synthesis.[7]

> “On 26 August, there was no lake found at the origin point, but rather the collapse of a mountain face.” — ICIMOD Rasuwa 2026 Q&A.[8]

> “The Gyirong-Rasuwa corridor has experienced two catastrophic transboundary disasters in 13 months: the July 2025 Purepu supraglacial lake flood and the August 2026 Langtang Lirung rock and ice collapse.” — ICIMOD, 13 October 2026.[9]

> “China-Nepal flood caused by draining ‘supraglacial’ lake that started forming as a small pond in end of December 2024 which grew significantly in June 2025” — ICIMOD, 9 July 2025.[12]

> “The flood occurred without warning at 3:15 a.m. Nepal time (5:30 a.m. Beijing time), and no alerts were issued in advance.” — Stimson Center on the 2025 event.[13]

> “It was not clear what caused the glacier to collapse…” — Reuters, 26 August 2026, correctly preserving uncertainty at the time.[14]

> “When the bedrock gave way, the glacier on top also got swept” — ICIMOD scientist Mohd. Farooq Azam, quoted by *The Kathmandu Post*.[15]

> “The ice and rocks were shaken loose by the earthquake that struck central Nepal on April 25, 2015.” — NASA Earth Observatory, describing the **separate 2015 Langtang avalanche**, not the 2026 flood.[10]

## NASA Earth Observatory finding

No NASA Earth Observatory page specifically covering the **26 August 2026 Rasuwa/Bhotekoshi flood** or the **8 July 2025 Rasuwa flood** was located. Searches covered the old and current Earth Observatory domains for “Rasuwa,” “Bhotekoshi/Bhote Koshi,” “Trishuli,” “Langtang Lirung,” “Nepal-China flood,” and “Nepal glacier collapse/debris avalanche 2026.” The old Earth Observatory search URL redirected to the current NASA Earth Observatory homepage.

The NASA Earth Observatory source actually opened was **“Landslide in Langtang Valley” (5 May 2015)**. It documents the earthquake-triggered 2015 Langtang avalanche and is useful only as historical/geographic context for pre-existing slope damage; it is not evidence of the 2025 or 2026 Rasuwa event.[10]

## Searched but not found / not obtained

- **NASA Earth Observatory event-specific coverage** for either July 2025 or August 2026: not found; only contextual 2015 Langtang and older Nepal hazard pages were located.
- **A final, field-validated Government of Nepal causal report** closing the 2026 mechanism questions: not found. The CHWRR report is “Assessment Report II,” and both CHWRR and ICIMOD explicitly call for further field, DEM, seismic, and hydraulic validation.[2][7]
- **A standalone Nepal Department of Mines and Geology / National Earthquake Monitoring and Research Center technical event report** for the 2026 mass movement: not found. Its seismic observations appear through NDRRMA/CHWRR/ICIMOD accounts.[1][2][7]
- **An official Chinese final source-causation report for the 2025 Purepu event:** not found/opened. A Tibet government news result timed out. For 2026, China’s Ministry of Water Resources page on the post-event barrier lake was opened.[17]
- **A final peer-reviewed reconstruction resolving the 25-versus-26 August timing and initial dam duration:** not found. The available ICIMOD synthesis explicitly leaves this unresolved.[7][8]

## Confidence summary

| Finding | Confidence |
|---|---|
| A real Rasuwa/Bhotekoshi–Trishuli disaster occurred on 26 Aug 2026 | **Very high** |
| Origin at/near 08:37 NPT on north Langtang Lirung, Nepal | **High** |
| Border impact around 08:45 NPT | **High** |
| Rock–ice/bedrock slope failure was the initiating hazard | **High** |
| 2026 was not a conventional pre-existing-lake GLOF | **High** |
| Heavy rain generated the 2026 flood pulse | **Very low / contradicted by later observations** |
| Rain/warmth/permafrost/2015 quake was the dominant root trigger | **Unknown; no single factor confirmed** |
| A short temporary debris blockage contributed to the initial surge | **Moderate** |
| A 25 Aug failure and 18–19 h debris dam preceded the surge | **Low; unresolved competing interpretation** |
| 8 Jul 2025 was a distinct Purepu supraglacial-lake outburst/drainage flood | **High** |
| 03:15 NPT was the exact 2025 source-release time | **Moderate-to-low; it is best treated as first arrival/observation** |

## Sources

[1] https://ndrrma.gov.np/mediafiles/publications/Bhotekoshi-Trishuli_Flood_Update_From_August_26_2026_to_October_3_2026.pdf — BHOTEKOSHI–TRISHULI FLOOD: SEARCH, RESCUE AND RELIEF UPDATE
    > "On 26 August 2026 (10 Bhadra 2083), a severe flash flood travelled through the Lhende Khola–Bhotekoshi–Trishuli–Narayani river system. It was caused by an ice and rock avalanche, rather than monsoon rainfall."
    > "Travelling at approximately 188 km/h from its source, the flood covered 20 km within seven to eight minutes and reached the Nepal–China border at Rasuwagadhi at 08:45."
[2] https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR%20revised_1790050465053_hkodqvs.pdf — Assessment Report II: Rasuwa–Bhote Koshi Flood Event, 2026 (2083)
    > "Crucially, in the six hours before the reported avalanche time (approximately 08:37 NST on August 26), the Kyangjing station recorded only 1.5 mm of rainfall."
    > "approximately 5200 masl (approximately 28.291242°N, 85.528066°E), collapsed, causing a huge ice–rock avalanche"
    > "The flood wave originated from the Bhote Koshi headwaters near the Nepal-China border following an ice-rock avalanche that temporarily blocked the river and subsequently released a large volume of water and debris."
    > "Upstream of Rasuwagadhi (28°17'14.8"N 85°31'29.6"E)"
[3] https://dhm.gov.np/mfd/api/image/publication/062e83a1d3d9b7b7c0.pdf — २०८३ भदौ १० को भोटेकोशी-त्रिशुली बाढीको मौसम सम्बन्धि प्रारम्भिक प्रतिवेदन
    > "र षवपद् प्रभाषवत क्षेरमा िासगरी रात्र कात्रलन/त्रबहानपिको समर्मा Isolated Heavy Rainfall भएको हुन सक्ने र सोको कारण षहमपषहरो गएको हुनसक्ने प्रारन्म्भक षवश्लेिण रहे को छ।"
[4] https://earthquake.usgs.gov/earthquakes/eventpage/us7000tbwb/executive — M 5.2 Landslide - 55 km NW of Kodāri̇̄, Nepal
    > "This event was initially reported as a magnitude 4.4 earthquake. Additional analysis of long period seismic waves indicate that the seismic energy was instead generated by a glacial collapse and debris flow."
    > "The location of this event was estimated from satellite images."
    > "A magnitude 5.2 seismic event occurred near the border between Nepal and China on Aug 26 at 8:37 AM local time (10:52 AM China Standard Time)."
[5] https://www.usgs.gov/programs/landslide-hazards/science/2026-nepal-debris-avalanche-and-flash-flood — 2026 Nepal Debris Avalanche and Flash Flood
    > "At this time, it is unclear if the initial slope failure was a landslide incorporating part of a glacier or a glacial collapse."
[6] https://www.gfz.de/en/press/news/details/extreme-flooding-in-china-and-nepal — Extreme flooding in China and Nepal
    > "On 26 August 2026, seismometers worldwide registered a moderate “earthquake” in the border region between Tibet and Nepal."
    > "The mechanism of the mass movement was most probably the break-off of a hanging glacier and underlying bedrock in the north flank of the Langtang Massif"
    > "It was timed at 02:52:23 Universal Time (UTC), that is 8:37am in Nepal, and 10:52am China Standard Time"
[7] https://doi.org/10.53055/ICIMOD.1150 — Understanding the Gyirong–Rasuwa disaster of 26 August 2026: A preliminary synthesis
    > "The source of the event was a bedrock failure that sheared away part of a hanging glacier; this has been established through seismic, satellite, and drone evidence."
    > "The event is best characterised as a cascading cryospheric geohazard rather than a glacial lake outburst flood (GLOF), as anticipated initially."
    > "No single factor can yet be identified as the dominant cause of failure."
[8] https://www.icimod.org/kyirong-rasuwa-flood-2026-nepal-china-border — Kyirong-Rasuwa Flood 2026 | Nepal-China Cryosphere Risk
    > "On 8 July 2025, a lake that had formed on top of the Purepu Glacier in Tibet, about 36 km north of the border, drained suddenly and sent a flood down the same Lhende–Bhotekoshi channel."
    > "On 26 August, there was no lake found at the origin point, but rather the collapse of a mountain face."
    > "A rapid analysis by IRDR Young Scientists in Nepal (Adhikari et al.), reviewed by Chinese and Integrated Research on Disaster Risk (IRDR) experts, reads satellite imagery from 25 and 26 August as showing the failure already present on the afternoon of 25 August, meaning the debris blocked the river for 18–19 hours, water built up behind it, and the 8:37 event was the result of a dam bursting."
[9] https://www.icimod.org/press-releases/second-major-himalayan-flood-in-seven-weeks-raises-new-questions-about-mountain-risk — Second major Himalayan flood in seven weeks raises alarm over compounding mountain hazards
    > "The disaster was not a conventional glacial lake outburst flood."
    > "The Gyirong-Rasuwa corridor has experienced two catastrophic transboundary disasters in 13 months: the July 2025 Purepu supraglacial lake flood and the August 2026 Langtang Lirung rock and ice collapse."
[10] https://earthobservatory.nasa.gov/images/85812/landslide-in-langtang-valley — Landslide in Langtang Valley
    > "The ice and rocks were shaken loose by the earthquake that struck central Nepal on April 25, 2015."
[11] https://dhm.gov.np/uploads/dhm/downloads/Report_Bhotekoshi_Flood_Update_1.pdf — भोटेकोशी बाढी अपडेट (24 Asar 2082 / 8 July 2025)
    > "शचरमा दे खाइएको बथान रसुिागढी शबथत नेपाल-चीन सीमाबाट करीब ३६ वकलोसमटर मासथ (अक्ािंशः २८.४०४३, दे शान्त्तरः ८५.६४६९, समुदि सतहबाट कररब ५१५० सम. उचाई) ले न्त्दे खोलाको मासथल्लो र्लाधार क्ेरमा पदाछ।"
    > "उपरोक्त वििरणहरुको आधारमा र्ल तथा मौसम विज्ञान विभाग वहमताल विबफोटबाटै यस बाढी सृर्ना भएको प्रारशम्भक सनष्कषामा पुगेको छ।"
[12] https://eocampaign1.com/web-version?p=d3025410-5cb8-11f0-a4b6-bf354d4c42dc&pt=campaign&t=1752063093&s=9d254356b427faddb32a7b56ad1c9e806546c1aae3f88e0164211164c14a5c4f — UPDATED PRESS RELEASE: HAZARDS EXPERTS SHOCKED BY GROWING PACE OF GLACIAL ORIGIN FLOODS
    > "China-Nepal flood caused by draining ‘supraglacial’ lake that started forming as a small pond in end of December 2024 which grew significantly in June 2025"
[13] https://www.stimson.org/2025/investigating-an-emerging-climate-hazard-transboundary-glacial-floods-on-the-china-nepal-border — Investigating an Emerging Climate Hazard: Transboundary Glacial Floods on the China-Nepal Border
    > "The flood occurred without warning at 3:15 a.m. Nepal time (5:30 a.m. Beijing time), and no alerts were issued in advance."
    > "This event has been attributed to the rapid expansion and sudden drainage of a supraglacial lake system that formed atop the Purepu Glacier, approximately 35 kilometers upstream from the Nepal-China border at an elevation of about 5,150 meters above sea level."
[14] https://www.reuters.com/business/environment/glacier-collapse-may-have-triggered-deadly-nepal-flash-flood-experts-say-2026-08-26 — Glacier collapse may have triggered deadly Nepal flash flood, experts say
    > "It was not clear what caused the glacier to collapse"
[15] https://kathmandupost.com/national/2026/08/28/what-triggered-the-rasuwa-flood-scientists-piece-together-a-complex-chain-of-events — What triggered the Rasuwa flood? Scientists piece together a complex chain of events
    > "When the bedrock gave way, the glacier on top also got swept"
[16] https://mapping.emergency.copernicus.eu/news/flood-in-nepal-emsr927 — Flood in Nepal | Copernicus EMS On Demand Mapping
    > "On the 26 August 2026, a flash flood reportedly triggered by a Glacial Lake Outburst Flood (GLOF) in Nepal has caused significant damage in Rasuwa District."
[17] http://www.mwr.gov.cn/english/News/WaterNews/202608/t20260828_2140670.html — China activates emergency response for high-risk barrier lake on China-Nepal border
    > "The barrier lake formed near the confluence where Nepal's Chhochen Khola River flows into the Purepu Tsangpo River in China after a deadly landslide that began in Nepal on Wednesday morning"
[18] https://risingnepaldaily.com/news/64905 — Rasuwagadhi flash flood attributed to glacial lake outburst
    > "Its coordinates are Latitude: 28.4043, Longitude: 85.6469, at an altitude of about 5,150 meters above sea level."
    > "Post-flood images, however, show its size reduced to roughly 0.60 square kilometers."
[19] https://thehimalayantimes.com/environment/glof-confirmed-as-the-reason-for-rasuwa-flood — GLOF confirmed as the reason for Rasuwa flood
    > "At approximately 3:15am yesterday, the water level at Timure station unexpectedly rose by 3.5 metres."
    > "There was no sign of rain in the upper parts of Nepal and China on July 4, 5, 6 and 7."
[20] https://www.reuters.com/sustainability/climate-energy/dozens-missing-after-floods-nepal-china-border-2025-07-08 — At least eight killed and dozens missing after floods on Nepal-China border
    > "At least eight people were killed and over two dozen were missing after the Bhote Koshi River flooded, washing away the "Friendship Bridge" that links China and Nepal, officials said on Tuesday."
