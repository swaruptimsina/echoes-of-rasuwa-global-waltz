# Independent validation: 26 August 2026 Rasuwa–Bhotekoshi event

## Bottom line

The event to validate is the **26 August 2026 Gyirong–Rasuwa / Rasuwa–Bhotekoshi disaster**, not the 8 July 2025 Purepu supraglacial-lake flood in the same corridor. Nepal’s CHWRR dates the rapid-onset flood to 26 August 2026; USGS locates the non-tectonic seismic source at **28.271°N, 85.515°E, 02:52:10 UTC (08:37:10 NPT)** and classifies it as a glacial collapse/debris flow rather than an earthquake.[1][2] The later ICIMOD synthesis calls it a cascading rock–ice geohazard, not a conventional GLOF.[5]

There is one important timing caveat.[6]

Most USGS/ICIMOD interpretations associate the mountain collapse with the 08:37 NPT signal on 26 August.[2][5]

An IRDR interpretation instead reads 25/26 August satellite imagery as showing failure on the afternoon of **25 August**, followed by 18–19 hours of impoundment and a 26 August dam breach.[6]

ICIMOD calls this the “most important open question”; therefore use **26 August for the destructive flood/event marker**, but do not treat 25 August as a proven quiet day.[6]

A defensible source AOI is centred on **28.288708°N, 85.528159°E** (HiRISK) or **28.291242°N, 85.528066°E** (CHWRR satellite interpretation). HiRISK reports Planet and Landsat-9 imagery and source-area photographs; CHWRR maps a hanging-glacier/bedrock collapse on the north side of Langtang Lirung.[1][3]

## Public STAC tests

### Queries actually run

| Query parameter | Exact value |
|---|---|
| Method | POST, `limit=500`, ascending datetime |
| Window | `2026-07-01T00:00:00Z/2026-09-30T23:59:59Z` |
| Source bbox | `[85.49, 28.25, 85.56, 28.32]` |
| Upper-corridor bbox | `[85.35, 28.24, 85.57, 28.32]` |
| Betrawati bbox | `[85.15, 27.94, 85.22, 28.00]` |
| Earth Search | `https://earth-search.aws.element84.com/v1/search`; `sentinel-2-l2a`, `landsat-c2-l2` |
| Planetary Computer | `https://planetarycomputer.microsoft.com/api/stac/v1/search`; same collections |
| USGS LandsatLook | `https://landsatlook.usgs.gov/stac-server/search`; `landsat-c2l2-sr` |

| Catalog / collection | source | upper corridor | Betrawati | Result |
|---|---:|---:|---:|---|
| Earth Search Sentinel-2 L2A | 46 | 46 | 44 | HTTP success |
| Planetary Computer Sentinel-2 L2A | 45 | 45 | 43 | HTTP success |
| Earth Search Landsat C2 L2 | 24 | 24 | 12 | HTTP success |
| Planetary Computer Landsat C2 L2 | 24 | 24 | 12 | HTTP success |
| USGS LandsatLook C2 L2 SR | 24 | 24 | 12 | HTTP success |

For the source query, 45/45 Planetary Computer Sentinel-2 product URIs match Earth Search; Earth Search has one additional 11 September product.[18][20] All 24 Landsat item IDs match between Earth Search and Planetary Computer, and all 24 Landsat scene IDs match USGS.[22] See `stac_crosscheck.json` and `stac_query_manifest.json`.

Earth Search Sentinel COGs were range-readable without credentials (HTTP 206 for TCI, SCL, B04, B08).[20] Current USGS asset HREFs redirected to EarthExplorer login (HTTP 302).[22] Planetary Computer’s permanent blob HREFs returned 409 unsigned but 206 after obtaining a public collection SAS token, as documented by Microsoft.[25] Exact checks are in `asset_http_checks.json`.

### Key optical acquisitions and usability

“Local obstruction” below is my reproducible mask statistic, not the catalog’s scene cloud number: Sentinel-2 SCL classes 3/8/9/10 (shadow, medium/high cloud, cirrus) or Landsat QA_PIXEL bits 1–4, divided by valid pixels.[18][22]

Mountain snow/ice is **not** counted as cloud.[18][22]

Bboxes and class counts are in `local_cloud_metrics.json` and `selected_optical_items.json`.

| Acquisition | UTC datetime | Catalog cloud | Local obstruction | Usability | Exact links |
|---|---|---:|---|---|---|
| **S2C_45RUM_20260812_0_L2A** (R119) | 2026-08-12 05:10:48.070 | 18.746611% | source context 3.002%; source scar 0%; Rasuwagadhi 0%; Betrawati 0% | **Excellent pre-event baseline** for source and corridor. | [STAC item](https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2C_45RUM_20260812_0_L2A), [TCI](https://sentinel-cogs.s3.us-west-2.amazonaws.com/sentinel-s2-l2a-cogs/45/R/UM/2026/8/S2C_45RUM_20260812_0_L2A/TCI.tif), [SCL](https://sentinel-cogs.s3.us-west-2.amazonaws.com/sentinel-s2-l2a-cogs/45/R/UM/2026/8/S2C_45RUM_20260812_0_L2A/SCL.tif).[18] |
| **S2B_45RUM_20260824_0_L2A** (R076) | 2026-08-24 05:00:49.736 | 38.568816% | source scar 5.336%; context 27.820%; zero valid pixels at Rasuwagadhi/Betrawati in this partial swath | **Strong immediate pre-event source view**, not a downstream scene. | [STAC item](https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2B_45RUM_20260824_0_L2A), [TCI](https://sentinel-cogs.s3.us-west-2.amazonaws.com/sentinel-s2-l2a-cogs/45/R/UM/2026/8/S2B_45RUM_20260824_0_L2A/TCI.tif), [SCL](https://sentinel-cogs.s3.us-west-2.amazonaws.com/sentinel-s2-l2a-cogs/45/R/UM/2026/8/S2B_45RUM_20260824_0_L2A/SCL.tif).[19] |
| **S2B_45RUM_20260827_0_L2A** (R119) | 2026-08-27 05:10:45.885 | 78.471315% | source scar 54.759%; context 67.454%; Rasuwagadhi 14.743%; Betrawati 15.824% | **Usable downstream with masking; only partial/qualitative at source.** Do not reject it from scene cloud alone. | [STAC item](https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2B_45RUM_20260827_0_L2A), [TCI](https://sentinel-cogs.s3.us-west-2.amazonaws.com/sentinel-s2-l2a-cogs/45/R/UM/2026/8/S2B_45RUM_20260827_0_L2A/TCI.tif), [SCL](https://sentinel-cogs.s3.us-west-2.amazonaws.com/sentinel-s2-l2a-cogs/45/R/UM/2026/8/S2B_45RUM_20260827_0_L2A/SCL.tif).[20] |
| **S2C_45RUM_20260928_0_L2A** (R076) | 2026-09-28 05:00:54.257 | 1.587821% | source scar 0%; context 0.153%; Rasuwagadhi 0.063% but only 3,157 valid pixels versus 22,648 in a full footprint; no Betrawati data | **Excellent clear late-post source view; only a partial Rasuwagadhi footprint.** Source scar is 92.001% SCL snow/ice, so use morphology, not unmasked spectral differencing. | [STAC item](https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2C_45RUM_20260928_0_L2A), [TCI](https://sentinel-cogs.s3.us-west-2.amazonaws.com/sentinel-s2-l2a-cogs/45/R/UM/2026/9/S2C_45RUM_20260928_0_L2A/TCI.tif), [SCL](https://sentinel-cogs.s3.us-west-2.amazonaws.com/sentinel-s2-l2a-cogs/45/R/UM/2026/9/S2C_45RUM_20260928_0_L2A/SCL.tif).[21] |
| **LC09_L2SP_141040_20260826_02_T1**; USGS **LC09_L2SP_141040_20260826_20260827_02_T1_SR** | 2026-08-26 04:47:48.916081 | 47.54% | source scar 85.277%; source context 87.148%; Rasuwagadhi 5.151% | Acquired **1 h 55 m 39 s after** the USGS event time. **Unusable for source attribution, but useful as same-day 30 m post-event evidence at Rasuwagadhi.** | [USGS STAC](https://landsatlook.usgs.gov/stac-server/collections/landsat-c2l2-sr/items/LC09_L2SP_141040_20260826_20260827_02_T1_SR), [PC red](https://landsateuwest.blob.core.windows.net/landsat-c2/level-2/standard/oli-tirs/2026/141/040/LC09_L2SP_141040_20260826_20260827_02_T1/LC09_L2SP_141040_20260826_20260827_02_T1_SR_B4.TIF), [PC QA](https://landsateuwest.blob.core.windows.net/landsat-c2/level-2/standard/oli-tirs/2026/141/040/LC09_L2SP_141040_20260826_20260827_02_T1/LC09_L2SP_141040_20260826_20260827_02_T1_QA_PIXEL.TIF) (SAS required).[22] |

Additional tested but mostly rejected scenes are retained in `selected_optical_items.json`: Sentinel-2 28 July (87–100% local obstruction), the alternate 24 August R119 granule (9.098% obstruction over the scar but 36.754% over source context), 1 September (good only around Rasuwagadhi), and Landsat 18 August/3 September plus WRS row 041.[18][19][20]

The 18 August Landsat scene is clear at Rasuwagadhi but 93.479% obstructed at the scar; the 26 August row-041 scene is 90.886% obstructed at Betrawati.[22]

Independent interpretation agrees with the locally usable parts: Copernicus compares 12 and 27 August Sentinel-2 around Betrawati/Gerkhu and reports a markedly wider channel and pale-brown sediment extending over the valley floor.[8] UNOSAT likewise used 27 August Sentinel-2 with 26 August PlanetScope to map mudflow/rockflow.[9][10]

## Official and independent map/report evidence

1. **Government of Nepal CHWRR Assessment Report II** — event chronology, source coordinate, Landsat-9/Planet interpretation, pre/post NRSC figure, hydrological profile and barrier lakes: [PDF](https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR%20revised_1790050465053_hkodqvs.pdf).[1]
2. **NDRRMA Situation Report 01 (1 September)** — official response report; attributes the 26 August event to a large ice–rock avalanche based on high-resolution satellite imagery and warns of residual impoundment/breach risk: [PDF](https://ndrrma.gov.np/mediafiles/rasuwa/Rasuwa_Flood_SitRep_Temp_ENG_01_01092026.pdf).[4]
3. **HiRISK NP3 rapid hazard assessment (28 August update)** — geolocated source, Landsat-9/Planet evidence, before/after source image and source-area photographs: [PDF](https://hirisk.org/wp-content/uploads/2026/08/RHA_NP3_RasuwaFlood.pdf).[3]
4. **ICIMOD preliminary synthesis (DOI 10.53055/ICIMOD.1150)** — integrates seismic, satellite, drone, government and observational evidence; its Figure 14 manually digitises flood extent from Landsat (26 Aug), Sentinel-2 (27 Aug) and PlanetScope (26/28 Aug): [record and PDF](https://lib.icimod.org/records/qdvc1-tc123).[5] Its pre-event InSAR analysis reports up to 40 cm LOS deformation over 7 July–24 August but explicitly says that this did not predict exact failure time.[7]
5. **UNOSAT 4257** — 230 km² analysed, approximately 20 km² affected; [product](https://unosat.org/products/4257), [PDF](https://unosat.org/static/unosat_filesystem/4257/Layout_Map1.pdf), [GDB](https://unosat.org/static/unosat_filesystem/4257/FL20260826NPL.gdb.zip).[9]
6. **UNOSAT 4259** — Rasuwa/Nuwakot impact assessment; approximately 350 km² analysed, 37 km² mapped as affected, with road/building exposure; [product](https://unosat.org/products/4259), [PDF](https://unosat.org/static/unosat_filesystem/4259/Layout_Map3.pdf), [GDB](https://unosat.org/static/unosat_filesystem/4259/FL20260826NPL.gdb.zip).[10]
7. **UNOSAT 4260** — two post-event barrier lakes from 28 August Cartosat-3; its map also credits 27 August Sentinel-2 and 26 August Landsat-9; [product](https://unosat.org/products/4260), [PDF](https://unosat.org/static/unosat_filesystem/4260/UNOSAT_BarrierLakes_Nepal_China_v1.pdf), [GDB](https://unosat.org/static/unosat_filesystem/4260/FL20260826NPL.gdb.zip).[11]
8. **Copernicus EMSR927** — official EU grading for Syapru Besi, Timure, Bidur and Phosretar. It records 27 August 05:05 UTC products at the first two locations and explicitly cancelled Bharatpur/Kyundi products for persistent cloud, a useful check against overclaiming optical coverage: [activation/AOIs](https://mapping.emergency.copernicus.eu/activations/EMSR927/aois).[12]
9. **Sentinel Asia / International Charter activation** — requested by Nepal DHM on 26 August; includes EOS-RS Sentinel-1 DPM, AIT Sentinel-1/Sentinel-2 DPM, FORMOSAT-5, ALOS-2 and PlanetScope products: [activation and product list](https://sentinel-asia.org/EO/2026/article20260826NP.html).[13]
10. **MapAction affected-area mapbook** — 11-page humanitarian reference series, published 6 September: [ReliefWeb page](https://reliefweb.int/map/nepal/nepal-rasuwa-floods-26th-august-2026-reference-map-series-affected-area-06092026), [direct PDF](https://reliefweb.int/attachments/98d0e044-1f52-4449-8cba-1ef72e6dd87f/ma011_v02_map_series_affected_area-mapbook-300dpi.pdf).[14]

The agencies are institutionally independent enough to form a useful convergence: Nepal government hydrology/disaster authorities, USGS, UNOSAT, EU Copernicus, Sentinel Asia partners, and regional cryosphere teams all identify the same source/corridor and post-event footprint, although exact failure timing and water-generation mechanism remain under investigation.[1][2][9]

## Dated/geolocated photographs and footage

- **HiRISK Figure 3**: post-event photographs of the source and deposit, tied by the report to `28.288708°N, 85.528159°E`; report updated 28 August.[3] The report says the photographs confirm the Landsat-9/Planet interpretation.[3]
- **AP gallery, 26 August**: multiple Niranjan Shrestha photographs captioned along the Trishuli River in **Nuwakot district**, including debris-choked banks, damaged houses and vehicles.[15] This is district-level caption geolocation, not published GPS EXIF.[15]
- **Reuters footage via RTÉ, 26 August**: footage at **Syapru Besi and Timure, Rasuwa**.[16] Reuters says it confirmed location from buildings, roads and terrain matching satellite imagery; authorities and corroborating videos confirmed the date.[16] This is the strongest explicit media-verification chain found.[16]
- **OnlineKhabar aerial photographs, 26 August**: an aerial assessment “several hours after” the flood spanning **Rasuwagadhi to Bidur**, naming Timure, Dhunche, Mailung, Syafrubesi and Betrawati.[17] The page supplies date/place context but not raw EXIF coordinates.[17]

Do not describe these media pages as GPS-geotagged unless the original files and EXIF are obtained; they are date/place-captioned or newsroom-verified.[15][16][17]

## Defensible null tests with real acquisitions

### Primary same-date spatial null (best control)

Use the same R119 acquisitions as the downstream event contrast: **S2C_45RUM_20260812_0_L2A → S2B_45RUM_20260827_0_L2A**, a 15-day interval with identical MGRS tile/orbit.[18][20]

Compare the affected Rasuwagadhi and Betrawati polygons against at least two non-intersecting controls from the same two COGs.[18][20]

- **Glacier control**, Nyalam County, Tibet: bbox `[85.71, 28.37, 85.73, 28.39]`. SCL is 100% snow/ice and 0% obstructed on both dates.[18][20]
- **Vegetated control**, Bhotang, Sindhupalchok (separate catchment): bbox `[85.63, 27.97, 85.65, 27.99]`. SCL vegetation is 92.054%/91.875%, with 0% obstruction on both dates.[18][20]

These controls share atmosphere, acquisition geometry and processing with the event pair.[18][20]

Exclude any control intersecting the published UNOSAT/Copernicus event polygons plus a conservative buffer, then sample many 1–2 km windows rather than relying on one hand-picked box.[9][12]

On common valid pixels, co-register stable rock/road tie points, measure channel-width/bare-sediment or robust multiband change, and require the affected-area statistic to exceed the predeclared 95th percentile of control-window changes.[18][20]

Full class counts and URLs are in `null_test_acquisitions.json`.

### Quiet-date source null

For the clear but seasonally separated source pair, compare **S2B_45RUM_20260824_0_L2A → S2C_45RUM_20260928_0_L2A** (R076, 35 days, local obstruction 5.336%→0%).[19][21]

Use the same future source-scar polygon in a no-event 35-day R076 interval: **S2B_45RUM_20241003_0_L2A → S2A_45RUM_20241107_0_L2A** (local obstruction 6.139%→0%).[23][24]

This source null is only defensible if snow/ice is masked or modelled: the 2026 event pair changes from 29.871% to 92.001% SCL snow/ice, while the 2024 quiet pair changes from 78.046% to 54.079%.[19][21][23]

Therefore use stable morphological evidence (scar edge, displaced rock/ice geometry, texture, DEM if available), not raw RGB/NDVI/NDSI difference alone.[19][21]

A proposed July 28→August 12 pre-event null was rejected over the source because the 28 July scene is 99.392% locally obstructed.[18]

## Reproducibility files

Folder: `/home/safal0715/Documents/research/_subagents/validation/`

| Purpose | Files |
|---|---|
| Event STAC queries | `query_stac.py`, `stac_query_manifest.json`, `stac_items.csv`, 15 `stac_raw_*` responses |
| Catalog cross-check | `crosscheck_stac.py`, `stac_crosscheck.json` |
| AOI cloud/use checks | `analyze_optical_assets.py`, `local_cloud_metrics.{csv,json}`, `asset_http_checks.json`, 16 quicklook PNGs |
| Selected assets | `build_selected_inventory.py`, `selected_optical_items.json` |
| Historical queries | `query_historical_null.py`, historical Earth Search/Planetary Computer JSON |
| Spatial-control scan | `scan_s2_quiet_controls.py`, `s2_quiet_control_candidates.csv` |
| Null-test record | `build_null_test.py`, `null_test_acquisitions.json` |
| Source copies | CHWRR, NDRRMA, HiRISK and ICIMOD PDFs; UNOSAT 4259 GDB; ArcGIS service/web-map JSON; detachment/barrier GeoJSON |
| Grounding | `citation-ledger.json`, evidence snippets, citation helper scripts |

## Limitations

| Limitation | Consequence |
|---|---|
| Catalog cloud is scene-wide, not AOI-specific | Use local SCL/QA screening before acceptance. |
| SCL/QA can confuse cloud, snow, shadow and bright rock | Treat masks as screening, not final interpretation. |
| 27 August source is more than half obstructed | Combine with Planet, Landsat, SAR, Cartosat and/or field/drone evidence. |
| Quicklook vision inspection failed with a 401 | Usability calls rely on masks, valid coverage, COG reads and cited agency interpretations. |
| UNOSAT/Copernicus products are preliminary | Do not present them as field validation. |

## Sources

[1] https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR%20revised_1790050465053_hkodqvs.pdf — Government of Nepal CHWRR Assessment Report II
    > "An extreme and rapid-onset flood occurred in the Lhende Khola–Bhote Koshi–Trishuli–Narayani river system on 10 Bhadra 2083 (26 August 2026)."
[2] https://earthquake.usgs.gov/earthquakes/eventpage/us7000tbwb/executive — USGS M 5.2 Landslide event us7000tbwb
    > "This event was initially reported as a magnitude 4.4 earthquake. Additional analysis of long period seismic waves indicate that the seismic energy was instead generated by a glacial collapse and debris flow."
[3] https://hirisk.org/wp-content/uploads/2026/08/RHA_NP3_RasuwaFlood.pdf — HiRISK Rapid Hazard Assessment NP3
    > "Lat: 28.288708°N-Lon: 85.528159°E-Elevation: ca. 5000 m a.s.l."
[4] https://ndrrma.gov.np/mediafiles/rasuwa/Rasuwa_Flood_SitRep_Temp_ENG_01_01092026.pdf — NDRRMA Situation Report 01
    > "On 26 August 2026, a major ice–rock avalanche occurred in the upper Bhote Koshi watershed near the China– Nepal border, approximately 20 km upstream of Rasuwagadhi."
[5] https://lib.icimod.org/records/qdvc1-tc123 — ICIMOD preliminary synthesis landing page
    > "On 26 August 2026, a catastrophic rock-and-ice collapse in the Langtang region of the Nepal Himalaya triggered a powerful, debris-laden surge that swept through the Gyirong–Rasuwagadhi border corridor, causing severe loss of life and extensive damage in Nepal and China."
[6] https://www.icimod.org/kyirong-rasuwa-flood-2026-nepal-china-border — ICIMOD Gyirong-Rasuwa event resource
    > "When did the mountain actually fail – on 26 August, or the day before? This is the most important open question."
[7] https://icimod.org/press-releases/second-major-himalayan-flood-in-seven-weeks-raises-new-questions-about-mountain-risk — ICIMOD synthesis press release
    > "Sentinel-1 satellite radar detected up to 40 cm of ground deformation between 7 July and 24 August 2026, during the 48 day before the collapse."
[8] https://eu-space.europa.eu/components/earth-observation-copernicus/image-of-the-day/aftermath-nepal-flash-flood — Copernicus EU Image of the Day: aftermath of Nepal flash flood
    > "This comparison of images acquired by one of the Copernicus Sentinel-2 satellites shows the area around Betrawati and Gerkhu before and after the event."
[9] https://unosat.org/products/4257 — UNOSAT Product 4257 Rasuwa mudflow extent
    > "This map illustrates the cumulative satellite-detected udflow/rockflow extent derived from Sentinel-2 imagery acquired on 27 August 2026 and PlanetScope imagery acquired on 26 August 2026."
[10] https://unosat.org/products/4259 — UNOSAT Product 4259 Rasuwa-Nuwakot impact assessment
    > "Within the analysed area of approximately 350 km², an estimated 37 km² of land appears to be affected by floodwaters."
[11] https://unosat.org/products/4260 — UNOSAT Product 4260 barrier lakes
    > "This map illustrates two newly formed barrier lakes detected from CARTOSAT-3 imagery acquired on 28 August 2026."
[12] https://mapping.emergency.copernicus.eu/activations/EMSR927/aois — Copernicus EMS Rapid Mapping EMSR927
    > "Grading Completed (situation as of 27/08/2026, 05:05 (UTC))"
[13] https://sentinel-asia.org/EO/2026/article20260826NP.html — Sentinel Asia activation: Rasuwa flash flood
    > "Occurrence Date (UTC): 26 August, 2026"
[14] https://reliefweb.int/map/nepal/nepal-rasuwa-floods-26th-august-2026-reference-map-series-affected-area-06092026 — MapAction affected-area reference map via ReliefWeb
    > "Nepal: Rasuwa Floods (26th August 2026) - Reference Map Series of Affected Area (06/09/2026)"
[15] https://apnews.com/nepal-floods-08-26-26 — AP photo gallery: Nepal Floods 08-26-26
    > "Damaged houses stand precariously near the swollen, debris-choked banks of the Trishuli River after flash floods in Nepal’s Nuwakot district on Wednesday, Aug. 26, 2026. (AP Photo/Niranjan Shrestha)"
[16] https://rte.ie/news/world/2026/0826/1589338-ariel-footage-nepal-mudslide — Reuters-verified drone footage via RTE
    > "Reuters confirmed the location from the buildings, roads and terrain which matched satellite imagery of the area."
[17] https://english.onlinekhabar.com/rasuwa-flood-in-pictures.html — OnlineKhabar aerial photo report
    > "An aerial assessment by Onlinekhabar several hours after the flood showed widespread destruction across the affected areas, from the Rasuwagadhi border point to Bidur in Nuwakot."
[18] https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2C_45RUM_20260812_0_L2A — Earth Search Sentinel-2 item 12 August 2026
    > ""id": "S2C_45RUM_20260812_0_L2A", "geometry": { "type": "Polygon""
[19] https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2B_45RUM_20260824_0_L2A — Earth Search Sentinel-2 item 24 August 2026
    > ""id": "S2B_45RUM_20260824_0_L2A", "geometry": { "type": "Polygon""
[20] https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2B_45RUM_20260827_0_L2A — Earth Search Sentinel-2 item 27 August 2026
    > ""id": "S2B_45RUM_20260827_0_L2A", "geometry": { "type": "Polygon""
[21] https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2C_45RUM_20260928_0_L2A — Earth Search Sentinel-2 item 28 September 2026
    > ""id": "S2C_45RUM_20260928_0_L2A", "geometry": { "type": "Polygon""
[22] https://landsatlook.usgs.gov/stac-server/collections/landsat-c2l2-sr/items/LC09_L2SP_141040_20260826_20260827_02_T1_SR — USGS Landsat 9 SR item 26 August 2026
    > ""id": "LC09_L2SP_141040_20260826_20260827_02_T1_SR", "description": "Landsat Collection 2 Level-2 Surface Reflectance Product""
[23] https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2B_45RUM_20241003_0_L2A — Earth Search quiet-date Sentinel-2 item 3 October 2024
    > ""id": "S2B_45RUM_20241003_0_L2A", "properties": { "created": "2024-10-03T09:50:57.217Z""
[24] https://earth-search.aws.element84.com/v1/collections/sentinel-2-l2a/items/S2A_45RUM_20241107_0_L2A — Earth Search quiet-date Sentinel-2 item 7 November 2024
    > ""id": "S2A_45RUM_20241107_0_L2A", "properties": { "created": "2024-11-07T17:06:50.564Z""
[25] https://planetarycomputer.microsoft.com/docs/concepts/sas — Planetary Computer SAS authentication documentation
    > "A SAS token is needed whenever you want to access Planetary Computer data at an Azure Blob URL."
