# Event facts: 26 August 2026 Rasuwa–Bhotekoshi disaster

**Study cutoff:** 15 November 2026  
**Event marker used in processing:** 2026-08-26 02:52:10 UTC / 08:37:10 Nepal Time  
**Status:** retrospective research, not an operational hazard product

## Verified identity

**OBSERVATION — high confidence.** A real disaster occurred on 26 August 2026. USGS records an M5.2-equivalent landslide signal at 02:52:10 UTC near 28.271°N, 85.515°E and reclassified the initially reported earthquake as a glacial-collapse/debris-flow signal.[6] Nepal's CHWRR gives the event date as 26 August and maps the hanging-glacier collapse near 28.291242°N, 85.528066°E at about 5,200 m.[2]

**OBSERVATION — high confidence.** The affected drainage was upper Chhochen/Lhende Khola → Lhende Khola → Bhote Koshi/Bhotekoshi → Trishuli → Narayani/Gandak. Government and USGS accounts place impacts along the Lhende and Trishuli corridor, including Rasuwagadhi.[2][7]

**INTERPRETATION — high confidence.** The initiating hazard was a bedrock/rock–ice failure on the north face of Langtang Lirung, not a conventional pre-existing-lake GLOF. ICIMOD's synthesis says bedrock failure sheared away part of a hanging glacier, while its event resource states that no lake was found at the origin.[8][11]

**INTERPRETATION — moderate confidence.** A short-lived debris blockage and release may have amplified the surge, but the sequence is unresolved. The competing proposal that failure began on 25 August and impounded water for 18–19 hours remains an open question; this project does not resolve it.[8]

## Rainfall context

**OBSERVATION — high confidence for the sampled products, low spatial representativeness.** Nepal CHWRR reports no rainfall at the initiation area at event time and concludes that the flood pulse was associated with the ice–rock avalanche rather than rainfall-generated runoff.[2]

This project independently fetched native GPM IMERG V07C Early and Late granules for the event half-hour. Both returned **0.0 mm h⁻¹** at the nearest 0.1° cell centre (85.549995°E, 28.25°N), with `randomError=0.24 mm h⁻¹`; the exact IDs are `G4288257564-GES_DISC` and `G4288718397-GES_DISC`. IMERG is a half-hourly 0.1° product, not a slope-scale gauge.[17] NASA warns that orographic estimates can have greater uncertainty and may be underestimated.[18]

POWER returned 4.50 mm d⁻¹ (`IMERG_PRECTOT`) and 1.17 mm d⁻¹ (`PRECTOTCORR`) for 26 August, while six complete model-hour bins ending with the 02:00 UTC bin summed to 0.46 mm. These are coarse satellite/model context and do not prove or disprove a local trigger. See `data/processed/hydro_context/hydro_context_summary.json`.

## Distinct 2025 event

The 8 July 2025 flood in the same corridor was a separate Purepu Glacier supraglacial-lake drainage event in Tibet; it must not be used as the causal model for 2026.[8] The two events share a downstream corridor but not the best-supported initiating mechanism.

## Independent evidence opened

| Evidence | What it supports | Confidence/limit |
|---|---|---|
| Nepal CHWRR Assessment Report II | Date, mapped source coordinate, drainage, rainfall analysis, satellite interpretation | High authority; still an assessment rather than a final field-validated reconstruction.[2] |
| USGS landslide event and special page | Exact seismic time/location, non-tectonic classification, satellite hazard mapping | High for event timing/type; USGS called some physical details preliminary.[6][7] |
| ICIMOD preliminary synthesis and event resource | Bedrock–ice failure interpretation, non-GLOF distinction, unresolved process questions | Medium–high; explicitly preliminary.[8][11] |
| UNOSAT product 4259 and live ArcGIS layer 7 | Independent optical detachment/reference geometry and downstream impact mapping | Preliminary and not field validated.[20] |
| Copernicus Sentinel-2 comparison | Wider post-event channel and pale-brown valley-floor sediment near Betrawati/Gerkhu | Independent optical corroboration; not a surveyed boundary.[22] |

No NASA Earth Observatory page specific to the July 2025 or August 2026 Rasuwa event was found after targeted searches. The NASA Earth Observatory Langtang page located concerns the separate 2015 earthquake avalanche and was not used as 2026 evidence.

## Live SAR/derived-product inventory

The table below comes from live CMR responses saved on 15 November 2026 for bbox **85.34–85.55°E, 28.23–28.32°N** and 1 July–15 October 2026. Counts are product records, not unique overpasses; NISAR revisions and OPERA burst granules can represent the same acquisition more than once.

| Collection | Records | Event relation and useful exact record |
|---|---:|---|
| Sentinel-1D SLC | 27 | Nearest pre: `S1D_IW_SLC__1SDV_20260824T001843_20260824T001910_004260_007D5D_98CC-SLC`; nearest post: `S1D_IW_SLC__1SDV_20260828T122140_20260828T122208_004326_007FA4_93F8-SLC`. |
| NISAR provisional RSLC | 30 | Nearest pre: `NISAR_L1_PR_RSLC_028_149_D_074_2005_QPDH_A_20260823T130631_20260823T130706_P05023_N_F_J_001`; nearest post: `NISAR_L1_PR_RSLC_029_048_D_074_2005_QPDH_A_20260828T125812_20260828T125846_P05023_N_F_J_001`. Event-period data are PROVISIONAL, not VALIDATED.[23] |
| NISAR provisional GCOV/GUNW/GOFF | 30 / 31 / 31 | Multiple 12-day event-spanning pairs; GUNW is an 80 m unwrapped-phase product with associated coherence/quality layers.[24] |
| NISAR urgent-response GUNW/GOFF | 6 / 6 | Track-48 products span 16–28 August; earliest archive insertion was about 3.15 days after the event for GUNW. |
| OPERA RTC-S1 | 45 bursts | Same-burst, same-track 12-day pairs exist on paths 19, 85 and 121. OPERA RTC is 30 m gamma-0 with no speckle filter.[25] |
| OPERA DSWx-S1 | 12 in the broad window | **Zero** records from 1 August through 11 September. Latest pre: 25 June; first post: 12 September, a 78.9996-day gap. |
| ALOS-2 ScanSAR | 0 in the event window | Latest AOI record found: `ALOS2585683050-250328-WBDR1.1__D`, acquired 28 March 2025. |
| SAOCOM / RCM CMR collections | 0 / 0 | Collection stubs returned no granules; ASF rejected these dataset names. Absence from these catalogs is not proof that no national/commercial acquisition exists. |

The complete 218-row timeline, exact CMR query URLs, archive insertion times, and granule concept IDs are in `data/acquisition_timeline.csv` and `data/acquisition_timeline_summary.json`.

## Confidence summary

| Finding | Confidence |
|---|---|
| Event date/time and Langtang Lirung source zone | **High** |
| Rock–ice/bedrock failure initiated the cascade | **High** |
| Conventional pre-existing-lake GLOF initiated 2026 | **Low / contradicted** |
| Immediate intense rain generated the flood pulse | **Low / contradicted at available scales** |
| Exact root cause of slope failure | **Unknown** |
| Short temporary blockage contributed | **Moderate** |
| 25 August failure with 18–19 h impoundment | **Low; unresolved** |

## Sources

[2] https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR_hnmns6o.pdf — Government of Nepal CHWRR Assessment Report II: Rasuwa-Bhote Koshi Flood Event, 2026
    > "An extreme and rapid-onset flood occurred in the Lhende Khola–Bhote Koshi–Trishuli–Narayani river system on 10 Bhadra 2083 (26 August 2026)."
    > "Study of available satellite images (Landsat 9, Planet Labs) shows that a hanging glacier located on the northern side of Langtang-Lirung mountain in Rasuwa district, at an elevation of approximately 5200 masl (approximately 28.291242°N, 85.528066°E), collapsed, causing a huge ice–rock avalanche which fell onto a debris-covered glacier located approximately 3800 masl."
    > "However, no rainfall was recorded around the slope failure area or flood-initiated area during the time of the flood These observations indicate that the extreme flood was likely generated as a cascading consequence of the ice-rock avalanche and subsequent displacement of the debris mass, rather than by rainfall-induced runoff."
[6] https://earthquake.usgs.gov/earthquakes/eventpage/us7000tbwb — USGS M 5.2 Landslide — 55 km NW of Kodari, Nepal
    > "This event was initially reported as a magnitude 4.4 earthquake. Additional analysis of long period seismic waves indicate that the seismic energy was instead generated by a glacial collapse and debris flow."
[7] https://www.usgs.gov/programs/landslide-hazards/science/2026-nepal-debris-avalanche-and-flash-flood — 2026 Nepal Debris Avalanche and Flash Flood
    > "USGS geologists are mapping the inundation boundary of the debris flow and flood by using satellite imagery. By comparing images taken before and after the event, geologists can identify newly affected areas, trace the limits of inundation, and disturbed surfaces from undisturbed terrain."
[8] https://www.icimod.org/kyirong-rasuwa-flood-2026-nepal-china-border — Gyirong-Rasuwa flood 2026
    > "On 26 August, there was no lake found at the origin point, but rather the collapse of a mountain face."
    > "On 8 July 2025, a lake that had formed on top of the Purepu Glacier in Tibet, about 36 km north of the border, drained suddenly and sent a flood down the same Lhende–Bhotekoshi channel."
[11] https://doi.org/10.53055/ICIMOD.1150 — Understanding the Gyirong–Rasuwa disaster of 26 August 2026: A preliminary synthesis
    > "The source of the event was a bedrock failure that sheared away part of a hanging glacier; this has been established through seismic, satellite, and drone evidence."
[17] https://www.earthdata.nasa.gov/data/catalog/ges-disc-gpm-3imerghhe-07 — GPM IMERG Early V07 catalog
    > "The precipitation estimates from the various precipitation-relevant satellite passive microwave (PMW) sensors comprising the GPM constellation are computed using the 2021 version of the Goddard Profiling Algorithm (GPROF2021), then gridded, intercalibrated to the GPM Combined Ku Radar-Radiometer Algorithm (CORRA) product, and merged into half-hourly 0.1°x0.1° (roughly 10x10 km) fields."
[18] https://gpm.nasa.gov/sites/default/files/2025-02/FAQ%20for%20IMERG%20V07%20Applications%20Users_202502.pdf — IMERG V07 Applications FAQ
    > "Greater uncertainty near orographic regions may lead to underestimated precipitation rates."
[20] https://unosat.org/products/4259 — UNOSAT Rasuwa-Nuwakot impact assessment 4259
    > "This map illustrates the cumulative satellite-detected mudflow/rockflow extent derived from Sentinel-2 imagery acquired on 27 August 2026 and PlanetScope imagery acquired on 26 August 2026."
[22] https://eu-space.europa.eu/components/earth-observation-copernicus/image-of-the-day/aftermath-nepal-flash-flood — Copernicus aftermath of Nepal flash flood
    > "By 27 August 2026, the river course appeared markedly wider, with extensive pale brown sediment deposits visible."
[23] https://nisar-docs.asf.alaska.edu/availability-overview — Available NISAR Data
    > "NISAR PROVISIONAL datasets were released July 20, 2026. These products are fully calibrated and have undergone validation at a limited set of sites around the world."
[24] https://nisar-docs.asf.alaska.edu/gunw — NISAR Geocoded Unwrapped Interferogram guide
    > "The GUNW product is an L2 product derived from the RIFG and RUNW products by geocoding the unwrapped phase and associated data layers (i.e., coherence magnitude, ionospheric phase screen) on a geographical grid at 80 m posting."
[25] https://hyp3-docs.asf.alaska.edu/guides/opera_rtc_product_guide — ASF OPERA RTC-S1 product guide
    > "The pixel values of the products represent gamma-0 power. The pixel spacing is 30 meters, and no speckle filter has been applied."
    > "For investigating the layover/shadow impacts for a specific RTC product, users will generally be better served by using the validity mask delivered with that product rather than the mask available as a static layer."
