# One-page research brief for DHM Nepal, NDRRMA, ICIMOD, and local government

## Scope

This is a retrospective satellite-data study of the 26 August 2026 Langtang Lirung–Bhote Koshi–Trishuli event, anchored to the Government of Nepal source coordinate and event reconstruction.[2] It is **research screening, not a forecast, warning product, evacuation recommendation, or field damage assessment**.

## What the real SAR data showed

- **Localized C-band coherence loss: medium-low confidence.** In two 12-day Sentinel-1D HyP3 interferograms, median normalized coherence inside the independent preliminary optical detachment polygon fell from **0.5129** in the 4–16 August pair to **0.3950** in the 16–28 August pair. The paired-pixel median change was **−0.1313**, while a 0.3–1.5 km control ring changed by **+0.1841**. UNOSAT’s polygon is independent satellite mapping, but it is preliminary rather than field ground truth.[20]
- **Control-calibrated screening mask: medium-low confidence.** A threshold fixed at the lower 5th percentile of the control distribution, followed by a four-pixel/0.0256 km² minimum mapping unit, flagged **158 of 307 target pixels (51.5%)**. It also flagged **1,225 of 30,161 control pixels (4.06%)**; those are the reported false alarms, not hidden background.
- **NISAR L-band coherence change: low confidence for attribution.** Median source-window coherence fell from **0.2188** in a 14–26 July quiet pair to **0.1021** in a 19–31 August event pair. The exploratory control changed only from **0.8616** to **0.8464**. Dates, polarization, geometry, and masks differ from Sentinel-1D, so absolute L- and C-band coherence are not compared directly.
- **NISAR displacement failed honestly.** Only **9 of 528** source pixels retained connected unwrapped phase in the event pair, versus **249 of 528** in the quiet pair and **420 of 420** in each control subset. A second NISAR look had no source pixels passing both subswath-validity conditions. No LOS displacement, velocity, acceleration, or pre-event movement is reported. GUNW’s 80 m phase/coherence layers are appropriate inputs in principle,[24] but these event pixels were not adequate.
- **NISAR pixel offsets also failed.** Event-source GOFF layers were raw, unculled, weakly correlated, and dominated by extreme outliers. They cannot support a sub-metre motion claim without culling and stable-reference modeling.
- **Backscatter remains an observable, not a class.** NISAR GCOV showed wider event-source HH change tails than the control, but this was not validated as debris, water, soil moisture, or movement.

## Data availability and latency

The exact-AOI 24-month inventory contains **6,803 product granules** after hydrologic-polygon filtering. Product records collapse to long source-date chains: up to **48 Sentinel-1A SLC dates**, **12 Sentinel-1D dates**, and **28 NISAR GUNW source dates** in one geometry, each with a 12-day median adjacent baseline. August NISAR products are provisional; ASF states that provisional products are calibrated but validated only at limited sites.[23]

The first Sentinel-1D image used here was acquired **2.395 days after the event** and inserted into CMR **3.254 days after the event**. The first matching OPERA RTC acquisition had the same 2.396-day offset, but its archive insertion in this snapshot was **46.379 days after the event**. Acquisition, production, archive insertion, and research processing are different clocks; none is warning time.

## What this does not show

- No validated precursor deformation or “slope breathing.”
- No unique physical cause from coherence loss.
- No complete map in layover/shadow; the HyP3 burst bundle lacked an explicit terrain-geometry mask.
- No claim that RCM, SAOCOM, NISAR S-band, or ALOS-2 had no acquisition. Their accessible catalogs were unsupported, split across archives, or had no matching post-event record in this fetched snapshot.
- No population-at-risk estimate. OSM proximity is context only.

## Recommended research follow-up

1. Process at least three matched pairs per season with per-acquisition layover/shadow masks and an independently chosen stable reference.
2. Ask a SAR scientist to review NISAR mask bits, ionosphere handling, connected components, and whether validated reprocessing changes August coverage.
3. Ask DHM/NDRRMA/ICIMOD for field-checked detachment/deposit boundaries, exact bridge and hydropower asset coordinates, and gauge time series suitable for independent validation.
4. Keep a local acquisition/availability log that records acquisition time, product-generation time, archive insertion, valid-pixel coverage, and false alarms separately.
5. Use `METHOD_CARD.md` for the exact free-tool rerun; do not promote the resulting mask to an alert layer without field and multi-season validation.

## Sources

[2] https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR_hnmns6o.pdf — Government of Nepal CHWRR Assessment Report II: Rasuwa-Bhote Koshi Flood Event, 2026
    > "An extreme and rapid-onset flood occurred in the Lhende Khola–Bhote Koshi–Trishuli–Narayani river system on 10 Bhadra 2083 (26 August 2026)."
    > "Study of available satellite images (Landsat 9, Planet Labs) shows that a hanging glacier located on the northern side of Langtang-Lirung mountain in Rasuwa district, at an elevation of approximately 5200 masl (approximately 28.291242°N, 85.528066°E), collapsed, causing a huge ice–rock avalanche which fell onto a debris-covered glacier located approximately 3800 masl."
    > "However, no rainfall was recorded around the slope failure area or flood-initiated area during the time of the flood These observations indicate that the extreme flood was likely generated as a cascading consequence of the ice-rock avalanche and subsequent displacement of the debris mass, rather than by rainfall-induced runoff."
[20] https://unosat.org/products/4259 — UNOSAT Rasuwa-Nuwakot impact assessment 4259
    > "This map illustrates the cumulative satellite-detected mudflow/rockflow extent derived from Sentinel-2 imagery acquired on 27 August 2026 and PlanetScope imagery acquired on 26 August 2026."
[23] https://nisar-docs.asf.alaska.edu/availability-overview — Available NISAR Data
    > "NISAR PROVISIONAL datasets were released July 20, 2026. These products are fully calibrated and have undergone validation at a limited set of sites around the world."
[24] https://nisar-docs.asf.alaska.edu/gunw — NISAR Geocoded Unwrapped Interferogram guide
    > "The GUNW product is an L2 product derived from the RIFG and RUNW products by geocoding the unwrapped phase and associated data layers (i.e., coherence magnitude, ionospheric phase screen) on a geographical grid at 80 m posting."
