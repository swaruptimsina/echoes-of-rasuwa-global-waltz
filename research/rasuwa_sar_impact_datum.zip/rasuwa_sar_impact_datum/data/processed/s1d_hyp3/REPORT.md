# HyP3 Sentinel-1D coherence/InSAR assessment — Rasuwa

**Assessment date:** 15 November 2026  
**Event marker:** 2026-08-26 02:52:10 UTC  
**Source coordinate:** 85.528066°E, 28.291242°N  
**Fixed catalog AOI:** 85.34–85.55°E, 28.23–28.32°N  
**Outcome:** **Two real Sentinel-1D Burst InSAR products succeeded, were downloaded, extracted, hashed, and read back from HyP3.**

## Decision

Sentinel-1D is actually supported for HyP3 InSAR, not merely accepted by a filename regex. ASF documents Sentinel-1D support in the ISCE2 burst workflow.[1] Here the live API first accepted two Sentinel-1D pairs with `validate_only=true`, left credits and job count unchanged, then processed both submitted jobs to `SUCCEEDED`. Each delivered bundle names the requested burst pair and records `hyp3_isce2 3.0.2 / ISCE 2.6.5`.

The scientifically minimal choice was one ascending path-85 VV burst chain:

- **quiet null:** 4–16 August 2026;
- **event:** 16–28 August 2026, with the first post-event observation 2.395486 days after failure;
- same full burst footprint `085_180590_IW2`, 12-day intervals, identical processing, and a shared middle acquisition;
- source point covered and 96.8307% of the fixed AOI covered by each burst;
- delivered perpendicular baselines: **−32.287 m** (null) and **−4.509 m** (event).

At 20×4 looks, Burst InSAR has 80 m pixel spacing and 160 m nominal resolution.[1] The live `/costs` endpoint returned **1 credit per single-burst job**, consistent with ASF's credit table.[2] Total cost was **2 / 8,000 credits (0.025%)**; readback showed **7,998 credits remaining**.

## Account, schema, and no-cost validation

| Check | Live result |
|---|---|
| HyP3 Basic API | `https://hyp3-api.asf.alaska.edu`, version `10.19.1` |
| SDK | `hyp3-sdk 7.7.8` |
| Authenticated `/user` | yes; credentials/user ID were not stored |
| Credits before | 8,000 |
| Existing jobs before | 0 |
| `INSAR_ISCE_BURST` cost | 1 credit/job |
| `validate_only` result | HTTP 200; 2 accepted S1D jobs, predicted costs `[1,1]` |
| State after validation | 8,000 credits, 0 jobs |
| State after submission | 7,998 credits, 2 jobs |

Primary artifacts: `raw/hyp3_preflight.json`, `raw/hyp3_openapi.json`, `raw/hyp3_validate_{request,response,check}.json`, and `raw/hyp3_submit_{request,response}.json`.

## Same-track S1D chains found

Live ASF search returned 27 S1D IW SLC scenes over the source and three consecutive same-geometry event/null chains. Catalog-state-vector perpendicular baselines below are rounded screening estimates; signs are pair-order dependent. The selected path-85 values were superseded by the precise delivered-product metadata above.

| Path / direction / frame | Quiet pair | Event pair | Event pre/post offsets | Approx. B⊥ null / event |
|---|---|---|---:|---:|
| 19 / descending / 497 | 12 Aug `...6C82` → 24 Aug `...98CC` | 24 Aug `...98CC` → 5 Sep `...F6E1` | −2.1066 / +9.8934 d | −70 / −45 m |
| **85 / ascending / 88** | **4 Aug `...F90B` → 16 Aug `...0444`** | **16 Aug `...0444` → 28 Aug `...93F8`** | **−9.6045 / +2.3955 d** | +30 / +5 m |
| 121 / descending / 499 | 7 Aug `...29BF` → 19 Aug `...A244` | 19 Aug `...A244` → 31 Aug `...F814` | −7.1122 / +4.8878 d | −106 / +114 m |

### Exact full-scene IDs

**Path 19**

- `S1D_IW_SLC__1SDV_20260812T001843_20260812T001910_004085_007738_6C82`
- `S1D_IW_SLC__1SDV_20260824T001843_20260824T001910_004260_007D5D_98CC`
- `S1D_IW_SLC__1SDV_20260905T001843_20260905T001910_004435_00837B_F6E1`

**Path 85 — selected**

- `S1D_IW_SLC__1SDV_20260804T122139_20260804T122206_003976_00737A_F90B`
- `S1D_IW_SLC__1SDV_20260816T122139_20260816T122207_004151_007980_0444`
- `S1D_IW_SLC__1SDV_20260828T122140_20260828T122208_004326_007FA4_93F8`

**Path 121**

- `S1D_IW_SLC__1SDV_20260807T001035_20260807T001102_004012_0074B7_29BF`
- `S1D_IW_SLC__1SDV_20260819T001036_20260819T001102_004187_007ABD_A244`
- `S1D_IW_SLC__1SDV_20260831T001036_20260831T001103_004362_0080EC_F814`

The machine-readable full inventory, CMR IDs, coverage, event offsets, and baselines are in `pair_candidates.json`, `pair_candidates.csv`, and `burst_pair_plan.json`.

## Exact submitted jobs

```json
{
  "jobs": [
    {
      "name": "rasuwa-s1d-p085-quiet-null-int80-20260804-20260816",
      "job_type": "INSAR_ISCE_BURST",
      "job_parameters": {
        "granules": [
          "S1_180590_IW2_20260804T122147_VV_F90B-BURST",
          "S1_180590_IW2_20260816T122147_VV_0444-BURST"
        ],
        "looks": "20x4",
        "apply_water_mask": true
      }
    },
    {
      "name": "rasuwa-s1d-p085-event-int80-20260816-20260828",
      "job_type": "INSAR_ISCE_BURST",
      "job_parameters": {
        "granules": [
          "S1_180590_IW2_20260816T122147_VV_0444-BURST",
          "S1_180590_IW2_20260828T122148_VV_93F8-BURST"
        ],
        "looks": "20x4",
        "apply_water_mask": true
      }
    }
  ]
}
```

Applying the same water mask to both jobs constrains phase unwrapping; coherence remains a separately delivered normalized 0–1 observable. HyP3's burst package also supplies connected components, which delineate independently unwrapped SNAPHU regions.[1]

## Job IDs and delivered products

| Role | Job ID | Status | ZIP | Bytes | SHA-256 |
|---|---|---|---|---:|---|
| Quiet null | `c5213bc1-2ff5-43c0-9483-99d106562b25` | `SUCCEEDED` | `S1_180590_IW2_20260804_20260816_VV_INT80_6E13.zip` | 17,046,625 | `52cacee117afee52a78c935481cf5a8fb44a162d319cb7971ec631a05d85d3ad` |
| Event | `aa593933-5823-4d79-bf61-8957a1dd080b` | `SUCCEEDED` | `S1_180590_IW2_20260816_20260828_VV_INT80_765B.zip` | 17,052,047 | `e0047be0cf79e347cd0c59ad6f45fe5dcbaa08ac5b92e131b9d93769f3461234` |

Readback was verified at 07:31:46 UTC. HyP3 service links expire 30 November 2026, but both ZIPs and all extracted files are local under `products/`. `product_manifest.json` records API sizes and SHA-256 for both archives and all 30 extracted files.

Each single-burst bundle contains:

- normalized coherence (`_corr.tif`, 0–1);
- wrapped and unwrapped geocoded phase (`_wrapped_phase.tif`, `_unw_phase.tif`);
- SNAPHU connected components (`_conncomp.tif`);
- geocoded look-vector θ/φ, GLO-30 DEM, and water mask;
- native range-Doppler complex wrapped interferogram, two-band look vectors (`_los_rdr.tif`), latitude, and longitude;
- browse PNG, parameter file, and README.

`_los_rdr.tif` is a radar-coordinate look-vector file, **not** a LOS-displacement raster. The single-burst package does not contain an amplitude image, a geocoded LOS displacement layer, or an atmospheric correction.

## Initial C-band coherence result

This is a descriptive feasibility check against the inherited preliminary UNOSAT optical detachment polygon, not a final landslide classification or displacement solution.

| Region/metric | Quiet 4–16 Aug | Event 16–28 Aug | Event − quiet |
|---|---:|---:|---:|
| Detachment median coherence | 0.5129 | 0.3950 | paired-pixel median **−0.1313** |
| Source-coordinate coherence | 0.5129 | 0.2859 | — |
| Detachment coherence-valid land pixels | 307/307 | 307/307 | 307 common |
| Detachment unwrapped/component-valid land pixels | 307/307 | 293/307 | — |
| Local 0.3–1.5 km control-ring median paired change | — | — | **+0.1841** |
| Detachment change minus local-control change | — | — | **−0.3155** |

Within the 307 common detachment pixels, 73.62% had lower event-pair than quiet-pair coherence. In contrast, coherence generally rose in the local ring and wider AOI in the event pair. This spatially localized relative loss is consistent with a real coherence change at the independently mapped detachment, but it does **not** identify a unique physical cause or a surveyed boundary.

Critical limits:

1. The burst bundle has no explicit layover/shadow or local-incidence validity layer. The apparently high C-band valid fraction is therefore not equivalent to terrain-screened observability.
2. Pixels are spatially correlated; no pixelwise p-value or independent-sample claim is made.
3. The two products have an 80 m northing-grid offset. Quiet coherence was bilinearly reprojected to the event grid; masks were nearest-neighbor resampled.
4. Nodata was censored and reported through a separate coverage denominator, never converted to zero coherence.
5. Unwrapped phase was not subtracted: each pair has an independent phase reference and may contain atmosphere, DEM residuals, glacier motion, snow/moisture change, and unwrapping error.
6. The event and null baselines and acquisition conditions differ even though their temporal spans and processing match.

Outputs: `analysis/coherence_comparison.json`, `analysis/coherence_region_summary.csv`, `analysis/coherence_event_minus_quiet.tif`, `analysis/coherence_pair_valid_mask.tif`, and `analysis/coherence_comparison.png`.

## Comparison with NISAR GUNW

NISAR GUNW is an 80 m unwrapped-phase product generated only for co-polarized nearest-neighbor 12-day pairs.[3] It includes 20 m and 80 m normalized coherence, 80 m unwrapped phase, a 20 m geocoded complex wrapped interferogram, connected components, offsets, an ionosphere phase screen and uncertainty, and external-correction lookup tables.[3]

The event-period NISAR products remain **PROVISIONAL**. Although validated NISAR L0–L2 collections began in November 2026, they start with acquisitions on 21 October; August data await later validated reprocessing.[4]

### Actual Rasuwa GUNW constraints

- The almost time-matched descending track-48 GUNW (`NISAR_L2_PR_GUNW_028_048_D_074_029_2000_SH_20260816T125812_20260816T125846_20260828T125812_20260828T125846_P05023_N_F_J_001`) was acquired only 36 min 24 s / 36 min 23 s after the C-band reference/secondary observations, but its inspected source window had **zero pixels passing both NISAR subswath-validity conditions**.
- The usable ascending track-98 GUNW (`NISAR_L2_PR_GUNW_028_098_A_016_029_4000_SH_20260819T233918_20260819T233953_20260831T233918_20260831T233952_P05023_N_F_J_001`) spans 19–31 August. In the sibling NISAR source subset it had coherence median **0.1021**, but only **9/528 (1.70%)** pixels had connected unwrapped phase; its polarization is HH, versus S1D VV.
- All eight inspected NISAR QA sidecars in the sibling analysis had at least one failed identification-group check. That prevents presenting the event product as a clean mission-QA pass.

### Layer parity and required comparison gate

| Requirement | Delivered S1D Burst InSAR | NISAR GUNW | Consequence |
|---|---|---|---|
| 12-day co-pol pair | VV, 12 d | HH, 12 d | Match interval, not wavelength/polarization |
| Normalized coherence | 80 m, 0–1 | 20 m and 80 m, 0–1 | Compare on common 80 m grid |
| Unwrapped phase | 80 m radians | 80 m radians | Require finite values and component continuity |
| Connected components | yes | yes | Never bridge or subtract across components |
| Wrapped product | 80 m phase + native complex radar burst | 20 m geocoded complex interferogram | Not layer-equivalent |
| Validity mask | water mask + nodata only | encoded water/subswath/anomaly/ionosphere flags | Decode NISAR mask; add independent C-band terrain screening |
| Ionosphere layer/uncertainty | absent | present | Raw phase corrections are not comparable |
| Tide/troposphere LUTs | absent | present when available, not pre-applied | Apply/document corrections before deformation claims |
| Pixel offsets | absent | included in GUNW; GOFF adds multiscale offsets | No ordered C-band counterpart |

A defensible C/L comparison must first compute event-minus-quiet coherence **within each sensor**, then compare the spatial contrasts. It must preserve masks and nodata, report full-reference coverage and valid-pixel statistics separately, require connected-component continuity, use an explicit steep-terrain screen, and avoid treating absolute C- and L-band coherence as interchangeable.

Machine-readable parity and the exact sibling-artifact inputs are in `nisar_comparison.json`.

## Exact rerun/readback route

From this directory:

```bash
# Query live account, costs, jobs, and OpenAPI without spending credits.
PYTHONPATH=.venv/lib/python3.12/site-packages \
  /home/safal0715/Documents/research/.venv/bin/python scripts/query_hyp3_preflight.py

# Rebuild scene/burst inventories and baseline screening.
/home/safal0715/Documents/research/.venv/bin/python scripts/build_pair_plan.py
/home/safal0715/Documents/research/.venv/bin/python scripts/build_burst_plan.py

# Re-run no-cost validation; verifies no account state change.
PYTHONPATH=.venv/lib/python3.12/site-packages \
  /home/safal0715/Documents/research/.venv/bin/python scripts/validate_jobs.py

# Existing jobs: read back and verify/download; do NOT resubmit.
PYTHONPATH=.venv/lib/python3.12/site-packages \
  /home/safal0715/Documents/research/.venv/bin/python scripts/monitor_download.py --timeout 60 --interval 5

# Reproduce descriptive analysis and NISAR comparison.
/home/safal0715/Documents/research/.venv/bin/python scripts/analyze_products.py
/home/safal0715/Documents/research/.venv/bin/python scripts/compare_nisar_requirements.py
```

`submit_jobs.py` is intentionally one-shot and refuses to run while `submitted_jobs.json` exists. For a genuinely new deployment/account, first replay `raw/hyp3_validate_request.json`, confirm credits and zero duplicate names, then submit the identical jobs with `validate_only=false` as recorded in `raw/hyp3_submit_request.json`. Expected cost is exactly 2 credits.

## Diagnosed issues

- `asf_search 10.2.0` retrieves S1D scenes and bursts but does not map the new `SENTINEL-1D_SLC` collection to `S1Product`; its automatic stack platform list also omits S1D. `build_pair_plan.py` filters metadata duplicates and explicitly casts science SLCs before state-vector baseline calculation. HyP3 itself processed S1D successfully.
- The external image-vision endpoint returned HTTP 401, so the generated quicklook was not replaced by an invented visual review. Numeric raster/grid checks and readback completed successfully.
- Direct shell access to some GitHub hosts was intermittent; authoritative documents were retrieved through the web extractor and pinned to repository commits in `sources/`.

## Sources

[1] https://raw.githubusercontent.com/ASFHyP3/hyp3-docs/4e3545b5b6bed39ee3c7d557c4649c4968215868/docs/guides/burst_insar_product_guide.md — ASF HyP3 Sentinel-1 Burst InSAR Product Guide
    > "ISCE2 has been updated to support processing of data collected by Sentinel-1D."
    > "Images are resampled to a pixel size that reflects the resolution of the output image based on the requested number of looks: 80 meters for 20x4 looks, 40 meters for 10x2 looks, and 20 meters for 5x1 looks."
    > "The *normalized coherence* file contains pixel values that range from 0.0 to 1.0, with 0.0 being completely non-coherent and 1.0 being perfectly coherent."
    > "The *connected components* file delineates regions unwrapped as contiguous units by the SNAPHU unwrapping algorithm."
[2] https://raw.githubusercontent.com/ASFHyP3/hyp3-docs/4e3545b5b6bed39ee3c7d557c4649c4968215868/docs/using/credits.md — ASF HyP3 credit costs
    > "| {{ table_indent(count=2) }} 1–4 pairs                         |       1        |          {{ hyp3_plus_cost(1) }}           |                {{ max_jobs_per_month(1) }}                 |"
[3] https://raw.githubusercontent.com/ua-asf/nisar-docs/fdd7665759e4698273c016775526b40e4aff9990/data-products/level-2/gunw.md — ASF NISAR GUNW product guide
    > "The GUNW product is an L2 product derived from the [RIFG](#rifg-product-overview) and [RUNW](#runw-product-overview) products by geocoding the unwrapped phase and associated data layers (i.e., coherence magnitude, ionospheric phase screen) on a geographical grid at 80 m posting."
    > "The GUNW products also include the wrapped complex interferogram (multi-looked at 30 m in range-Doppler coordinates and geocoded at 20-m posting), the unwrapped interferometric phase in radians (80-m posting), the normalized interferometric coherence magnitude (20-m and 80-m posting), connected components mask, and sub-pixel offset layers obtained from incoherent cross-correlation."
    > "The GUNW product also includes an ionospheric phase screen layer from the RUNW product and a layer quantifying its uncertainty."
[4] https://raw.githubusercontent.com/ua-asf/nisar-docs/fdd7665759e4698273c016775526b40e4aff9990/data-availability/availability-overview.md — ASF NISAR data availability
    > "NISAR PROVISIONAL datasets were released July 20, 2026. These products are fully calibrated and have undergone validation at a limited set of sites around the world."
    > "NISAR VALIDATED datasets were released November 6, 2026. These products are fully calibrated and validated, and collections are available for all mission products from Level 0 through Level 2. VALIDATED collections include products for all L-band NISAR acquisitions starting October 21, 2026."
