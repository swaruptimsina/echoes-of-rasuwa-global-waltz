# Candidate connected upper Bhote Koshi–Lhende–Langtang–Trishuli AOI

**Status:** Candidate for technical review; not an official basin, legal boundary, evacuation zone, or operational warning product.  
**Generated:** 2026-11-15 UTC  
**Primary polygon:** `/home/safal0715/Documents/research/_subagents2/aoi/outputs/connected_system_aoi.geojson`

## Recommendation

Use the unsimplified **4,774.048 km² connected catchment** as the expanded analysis AOI. It is the union of the 37 HydroBASINS level-12 units that drain to the official pour point of `HYBAS_ID=4120833490` at **85.110416666667°E, 27.864583333333°N**, on the upper Trishuli immediately upstream of the first HydroBASINS unit shared with Tadi Khola at Devighat.[1][15]

This is preferable to a hand-drawn box because HydroBASINS supplies explicit `NEXT_DOWN` topology and nested basin polygons derived at 15 arc-second resolution.[1][5]

Its accompanying pour-point layer defines each point from the highest-flow-accumulation grid cell within the sub-basin.[15]

The official 2026 CHWRR assessment identifies the event path as upper Lhende/Chhochen → Bhote Koshi → Trishuli, which is why the Lhende–Chhochen branch is retained as a named sub-area rather than treated as an isolated scene footprint.[7]

Use the separate 750 m buffered **Devighat corridor supplement** only for infrastructure/context display. It follows 15.270 km of five real HydroRIVERS reaches downstream of the catchment outlet; it is not a watershed and is excluded from every area total.[2][6]

## Delineation method and checks

1. Downloaded HydroBASINS Asia level 12 v1c and built the reverse graph of all `NEXT_DOWN` links.[1][5]
2. Selected `HYBAS_ID=4120833490` and recursively retained every upstream level-12 unit: **37 units**.[1][5]
3. Unioned their original WGS 84 polygons without a bounding-box clip.
4. Extracted all HydroRIVERS reaches whose `HYBAS_L12` belongs to those units. HydroRIVERS represents rivers meeting a ≥10 km² catchment or ≥0.1 m³/s average-flow threshold and is co-registered to HydroBASINS.[2][6]
5. Verified **640 reaches, 1,571.60 km total mapped reach length, one egress, and zero graph cycles**. The single egress reach has `UPLAND_SKM=4781.3`, matching the selected HydroBASINS upstream-area attribute.[2][6]
6. Partitioned the same 37 units into five disjoint named sub-areas. Pairwise overlap is 0 km² and the partition/full-polygon symmetric difference is 0 km².[1][5]
7. Independently sampled five Copernicus GLO-30 public COG tiles. Copernicus GLO-30 is a 30 m digital **surface** model, so it corroborates relief but does not redefine the hydrologically conditioned HydroBASINS boundary.[3]
8. Subset the 2017–2024 Glacial Lake Observatory v1.02 Sentinel-2 unique-lake polygons by representative coordinate. Those polygons are dissolved maximum observed extents, not one-date lake surfaces.[11][12][13]
9. Queried current OSM names, settlements, bridges, waterways, and waterbodies through the read-only Overpass API; the retained GeoJSON represents element centres for context, while the raw responses preserve the queried source data.[4]

## Outlet and included/excluded drainage

### Chosen outlet

| Item | Value |
|---|---:|
| HydroBASINS unit | `4120833490` |
| Official pour point | `85.110416666667, 27.864583333333` |
| Copernicus DSM elevation at point | 473.0 m |
| HydroBASINS `UP_AREA` | 4,781.3 km² |
| Sum of selected `SUB_AREA` values | 4,781.0 km² |
| WGS 84 ellipsoidal area of union | 4,774.048 km² |
| Difference, attribute vs geometric | 7.252 km² (0.152%) |
| `NEXT_DOWN` | `4120835140` |

The outlet was deliberately placed **above Tadi Khola**. The Tadi branch unit `4120833730` has `UP_AREA=672.8 km²` and the same `NEXT_DOWN=4120835140` as the selected Trishuli outlet. Thus the two branches first join in the next downstream HydroBASINS unit, and Tadi is topologically excluded rather than removed by visual clipping.[1][5][15]

### Included

- **Kyirong Tsangpo headwaters.** They are required for a complete catchment at the selected outlet: Kyirong and Lhende both pour into `HYBAS_ID=4120824370` above Rasuwagadhi. Omitting Kyirong would produce an event-source polygon, not the full connected-system catchment.[1][5]
- **Lhende–Chhochen glaciated headwaters**, including the cross-border source branch emphasized by CHWRR.[7]
- **Langtang Khola**, plus the Langtang valley and high slopes.
- **Rasuwa local tributaries and slopes**, including the Rasuwagadhi–Timure–Syabrubesi/Thulo Syabru–Dhunche–Mailung sequence and the Gosainkunda highlands.
- **Upper Trishuli to the selected outlet**, including Betrawati and Bidur.

### Excluded

- **Tadi Khola** (`HYBAS_ID=4120833730`, `UP_AREA=672.8 km²`), because it joins in the next downstream unit.[1][5]
- **Lower Trishuli, Narayani, Budhi Gandaki, Marsyangdi, and other downstream branches**, because they are downstream or join below the selected outlet.
- **Nearby Tibetan endorheic units** that are spatially close but have a different sink/topology.
- **Devighat below the outlet** from catchment-area calculations. Devighat and the OSM `devighat-Tadi bridge` are carried only in the clearly labelled corridor supplement.

## Five named sub-areas

These are a complete, non-overlapping partition of the candidate catchment, not independent overlapping buffers.[1][5]

| ID | Name | Units | Geodesic area (km²) | Nepal / China | Median DSM (m) | GLO lakes |
|---|---|---:|---:|---:|---:|---:|
| `kyirong_headwaters` | Kyirong Tsangpo cross-border headwaters | 17 | 2,163.950 | 0.41% / 99.59% | 4,778.8 | 65 |
| `lhende_chhochen_headwaters` | Lhende–Chhochen glaciated headwaters | 7 | 917.159 | 5.45% / 94.55% | 5,001.8 | 123 |
| `langtang_khola` | Langtang Khola headwaters and valley | 4 | 586.873 | 84.39% / 15.61% | 4,887.6 | 51 |
| `rasuwa_upper_corridor` | Rasuwagadhi–Syabrubesi–Dhunche corridor and local slopes | 5 | 555.962 | 75.20% / 24.80% | 3,263.5 | 31 |
| `lower_trishuli_corridor` | Mailung–Betrawati–Bidur lower upper-Trishuli corridor and slopes | 4 | 550.104 | 100% / 0% | 1,808.6 | 2 |
| **Total** |  | **37** | **4,774.048** | 31.89% / 68.11% | 4,598.7 | **272** |

The first three are tributary catchments. The last two are incremental interbasin partitions made by subtracting the upstream tributary closures from successive main-stem closures; they should not be interpreted as separately gauged watersheds.[1][5]

## Cross-border geography

Using mutually exclusive Natural Earth 1:10m de facto country polygons, **3,251.709 km² (68.11%)** is on the China side and **1,522.339 km² (31.89%)** is on the Nepal side. Natural Earth explicitly describes its country layer as a de facto representation, so this split is analytical, not a statement on legal jurisdiction.[14]

A sensitivity check with independently authored geoBoundaries Nepal and China ADM0 layers produced **933.135 km² of overlap inside this AOI**. The API documents source-specific gbOpen boundary layers and licences.[8][9][10] Those independent intersections were therefore not summed; the mutually exclusive Natural Earth layer was used for reported percentages. Any legal or operational cross-border use requires an agreed authoritative boundary.

Hydrologically, the most important implication is that both Kyirong and Lhende headwaters are mostly north of the mapped international boundary, while the Langtang and lower Trishuli sub-areas are mostly or wholly in Nepal. A Nepal-only AOI would omit most upstream contributing area.[1][14]

## DEM evidence

The processed Copernicus GLO-30 raster contains **5,699,685 valid in-polygon pixels**.[3]

| Statistic | Elevation |
|---|---:|
| Minimum | 460.0 m |
| P10 | 2,274.5 m |
| Median | 4,598.7 m |
| P90 | 5,551.6 m |
| Maximum | 7,282.8 m |
| Area-sample pixels ≥3,000 m | 82.85% |
| Area-sample pixels ≥4,000 m | 68.55% |
| Area-sample pixels ≥5,000 m | 34.09% |

At 1 km spacing, 449 samples along the mapped catchment boundary have a median elevation of **5,508.9 m**. Excluding a 5 km neighbourhood around the outlet raises the boundary median to **5,523.6 m**, with 76.26% of samples above 5,000 m. In contrast, the main control elevations descend from 2,012.5 m at the Kyirong pour point and 1,826.7 m at the Lhende pour point to 1,470.7 m at Langtang, 931.1 m at the upper-corridor control, and 473.0 m at the final outlet.[3][15]

This high-divide/low-channel contrast is consistent with a connected high-relief basin.

This is supporting evidence, not an independent flow-direction delineation. GLO-30 is a DSM containing vegetation and built surfaces, is not depression-filled for hydrology, and cannot resolve valley hydraulics or sub-grid diversions by itself.[3]

## Glacial lakes and downstream context

The GLO subset contains **272 unique Sentinel-2 lake maximum extents**, including **193 glacier-fed** and **79 non-glacier-fed** classifications, with 9.989 km² summed dissolved maximum extent.[11][12][13]

It includes 191 lake IDs assigned to China and 81 to Nepal. Thirty-one have a source significance flag of `TRUE` for 2017–2024 expansion.[12][13]

The source README reports automated classification, resolution/date/freezing limitations, and validation metrics; this output retains its classifications rather than treating every high-elevation water polygon as equally hazardous.[11][12][13]

One selected GLO feature carries the source basin label `Koshi` while the other 271 are labelled `Gandaki`. Because its representative coordinate falls inside the topology-derived Trishuli polygon, it is retained and flagged as a cross-dataset boundary/classification mismatch rather than silently discarded.[12][13]

OSM context confirms named locations inside the catchment such as Rasuwa Gadhi, Timure, Thulo Syabru, Dhunche, Langtang, Mailung, Betrawati, Bidur, and Gosaikunda. Devighat and the `devighat-Tadi bridge` lie just below the catchment outlet and are marked `corridor_supplement_only=true`. OSM is community-maintained and incomplete; these points are for indexing and map context, not a definitive asset inventory.[4]

## Uncertainty and appropriate use

- **HydroBASINS boundary precision:** level 12 is derived from 15 arc-second HydroSHEDS/SRTM hydrography, roughly 500 m at the equator. It is appropriate for a regional AOI, not parcel-scale or hydraulic modelling.[1][5]
- **Pour-point precision:** coordinates are centres of HydroSHEDS flow-accumulation cells. Decimal precision in the file is not equivalent to surveyed accuracy.[15]
- **Area:** the 0.152% difference between HydroBASINS `UP_AREA` and the WGS 84 geometric union reflects source attributes, polygon discretisation, and area method.[1][5]
- **Political boundary:** the reported Nepal/China percentages depend on Natural Earth's de facto 1:10m representation. The geoBoundaries overlap test demonstrates material boundary-source sensitivity.[8][14]
- **DEM:** Copernicus is a DSM, not a hydrologically conditioned DTM. Terrain statistics support the divide but do not prove every local flow path.[3]
- **Lakes:** GLO polygons are merged 2017–2024 maximum extents; they are not contemporaneous 2026 surfaces and do not by themselves establish outburst hazard.[11][12][13]
- **OSM:** names and bridge/settlement completeness vary. Raw Overpass responses and OSM timestamps are retained for audit.[4]
- **Operational use:** local hydrologist review, a finer conditioned flow-direction product, surveyed/gauge cross-sections, and event-specific hydraulic routing are still required before warning, inundation, or infrastructure decisions.

## Exact deliverables

### Candidate geometry

- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/connected_system_aoi.geojson` — authoritative candidate geometry from this run.
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/connected_system_aoi_simplified.geojson` — display-only simplification.
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/named_subareas.geojson` — five named polygons.
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/outlet_and_pour_points.geojson` — system, tributary, excluded-Tadi, and downstream reference points.
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/downstream_corridor_supplement.geojson` — clearly labelled non-catchment 750 m river corridor.
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/downstream_corridor_centerline.geojson` — five source reaches used for the supplement.

### Evidence layers and audit products

- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/hydrorivers_connected_network.geojson`
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/glacial_lakes_glo_s2_2017_2024.geojson`
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/osm_named_context.geojson`
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/copernicus_glo30_connected_system_masked.tif`
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/dem_evidence.json`
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/selection_diagnostics.json`
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/geojson_validation.json`
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/source_metadata.json` — 29 source records with exact URLs, local paths, byte sizes, SHA-256, MD5, versions, roles, and licences.
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/subareas_summary.csv`
- `/home/safal0715/Documents/research/_subagents2/aoi/outputs/connected_system_preview.png`
- `/home/safal0715/Documents/research/_subagents2/aoi/scripts/process_connected_aoi.py` — reproducible processing script.

## Core source downloads and hashes

The complete 29-record ledger is in `outputs/source_metadata.json`. Core inputs are:

| Product | Exact URL | SHA-256 |
|---|---|---|
| HydroBASINS Asia L12 v1c | `https://data.hydrosheds.org/file/HydroBASINS/standard/hybas_as_lev12_v1c.zip` | `05e98a001fc526cd5fcdbbc8144fe0aa3ce6712c35624f72e4728b219193fdb9` |
| HydroBASINS L12 pour points | `https://data.hydrosheds.org/file/hydrobasins/pour_point/hybas_pour_lev12_v1_shp.zip` | `73d1b2befac117b9cec00363249d52036c35e582e4e35a6dd16461745f472639` |
| HydroRIVERS Asia v1.0 | `https://data.hydrosheds.org/file/HydroRIVERS/HydroRIVERS_v10_as_shp.zip` | `29780b0a75f90024f22e7e2029e5e3045f7325cda0528db65c5cc4c864b98525` |
| GLO S2 unique lakes v1.02 | `https://zenodo.org/api/records/19370146/files/S2_20172024_NTB_GLOID_UniqueLakes_v1.02.gpkg/content` | `e5f30a066a5b465525bade9ade002c6202a67a82517088a62fc9929e034a12e8` |
| Natural Earth Admin 0 v5.1.1 | `https://naturalearth.s3.amazonaws.com/10m_cultural/ne_10m_admin_0_countries.zip` | `ce1ac7036499a0edd641fbc093cd209a98f96a49d2eca8480aaacad35138a7f6` |
| OSM context response | `https://overpass-api.de/api/interpreter` (POST query retained as `raw/osm_context_query.ql`) | `aff84063fcd15f46c6aa80e69e07a6190803d38072b43c45233471ddfb628143` |
| OSM water response | `https://overpass-api.de/api/interpreter` (POST query retained as `raw/osm_water_query.ql`) | `d45e354d36507242ad12bf7c92bc5814338e1a2d6bfe4dfcb866059624eeea64` |

Copernicus GLO-30 source tiles and SHA-256 values:

- `https://copernicus-dem-30m.s3.amazonaws.com/Copernicus_DSM_COG_10_N27_00_E084_00_DEM/Copernicus_DSM_COG_10_N27_00_E084_00_DEM.tif` — `66ae02e02fff0bcc1455717c1a5d6199c5ad3d00f96a1a94c10b74f3301d122a`
- `https://copernicus-dem-30m.s3.amazonaws.com/Copernicus_DSM_COG_10_N27_00_E085_00_DEM/Copernicus_DSM_COG_10_N27_00_E085_00_DEM.tif` — `5a0ec09cda62bcacfccacae0724e6493bee8f3f6fe11fb0ef47ccf3fa3716194`
- `https://copernicus-dem-30m.s3.amazonaws.com/Copernicus_DSM_COG_10_N28_00_E084_00_DEM/Copernicus_DSM_COG_10_N28_00_E084_00_DEM.tif` — `4df89793d0dc6373deb9c27536a1d7039ec4a9962a699a2312f57c935fbbe6dc`
- `https://copernicus-dem-30m.s3.amazonaws.com/Copernicus_DSM_COG_10_N28_00_E085_00_DEM/Copernicus_DSM_COG_10_N28_00_E085_00_DEM.tif` — `1590255a0ae7e8c1f49b277e287032a18a2e32c8e13c4c3298ed458f851cd3c7`
- `https://copernicus-dem-30m.s3.amazonaws.com/Copernicus_DSM_COG_10_N29_00_E085_00_DEM/Copernicus_DSM_COG_10_N29_00_E085_00_DEM.tif` — `8fe8cf7b253bea4981e0b4e4e417a6e7676d720fec7c8a03c341c30dc2624a2a`

## Sources

[1] https://www.hydrosheds.org/products/hydrobasins
[2] https://www.hydrosheds.org/products/hydrorivers
[3] https://registry.opendata.aws/copernicus-dem
[4] https://wiki.openstreetmap.org/wiki/Overpass_API
[5] https://data.hydrosheds.org/file/technical-documentation/HydroBASINS_TechDoc_v1c.pdf
[6] https://data.hydrosheds.org/file/technical-documentation/HydroRIVERS_TechDoc_v10.pdf
[7] https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR_hnmns6o.pdf
[8] https://www.geoboundaries.org/api.html
[9] https://www.geoboundaries.org/api/current/gbOpen/NPL/ADM0
[10] https://www.geoboundaries.org/api/current/gbOpen/CHN/ADM0
[11] https://doi.org/10.5194/essd-18-5143-2026
[12] https://doi.org/10.5281/zenodo.17802333
[13] https://zenodo.org/records/19370146
[14] https://www.naturalearthdata.com/downloads/10m-cultural-vectors/10m-admin-0-countries
[15] https://data.hydrosheds.org/file/hydrobasins/pour_point/HydroBASINS_PourPoint_TechDoc_v1.pdf
