# Broad Rasuwa connected-system SAR metadata inventory

**Catalog snapshot:** 2026-11-15  
**Acquisition window:** `2024-11-15T00:00:00Z` through `2026-11-15T23:59:59Z`  
**Authoritative table:** `inventory.csv` — **12,931 unique CMR granule concepts**

## Exact AOI

The search AOI is the deliberately broad WGS84 rectangle:

- **BBox:** `[84.30, 27.50, 85.75, 28.50]` (west, south, east, north)
- **WKT:** `POLYGON((84.30 27.50,85.75 27.50,85.75 28.50,84.30 28.50,84.30 27.50))`
- **Approximate dimensions:** 142.360 km × 111.195 km

It encloses the Purepu/upper-Lhende source area, Langtang Lirung and Rasuwa, and the downstream Trishuli corridor through the Narayani transition. This is a footprint-intersection inventory, so a returned scene can extend well outside the river corridor. The exact polygon and anchor coordinates are retained in `aoi.geojson` and `config.json`.

## Method and integrity

CMR collection discovery used broad mission/SAR terms, then selected 69 direct or clearly SAR-derived collections from 380 unique collection records. Every selected collection was queried separately. CMR granules were harvested with the documented `CMR-Search-After` header and `page_size=200`; Search After is NASA's preferred deep-paging method.[1]

ASF searches used the documented dataset, processing-level, polygon, time, GeoJSON, and count outputs.[2] Every ASF result set was checked against `output=count`; large Sentinel-1 burst, OPERA RTC, and SMAP result sets were divided into count-checked 90-day temporal pages, following ASF's recommendation to split date ranges when needed.[4]

The final inventory was deduplicated by exact CMR granule concept ID, then ASF features were joined by collection and exact scene/file identifiers. The join matched **11,981 ASF features to CMR records**, with **zero ASF-only or ambiguous rows**. The remaining **950 records are CMR-only**. `catalog_crosswalk.csv` preserves the reconciliation.

Machine validation (`validation.json`) passed:

- 253 retained raw responses; 221,843,969 bytes hashed and reparsed.
- 82 CMR paginated query chains; 11 required multiple pages.
- 12,931 inventory rows = 12,931 unique CMR granule concept IDs.
- Every reported count matches its raw response.
- Every producer granule ID, URL-table reference, and raw SHA-256 matches.
- 330,625 normalized URL records are retained in `granule_urls.csv`.

## Inventory results

Counts are **product granules**, not independent overpasses. Sentinel-1 bursts, OPERA bursts/tiles, interferometric pairs, revised NISAR maturities, and SMAP swaths can multiply records for one acquisition period.

| Mission/product family | Granules | Result |
|---|---:|---|
| NISAR all selected science levels/maturities | 1,377 | L0B 112; L1 536; L2 615; L3 114 |
| Sentinel-1 full-scene SLC | 471 | S1A 377; S1D 94; S1B/S1C zero |
| Sentinel-1 GRD | 414 | dual-pol high-resolution only: S1A 333; S1D 81 |
| Sentinel-1 RAW (additional discovery) | 472 | S1A 378; S1D 94 |
| Sentinel-1 SLC bursts (additional discovery) | 5,536 | Burst/polarization child products |
| OPERA RTC-S1 | 2,766 | Burst products |
| OPERA DSWx-S1 | 883 | PO.DAAC MGRS-tile products |
| OPERA DIST-ALERT-S1 (additional discovery) | 67 | CMR-only in this run |
| ALOS-2 PALSAR-2 ScanSAR L1.1 | 21 | CMR and ASF agree |
| ARIA Sentinel-1 GUNW (additional discovery) | 18 | CMR and ASF agree |
| SMAP L1A radar receive-only (additional discovery) | 906 | Near-global swath geometry; not proof of localized imaging |
| SAOCOM | 0 | CMR collection stub has zero global granules; ASF probe rejected |
| RCM | 0 | CMR collection stub has zero global granules; ASF probe rejected |

### NISAR L/S, levels, and maturities

The 1,377 NISAR rows cover `RRSD`, `RSLC`, `RIFG`, `RUNW`, `ROFF`, `GSLC`, `GCOV`, `GUNW`, `GOFF`, and `SME2`, across Beta (248), Provisional (889), Validated (65), and Urgent Response (175). All 1,377 returned granules identify the actual sensor as **L-SAR** and carry `jointObservation=TRUE`.

`jointObservation=TRUE` means that the L-band product was acquired during a simultaneous L/S observation; it is not an S-band product file. ASF's API documentation and NISAR availability guide direct users to ISRO Bhoonidhi for S-band products.[2][5] Therefore the dedicated S-band result is reported as **not distributed by CMR/ASF**, not as “NISAR made zero S-band observations.”

The collection sweep also records honest zero-result maturities: validated RIFG/RUNW/ROFF/GOFF/GUNW, provisional/validated CRSD, and validated SME2 (no collection was available). The NISAR guide says validated Level 0–2 L-band collections were released in November 2026 and validated SME2 was not yet available.[5]

### Sentinel-1 and derived C-band products

Only Sentinel-1A and Sentinel-1D returned full-scene SLC/GRD/RAW granules in this AOI/window. Sentinel-1B and Sentinel-1C collections were still queried and are preserved as accepted zero-result searches. The inventory includes exact orbit, relative track/path, frame, direction, polarization, beam/swath, acquisition times, and product URLs wherever the source metadata expose them.

OPERA RTC and DSWx were both positive. OPERA CSLC-S1 and DISP-S1 collections were queried but returned zero CMR granules for the AOI/window; ASF also returned zero for CSLC and accepted-but-zero capability probes for DSWx/DISP. ARIA GUNW and OPERA DIST-ALERT-S1 were retained as additional open SAR-derived products discovered during the sweep.

### ALOS-2, SAOCOM, RCM, and other open archives

ALOS-2 returned 21 exact ScanSAR L1.1 records, and CMR/ASF scene sets matched. SAOCOM and RCM each had a visible CMR federated collection with zero global granules. Their ASF dataset probes returned HTTP 500 after retries, and the raw gateway bodies are retained. These are **unsupported/archive failures**, not zero-acquisition evidence.

ASF accepted but returned zero window results for ALOS PALSAR, UAVSAR, RADARSAT-1, ERS, JERS-1, AIRSAR, SEASAT, and SIR-C. `archive_status.csv` distinguishes supported-zero searches, populated collections with local zero results, global-zero collection stubs, and rejected/unsupported probes.

## Access and login

Metadata searches were public and unauthenticated. Every granule carries `metadata_access`, `data_access`, `login_required`, and `access_notes`. ASF documents that file downloads require NASA Earthdata Login, with extra research agreements for JERS-1 and RADARSAT-1.[3] The inventory retains HTTPS, S3, browse, metadata, quality, and service URLs without embedding credentials.

## Files

| File | Purpose |
|---|---|
| `inventory.csv` | Canonical one-row-per-granule inventory with IDs, platform/band, polarization, orbit/track/direction, times, product/maturity, access, primary URLs, attributes, and notes |
| `granule_urls.csv` | Lossless normalized URL table (330,625 rows) |
| `collections.csv` | 69 selected collections, global counts, AOI/window counts, access, and zero results |
| `discovered_collections.csv` | 380 deduplicated discovery records with selection/exclusion reasons |
| `queries.csv` | Every exact request URL, page/partition, HTTP status, counts, Search-After token, raw path, SHA-256, and error |
| `asf_queries.csv` | Count-validated ASF query summary |
| `catalog_crosswalk.csv` | Exact ASF-to-CMR scene reconciliation |
| `archive_status.csv` | Positive, supported-zero, global-zero, and unsupported results |
| `field_completeness.csv` | Per-collection availability of orbit/track/direction/polarization/URL fields |
| `summary.json`, `report_stats.json` | Machine-readable aggregate results |
| `validation.json` | Executed validation result |
| `raw/cmr/`, `raw/asf/` | Unmodified response bodies |
| `scripts/build_inventory.py` | Rebuilds discovery, pagination, normalization, dedupe, and outputs |
| `scripts/refresh_normalized_fields.py` | Recomputes normalized polarization fields in an existing snapshot from retained exact attributes |
| `scripts/validate_inventory.py` | Rehashes/reparses raw responses and checks all invariants |
| `scripts/summarize_inventory.py` | Builds compact statistics and field-completeness output |

## Limitations

- Intersection is based on catalog geometry, not guaranteed valid pixels over every connected-system feature.
- Product counts are not unique acquisitions. `producer_granule_id` and acquisition fields must be used for acquisition-level grouping.
- Blank orbit/track/direction cells mean the source UMM/ASF record did not expose that field; they were not guessed. DSWx-S1 and DIST-ALERT-S1 are notable examples.
- SMAP receive-only swaths have near-global footprints and centers frequently far from Nepal; they are retained as a discovered open L-band radar product with an explicit caution.
- No imagery was downloaded or interpreted, and no national/commercial catalog outside CMR/ASF/Bhoonidhi was enumerated.

## Sources

[1] https://cmr.earthdata.nasa.gov/search/site/docs/search/api.html — NASA CMR Search API documentation
[2] https://docs.asf.alaska.edu/api/keywords — ASF Search API keywords and endpoints
[3] https://docs.asf.alaska.edu/api/basics — ASF Search API basics and access requirements
[4] https://docs.asf.alaska.edu/api/cookbook — ASF Search API cookbook and count validation
[5] https://nisar-docs.asf.alaska.edu/availability-overview — ASF NISAR data availability overview
