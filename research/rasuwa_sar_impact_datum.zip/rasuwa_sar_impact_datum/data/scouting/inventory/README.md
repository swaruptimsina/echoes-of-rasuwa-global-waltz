# Rasuwa all-mission SAR inventory

Real CMR and ASF metadata inventory for the broad Purepu–Lhende/Bhote Koshi–Langtang/Rasuwa–Trishuli connected system.

- **Window:** `2024-11-15T00:00:00Z` to `2026-11-15T23:59:59Z`
- **BBox:** `[84.30, 27.50, 85.75, 28.50]` WGS84
- **WKT:** `POLYGON((84.30 27.50,85.75 27.50,85.75 28.50,84.30 28.50,84.30 27.50))`
- **Canonical inventory:** `inventory.csv`
- **Narrative result:** `summary.md`
- **Machine validation:** `validation.json`

## Rebuild

The scripts use only the Python standard library and issue unauthenticated metadata requests. They never read Earthdata credentials and do not download imagery.

```bash
python scripts/build_inventory.py
python scripts/refresh_normalized_fields.py  # optional for an existing snapshot
python scripts/summarize_inventory.py
python scripts/validate_inventory.py
```

`build_inventory.py` clears and rebuilds `raw/cmr/` and `raw/asf/` unless invoked with `--keep-raw`. It uses CMR Search-After pagination and count-validated ASF temporal partitioning, then deduplicates and crosswalks exact scene IDs.

## Main outputs

- `inventory.csv` — one row per exact granule, including platform/band, product/maturity, polarization, orbit/track/frame/direction, acquisition times, access/login, URLs, source attributes, and notes.
- `granule_urls.csv` — normalized lossless URL table.
- `collections.csv` / `discovered_collections.csv` — selected and broad-discovery collection records.
- `queries.csv` — request/page manifest with exact URL, status, count, Search-After token, raw path, bytes, and SHA-256.
- `asf_queries.csv` / `catalog_crosswalk.csv` — ASF count validation and exact ASF-to-CMR reconciliation.
- `archive_status.csv` — positive, supported-zero, global-zero, and unsupported results.
- `field_completeness.csv` — source-field coverage by collection.
- `summary.json` / `report_stats.json` — aggregate machine-readable results.
- `raw/` — unmodified CMR and ASF response bodies.

Counts are product granules, not unique overpasses. See `summary.md` for mission results and archive limitations.
