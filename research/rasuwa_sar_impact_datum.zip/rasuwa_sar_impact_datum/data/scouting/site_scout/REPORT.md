# Subtle-change site scout: Rasuwa first, SAR-data-rich analogues second

**Cutoff:** 15 November 2026  
**Scope:** retrospective research and site prioritisation; not an operational warning product  
**Coordinate convention:** WGS84 decimal degrees. Every bbox is `[west, south, east, north]` and is an analyst-defined compact study box, not a published hazard footprint.

## Decision

Nine sites survive the first pass: **six Rasuwa/connected-system targets first**, followed by **three Himalayan analogues**. The best Rasuwa pilots are **R1 Langtang Lirung** for an unresolved precursor test, **R5 Upper Trishuli-1/Hakubesi–Mailung** for direct worker and infrastructure relevance, **R3 Rasuwagadhi–Timure** for repeated-event cumulative change, and **R2 Purepu** for a same-corridor mechanism contrast. **A2 Chamoli** is the strongest external benchmark. **A1 Gongbatongsha** is retained as a process analogue but is weaker for retrospective SAR because its 2016 event window has only five point-intersecting SLC acquisitions.

The data-density column is **actually queried**, not estimated. Every coherence score is **PENDING** because scene-footprint intersection does not establish coherent or geometry-valid pixels in steep terrain.

## Transparent 0–5 rubric

| Code | Dimension | 0 | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|---|---|
| **H** | Hazard/event evidence | speculative | generic susceptibility | historic/poorly located | credible process/event | official or peer-reviewed event, mechanism partly open | time- and location-specific, multi-source reconstruction |
| **G** | Independent ground truth | none | model only | one unvalidated remote map | independent second sensor or impact report | multi-sensor/agency mapping or direct ground report | field/drone/gauge/seismic reference plus independent imagery/inventory |
| **X** | People/infrastructure exposure | none | remote/no identified assets | assets only | settlement or critical infrastructure exposed | documented structural/service damage or displacement | deaths/missing plus critical-infrastructure damage |
| **R** | Rasuwa-story relevance | none | generic EO use | mountain hazard only | one shared mechanism or exposure type | strong Himalayan process comparator | same river system or near-isomorphic cascade/exposure problem |
| **N** | Novelty/additive value | saturated | pure replication | incremental update | benchmark transfer | unresolved or under-monitored update | new event/mechanism contrast with a crisp falsifiable subtle-change test |
| **D** | Catalogued SAR density | no current S1 SLC | `<12` unique S1 acquisitions/year | `12–<24`/year | `24–<36`/year and study/event coverage | `≥36`/year plus a second direction or NISAR and study/event coverage | `≥60`/year, ascending+descending, NISAR, and study/event coverage |
| **C** | Usable interferometric coherence/geometry | no usable pair | `<20%` | `20–<40%` | `40–<60%` | `60–<80%` | `≥80%` |

For **C**, the proposed inventory is the lower-quartile fraction of target pixels that are both geometry-valid and coherent in at least three matched 12-day pairs, using a preregistered nominal coherence threshold of `0.3`; dry and monsoon seasons must be reported separately. If fewer than three matched pairs exist, cap C at 2. This protocol still needs product-specific review before execution. Layover, shadow and screened pixels remain unknown, not unchanged.

The preliminary subtotal is `H+G+X+R+N+D` out of 30. The eventual full score is out of 35 after C is measured.

## Inventory method and cautions

ASF point searches used the public Search API endpoint, WKT `POINT(lon lat)`, explicit UTC windows, `maxResults=10000`, and GeoJSON output.[15][16] The common current-density window is **2024-01-01 through 2026-11-15**; NISAR RSLC counts begin **2026-06-17**. Event windows are 90 days centred on each event; R6 instead uses the published study interval, 2014-10-01 through 2017-03-31.

Counts were deduplicated as follows: Sentinel-1 by UTC day + relative path + direction; NISAR by UTC start minute + path + frame + direction; OPERA by day + path + direction + burst. A count is a catalogued acquisition intersecting the point, not proof that the target pixel is valid, coherent, unshadowed, correctly unwrapped, or scientifically interpretable. Raw GeoJSON, exact URLs and the parser are retained with this report.

## Preliminary candidate table

| ID | Candidate and subtle observable | Exact anchor; compact bbox | H/G/X/R/N/D/C | Preliminary subtotal | Queried SAR inventory |
|---|---|---|---:|---:|---|
| **R1** | **Langtang Lirung north-face source** — multi-epoch LOS rate/acceleration, amplitude/coherence change, glacier motion versus bedrock motion | Published collapse point **28.291242 N, 85.528066 E**; bbox **[85.5000, 28.2700, 85.5600, 28.3200]**.[1] | `5/4/5/5/5/5/PENDING` | **29/30** | 254 current S1 SLC (**88.4/y**), 23 NISAR RSLC; 22 event-window S1 and 22 OPERA RTC, with **3** same-geometry brackets.[20][21][22][23] |
| **R2** | **Purepu Glacier supraglacial-lake source** — lake-area/roughness trajectory, drainage-channel change and post-outburst refilling | DHM point **28.404300 N, 85.646900 E**; bbox **[85.6200, 28.3800, 85.6800, 28.4300]**.[4][5] | `5/4/5/5/4/5/PENDING` | **28/30** | 254 current S1 SLC (**88.4/y**), 23 NISAR; 23 event-window S1 and 23 OPERA RTC, with **3** brackets.[24][25][26][27] |
| **R3** | **Rasuwagadhi–Timure border/bridge/dry-port reach** — cumulative channel aggradation, bank retreat, bridge/yard settlement after two floods | Analyst midpoint **28.2653116 N, 85.3722252 E** of Rasuwagadhi **28.2777749, 85.3777789** and Timure **28.2528483, 85.3666715**; bbox **[85.3500, 28.2400, 85.4000, 28.3000]**.[17][56] | `5/4/5/5/4/5/PENDING` | **28/30** | 224 current S1 (**77.9/y**), 25 NISAR; 17 event-window S1 and 14 OPERA RTC, with **3** S1 brackets.[28][29][30][31] |
| **R4** | **Syabrubesi confluence/gauge/bridge reach** — bank-line migration, bridge approaches, gauge-foundation and road-corridor deformation | OSM settlement anchor **28.1645690 N, 85.3427433 E**; bbox **[85.3200, 28.1400, 85.3700, 28.1900]**.[18] | `5/4/4/5/4/4/PENDING` | **26/30** | 169 current S1 (**58.8/y**), 23 NISAR; 14 event-window S1 and 14 OPERA RTC, with **2** brackets.[32][33][34][35] |
| **R5** | **Upper Trishuli-1 / Hakubesi–Mailung corridor** — tunnel-portal/stockyard settlement, slope creep, debris persistence and access-road deformation | Analyst midpoint **28.0944644 N, 85.2441901 E**; project **28.0724471, 85.2093068**, Hakubesi **28.1164817, 85.2790735**, Mailung **28.0717737, 85.2070031**; bbox **[85.1900, 28.0500, 85.3000, 28.1400]**.[19][57][58] | `5/5/5/5/5/4/PENDING` | **29/30** | 169 current S1 (**58.8/y**), 34 NISAR; 14 event-window S1 and 14 OPERA RTC, with **2** brackets.[36][37][38][39] |
| **R6** | **Published Trishuli slow-landslide cluster A–F** — updated dry-season creep/acceleration and road-intersection motion | Analyst query point **28.0850 N, 85.2300 E** at the centre of the published Figure 4 cluster; bbox **[85.1400, 28.0000, 85.3100, 28.1700]**; not a published landslide centroid.[7] | `4/5/4/5/4/4/PENDING` | **26/30** | 169 current S1 (**58.8/y**), 34 NISAR; **105** unique S1 and 41 OPERA RTC acquisitions in the 2014–2017 study window.[40][41][42][43] |
| **A1** | **Gongbatongsha Lake / Upper Bhote Koshi 2016 cascade** — small-lake change, slope-to-lake trigger and sediment-amplification benchmark | Published lake point **28.0780556 N, 86.0700000 E** (converted from 28°04′41″N, 86°04′12″E); bbox **[86.0400, 28.0500, 86.1000, 28.1100]**.[8] | `5/5/4/5/3/4/PENDING` | **26/30** | 171 current S1 (**59.5/y**), 34 NISAR; only **5** event-window S1 and 5 OPERA RTC, though two geometries bracket the event.[44][45][46][47] |
| **A2** | **Chamoli/Ronti Peak 2021 rock–ice source** — blind transfer benchmark for precursor and source/runout detection | GEER source **30.3764028 N, 79.7164306 E** (30°22′35.05″N, 79°42′59.15″E); bbox **[79.7000, 30.3500, 79.7550, 30.4100]**.[11] | `5/5/5/5/3/5/PENDING` | **28/30** | 339 current S1 (**117.9/y**), 32 NISAR; 34 event-window S1 and 34 OPERA RTC, with **4** brackets.[48][49][50][51] |
| **A3** | **South Lhonak Lake 2023 source** — moraine deformation, lake change and calving/GLOF benchmark | Analyst point **27.9100 N, 88.1900 E** inside the lake; bbox **[88.1500, 27.8800, 88.2300, 27.9400]**, enclosing NDMA **27.9055556, 88.1722222** and PDNA **27.9157500, 88.2069444** anchors.[12][13] | `5/5/5/4/3/4/PENDING` | **26/30** | 167 current S1 (**58.1/y**), 44 NISAR; 16 event-window S1 and 24 OPERA RTC, with **2** brackets.[52][53][54][55] |

## Why each candidate survives

### R1 — Langtang Lirung source: highest scientific novelty

The Government of Nepal mapped the collapse with Landsat 9 and Planet imagery at the exact anchor above.[1] ICIMOD’s opened report, **_Understanding the Gyirong–Rasuwa disaster of 26 August 2026: A preliminary synthesis_**, describes a bedrock failure that sheared away hanging glacier ice and says the interpretation draws on seismic, satellite and drone evidence.[2] UNOSAT independently mapped the downstream disturbance from 26–27 August PlanetScope and Sentinel-2 imagery, but explicitly labels its product preliminary and not field validated.[3]

> “Whether the pre-event InSAR displacement represented a precursory deformation of the failing bedrock–ice slope, glacier movement, an atmospheric or geometric effect, or a combination of these processes.”[2]

**Falsifiable subtle-change test:** reproduce a progressive source-tied LOS signal across independent Sentinel-1 and NISAR interferograms, then test it against glacier velocity, atmosphere/elevation, unwrapping components, geometry masks and neighbouring glaciated controls. The same report gives the load-bearing novelty: it reports up to 40 cm of Sentinel-1 LOS deformation but leaves the physical interpretation open.[2]

**Lives/exposure:** UNOSAT estimated 37 km² affected within its analysed area, about 120 km of potentially affected roads and about 5,000 exposed or nearby buildings, while warning that the analysis had not been field validated.[3] The later government response records extensive hydropower, road, bridge and displacement impacts along the connected corridor.[6]

### R2 — Purepu: same corridor, different mechanism

DHM’s opened 2025 update places the source at 28.4043 N, 85.6469 E and compares Sentinel-2/NDWI imagery before and after lake drainage.[4] The opened peer-reviewed article **_Remote sensing interpretation of causes and dynamics of the Gyirong outburst flood disaster, Tibet, on July 8, 2025_** independently reports a rapid lake-area reduction and a preceding growth trajectory.[5]

> “This event was triggered by a rapid reduction of ~ 0.31 km2 (~ 45%) in supraglacial lake area in the upper Purepu Tsangpo… [and] the lake’s surface area expanded ~ 7.65-fold, from ~ 0.08 km2 on May 9 to ~ 0.69 km2 on July 6, 2025.”[5]

The article reports at least nine deaths and 19 missing at Gyirong land port.[5] An independent Stimson account reports deaths/missing, trade-corridor interruption, hydropower impacts and agricultural erosion, and describes the absence of advance warning.[59]

**Falsifiable subtle-change test:** ask whether SAR-derived lake area, shoreline roughness and connected drainage change could have separated rapid 2025 expansion from seasonal controls without using the known outburst date. This gives Rasuwa a clean paired design: same downstream corridor, but supraglacial drainage in 2025 versus rock–ice/bedrock collapse in 2026.[2][5]

### R3 — Rasuwagadhi–Timure: repeated-event exposure hotspot

The bbox joins two independently geocoded settlement anchors.[17][56]

The 2025 flood halted trade and damaged border facilities and bridges.[59]

The 2026 flood reached Rasuwagadhi within minutes and then propagated through Timure and the downstream corridor.[1][6]

The opened government title **_BHOTEKOSHI–TRISHULI FLOOD: SEARCH, RESCUE AND RELIEF UPDATE_** provides direct ground-response evidence; UNOSAT supplies independent optical extent and exposed-building/road context.[3][6]

> “Travelling at approximately 188 km/h from its source, the flood covered 20 km within seven to eight minutes and reached the Nepal–China border at Rasuwagadhi at 08:45.”[6]

**Falsifiable subtle-change test:** measure persistent post-event channel-bar elevation proxies, bank-line retreat and structural/yard settlement after the 2025 and 2026 shocks, using pre-pre null intervals and field/optical bridge and channel references. The repeated disturbances make this a stronger cumulative-risk site than a one-off flood footprint.

### R4 — Syabrubesi: gauge failure plus settlement-scale change

The OSM anchor is 28.1645690 N, 85.3427433 E.[18] The government update records that the flood destroyed the Syabrubesi hydrological station at 08:50, while also documenting disruption to the Syabrubesi–Rasuwagadhi and Betrawati–Mailung–Syabrubesi roads.[6]

> “It destroyed the hydrological stations at Syafrubesi at 08:50 and Betrawati at 09:20.”[6]

**Ground truth:** the station failure time is a direct operational observation; government repair/search records and UNOSAT’s independent Planet/Sentinel-2 map can anchor reach-scale interpretation.[3][6] **Subtle-change test:** detect bank migration, road-edge retreat, bridge-approach settlement and persistent debris while separating river-stage backscatter from permanent geomorphic change. Exposure is high, but site-specific casualty attribution is weaker than at R3 or R5, hence X=4.

### R5 — Upper Trishuli-1 / Hakubesi–Mailung: clearest lives-to-infrastructure link

The bbox joins an OSM-mapped Upper Trishuli-1 industrial site, Hakubesi and Mailung.[19][57][58]

The government update identifies Upper Trishuli-1 as a 216 MW project and records extensive tunnel/adit search and debris-clearance operations.[6]

> “Using three grinders, one gas cutter and two rotary rescue saws, teams recovered six bodies trapped in the steel reinforcement mesh in Upper Trishuli 1 (216 MW) Adit 3.”[6]

The same update later states that 31 bodies were recovered by cutting steel; these lines may be cumulative or differently scoped, so this scout does **not** add them or claim a unique site total.[6] The broader assessment says 13 hydropower projects with 759.025 MW combined capacity were affected.[6]

**Falsifiable subtle-change test:** monitor tunnel-portal/stockyard settlement, unstable access slopes, road deformation and persistence/remobilisation of flood debris against project inspections and high-resolution optical/drone controls. This site scores highest because the observable is subtle, the ground response is direct, and the link to worker safety and energy infrastructure is explicit.

### R6 — Trishuli slow landslides: published baseline ready for a NISAR update

The opened NASA NTRS record **_InSAR-based detection method for mapping and monitoring slow-moving landslides in remote regions with steep and mountainous terrain: An application to Nepal_** reports six slow-moving landslides, 0.39–1.66 km² in area, with 2.1–8.8 cm/year dry-season LOS rates.[7]

> “Due to periods of low coherence during the monsoon season (June – September) each year… our time series analysis is limited to the 2014-2015 and 2016-2017 dry seasons.”[7]

Independent checking is unusually strong: the study compared detections with stereo aerial-photo and field-validated mapping, includes ground photos, and reports that landslides A and D–F cross roads and that agriculture/ground deformation affects the Trishuli highway.[7]

**Falsifiable subtle-change test:** update each published polygon with harmonised Sentinel-1 and NISAR dry-season rates, test for acceleration relative to 2014–2017, and separately quantify monsoon censoring. C remains pending despite the older study because current NISAR/Sentinel coherence and valid-pixel fractions have not been measured.

## Himalayan analogues that add, rather than distract

### A1 — Gongbatongsha 2016: transboundary sediment-amplification benchmark

The opened article **_Transition of a small Himalayan glacier lake outburst flood to a giant transborder flood and debris flow_** publishes the lake coordinate used here and reconstructs a small lake outburst that amplified through erosion and sediment entrainment before damaging Nepalese infrastructure.[8]

> “The Gongbatongsha Lake (28°04′41″ N; 86°04′12″E) is located in the Zhangzangbo valley, Poiqu/Bhotekoshi basin at an elevation of 4623 m in the central Himalaya.”[8]

Independent field/high-resolution-image validation is available in the reconstruction.[8] A second opened study, **_Glacial Lake Inventory and Lake Outburst Flood/Debris Flow Hazard Assessment after the Gorkha Earthquake in the Bhote Koshi Basin_**, reports damage to 77 houses, three bridges, the Arniko Highway and the Upper Bhote Koshi Hydropower intake.[9]

**Why it helps Rasuwa:** it tests the hypothesis that pre-existing channel sediment and landslides can amplify a modest upstream release into a severe transboundary debris flow. **Why it is reserve priority:** present-day S1/NISAR coverage is dense, but the actual 2016 window has only five point-intersecting SLC acquisitions and long nearest-event gaps.[44][45][46]

### A2 — Chamoli 2021: strongest near-isomorphic benchmark

The opened USGS/Science record **_A massive rock and ice avalanche caused the 2021 disaster at Chamoli, Indian Himalaya_** describes a rock–ice collapse that transformed into a debris flow, severely damaged two hydropower projects, and left over 200 people killed or missing.[10]

> “Our analysis of satellite imagery, seismic records, numerical model results, and eyewitness videos reveals that ~27x106 m3 of rock and glacier ice collapsed from the steep north face of Ronti Peak.”[10]

The opened GEER field report **_Site Visit and Drone Based Reconnaissance Study of the Severely Affected Infrastructure by February 7th, 2021, Chamoli Rock-Ice Avalanche Disaster, Uttarakhand, India_** publishes the exact source coordinate and supplies post-event drone photogrammetry, DEMs, georeferenced field imagery and infrastructure observations.[11]

**Falsifiable transfer test:** freeze the Rasuwa precursor/change workflow first, then run it blind at Chamoli and test whether it finds the known source and event interval without site-specific threshold tuning. Chamoli is a benchmark rather than a novelty claim, but it has the densest catalogued SAR record in this shortlist.

### A3 — South Lhonak 2023: GLOF and moraine-deformation benchmark

The pre-event NDMA mission report documents a September 2023 field expedition, risk assessment and instrument installation at South Lhonak.[13] The official Sikkim **_Post Disaster Needs Assessment: Glacial Lake Outburst Flood Sikkim – 2023_** reports 55 lives lost and about 80,000 people across 100 villages affected, along with major road, bridge and hydropower damage.[12]

The opened article **_Glacier calving and moraine collapse triggered the glacial lake outburst flood in South Lhonak Lake, Indian Himalaya_** uses ten satellite missions and explicitly includes PlanetScope and Sentinel-1 SAR before and after the event.[14]

> “Our analysis of PlanetScope and Sentinel-1 SAR imagery from before and after the GLOF event on 27 September and 6 October 2023, respectively, revealed significant glacier retreat and changes in SLL… The glacier retreated by 49.6 ± 7.1 m over these 10 days.”[14]

**Falsifiable transfer test:** quantify whether pre-event moraine/lake change is separable from seasonal snow, glacier motion and atmospheric/geometry artefacts, then compare its warning observables with Purepu and with the non-lake Langtang failure. This strengthens the Rasuwa narrative by preventing one “glacial flood” mechanism from being transferred indiscriminately to another.

## Recommended sequence

1. **R1 Langtang source:** inventory coherence/layover by track and reproduce or bound the reported precursor before any warning claim.
2. **R5 Upper Trishuli-1 corridor:** assemble project/drone/field references and test persistent infrastructure/slope change.
3. **R3 Rasuwagadhi–Timure + R2 Purepu as a paired study:** one downstream exposure hotspot, two different upstream mechanisms and two consecutive disasters.
4. **R6 Trishuli cluster:** update the published field-checked slow-landslide baseline with NISAR; preserve monsoon censoring.
5. **R4 Syabrubesi:** reach-scale gauge/road/bridge recovery study after the higher-priority references are assembled.
6. **A2 Chamoli, then A3 South Lhonak:** blind external validation. Use A1 only as a sediment-amplification comparator, not as the primary event-era InSAR benchmark.

## Stop conditions before promoting any site

- **Coherence/geometry:** no C score until actual target/control pixels are inventoried by track, season and pair; catalog counts cannot substitute.
- **Ground truth:** no physical class from amplitude darkness or coherence loss alone. Require event-matched optical/UAV/field labels and report observable-area fraction separately from accuracy.
- **Exposure:** keep corridor-wide totals separate from site-specific losses; do not apportion casualties or economic damage to a bbox without a source that does so.
- **Novelty:** a successful visualisation is not a precursor. Pre-register target, controls, date window, thresholds and null tests before examining deformation histories.

## Reproducibility files

- `candidates.json` — typed anchors, component points, bboxes, event windows and coordinate provenance.
- `catalog_queries.csv` — 36 exact ASF URLs, HTTP status, returned-record count and raw response path.
- `raw/catalog/*.json` — retained ASF GeoJSON responses.
- `catalog_inventory.json` — deduplicated counts, directions, paths and nearest same-geometry event brackets.
- `site_scores.csv` / `site_scores.json` — the nine-row preliminary score table.
- `scripts/query_sar_inventory.py` — query, deduplication and scoring code.
- `evidence/` and `citation-ledger.json` — opened source text and quote-backed URL ledger.

## Sources

[1] https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR%20revised_1790050465053_hkodqvs.pdf — Assessment Report II: Rasuwa–Bhote Koshi Flood Event, 2026
    > "Study of available satellite images (Landsat 9, Planet Labs) shows that a hanging glacier located on the northern side of Langtang-Lirung mountain in Rasuwa district, at an elevation of approximately 5200 masl (approximately 28.291242°N, 85.528066°E), collapsed, causing a huge ice–rock avalanche which fell onto a debris-covered glacier located approximately 3800 masl."
[2] https://lib.icimod.org/records/r745z-mvm84 — Understanding the Gyirong–Rasuwa disaster of 26 August 2026: A preliminary synthesis
    > "The source of the event was a bedrock failure that"
    > "Pre-event line-of-sight (LOS) displacement recorded by Sentinel-1 InSAR between 7 July and 24 August 2026 (a 48-day period) revealed deformation patterns of up to 40 cm across the failed area, suggesting destabilisation of the rock–ice system prior to failure"
    > "Whether the pre-event InSAR displacement represented a precursory deformation of the failing bedrock–ice slope, glacier movement, an atmospheric or geometric effect, or a combination of these processes."
[3] https://unosat.org/products/4259 — Mudflow/Rockflow Impact Assessment in Rasuwa & Nuwakot Districts
    > "This map illustrates the cumulative satellite-detected mudflow/rockflow extent derived from Sentinel-2 imagery acquired on 27 August 2026 and PlanetScope imagery acquired on 26 August 2026."
    > "Approximately 120 km of roads are potentially affected by the mapped flood/mudflow extent. Based on building footprint data, approximately 5,000 buildings are exposed to or located near the affected areas."
    > "This is a preliminary analysis and has not yet been validated in the field."
[4] https://dhm.gov.np/uploads/dhm/downloads/Report_Bhotekoshi_Flood_Update_1.pdf — Bhote Koshi Flood Update, 8 July 2025
    > "शचरमा दे खाइएको बथान रसुिागढी शबथत नेपाल-चीन सीमाबाट करीब ३६ वकलोसमटर मासथ (अक्ािंशः २८.४०४३, दे शान्त्तरः ८५.६४६९, समुदि सतहबाट कररब ५१५० सम. उचाई) ले न्त्दे खोलाको मासथल्लो र्लाधार क्ेरमा पदाछ।"
[5] https://link.springer.com/article/10.1007/s11069-026-08081-1 — Remote sensing interpretation of causes and dynamics of the Gyirong outburst flood disaster, Tibet, on July 8, 2025
    > "On July 8, 2025, a catastrophic GLOF struck Gyirong land port, Tibet, China, causing at least nine deaths and leaving 19 people missing."
    > "This event was triggered by a rapid reduction of ~ 0.31 km2 (~ 45%) in supraglacial lake area in the upper Purepu Tsangpo, a tributary of the Donglin Tsangpo. Remote sensing analysis reveals that the lake’s surface area expanded ~ 7.65-fold, from ~ 0.08 km2 on May 9 to ~ 0.69 km2 on July 6, 2025"
[6] https://ndrrma.gov.np/mediafiles/publications/Bhotekoshi-Trishuli_Flood_Update_From_August_26_2026_to_October_3_2026.pdf — BHOTEKOSHI–TRISHULI FLOOD: SEARCH, RESCUE AND RELIEF UPDATE
    > "Travelling at approximately 188 km/h from its source, the flood covered 20 km within seven to eight minutes and reached the Nepal–China border at Rasuwagadhi at 08:45. It destroyed the hydrological stations at Syafrubesi at 08:50 and Betrawati at 09:20."
    > "Energy: Thirteen hydropower projects with a combined capacity of 759.025 MW, five solar plants totalling 24.36 MW, one substation, transmission lines and distribution systems were affected."
    > "Roads and bridges: 69 km of roads were damaged. Of 37 affected motorable bridges, 33 were washed away, and 68 suspension bridges were damaged."
    > "Using three grinders, one gas cutter and two rotary rescue saws, teams recovered six bodies trapped in the steel reinforcement mesh in Upper Trishuli 1 (216 MW) Adit 3."
    > "A total of 1,085 displaced people are residing in 17 camps: 843 in nine camps in Rasuwa, 121 in four camps in Nuwakot and 121 in four camps in Dhading."
[7] https://ntrs.nasa.gov/citations/20205004356 — InSAR-based detection method for mapping and monitoring slow-moving landslides in remote regions with steep and mountainous terrain: An application to Nepal
    > "areas ranging from 0.39 to 1.66 km2 and long-term dry-season displacement rates ranging from"
    > "mapped landslides using stereo-pair aerial photos and field validation."
    > "that landslides A and D-F cut across the road network (Figure 4), and are moving at rates"
    > "the landslides and show agriculture and ground surface deformation that is impacting the Trishuli highway"
[8] https://pmc.ncbi.nlm.nih.gov/articles/PMC9300610 — Transition of a small Himalayan glacier lake outburst flood to a giant transborder flood and debris flow
    > "The Gongbatongsha Lake (28°04′41″ N; 86°04′12″E) is located in the Zhangzangbo valley, Poiqu/Bhotekoshi basin at an elevation of 4623 m in the central Himalaya."
    > "The results are validated using published data and high-resolution satellite imagery and DEMs."
    > "On 5 July 2016, a debris flow originating in Tibet Autonomous Region at 4610 m elevation crossed the border into Nepal and struck the Upper Bhotekoshi hydropower plant, causing great damage to the plant and various infrastructures, including the Arniko Highway"
[9] https://www.mdpi.com/2073-4441/12/2/464 — Glacial Lake Inventory and Lake Outburst Flood/Debris Flow Hazard Assessment after the Gorkha Earthquake in the Bhote Koshi Basin
    > "The GLOF caused severe damage downstream of Bhote Koshi, damaging 77 houses, 3 bridges and the Araniko Highway, and destroying the intake dam of the Upper Bhote Koshi Hydropower Project in Nepal"
[10] https://pubs.usgs.gov/publication/70221399 — A massive rock and ice avalanche caused the 2021 disaster at Chamoli, Indian Himalaya
    > "On 7 Feb 2021, a catastrophic mass flow descended the Ronti Gad, Rishiganga, and Dhauliganga valleys in Chamoli, Uttarakhand, India, causing widespread devastation and severely damaging two hydropower projects. Over 200 people were killed or are missing."
[11] https://geerassociation.org/components/com_geer_reports/geerfiles/Chamoli_Report.pdf — Site Visit and Drone Based Reconnaissance Study of the Severely Affected Infrastructure by February 7th, 2021, Chamoli Rock-Ice Avalanche Disaster
    > "A - Source of rock-ice avalanche (30°22'35.05"N, 79°42'59.15"E)"
    > "Field reconnaissance involves capturing geo-referenced images of the affected areas through drones and digital cameras that provide direct information about the conditions on the ground to assess the consequences/damage resulting from the disaster."
[12] http://ssdma.nic.in/Uploads/resources/SIKKIM%20PDNA.pdf — Post Disaster Needs Assessment: Glacial Lake Outburst Flood Sikkim – 2023
    > "Tragically, 55 lives were lost and an es�mated 80,000 people across 100 villages were affected."
[13] https://www.ndma.gov.in/sites/default/files/PDF/Reports/GLOF_Mission_Report_NDMA.pdf — Mission report of GLOF Risk Assessment & Installation of AWS in Sikkim
    > "In September 2023, a pioneering expedition was conducted to two high Risk Glacial lakes of Sikkim named South Lhonak and Shako Cho Lake."
    > "The South Lhonak Glacial Lake, located at an altitude of 5,200 meters, is one of the fastest expanding lakes in Sikkim Himalaya (Eastern Himalaya)"
[14] https://iopscience.iop.org/article/10.1088/2515-7620/ae1936 — Glacier calving and moraine collapse triggered the glacial lake outburst flood in South Lhonak Lake, Indian Himalaya
    > "Our analysis of PlanetScope and Sentinel-1 SAR imagery from before and after the GLOF event on 27 September and 6 October 2023, respectively, revealed significant glacier retreat and changes in SLL (figures 1 (a) to (f)). The glacier retreated by 49.6 ± 7.1 m over these 10 days."
    > "Initially a supraglacial lake in 1962, it evolved into a moraine-dammed lake by 1983 and expanded 12-fold from 0.11 km² (1962) to 1.4 km² (2023)."
[15] https://docs.asf.alaska.edu/api/keywords — ASF Search API Keywords and Endpoints
    > "Search by polygon, a line segment (“linestring”), or a point defined in 2-D Well-Known Text (WKT)."
[16] https://docs.asf.alaska.edu/api/basics — ASF Search API Basics
    > "The Search endpoint uses this base URL: https://api.daac.asf.alaska.edu/services/search/param"
[17] https://nominatim.openstreetmap.org/search?q=Rasuwagadhi%2C+Nepal&format=jsonv2 — OpenStreetMap Nominatim search: Rasuwagadhi, Nepal
    > ""lat":"28.2777749","lon":"85.3777789","category":"place","type":"hamlet","place_rank":20,"importance":0.22697289548003588,"addresstype":"hamlet","name":"रसुवागढी","display_name":"रसुवागढी, Gosaikunda-02, गोसाइँकुण्ड गाउँपालिका, रसुवा जिल्ला, बागमती प्रदेश, नेपाल""
[18] https://nominatim.openstreetmap.org/search?q=Syabru+Besi%2C+Nepal&format=jsonv2 — OpenStreetMap Nominatim search: Syabru Besi, Nepal
    > ""lat":"28.1645690","lon":"85.3427433","category":"place","type":"hamlet","place_rank":20,"importance":0.1333833348592355,"addresstype":"hamlet","name":"स्याफ्रु बेसी","display_name":"स्याफ्रु बेसी, Gosaikunda-03, स्याप्रु बेसी, गोसाइँकुण्ड गाउँपालिका, रसुवा जिल्ला, बागमती प्रदेश, नेपाल""
[19] https://nominatim.openstreetmap.org/search?q=Upper+Trishuli-1&format=jsonv2 — OpenStreetMap Nominatim search: Upper Trishuli-1
    > ""lat":"28.0724471","lon":"85.2093068","category":"landuse","type":"industrial","place_rank":24,"importance":0.08005000152590216,"addresstype":"industrial","name":"Upper Trishuli-1 Hydroelectric Project""
[20] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.528066+28.291242%29&start=2024-01-01T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R1 current_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261111T001036_20261111T001103_005412_00A53C_752C-SLC", "flightDirection": "DESCENDING", "pathNumber": 121, "processingLevel": "SLC""
[21] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=RSLC&intersectsWith=POINT%2885.528066+28.291242%29&start=2026-06-17T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R1 current_nisar_rslc
    > ""fileID": "NISAR_L1_UR_RSLC_035_098_A_016_4005_DHDH_A_20261111T233918_20261111T233953_P05036_F_F_J_001", "flightDirection": "ASCENDING", "pathNumber": 98, "processingLevel": "RSLC""
[22] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.528066+28.291242%29&start=2026-07-12T00%3A00%3A00Z&end=2026-10-10T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R1 event_or_study_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261006T001037_20261006T001104_004887_009321_B7AE-SLC", "flightDirection": "DESCENDING", "pathNumber": 121, "processingLevel": "SLC""
[23] https://api.daac.asf.alaska.edu/services/search/param?dataset=OPERA-S1&processingLevel=RTC&intersectsWith=POINT%2885.528066+28.291242%29&start=2026-07-12T00%3A00%3A00Z&end=2026-10-10T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R1 event_or_study_opera_rtc
    > ""fileID": "OPERA_L2_RTC-S1_T121-258660-IW3_20261006T001048Z_20261012T172107Z_S1D_30_v1.0", "flightDirection": "DESCENDING", "pathNumber": 121, "processingLevel": "RTC""
[24] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.6469+28.4043%29&start=2024-01-01T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R2 current_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261111T001036_20261111T001103_005412_00A53C_752C-SLC", "flightDirection": "DESCENDING", "pathNumber": 121, "processingLevel": "SLC""
[25] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=RSLC&intersectsWith=POINT%2885.6469+28.4043%29&start=2026-06-17T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R2 current_nisar_rslc
    > ""fileID": "NISAR_L1_UR_RSLC_035_098_A_016_4005_DHDH_A_20261111T233918_20261111T233953_P05036_F_F_J_001", "flightDirection": "ASCENDING", "pathNumber": 98, "processingLevel": "RSLC""
[26] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.6469+28.4043%29&start=2025-05-24T00%3A00%3A00Z&end=2025-08-22T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R2 event_or_study_s1_slc
    > ""fileID": "S1A_IW_SLC__1SDV_20250822T001931_20250822T001958_060641_078B61_FDD1-SLC", "flightDirection": "DESCENDING", "pathNumber": 19, "processingLevel": "SLC""
[27] https://api.daac.asf.alaska.edu/services/search/param?dataset=OPERA-S1&processingLevel=RTC&intersectsWith=POINT%2885.6469+28.4043%29&start=2025-05-24T00%3A00%3A00Z&end=2025-08-22T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R2 event_or_study_opera_rtc
    > ""fileID": "OPERA_L2_RTC-S1_T019-039569-IW1_20250822T001940Z_20250822T045424Z_S1A_30_v1.0", "flightDirection": "DESCENDING", "pathNumber": 19, "processingLevel": "RTC""
[28] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.3722252+28.2653116%29&start=2024-01-01T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R3 current_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261108T122140_20261108T122208_005376_00A3FE_1388-SLC", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "SLC""
[29] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=RSLC&intersectsWith=POINT%2885.3722252+28.2653116%29&start=2026-06-17T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R3 current_nisar_rslc
    > ""fileID": "NISAR_L1_UR_RSLC_035_098_A_016_4005_DHDH_A_20261111T233918_20261111T233953_P05036_F_F_J_001", "flightDirection": "ASCENDING", "pathNumber": 98, "processingLevel": "RSLC""
[30] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.3722252+28.2653116%29&start=2026-07-12T00%3A00%3A00Z&end=2026-10-10T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R3 event_or_study_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261003T122140_20261003T122208_004851_0091DF_22F7-SLC", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "SLC""
[31] https://api.daac.asf.alaska.edu/services/search/param?dataset=OPERA-S1&processingLevel=RTC&intersectsWith=POINT%2885.3722252+28.2653116%29&start=2026-07-12T00%3A00%3A00Z&end=2026-10-10T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R3 event_or_study_opera_rtc
    > ""fileID": "OPERA_L2_RTC-S1_T085-180590-IW2_20261003T122149Z_20261012T175809Z_S1D_30_v1.0", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "RTC""
[32] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.3427433+28.164569%29&start=2024-01-01T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R4 current_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261108T122140_20261108T122208_005376_00A3FE_1388-SLC", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "SLC""
[33] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=RSLC&intersectsWith=POINT%2885.3427433+28.164569%29&start=2026-06-17T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R4 current_nisar_rslc
    > ""fileID": "NISAR_L1_UR_RSLC_035_098_A_016_4005_DHDH_A_20261111T233918_20261111T233953_P05036_F_F_J_001", "flightDirection": "ASCENDING", "pathNumber": 98, "processingLevel": "RSLC""
[34] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.3427433+28.164569%29&start=2026-07-12T00%3A00%3A00Z&end=2026-10-10T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R4 event_or_study_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261003T122140_20261003T122208_004851_0091DF_22F7-SLC", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "SLC""
[35] https://api.daac.asf.alaska.edu/services/search/param?dataset=OPERA-S1&processingLevel=RTC&intersectsWith=POINT%2885.3427433+28.164569%29&start=2026-07-12T00%3A00%3A00Z&end=2026-10-10T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R4 event_or_study_opera_rtc
    > ""fileID": "OPERA_L2_RTC-S1_T085-180589-IW2_20261003T122146Z_20261012T175809Z_S1D_30_v1.0", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "RTC""
[36] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.2441901+28.0944644%29&start=2024-01-01T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R5 current_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261108T122140_20261108T122208_005376_00A3FE_1388-SLC", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "SLC""
[37] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=RSLC&intersectsWith=POINT%2885.2441901+28.0944644%29&start=2026-06-17T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R5 current_nisar_rslc
    > ""fileID": "NISAR_L1_UR_RSLC_035_098_A_016_4005_DHDH_A_20261111T233918_20261111T233953_P05036_F_F_J_001", "flightDirection": "ASCENDING", "pathNumber": 98, "processingLevel": "RSLC""
[38] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.2441901+28.0944644%29&start=2026-07-12T00%3A00%3A00Z&end=2026-10-10T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R5 event_or_study_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261003T122140_20261003T122208_004851_0091DF_22F7-SLC", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "SLC""
[39] https://api.daac.asf.alaska.edu/services/search/param?dataset=OPERA-S1&processingLevel=RTC&intersectsWith=POINT%2885.2441901+28.0944644%29&start=2026-07-12T00%3A00%3A00Z&end=2026-10-10T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R5 event_or_study_opera_rtc
    > ""fileID": "OPERA_L2_RTC-S1_T085-180589-IW2_20261003T122146Z_20261012T175809Z_S1D_30_v1.0", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "RTC""
[40] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.23+28.085%29&start=2024-01-01T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R6 current_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261108T122140_20261108T122208_005376_00A3FE_1388-SLC", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "SLC""
[41] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=RSLC&intersectsWith=POINT%2885.23+28.085%29&start=2026-06-17T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R6 current_nisar_rslc
    > ""fileID": "NISAR_L1_UR_RSLC_035_098_A_016_4005_DHDH_A_20261111T233918_20261111T233953_P05036_F_F_J_001", "flightDirection": "ASCENDING", "pathNumber": 98, "processingLevel": "RSLC""
[42] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2885.23+28.085%29&start=2014-10-01T00%3A00%3A00Z&end=2017-03-31T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R6 event_or_study_s1_slc
    > ""fileID": "S1A_IW_SLC__1SDV_20170325T001858_20170325T001925_015841_01A194_9E5B-SLC", "flightDirection": "DESCENDING", "pathNumber": 19, "processingLevel": "SLC""
[43] https://api.daac.asf.alaska.edu/services/search/param?dataset=OPERA-S1&processingLevel=RTC&intersectsWith=POINT%2885.23+28.085%29&start=2014-10-01T00%3A00%3A00Z&end=2017-03-31T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query R6 event_or_study_opera_rtc
    > ""fileID": "OPERA_L2_RTC-S1_T019-039572-IW1_20170325T001917Z_20250925T085726Z_S1A_30_v1.0", "flightDirection": "DESCENDING", "pathNumber": 19, "processingLevel": "RTC""
[44] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2886.07+28.0780556%29&start=2024-01-01T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A1 current_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261111T001036_20261111T001103_005412_00A53C_752C-SLC", "flightDirection": "DESCENDING", "pathNumber": 121, "processingLevel": "SLC""
[45] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=RSLC&intersectsWith=POINT%2886.07+28.0780556%29&start=2026-06-17T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A1 current_nisar_rslc
    > ""fileID": "NISAR_L1_UR_RSLC_035_098_A_016_4005_DHDH_A_20261111T233918_20261111T233953_P05036_F_F_J_001", "flightDirection": "ASCENDING", "pathNumber": 98, "processingLevel": "RSLC""
[46] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2886.07+28.0780556%29&start=2016-05-21T00%3A00%3A00Z&end=2016-08-19T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A1 event_or_study_s1_slc
    > ""fileID": "S1A_IW_SLC__1SSV_20160813T122155_20160813T122222_012582_013B7C_2664-SLC", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "SLC""
[47] https://api.daac.asf.alaska.edu/services/search/param?dataset=OPERA-S1&processingLevel=RTC&intersectsWith=POINT%2886.07+28.0780556%29&start=2016-05-21T00%3A00%3A00Z&end=2016-08-19T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A1 event_or_study_opera_rtc
    > ""fileID": "OPERA_L2_RTC-S1_T085-180588-IW3_20160813T122202Z_20250927T125123Z_S1A_30_v1.0", "flightDirection": "ASCENDING", "pathNumber": 85, "processingLevel": "RTC""
[48] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2879.7164306+30.3764028%29&start=2024-01-01T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A2 current_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261114T003431_20261114T003458_005456_00A6B6_13E3-SLC", "flightDirection": "DESCENDING", "pathNumber": 165, "processingLevel": "SLC""
[49] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=RSLC&intersectsWith=POINT%2879.7164306+30.3764028%29&start=2026-06-17T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A2 current_nisar_rslc
    > ""fileID": "NISAR_L1_UR_RSLC_035_127_A_017_4005_DHDH_A_20261113T235631_20261113T235706_P05036_F_F_J_001", "flightDirection": "ASCENDING", "pathNumber": 127, "processingLevel": "RSLC""
[50] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2879.7164306+30.3764028%29&start=2020-12-24T00%3A00%3A00Z&end=2021-03-24T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A2 event_or_study_s1_slc
    > ""fileID": "S1A_IW_SLC__1SDV_20210323T124722_20210323T124749_037126_045F06_DFAA-SLC", "flightDirection": "ASCENDING", "pathNumber": 129, "processingLevel": "SLC""
[51] https://api.daac.asf.alaska.edu/services/search/param?dataset=OPERA-S1&processingLevel=RTC&intersectsWith=POINT%2879.7164306+30.3764028%29&start=2020-12-24T00%3A00%3A00Z&end=2021-03-24T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A2 event_or_study_opera_rtc
    > ""fileID": "OPERA_L2_RTC-S1_T129-275110-IW3_20210323T124742Z_20250904T135126Z_S1A_30_v1.0", "flightDirection": "ASCENDING", "pathNumber": 129, "processingLevel": "RTC""
[52] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2888.19+27.91%29&start=2024-01-01T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A3 current_s1_slc
    > ""fileID": "S1D_IW_SLC__1SDV_20261103T121312_20261103T121339_005303_00A17B_5C5F-SLC", "flightDirection": "ASCENDING", "pathNumber": 12, "processingLevel": "SLC""
[53] https://api.daac.asf.alaska.edu/services/search/param?dataset=NISAR&processingLevel=RSLC&intersectsWith=POINT%2888.19+27.91%29&start=2026-06-17T00%3A00%3A00Z&end=2026-11-15T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A3 current_nisar_rslc
    > ""fileID": "NISAR_L1_UR_RSLC_035_120_D_074_4005_DHDH_A_20261113T124953_20261113T125028_P05036_F_F_J_001", "flightDirection": "DESCENDING", "pathNumber": 120, "processingLevel": "RSLC""
[54] https://api.daac.asf.alaska.edu/services/search/param?dataset=SENTINEL-1&processingLevel=SLC&intersectsWith=POINT%2888.19+27.91%29&start=2023-08-20T00%3A00%3A00Z&end=2023-11-18T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A3 event_or_study_s1_slc
    > ""fileID": "S1A_IW_SLC__1SDV_20231115T000326_20231115T000353_051220_062DB9_B370-SLC", "flightDirection": "DESCENDING", "pathNumber": 48, "processingLevel": "SLC""
[55] https://api.daac.asf.alaska.edu/services/search/param?dataset=OPERA-S1&processingLevel=RTC&intersectsWith=POINT%2888.19+27.91%29&start=2023-08-20T00%3A00%3A00Z&end=2023-11-18T23%3A59%3A59Z&maxResults=10000&output=geojson — ASF live query A3 event_or_study_opera_rtc
    > ""fileID": "OPERA_L2_RTC-S1_T048-101863-IW3_20231115T000340Z_20231119T204937Z_S1A_30_v1.0", "flightDirection": "DESCENDING", "pathNumber": 48, "processingLevel": "RTC""
[56] https://nominatim.openstreetmap.org/search?q=Timure%2C+Rasuwa%2C+Nepal&format=jsonv2 — OpenStreetMap Nominatim search: Timure, Rasuwa
    > ""lat":"28.2528483","lon":"85.3666715","category":"place","type":"suburb","place_rank":19,"importance":0.14671666819256882,"addresstype":"suburb","name":"टिमुरे","display_name":"टिमुरे, Gosaikunda-02, गोसाइँकुण्ड गाउँपालिका, रसुवा जिल्ला, बागमती प्रदेश, नेपाल""
[57] https://nominatim.openstreetmap.org/search?q=Haku+Besi%2C+Nepal&format=jsonv2 — OpenStreetMap Nominatim search: Haku Besi, Rasuwa
    > ""lat":"28.1164817","lon":"85.2790735","category":"place","type":"hamlet","place_rank":20,"importance":0.1333833348592355,"addresstype":"hamlet","name":"हाकु बेसी","display_name":"हाकु बेसी, Aamachhodingmo-01, आमाछोदिङ्मो गाउँपालिका, रसुवा जिल्ला, बागमती प्रदेश, नेपाल""
[58] https://nominatim.openstreetmap.org/search?q=Mailung%2C+Rasuwa%2C+Nepal&format=jsonv2 — OpenStreetMap Nominatim search: Mailung, Rasuwa
    > ""lat":"28.0717737","lon":"85.2070031","category":"place","type":"hamlet","place_rank":20,"importance":0.1333833348592355,"addresstype":"hamlet","name":"मैलुङ","display_name":"मैलुङ, Uttargaya-01, उत्तरगया गाउँपालिका, रसुवा जिल्ला, बागमती प्रदेश, नेपाल""
[59] https://www.stimson.org/2025/investigating-an-emerging-climate-hazard-transboundary-glacial-floods-on-the-china-nepal-border — Investigating an Emerging Climate Hazard: Transboundary Glacial Floods on the China-Nepal Border
    > "The flood damaged critical infrastructure, halted trade along the busy Nepal-China trade corridor, and caused significant impacts over 100-kilometers downstream, including damaging hydropower projects, disrupting electricity production, and eroding agricultural lands."
