TITLE: Remote sensing interpretation of causes and dynamics of the Gyirong outburst flood disaster, Tibet, on July 8, 2025
URL: https://link.springer.com/article/10.1007/s11069-026-08081-1?error=cookies_not_supported&code=a0bfd2c8-da19-4251-80f1-873f9df56f10
ERROR: None

## Abstract

In high mountain regions, glacial lake outburst floods (GLOFs) are significant geomorphic processes that reshape landscapes and have been studied extensively for their devastating impacts. On July 8, 2025, a catastrophic GLOF struck Gyirong land port, Tibet, China, causing at least nine deaths and leaving 19 people missing. This event was triggered by a rapid reduction of ~ 0.31 km2 (~ 45%) in supraglacial lake area in the upper Purepu Tsangpo, a tributary of the Donglin Tsangpo. Remote sensing analysis reveals that the lake’s surface area expanded ~ 7.65-fold, from ~ 0.08 km2 on May 9 to ~ 0.69 km2 on July 6, 2025, likely driven by global warming and intense regional rainfall, as inferred from meteorological data. Our remote sedimentological investigation indicates that the outburst flood, originating from a supraglacial lake on a debris-covered glacier, drained through supraglacial and englacial channels to downstream areas. Using the superelevation phenomenon, flow velocity and peak discharge were estimated, revealing that the flood weakened in wide, gently sloping U-shaped valleys after exiting the glacier terminus. In narrow, V-shaped valleys downstream, however, extensive erosion and entrainment substantially amplified the flood, resulting in an approximately sixfold increase in peak discharge, reaching ~ 8,400 m3/s, and ultimately evolving into a debris flow. This amplification is attributed to the topographic constraints of V-shaped valleys, where periglacial geomorphology transitions from glacier-dominated U-shaped valleys upstream to river-erosion-dominated V-shaped valleys downstream, with channels rich in erodible sediments. These conditions enhance volume amplification during GLOF evolution, increasing destructive potential. This study underscores the hazards of supraglacial lakes on debris-covered glaciers, emphasizing the urgent need for regional glacial lake hazard assessments and quantitative risk evaluations.

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig1_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig2_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig3_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig4_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig5_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig6_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig7_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig8_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig9_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig10_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig11_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig12_HTML.png)

![](//media.springernature.com/m312/springer-static/image/art%3A10.1007%2Fs11069-026-08081-1/MediaObjects/11069_2026_8081_Fig13_HTML.png)

### Similar content being viewed by others

## Data availability

All data is with the corresponding author and will be made available on reasonable request.

## References

- Benn DI, Bolch T, Hands K et al (2012) Response of debris-covered glaciers in the Mount Everest region to recent warming, and implications for outburst flood hazards. Earth Sci Rev 114(1–2):156–174. [https://doi.org/10.1016/j.earscirev.2012.03.008](https://doi.org/10.1016/j.earscirev.2012.03.008)
- Bennett GL, Panici D, Rengers FK et al (2025) Landslide-channel feedbacks amplify channel widening during floods. Npj Nat Hazards 2(1):7. [https://doi.org/10.1038/s44304-025-00059-6](https://doi.org/10.1038/s44304-025-00059-6)
- Bulmer MH, Barnouin-Jha OS, Peitersen MN, Bourke M (2002) An empirical approach to studying debris flows: implications for planetary modeling studies. J Geophys Res Planets 107(E5):9–1. [https://doi.org/10.1029/2001JE001531](https://doi.org/10.1029/2001JE001531)
- Chen C, Zhang C, Liu X et al (2023a) Effects of freeze-thaw cycles on permeability behavior and desiccation cracking of Dalian red clay in China considering saline intrusion. Sustainability 15(4):3858. [https://doi.org/10.3390/su15043858](https://doi.org/10.3390/su15043858)
- Chen F, Wang J, Li B et al (2023b) Spatial variability in melting on Himalayan debris-covered glaciers from 2000 to 2013. Remote Sens Environ 291:113560. [https://doi.org/10.1016/j.rse.2023.113560](https://doi.org/10.1016/j.rse.2023.113560)
- Cook KL, Andermann C, Gimbert F et al (2018) Glacial lake outburst floods as drivers of fluvial erosion in the Himalaya. Science 362(6410):53–57. [https://doi.org/10.1126/science.aat4981](https://doi.org/10.1126/science.aat4981)
- Furian W, Maussion F, Schneider C (2022) Projected 21st-century glacial lake evolution in High Mountain Asia. Front Earth Sci 10:821798. [https://doi.org/10.3389/feart.2022.821798](https://doi.org/10.3389/feart.2022.821798)
- Glen E, Leeson A, Banwell AF et al (2025) A comparison of supraglacial meltwater features throughout contrasting melt seasons: Southwest Greenland. Cryosphere 19(3):1047–1066. [https://doi.org/10.5194/tc-19-1047-2025](https://doi.org/10.5194/tc-19-1047-2025)
- Gouli MR, Hu K, Khadka N et al (2025) Quantitative assessment of the GLOF risk along China-Nepal transboundary basins by integrating remote sensing, machine learning, and hydrodynamic model. Int J Disaster Risk Reduct 118:105231. [https://doi.org/10.1016/j.ijdrr.2025.105231](https://doi.org/10.1016/j.ijdrr.2025.105231)
- Gregoretti C, Stancanelli LM, Bernard M et al (2019) Relevance of erosion processes when modelling in-channel gravel debris flows for efficient hazard assessment. J Hydrol 568:575–591. [https://doi.org/10.1016/j.jhydrol.2018.10.001](https://doi.org/10.1016/j.jhydrol.2018.10.001)
- Grima C, Koch I, Greenbaum J et al (2019) Surface and basal boundary conditions at the Southern McMurdo and Ross Ice Shelves, Antarctica. J Glaciol 65(252):675–688. [https://doi.org/10.1017/jog.2019.44](https://doi.org/10.1017/jog.2019.44)
- Hall K (2007) Evidence for freeze–thaw events and their implications for rock weathering in northern Canada: II. the temperature at which water freezes in rock. Earth Surf Process Landf 32(2):249–259. [https://doi.org/10.1002/esp.1389](https://doi.org/10.1002/esp.1389)
- Harrison S, Kargel JS, Huggel C et al (2018) Climate change and the global pattern of moraine-dammed glacial lake outburst floods. Cryosphere 12(4):1195–1209. [https://doi.org/10.5194/tc-12-1195-2018](https://doi.org/10.5194/tc-12-1195-2018)
- Hugonnet R, McNabb R, Berthier E et al (2021) Accelerated global glacier mass loss in the early twenty-first century. Nature 592(7856):726–731. [https://doi.org/10.1038/s41586-021-03436-z](https://doi.org/10.1038/s41586-021-03436-z)
- Hungr O, Morgan G, Kellerhals R (1984) Quantitative analysis of debris torrent hazards for design of remedial measures. Can Geotech J 21(4):663–677. [https://doi.org/10.1139/t84-073](https://doi.org/10.1139/t84-073)
- Ikeya H, Uehara S (1982) Debris flow in s-shaped channel curves. J Jpn Soc Civ Eng 24:645–650
- Komori J, Koike T, Yamanokuchi T et al (2012) Glacial lake outburst events in the Bhutan Himalayas. Global Environ Res 16(1):59–70
- Liu JJ, Cheng ZL, Li Y (2014) The 1988 glacial lake outburst flood in Guangxieco Lake, Tibet, China. Nat Hazards Earth Syst Sci 14(11):3065–3075. [https://doi.org/10.5194/nhess-14-3065-2014](https://doi.org/10.5194/nhess-14-3065-2014)
- Miles ES, Watson CS, Brun F et al (2018) Glacial and geomorphic effects of a supraglacial lake drainage and outburst event, Everest region, Nepal Himalaya. Cryosphere 12(12):3891–3905. [https://doi.org/10.5194/tc-12-3891-2018](https://doi.org/10.5194/tc-12-3891-2018)
- Miles KE, Hubbard B, Irvine-Fynn TD et al (2020) Hydrology of debris-covered glaciers in high mountain Asia. Earth Sci Rev 207:103212. [https://doi.org/10.1016/j.earscirev.2020.103212](https://doi.org/10.1016/j.earscirev.2020.103212)
- Mizuyama T, Uehara S (1981) Debris flow in steep slope channel curves. J Jpn Soc Civ Eng 23:243–248
- Moore PL (2021) Numerical simulation of supraglacial debris mobility: implications for ablation and landform genesis. Front Earth Sci 9:710131. [https://doi.org/10.3389/feart.2021.710131](https://doi.org/10.3389/feart.2021.710131)
- Narama C, Daiyrov M, Tadono T et al (2017) Seasonal drainage of supraglacial lakes on debris-covered glaciers in the Tien Shan Mountains, Central Asia. Geomorphology 286:133–142. [https://doi.org/10.1016/j.geomorph.2017.03.002](https://doi.org/10.1016/j.geomorph.2017.03.002)
- Nicholson LI, McCarthy M, Pritchard HD, Willis I (2018) Supraglacial debris thickness variability: impact on ablation and relation to terrain properties. Cryosphere 12(12):3719–3734. [https://doi.org/10.5194/tc-12-3719-2018](https://doi.org/10.5194/tc-12-3719-2018)
- Prochaska AB, Santi PM, Higgins JD, Cannon SH (2008) A study of methods to estimate debris flow velocity. Landslides 5(4):431–444. [https://doi.org/10.1007/s10346-008-0137-0](https://doi.org/10.1007/s10346-008-0137-0)
- Pudasaini SP, Krautblatter M (2021) The mechanics of landslide mobility with erosion. Nat Commun 12(1):6793. [https://doi.org/10.1038/s41467-021-26959-5](https://doi.org/10.1038/s41467-021-26959-5)
- Sattar A, Haritashya UK, Kargel JS et al (2022) Transition of a small Himalayan glacier lake outburst flood to a giant transborder flood and debris flow. Sci Rep 12(1):12421. [https://doi.org/10.1038/s41598-022-16337-6](https://doi.org/10.1038/s41598-022-16337-6)
- Sattar A, Cook KL, Rai SK et al (2025) The Sikkim flood of October 2023: drivers, causes, and impacts of a multihazard cascade. Science 387(6740):eads2659. [https://doi.org/10.1126/science.ads2659](https://doi.org/10.1126/science.ads2659)
- Scheidl C, McArdell BW, Rickenmann D (2015) Debris-flow velocities and superelevation in a curved laboratory channel. Can Geotech J 52(3):305–317
- Shrestha F, Steiner JF, Shrestha R et al (2023) A comprehensive and version-controlled database of glacial lake outburst floods in High Mountain Asia. Earth Syst Sci Data 15(9):3941–3961. [https://doi.org/10.5194/essd-15-3941-2023](https://doi.org/10.5194/essd-15-3941-2023)
- Shugar DH, Burr A, Haritashya UK et al (2020) Rapid worldwide growth of glacial lakes since 1990. Nat Clim Change 10(10):939–945. [https://doi.org/10.1038/s41558-020-0855-4](https://doi.org/10.1038/s41558-020-0855-4)
- Takahisa M (1988) Technical standard for the measures against debris flow (draft). Tech Mem PWRI 2632:48
- Taylor C, Robinson TR, Dunning S et al (2023) Glacial lake outburst floods threaten millions globally. Nat Commun 14(1):487. [https://doi.org/10.1038/s41467-023-36033-x](https://doi.org/10.1038/s41467-023-36033-x)
- Veh G (2019) Outburst floods from moraine-dammed lakes in the Himalayas: detection, frequency, and hazard. Institutional Repository of the University of Potsdam. [https://doi.org/10.25932/publishup-43607](https://doi.org/10.25932/publishup-43607)
- Wang H, Cui P, Li Y et al (2024a) Rock and ice avalanche-generated catastrophic debris flow at Chamoli, 7 February 2021: new insights from the geomorphic perspective. Geomorphology 452:109110. [https://doi.org/10.1016/j.geomorph.2024.109110](https://doi.org/10.1016/j.geomorph.2024.109110)
- Wang X, Zhang G, Veh G et al (2024b) Reconstructing glacial lake outburst floods in the Poiqu River basin, central Himalaya. Geomorphology 449:109063. [https://doi.org/10.1016/j.geomorph.2024.109063](https://doi.org/10.1016/j.geomorph.2024.109063)
- Yao T, Xue Y, Chen D et al (2019) Recent Third Pole’s rapid warming accompanies cryospheric melt and water cycle intensification and interactions between monsoon and environment: multidisciplinary approach with observations, modeling, and analysis. Bull Am Meteorol Soc 100(3):423–444. [https://doi.org/10.1175/BAMS-D-17-0057.1](https://doi.org/10.1175/BAMS-D-17-0057.1)
- Zeller L, McGrath D, McCoy SW et al (2024) Seasonal to decadal dynamics of supraglacial lakes on debris-covered glaciers in the Khumbu region, Nepal. Cryosphere 18(2):525–541. [https://doi.org/10.5194/tc-18-525-2024](https://doi.org/10.5194/tc-18-525-2024)
- Zhang G, Carrivick JL, Emmer A et al (2024) Characteristics and changes of glacial lakes and outburst floods. Nat Rev Earth Environ 5(6):447–462. [https://doi.org/10.1038/s43017-024-00554-w](https://doi.org/10.1038/s43017-024-00554-w)
- Zheng G, Allen SK, Bao A et al (2021) Increasing risk of glacial lake outburst floods from future Third Pole deglaciation. Nat Clim Change 11(5):411–417. [https://doi.org/10.1038/s41558-021-01028-3](https://doi.org/10.1038/s41558-021-01028-3)
- Zhou GG, Lu X, Xie Y et al (2022) Mechanisms of the non‐uniform breach morphology evolution of landslide dams composed of unconsolidated sediments during overtopping failure. J Geophys Res Earth Surf 127(10):e2022JF006664. [https://doi.org/10.1029/2022JF006664](https://doi.org/10.1029/2022JF006664)
- Zimmer PD, Gabet EJ (2018) Assessing glacial modification of bedrock valleys using a novel approach. Geomorphology 318:336–347. [https://doi.org/10.1016/j.geomorph.2018.06.021](https://doi.org/10.1016/j.geomorph.2018.06.021)

## Acknowledgements

This study is supported by the National Natural Science Foundation of China (42401008), the Key Research and Development Program of Xizang Autonomous Region (XZ202301ZY0039G), and the Science and Technology Research Program of the Institute of Mountain Hazards and Environment, Chinese Academy of Sciences (IMHE-ZDRW-01).

## Funding

This research was funded by the National Natural Science Foundation of China (42401008), the Key Research and Development Program of Xizang Autonomous Region (XZ202301ZY0039G), and the Science and Technology Research Program of the Institute of Mountain Hazards and Environment, Chinese Academy of Sciences (IMHE-ZDRW-01).

## Ethics declarations

### Conflict of interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

## Additional information

### Publisher's Note

Springer Nature remains neutral with regard to jurisdictional claims in published maps and institutional affiliations.

## Rights and permissions

Springer Nature or its licensor (e.g. a society or other partner) holds exclusive rights to this article under a publishing agreement with the author(s) or other rightsholder(s); author self-archiving of the accepted manuscript version of this article is solely governed by the terms of such publishing agreement and applicable law.

## About this article

### Cite this article

Zhang, Q., Hu, K., Liu, S. *et al.* Remote sensing interpretation of causes and dynamics of the Gyirong outburst flood disaster, Tibet, on July 8, 2025. *Nat Hazards***122**, 316 (2026). https://doi.org/10.1007/s11069-026-08081-1

- Received
- Accepted
- Published
- Version of record
- DOIhttps://doi.org/10.1007/s11069-026-08081-1

### Keywords