Site Visit and Drone Based Reconnaissance Study of the Severely
Affected Infrastructure by February 7th
, 2021, Chamoli Rock-Ice
Avalanche Disaster, Uttarakhand, India
Reconnaissance Team and Authors:
Prashanth Vangla, Assistant Professor, IIT Delhi, India
Dipali Jindal, Ph.D. Student, IIT Delhi, India
Avinash Sajwan, Ph.D. Student, IIT Delhi, India
Rituraj Devrani, Ph.D. Candidate, IIT Delhi, India
Reconnaissance Coordinators and Authors (in alphabetical order):
J. David Frost, Elizabeth and Bill Higginbotham Professor, Georgia Institute of Technology, USA
G. V. Ramana, Professor, IIT Delhi, India
Other Contributors (in alphabetical order):
Alejandro Martinez, University of California Davis, USA
Biruk Gissila, Ph.D Candidate, IIT Delhi, India
C. T. Dhanya, IIT Delhi, India
G. Madhavi Latha, IISc, India
G.L.Sivakumar Babu, IISc, India
G. S. P, Madabhushi, University of Cambridge, UK
E. Nichols, GEER Recorder, Georgia Institute of Technology
K. S. Rao, IIT Delhi, India
R. Ayothiraman, Professor, IIT Delhi, India
Sri Harsha Kota, IIT Delhi, India
GEER – 074
doi:10.18118/G6V95B
Barrage of Tapovan Vishnugad hydroelectric project 
2
Acknowledgments
This report is an outcome of a collaborative project supported by the Scheme for Promotion of
Academic and Research Collaboration (SPARC) Project #P83, MoE, India at IIT Delhi. The
sponsored collaborative project titled "Advanced Technologies for Post-Disasters
Reconnaissance, Forensic and Environmental Impact Studies - Geotechnical" among IIT Delhi,
IISc, Georgia Institute of Technology, University of California, Davis, and the University of
Cambridge, mobilized a team from IIT Delhi to conduct a reconnaissance study to gather the
perishable data of the February 07th,
 2021 Chamoli disaster.
Any opinions, findings, conclusions, or recommendations expressed in this report are those of the
authors and do not necessarily reflect the views of the MoE. The reconnaissance team and
coordinators would like to acknowledge and appreciate several officials, news reporters, locals of
the Tapovan and Rishiganga areas who supported the reconnaissance team during the field trip.
Our special thanks to Mr. Kundan Prasad, CO, ITBP., Mr. Benudhar Nayak, Commandant, ITBP,
Mr. Sher Singh Butola, Assistant Commandant, ITBP, Mr. Ravi Kumar Yadav, GREF, Dr. Sunita
Kumari, Associate Professor, NIT Patna, and other several officials of ITBP, for facilitating local
logistics and permissions to access the affected areas for collecting all the crucial information for
the recce. We especially appreciate Mr. Sher Singh Butola for his constant support and valuable
aftermath insights into the study area he gathered through the aerial survey conducted with ITBP
support. We also thank several locals who helped us during the recce study, special mentions to
Mr. Sikim (brother of the NTPC staff, who was missing after the floods), who witnessed the event,
explained the event's details, and its effects on the Rishiganga project. He also provided critical
pre and post-event videos/photographs that are used in the report with his permission. 
3
Contents
Acknowledgments........................................................................................................................... 2
Statement of General Liability Limitation – Disclaimer ................................................................ 8
Summary 9
Chapter 1: Introduction 11
1.1 February 7th
, 2021 Cascading Chamoli disaster ............................................................. 11
Chapter 2: Reconnaissance survey…………………………………………………………… 18
2.1 Planning and Implementation……………………………………………………………...18
2.2 Equipment and tools……………………………………………………………………….19
Chapter 3: Impacts on the infrastructure in the reconned areas……………………………20
3.1 Study Area – I: Rishiganga HEP and Raini Bridge……………………………………20
3.1.1 Photogrammetric evidence of Rishiganga-HEP and Raini village…………………24
3.1.2 Topography and debris……………………………………………………………..27
3.1.3 DEM analysis for erosion and debris deposition……………………………….…..35
3.1.4 Photogrammetry evidence of Reconned area - I…………………………….……..41
3.2  Study Area – II: Tapovan HEP 51
3.2.1 Photogrammetry evidence of TV-HEP…………………………………………….54
3.2.2 Flood level at Tapovan-HEP……………………………………………………….56
3.2.3 3D View of TV-HEP………………………………………………………………58
Recommendations……………………………………………………………………………….66
References……………………………………………………………………………………….68 
4
List of Figures
Figure 1.1 (a) Suspected Site of Rockslide/Snow Avalanche (16 September 2020, source:
KOMPSAT 3A) (b) Observed cracks (05 February 2021, source: SENTINEL 2A) (c) Crack width
(source: PLEIADES) (d) 3D Rendition of the Suspected Area of Rockslide/Snow Avalanche (09-
Feb2021, source: ISRO-CARTOSAT-3 satellite) ........................................................................ 13
Figure 1.2 Overview of the rock-ice avalanche travel path (bold blue line) from the event source
to the point where the floodwater and debris were detained. ........................................................ 14
Figure 1.3 Srinagar Dam with turbid water (Dated 11/02/2021) (30°14'31.28"N, 78°49'20.41"E)
....................................................................................................................................................... 15
Figure 1.4 Distance and elevation difference of different affected areas from the source of rock-
ice avalanche ................................................................................................................................. 17
Figure 3.1 Status of Infrastructure in the Rishiganga HEP location before and after the event. The
locations of the structures are marked by solid yellow line shapes a) Google Earth imagery,
November 2018. b) ortho-imagery from drone survey, February 11th, 2021. ............................. 21
Figure 3.2 Impoundment connected to the diversion tunnel a) during the construction b) after
filling the water (Photo courtesy: Sikim, native) .......................................................................... 22
Figure 3.3 Powerhouse, three-story building on Rishiganga river left bank and RCC bridge
connecting Niti Valley a) from right bank road connecting to RCC bridge b) from penstock
location (Photo courtesy: Sikim, native) ....................................................................................... 23
Figure 3.4 Inside view of the powerhouse (Photo courtesy: Sikim, native) ................................. 24
Figure 3.5 Three-dimensional aerial view of the reconned area-I generated from its DEM draped
by the mosaic image. (Dated: February 11th, 2021) ............................................................................................25 
5
Figure 3.6 3D perspective view of exact locations and the components of the Rishiganga HEP and
Raini bridge a) (Left image) mapped in the DEM draped by the mosaic image b) (right image)
close-up view of pre (obtained from the Google imagery) and post-event appearance of the
infrastructures (Dated: February 11th,
 2021) .................................................................................. 26
Figure 3.7 DEMs of Rishiganga area a) pre-event and b) post-event ........................................... 29
Figure 3.8 Proposed cross-sections along the riverbed from CS1 to CS13 from post-event
orthophoto and DEM ..................................................................................................................... 30
Figure 3.9 Surface elevation profile in the valley along the riverbed from CS-1 to CS-12. ......... 31
Figure 3.10 Variation of cross-sectional shape in the valley along the river from CS-1 to CS-13.
....................................................................................................................................................... 33
Figure 3.11 Variation of the cross-section area in the valley along the river from CS-1 to CS-13
....................................................................................................................................................... 34
Figure 3.12 Variation of flood watermark along Rishiganga and Raini village ............................ 35
Figure 3.13 DEM of difference between pre-event and post-event DEM of Rishiganga HEP ..... 37
Figure 3.14 Slope calculated from DEM (resolution-1m) of Rishiganga HEP ............................. 39
Figure 3.15 Types of profile curvature (ESRI ArcGIS manual) .................................................... 39
Figure 3.16 Profile curvature calculated from DEM (resolution-1m) of Rishiganga HEP ........... 40
Figure 3.17 Barrage region, 30°28'42.68"N 79°42'0.50" E (Dated: 11/2/2021)............................ 41
Figure 3.18 Marks of impoundment region@ 30°28'45.39"N 79°41'53.46" E (Dated: 11/02/2021
....................................................................................................................................................... 42
Figure 3.19 Accumulated Boulders/ Broken concrete structures, a few centimeters ahead of the
tail of impoundment @ 30°28'47.40"N 79°41'53.25"E (Dated:11/02/2021) ............................... 42
Figure 3.20 Buried pipe/tunnel structure@ 30°28'56.39"N 79°41'49.20" E ................................. 43
Figure 3.21 a)Pre- and b) Post-event temporary building location @ 30°28'46.26"N 79°41'50.83"E 
6
(Dated:11/02/2021) ........................................................................................................................ 44
Figure 3.22 Buried powerhouse region @30°29'5.11"N 79°41'40.46"E (Dated: 11/02/2021) ..... 45
Figure 3.23 Damaged/Buried Residential Houses@ 30°28'51.83"N 79°41'49.93"E .................... 46
(Dated: 11/02/2021) ....................................................................................................................... 46
Figure 3.24 Post-event images at the location of the penstock illustrate the damage caused, exposed
reinforcement, and deposition of debris covering the penstock a) top view (30°29'2.57"N
79°41'40.91"E) b) side view. (Dated: February 11th, 2021).......................................................... 47
Figure 3.25 Damaged Raini bridge across the bank of Rishiganga River with only left abutment
and no decks. (30°29'7.95"N, 79°41'39.56"E) (Dated: February 11th, 2021) ............................... 48
Figure 3.26 Crater formation at mountain face from the collision of debris flow with the hill
(N30ᵒ29'11.30", E79ᵒ41’29.65”, Elevation-1989 m). (Dated: February 11th
, 2021)  ...................... 50
Figure 3.27 Raised watermarks upstream of Dhauliganga as proof of temporary blockage of the
main river and debris throwback after the impact with the hill. (N 30ᵒ29’11.30” E079ᵒ41’29.65”,
Elevation-1989 m) (Dated: February 11th, 2021) .......................................................................... 50
Figure 3.28 Close-up view of barrage site infrastructure (Source: NTPC Tapovan) .................... 51
Figure 3.29 Tapovan HEP area (a) pre and (b) post-event orthophoto data showing the collapsed
bridges, damaged structures, accumulated boulders, muddy water and, affected barrage gates ... 53
Figure 3.30 Surface plan overlaid on orthophoto. ......................................................................... 55
Figure 3.31 Variation of flood debris marks along the study area a) Orthorectified mosaic image
b) elevation of debris marks vs. the traverse distance of flood ...................................................... 57
Figure 3.32 3D view of Tapovan barrage site ................................................................................ 58
Figure 3.33 Pre-and post-disaster situation at the barrage site. ..................................................... 59
Figure 3.34 Aftermath marks of the Intake structure, desilting chamber, and conduits@
30°29'35.89"N 79°37'41.67"E (Dated:11/02/2021) ....................................................................... 60 
7
Figure 3.35 Close-up view of the Intake structure ......................................................................... 61
Figure 3.36 Distorted steel bars at the tail of intake structure ....................................................... 61
Figure 3.37 View of Tapovan barrage @ 30°29'35.89"N 79°37'41.67"E (Dated: 11/02/2021) .... 62
Figure 3.38 Dimensions of the existing and vanished portion of the breast wall (highlighted with
red strips) along with the accumulated boulders ............................................................................ 63
Figure 3.39 Close-up view of a boulder ......................................................................................... 63
Figure 3.40 Yellow solid line circles indicating the guardrooms a) snapshot taken from a video
presents the two guard rooms just before the event (Source: Sikim (native), February 7th
, 2021)
b)  sustained and washed away guard rooms (Source: DSLR, February 11th
, 2021)) ................... 64
Figure 3.41: Close-up of collapsed bridge-1 U/s of Tapovan Barrage site.................................... 65
(dated 11/2/21)
  
8
Statement of General Liability Limitation – Disclaimer
This reconnaissance mission team was comprised of individual volunteers. The findings and
observations presented in this report are based on the conditions of the observed features at the
time of the inspection and their experience with other similar structures. This report is not an
assessment of the situation or safety of the structures observed. No warranty or guarantee regarding
the performance or safety of the observed structures is included or intended. Any use of or
reliance on this report is at the sole risk of the party using or relying on the report.
NSF Acknowledgement
The work of the GEER Association is based in part on work supported by the National Science
Foundation through the Engineering for Civil Infrastructure Program under Grant No.
CMMI1826118. Any opinions, findings, and conclusions or recommendations expressed in this
material are those of the authors and do not necessarily reflect the views of the NSF.
9
Summary
This report documents the field observations made by the reconnaissance team during the site visit
undertaken from February 9th
 through 11th
, 2021, in the flash flood location in Chamoli District,
Uttarakhand, India. The extreme event of the flash flood unfolded on 7th
 Feb 2021 and inundated
the banks of the Rishiganga and Dhauliganga rivers with debris flow. The extreme event caused
massive destruction to hydropower projects (Rishiganga HEP and Tapovan Vishnugad HEP),
bridges, roads, houses, and out of a total of 204 missing persons, 78 people were reported dead as
per the published document by the Disaster Management Division, Ministry of Home Affairs
(https://ndmindia.mha.gov.in/NDMINDIA-CMS/viewsituationDisasterReportPdfDocument-103).
Initially, it is speculated that a glacial lake outburst flood (GLOF) might have been the cause of the
flash floods. However, subsequent analysis of satellite images revealed that a rock-ice avalanche
caused debris flow and flash flood (Martha et al., 2021). This report doesn’t present and discuss the
causative factors of the disaster but focuses on collecting perishable data and damage assessment
based on a drone-based reconnaissance study (Zwęgliński 2020). The planning and implementation
of the reconnaissance study were by the IIT Delhi Team. The site visit is undertaken from February
9th
 through February 11th
, 2021, two days after the event, as summarized in subsequent chapters.
Field reconnaissance involves capturing geo-referenced images of the affected areas through
drones and digital cameras that provide direct information about the conditions on the ground to
assess the consequences/damage resulting from the disaster. Digital Elevation Models (DEMs) of
the affected areas, including upstream and downstream of Rishiganga HEP (R-HEP) and Tapovan
Vishnugad HEP (TV-HEP), generated from the drone survey are used to describe the severity of
damage to the hydropower infrastructure, flood height range and topographical variation due to
floods. Further, the cross-sectional variation of the river valley of both the locations (R-HEP and 
10
TV-HEP) is quantitatively analyzed using DEMs. The report also presents the geometrical features
of the damaged structures and rock fragments/boulders (Collins 2014) that were rolled downstream
by the flash floods. Additionally, the classification of soil samples collected with a hand auger
from different locations at the Rishiganga site is presented. The report also highlights the
importance and usefulness of pre and post-event images/videos obtained from the locals to locate
and map the lost and damaged structures and get a qualitative gauge of the damage incurred. Some
efforts are made to quantify the erosion, deposition, and topographical changes based on the
observations made during the field reconnaissance and drone survey. 
11
Chapter 1: Introduction
1.1 February 7th, 2021 Cascading Chamoli disaster
Chamoli lies in the north-eastern part of Uttarakhand state, India. A significant part of the district
is always covered with snow. The topography of the Chamoli district has high hills and
mountains with very narrow valleys, deep gorges having very high gradients. Several important
rivers Alaknanda, and tributaries (Rishiganga and Dhauliganga) flow through this region. These
rivers generally flow with high velocity in steep and narrow channels, often resulting in excessive
erosion and collapse of the banks. Due to the cool and moist climate, the soils have developed from
rocks like granite, schist, gneiss, phyllites, shales, and slate. Structural imbalances generally
accompany the occurrence of groundwater in hilly areas. The state is prone to landslides,
earthquakes, and floods due to these geological and physiographic features (Martha and Vinod
Kumar 2013).
Around 10:22 am [IST], a catastrophic ice-rock avalanche that transformed into a mud and
debris flood wave with extreme speed descended the Ronti Gad, Rishiganga, Tapovan, and
Dhauliganga valleys in Chamoli district, Uttarakhand, India. It caused massive destruction of
hydropower structures, roads, and bridges and killed several people along its path. Rishiganga and
Tapovan Vishnugad hydropower projects were damaged severely. The disaster is the first of its
kind in India. It can be classified as an extreme event for two reasons: 1) it is an enormous and
devastating debris flood wave causing massive devastation, and 2) it opened up a new dimension
for learning and provided an opportunity to review and redesign current policies for planning
hydropower infrastructure in high hills and mountainous areas.
The satellite images (KOMPSAT 3A, SENTINEL 2A, and PLEIADES) that were released
immediately after the event revealed that the source of the flash flood was found at Ronti Peak
(Glacier Valley) at an altitude of about 5500 m Mean Sea Level (MSL). Figures 1.1a and 1.1b 
12
present the satellite images of suspected rock-ice slide avalanche location (captured on 16th
 Sep
2020) and crack formation just before the event, i.e., 5th
 Feb 2021, respectively. The image presented
in Figure 1.1(c), captured on 9th Feb 2021, clearly indicates that a massive and suspended site was
dislodged, forming a vast cavity with approximate dimensions of 0.61 km wide and 1.32 km high.
Figure 1.1(d) presents a 3D interpretation of the slide and its location. Figure 1.2 gives the overviews
of the rock-ice avalanche travel path (bold blue line) from the event source to the point where the
floodwater and debris were detained.
13
Figure 1.1 a) Suspected Site of Rockslide/Snow Avalanche (16 September 2020, source: KOMPSAT
3A) (b) Observed cracks (05 February 2021, source: SENTINEL 2A) (c) Crack width (source:
PLEIADES) (d) 3D Rendition of the Suspected Area of Rockslide/Snow Avalanche (09-Feb2021,
source: ISRO-CARTOSAT-3 satellite)
 
14
Figure 1.2 Overview of the rock-ice avalanche travel path (bold blue line) from the event source to the point where the floodwater and debris
were detained.
A - Source of rock-ice avalanche (30°22'35.05"N, 79°42'59.15"E)
B - Ronti Gad (30°23'39.27"N, 79°43'18.71"E)
C - Rishiganga HEP (30°28'42.04"N, 79°41'59.65"E)
D - Confluence: Rishiganga and Dhauliganga (30°29'17.54"N, 79°41'24.47"E)
E - Tapovan HEP (30°29'32.85"N, 79°37'52.51"E)
F - Confluence: Dhauliganga and Alaknanda (30°33'44.68"N, 79°34'33.99"E)
G - Vishnuprayag HEP (30°34'1.09"N, 79°32'48.56"E)
H - Vishnuprayag Pipalkoti HEP (30°25'58.80"N, 79°25'26.40"E)
I – Srinagar Dam/ Alaknanda HEP (30°14'31.28"N, 78°49'20.41"E)
 
15
Figure 1.3 Distance and elevation difference of different affected areas from the source of rock-
ice avalanche
Figure 1.3 depicts the distance and elevation difference of different hydropower projects
and rivers from the source of the rock-ice avalanche. One can imagine the impact and the intensity
of the damage incurred by hydroelectric projects and associated structures due to the flash flood.
The first interaction of dislodged mass with the ground surface was with a small stream through
which the glacier drains, i.e., Ronti Gad, at a distance of approximately 1.6 km and about an
elevation of 1800 m below the source. Then it traveled along the valley of Ronti Gad and mixed
with Rishiganga River, a source for the 13.2 MW Rishiganga hydroelectric project (HEP) near
Raini Village at an approximate distance of 15 km with an elevation difference of 3631 m from the
impact (source) site. It is the first HEP to face the brunt of the intense rock-ice avalanche. Most   its
structures/components were swept away and buried. Debris from R-HEP damaged other units
downstream and several megastructures, including one of the essential RCC bridges at Rishiganga 
16
(1985 above mean sea level) in the neighborhood of Dhauliganga (at a distance and elevation of
about 17 km and 3755 m from the source site). TV-HEP (520 MW, under construction) at
Dhauliganga, approx. 8 km downstream of R-HEP, and 23 km from the impact site, tap the river
water of Rishiganga and Dhauliganga. This second hydroelectric plant was impacted by flash
floods which contained large amounts of mud, debris, and large chunks of concrete/rock. The
Dhauliganga river, after the confluence with Rishiganga river, joins Alaknanda at Vishnuprayag
(confluence: 4247m elevation,  and 33 km distance from the slide location), is the source river for
two power projects along the way, namely, Vishnuprayag Hydro Electric Project (400 MW,
operational) and Vishnugad Pipalkoti Hydro Electric Project (444 MW, under construction). These
two HEPs have received minor to no damage. The Srinagar dam of Alaknanda HEP, located at
about 129 km and 5126 m elevation below the source, received and detained the debris and
floodwater produced by the avalanche (Figure 1.4.)  
17
Figure 1.4 Srinagar Dam with turbid water (Dated 11/02/2021) (30°14'31.28"N, 78°49'20.41"E)
 
18
Chapter 2: Reconnaissance survey
2.1 Planning and Implementation
The team planned their initial route map to visit the locations affected by the Chamoli disaster,
based on preliminary information gathered from social media and news reports. The Google Earth
Pro and Maps of India were utilized to locate the affected areas, including details about
hydropower projects, bridges, houses, roads, and flash flood travel paths. It was also learned that
some of the severely affected regions were partly inaccessible. The objective of the reconnaissance
study was to get a first-hand view and collect the perishable data of the areas that are severely
affected by disaster (Wartman et al., 2020), which could be used to understand the response of and
damage to the infrastructure in these areas. To this end, the team decided to primarily conduct
drone-based reconnaissance and collect the soil samples at possible locations.
The team traveled to Chamoli district on February 9th,
 2021, and reached in the evening on
February 10th
 and stayed at the nearest location of the affected areas, i.e., Joshimath. The areas to
be studied were decided, namely, Rishiganga HEP and Tapovan HEP, after learning from the locals
and government officials that these places were severely affected and further confirmed through
the field visit by the team. Early at 6:00 am on February 11th
, the team first visited the Rishiganga
HEP area, which was severely affected due to its proximity to the avalanche source. A  drone
imagery survey was conducted, covering approximately 41.9 hectares along the Rishiganga river
stretch. The starting location of the survey is at 30°28'18.40"N, 79°42'26.66"E and the ending
location at 30°29'19.42"N, 79°41'24.60"E upstream and downstream of Rishiganga river,
respectively. The team also collected soil samples from this location for soil characterization. On
the same day, in the afternoon, the team traveled 8 km downstream of R-HEP to the second
hydropower project along the travel path of flash floods, i.e., Tapovan HEP, at Dhauliganga. The 
19
aerial survey carried out in this area spanned between 30°29'43.16"N, 79°37'25.53"E and
30°29'31.65"N, 79°37'54.99"E, covering an area of about 11.8 hectares. In addition to drone
surveys and sample collections, the team also collected valuable information from the locals that
witnessed and captured the event using smartphones and cameras.
2.2 Equipment and tools
In this reconnaissance study, the team used state-of-the-art as well as conventional equipment and
tools to accomplish the objectives systematically. The details of the equipment used in the study
are given below.
Equipment and tools:
▪ Drone
o TALV2400- RPASF (Flight altitudes above ground level (AGL) 70 m)
▪ Differential Global Positioning System (DGPS)
o  EMLID RS2 DGPS was used for establishing Ground Control Points
(GCP)
o Ground sample distance (GSD) considered was 3 cm.
▪ DSLR Camera
▪ Rugged Handheld Garmin GPS (eTrex® 10)
▪ Extendable Auger Soil Samplers, pick-ax, and construction spade. 
20
Chapter 3: Impacts on the infrastructure in the study areas
The impacts on the infrastructure of two locations, namely, Rishiganga HEP/Raini village and
Tapovan, that were severely affected by the rock-ice avalanche, are discussed in the following
sections.
3.1 Study Area – I: Rishiganga HEP and Raini Bridge
The first reconnoitered area consisted of several vital infrastructures, including a barrage,
impoundment, and components of the hydropower plant, roads, and a reinforced concrete bridge,
as shown in Figure 3.1a. Figure 3.1b presents the post-event orthophoto generated from the drone
survey of the same area. The hydroelectric project commissioned in September 2012 was a Run-
of-River (RoR) with a capacity of 13.2 MW on the Rishiganga River, expected to generate
approximately 59,031 MWh (net) electricity per annum, and was completely damaged. The RCC
Bridge is a crucial and necessary structure connecting the two parts of the Raini village and links
13 villages close to the border with China that got completely washed away. Along with these
structures, several other associated and supporting buildings of HEP and connecting roads also
suffered severe damage, as shown in Figure 3.1b, due to the flash floods. Figures 3.2-3.4 give the
close-up view images of the REP and Raini bridge components collected from the locals. Figure
3.2 presents the impoundment connected to the diversion tunnel before and after filling the water.
Figure 3.3 shows staff quarters, office buildings, and some utility structures of the power plant before
the event. The powerhouse, penstock, and three-story building are on the Rishiganga river left bank.
Figure 3.4 presents an inside view of the power plant. These structures were destroyed and thus
missing after the disaster (Figure 3.1b). 
21
(a)
(b)
Figure 3.1 Status of Infrastructure in the Rishiganga HEP location before and after the event. The locations of the
structures are marked by solid yellow line shapes a) Google Earth imagery, November 2018. b) ortho-imagery from drone
survey, February 11th, 2021 
22
(a)
(b)
Figure 3.1 Impoundment connected to the diversion tunnel a) during the
construction b) after filling the water (Photo courtesy: Sikim, native) 30°28'45.39"N
79°41'53.46" E
 
23
(a)
(b)
Figure 3.2 Powerhouse, three-story building on Rishiganga river left bank and RCC bridge connecting Niti
Valley a) from right bank road connecting to RCC bridge b) from penstock location (Photo courtesy: Sikim,
native) @30°29'5.11"N 79°41'40.46"E 
24
Figure 3.3 Inside view of the powerhouse(Photo courtesy: Sikim, native) @30°29'5.11"N
79°41'40.46" E
3.1.1 Photogrammetric evidence of Rishiganga-HEP and Raini village
A 3D aerial view downstream and upstream of HEP is presented in Figure 3.5, developed
using the DEM draped by the mosaic images captured by the drone. Figure 3.6a illustrates the 3D
perspective view and locations of prominent features before the event that existed in the study area.
The features/structures at this location, barrage, and impoundment, temporary buildings,
powerhouse, and bridge, are marked as A, B, C, and D, respectively, as shown in Figure 3.6a.
Figure 3.6b presents the A, B, C, and D locations pre and post-event appearance. The comparison
of pre (obtained from the Google imagery data) and post-event have shown in Figure 3.6b
illustrates the extent of damage to the infrastructure. 
25
Figure 3.4 Three-dimensional aerial view of the study area-I generated from its DEM draped by the mosaic image. (Dated: February 11th, 2021)
 
26
Figure 3.5 3D perspective view of exact locations and the components of the Rishiganga HEP and Raini bridge a) (Left image) mapped in the DEM
draped by the mosaic image b) (right image) close-up view of pre (obtained from the Google imagery) and post-event appearance of the
infrastructures (Dated: February 11th, 2021) @30°29'5.11"N 79°41'40.46" E
 
27
3.1.2 Topography and debris
The pre and post-event DEM valley cross-sections and profiles are utilized to capture the
debris flow dynamics and the trend of soil erosion, debris deposition, and break-down of rock
fragments. The pre-event DEM is created using the Google Earth, DEM database from GPS
Visualizer and ArcGIS. Google Earth is used to locate and obtain a large dataset of point
coordinates (longitude and latitude) from the site of interest. GPS Visualizer is used to search for
the best possible and accurate elevation values from the DEM databases such as Shuttle Radar
Topography Mission (SRTM, resolution-30m) and Advanced Spaceborne Thermal Emission and
Reflection Radiometer (ASTER, resolution-30m). ArcGIS is used to create DEM of the pre-event
from the dataset of these points. The post-event DEM is created using the data set generated from
the high-resolution drone survey.
It may be noted that pre-event DEM is processed by ‘Natural Neighbor’ or ‘area stealing
spatial interpolation (Sibson, 1981) in ArcGIS to improve its resolution as close to the post-event
DEM. Figures 3.7a and 3.7b present pre and post-event DEMs of the Rishiganga HEP region at
10cm resolution. The locations A, B, C, and D, are also highlighted in Figures 3.7 a and 3.7b for
clarity.  Although the final resolution of pre-event and post-event DEM are the same, the drone-
based post-event DEM is more accurate, while the interpolated pre-event DEM represents the
average topography and may include elevation errors. Therefore the quantitative analysis presented
in the following sections, despite some errors is helpful for preliminary assessment of
topographical changes, flow dynamics, and the tendency of deposition and erosion. 
28
(a) 
29
(b)
Figure 3.6 DEMs of Rishiganga area a) pre-event and b) post-event@30°29'5.11"N
79°41'40.46"E
 
30
3.1.2.1 Debris flow characteristics based on cross-section and elevation
A total of 13 cross-sections at important locations were examined for pre and post-event to
understand the debris flow dynamics. The selected cross-sections are abbreviated as CS# (#1
through 13), as shown in Figure 3.8. CS1 and CS13 represent cross-sections located near upstream
of the barrage and the confluence of the rivers, respectively. The barrage is located around CS6,
the powerhouse is between CS9 and CS11, and the bridge was at CS11. The elevation profile across
cross-sections CS-1 to CS-13 are shown in Figure 3.9, and can significantly influence the flow
velocity.
Figure 3.7Proposed cross-sections along the riverbed from CS1 to CS13 from post-event
orthophoto and DEM @30°29'5.11"N 79°41'40.46"E 
31
Figure 3.8 Surface elevation profile in the valley along the riverbed from CS-1 to CS-13.
The pre-event and post-event cross-sections were obtained from their respective DEMs.
Figures 3.10 and 3.11 compare the pre and post-event cross-section shapes and areas, respectively.
The cross-sectional profiles were generated from DEM using the ArcGIS Spatial Analyst tool.
Further these profiles were opened in MATLAB to generate the valley cross-sectional area.  It can
be observed that the shape and area of the post-event cross-sections are due to erosion and debris
deposition in the valley. A majority of the erosion can be noticed on the right bank of the valley
and deposition on the left side of the bank.
Generally, the broader cross-section of the valley implies a decrease in the flow velocity,
causing the flow to lose energy and momentum, leading to debris deposition. In contrast, narrow
cross-sections can speed up the debris flow and may result in erosion of the valley. Figure 3.9
clearly shows that area of the pre-event cross-sections varies significantly between CS1 to CS13.
The area increases gradually from CS1 to CS6 and followed a rapid increase and sudden drop
between CS6 and CS8. The CS8 and CS9 cross-section areas are almost identical, and the lowest 
32
area was noticed at CS10.  Again gradual increase after CS10 till CS13 can be observed.
Similarly, from Figure 3.9, it is evident that there is a significant change in elevations
between the cross-sections from CS1 to CS13; the maximum and minimum are 2090m and 1950m,
respectively. A steep decline in elevation and increase in slope is observed between CS8 and CS9.
This could have increased the flow velocity, aggravated debris flow's momentum, and caused
massive destruction to the nearby powerhouse and bridge. These rapid and sudden changes in
cross-sections (shapes and sizes) and elevations explain the extent of damage to the structures due
to increased flow velocity and energy. An analysis of the cross-section study revealed the critical
flow dynamics and plausible relation to the extent of damage and debris deposition. 
33
Figure 3.10 Variation of cross-sectional shape in the valley along the river from CS-1 to CS-13. 
34
Figure 3.11 Variation of the cross-section area in the valley along the river from CS-1 to CS-13
3.1.2.2 Flood level at Rishiganga-HEP
The visible watermarks left by the debris flow along the Rishiganga river were identified using
DEM draped by the mosaic images. The post-event baseline is assumed at the centerline of the
Rishiganga river flowing in the longitudinal direction (middle of the Rishiganga) observed on
February 11th, 2021. The debris flow watermark elevations, baseline elevations, and location of
cross-sections are shown in Figure 3.12. Only the debris watermarks selected in the region from
CS6 through CS11 are shown, as they were distinctly visible. The maximum and minimum
elevations for debris watermark and baseline at CS6 and CS11 are 2090m  and 1990m and 2030 m
and 1950 m, respectively. The watermark profile is decreasing with the decrease in the elevation
from CS-6 to CS-13 as excepted. However, sudden variations in the watermarks are noticed at
different locations from CS-6 to CS-13. These variations can be attributed to their valley cross-
section shape and area. At Raini bridge (CS-11), the elevation of the debris, watermark rises 
35
despite the increase in the cross-section area of the valley. This increase may be attributed to
splashing caused by the obstruction at the Raini bridge and temporary blockage of the flow at the
confluence of Rishiganga and Dhauliganga (Figure 3.27). The steep decrease in the cross-sectional
area after CS-7 (Figure 3.10) causes an increase in the flow velocity and the watermark trendline
between CS-7 and CS-8 (Figure 3.11). Watermark decreases again after CS- 12, which is due to
the increase in cross-sectional area.
Figure 3.12 Variation of flood watermark along Rishiganga and Raini village
3.1.3 DEM analysis for erosion and debris deposition
The raster image calculation of subtracting pre-event DEM (Figure 3.7a) from post-event DEM
(Figure 3.7b) produced a new raster image, often addressed as DEM of Difference (DOD), as
shown in Figure 3.13. The pixels of the DOD raster image include positive and negative elevation
values (in meters) representing deposition and erosion, respectively. The red and blue shaded zones
are used to distinguish the positive and negative elevations, as shown in Figure 3.13. It can be 
36
observed that the majority of the right bank of the valley is in the blue shade, indicating debris
deposition consistent with observations deduced from the pre and post-event cross-section analysis.
It is also evident from Figure 3.13 that the infrastructure at locations A, B, and C got buried by the
debris deposition, as is also evident in Figures 3.1b, 3.5, and 3.6. Significant erosion is observed
at the location just above A and B, and moderate erosion along the valley center portion and left
bank. The bridge location C experienced both erosion and deposition.
The shape and size of the cross-sections, and their elevations, as well as the built
infrastructure, significantly influenced erosion and debris deposition patterns. For instance, a
gradual increase of cross-sectional area is observed between CS-10 to CS-12, causing debris
deposition in these areas. The increase in cross-sectional area from CS-6 to CS-7 is abrupt but
decreases afterward. This sudden increase in the area reduces the increased flow velocity through
CS-6 and deposits massive debris at CS-7 just after eradicating the barrage and side slopes of the
valley. 
37
Figure 3.13 DEM of difference between pre-event and post-event DEM of Rishiganga
HEP@30°29'5.11"N 79°41'40.46" E
 
38
3.1.3.1 Slope and Curvature Changes
To further understand the effect of debris flow on the valley, the slope and curvatures of
the valley have been examined by estimating these parameters using ArcGIS. The rate of elevation
change for each digital elevation model (DEM) cell is represented by a slope. Slope values are
estimated from the post-event DEM (resolution-1m) of Rishiganga using ArcGIS and categorized
in nine different classes from 0 to 90 degrees (Figure 3.14). The locations “A-D” in Figure 3.12b
have a slope between 0-10 degrees after the debris deposition. The analysis shows that slope values
were minimal in the observed impact zone, indicating that the terrain has flattened, which may be
due to the erosion and subsequent deposition of debris. The curvature values (second derivative of
the surface) are calculated from the post-event DEM (resolution-1m) of Rishiganga using ArcGIS.
The curvature function displays the shape or curvature of the slope, which can be concave, convex,
or flat (Figure 3.15). Figure 3.16 shows more than 75% of the coverage area in blue shades that
have positive curvature values indicating that the surface is upwardly convex. This might be due
to the debris deposition and signifies a tendency for accelerated flow and erosion. The zone near
the bank of Rishiganga shows negative curvature values indicating that the surface is upwardly
concave. This might be due to the cutting and eroding of the valley due to the debris flow and now
tends to decelerate flow and deposition. (Figure 3.16). 
39
Figure 3.14 Slope calculated from DEM (resolution-1m) of Rishiganga HEP@30°29'5.11"N
79°41'40.46"E
Figure 3.15 Types of profile curvature (ESRI ArcGIS manual) 
40
Figure 3.16 Profile curvature calculated from DEM (resolution-1m) of Rishiganga HEP
@30°29'5.11"N 79°41'40.46"E 
41
3.1.4 Photogrammetry evidence of Studied area - I
The valley floors upstream and downstream of the Rishiganga HEP were heavily deposited by
debris consisting of soil, broken pieces of infrastructures, and fragmented rocks of mountain sides
collected from the source and along the pathway of flash floods. Figures 3.17-3.19 present the
upstream and downstream valleys of R-HEP show the muddy depositions (consisting of sediment
grains ranging from 75µm to 2 mm, as obtained from the sieve analysis performed on the samples
brought from the site) and boulders of sizes ranging from 0.5 m to 5 m.
3.1.4.1 Barrage and Impoundment (A)
The barrage of the powerhouse was partially washed away and partially submerged under
the debris, as shown in Figure 3.17. Similarly, damage to the other supporting structures such as
water impounding and intake zone for the headrace tunnel was exceptionally severe, as shown in
Figures 3.18 - 3.20.
Figure 3.17 Barrage region, 30°28'42.68"N 79°42'0.50" E (Dated: 11/2/2021) 
42
Figure 3.18 Marks of impoundment region@ 30°28'45.39"N 79°41'53.46" E (Dated: 11/02/2021
Figure 3.19 Accumulated Boulders/ Broken concrete structures, a few centimeters ahead of the
tail of impoundment @ 30°28'47.40"N  79°41'53.25"E (Dated:11/02/2021) 
43
Figure 3.20 Buried pipe/tunnel structure@ 30°28'56.39"N 79°41'49.20" E 
44
3.1.4.2 Temporary buildings (B)
Figure 3.21a shows the pre-event imagery of November 17th
, 2018 obtained from Google
Earth. This image highlights the temporary buildings near the downstream of the barrage, whereas
3.21b gives a post-event close-up view of the same location, filled with debris and giant boulders.
a)
b)
Figure 3.21 a)Pre- and b) Post-event temporary building location @ 30°28'46.26"N
79°41'50.83"E (Dated:11/02/2021) 
45
3.1.4.3 Powerhouse (C)
The powerhouse site also experienced similar damage. Figures 3.22 and 3.23 show that the
multi-story building, powerhouse, and utility structures were washed away from their locations.
The extent of the damage caused by the flash flood at the penstock location can be seen clearly in
the images in Figure 3.24. The debris mark (solid red line), as shown in Figure 3.24a, indicates the
height the flood reached up to the of the penstock, which is at an elevation of about 1986 m MSL,
causing damage to the penstock support system (steel bars are exposed) and burying the turbine
with debris.
Figure 3.22 Buried powerhouse region @30°29'5.11"N 79°41'40.46" E (Dated: 11/02/2021) 
46
Figure 3.23 Damaged/Buried Residential Houses@ 30°28'51.83"N 79°41'49.93"E (Dated:
11/02/2021) 
47
(a)
(b)
Figure 3.24 Post-event images at the location of the penstock illustrate the damage caused,
exposed reinforcement, and deposition of debris covering the penstock a) top view (30°29'2.57"N
79°41'40.91"E) b) side view. (Dated: February 11th, 2021)
Debris
Anchoring
fundament 
48
3.1.4.4 RCC Bridge (D)
The right bank abutment and the approach slab of the RCC bridge were severely damaged
and buried under the muddy deposits, in contrast to the left bank abutment and approaching slab,
as shown in Figure 3.25. It also clearly shows the bridge superstructure at an elevation of 1973
MSL was completely washed away by flash floods.
Figure 3.25 Damaged Raini bridge across the bank of Rishiganga River with only left abutment
and no decks. (30°29'7.95"N, 79°41'39.56"E) (Dated: February 11th, 2021) 
49
3.1.4.5 The confluence of Dhauliganga and Rishiganga
The debris flow moving with extremely high velocity and kinetic energy crashed with the
mountain face at the Dhauliganga and Rishiganga confluence and formed craters on the face, as
shown in Figure 3.26 in solid black lines. The mountain on the right bank of Dhauliganga acted
like a barrier in the path of incoming massive debris flow from Rishiganga and created a temporary
blockage. It resembles the "water hammer" phenomenon in the dam when gates behind penstocks
are closed abruptly. The temporary blockage at the confluence resulted in impounding and raising
the water level upstream of the Dhauliganga, evident from the debris mark highlighted in the solid
blue line in Figure 3.27. 
50
Figure 3.26 Crater formation at mountain face from the collision of debris flow with the hill
(N30ᵒ29'11.30", E79ᵒ41’29.65”, Elevation-1989 m). (Dated: February 11th
, 2021)
Figure 3.27 Raised watermarks upstream of Dhauliganga as proof of temporary blockage of the
main river and debris throwback after the impact with the hill. (N 30ᵒ29’11.30” E079ᵒ41’29.65”,
Elevation-1989 m) (Dated: February 11th, 2021) 
51
3.2 Study Area – II: Tapovan HEP
The tragic episode of flash floods in Chamoli has led to infrastructure damage in and around
Tapovan-HEP as well, which was under construction. The catchment area of this project is 3,100
square kilometers. Naithani and Murthy, 2006, reported that Tapovan Dam consists of hydropower
related structures such as a desilting basin (140m (L) ×76.5m (W)), an intake structure with four bays
each of 8.0 m width and separated by 1.5 m thick piers with 2.8 m high gates, conduits, and barrage s
with bays of 12m width, each separated by 2.5 m wide piers. This area also consists of breast walls
that were constructed to support the piers or hold the water up to a head 12 m above the crest level of
the intake, two suspension bridges, i.e., one on the upstream and one on the downstream sides of the
barrage, respectively, and a workshop consisting of a batching plant in the nearby vicinity upstream
of the barrage on the left bank of the river. Figure 3.28 gives a close-up view of the under-
construction barrage site. The NTPC officials took the image on December 14th
, 2020 i.e.,
approximately two months before the extreme event.
Figure 3.28 Close-up view of barrage site infrastructure (Source: NTPC Tapovan via National
Institute of Disaster Management (NIDM), MHA-Webinar on Lessons from Chamoli Disaster
2021 https://www.youtube.com/watch?v=fE6yjZE6pUg&t=1709s ) @ 30°32'7.84"N 79°31'10.71" E
52
The pre and post-event visuals of the TV-HEP are presented in Figures 3.29a and 3.29b,
respectively. The pre-event visual was obtained from the Google imagery of 2017, and the post-
event was a digital ortho mosaic generated from the drone survey. It is evident from these figures
that Tapovan HEP was severely affected by the flash floods and heavily deposited with debris,
including soil and boulders of different sizes. 
53
a)
b)
Figure 3.29 Tapovan HEP area (a) pre and (b) post-event orthophoto data showing the collapsed bridges, damaged structures,
accumulated boulders, muddy water and, affected barrage gates@ 30°32'7.84"N 79°31'10.71" E
54
3.2.1 Photogrammetry evidence of TV-HEP
A post-event drone-based reconnaissance study similar to Rishiganga HEP was conducted at the
affected TV-HEP site to visualize and document the damage caused by the flash flood. The entire
data of this site captured by the drone survey was aligned by aerial triangulation. Further, the
aligned data was orthorectified and geo-referenced using the GCP information obtained from
EMLID RS2 DGPS equipment. Subsequently, the contour lines were generated on a scale of
1:1000. Figure 3.30 clearly shows the contour drawing draped over the orthoimage of TV-HEP.
The contours, namely of pink and yellow colors, represent the major and minor contours at an
interval of 5 m and 1 m, respectively. The irregular contour lines indicate the uneven surface,
whereas closely spaced lines represent steep terrain. The minimum and maximum contour traced
by the drone survey are 1840 m and 1905 m. Also, from the generated surface profile, the observed
lowest point of the river is noted at 1851 m. The bridge-1, which was upstream of the barrage site,
was estimated to be about 117.70 m in length and 7.95 m wide at a height of approximately 20 m
from bedrock, and got washed away entirely, as marked by the black color line plotted in Figure
3.30 for reference. 
55
Figure 3.30 Surface plan overlaid on orthophoto @ 30°32'7.84"N 79°31'10.71" E
56
3.2.2 Flood level at Tapovan-HEP
Figure 3.31a illustrates the ortho mosaic draped over the surface profile of DEM, which is
used for identifying the watermarks left by the debris flow at Tapovan HEP. A reference point (X)
and an endpoint (Y) were considered at the upstream and downstream line along the selected post-
event baseline to obtain the variation of flood watermarks along the scanned area. The points
obtained in this region are plotted against the traverse length of the flood, as shown in Figure 3.31b
for further analysis. The post-event baseline is assumed at the centerline of the Rishiganga
observed on February 11th, 2021. The dotted line in Figure 3.31b represents the deck level of the
barrage at an elevation of about 1861m  MSL, which is considered the datum point for establishing
the high flood level at different elevations. The trend line (solid blue) of the data in the graph clearly
shows the debris mark along the valley of the Tapovan-HEP. It’s evident from the figure that the
difference between the baseline and the debris mark is decreasing from the upstream and
downstream reference points X and Y, respectively. However, the elevation difference increased
suddenly after the X reference about 100  m (upstream) due to the narrow valley cross-section. It
reached a height equal to the barrage about 1864 m MSL including bridge-I and collapsed the
bridge and severely affected the barrage. 
57
(a)
(b)
Figure 3.31 Variation of flood debris marks along the study area a) Orthorectified mosaic image b)
elevation of debris marks vs. the traverse distance of flood @ 30°32'7.84"N 79°31'10.71" E
x 
58
3.2.3 3D View of TV-HEP
The post-event aerial view of the entire scanned area of TV- HEP in three dimensions was
reconstructed using an ortho mosaic and DEM, as shown in Figure 3.32. The ortho mosaic is
draped over the DEM to follow the surfa...