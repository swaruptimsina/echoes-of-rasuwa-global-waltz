Post Disaster 
Needs Assessment 

Glacial Lake Outburst Flood Sikkim - 2023 

2023 


Message 

th
In the early hours of 4  October, 2023, the state of Sikkim faced an unprecedented calamity, marking one 

rd
of the worst ever incidents in the past decade. The night of 3  October, 2023, witnessed a massive 
landmass slipping into the South Lhonak lake, triggering a chain of events that led to a devasta�ng flash 
flood downstream along the Teesta River basin. This catastrophe resulted in severe damages to the low-
lying areas of 4 districts namely, Mangan, Gangtok, Namchi and Pakyong. 

Tragically, 55 lives were lost and an es�mated 80,000 people across 100 villages were affected. In 
response, relief assistance was swi�ly provided to displaced families as per the prevailing norms in the 
State, over and above the norms of assistance laid by the Government of India. The coordinated efforts 
of rescue teams from the Na�onal Disaster Response Force, State Disaster Response Force, Army, Sikkim 
Police and ITBP were pivotal in saving numerous lives. The commendable ac�ons of the community / 
locals in evacua�on and rescue of stranded people merit special acknowledgement. 

As the affected popula�on gradually resumed normalcy, the State transi�oned from relief to the 
recovery phase. The State Government of Sikkim, in collabora�on with the Na�onal Disaster 

th
th
Management Authority (NDMA), ini�ated the post disaster needs assessment (PDNA) from 7  to 11  
December, 2023. This collabora�ve effort involved various Line departments from the State, as well as 
experts from interna�onal and na�onal agencies. The par�cipatory appraisal encompassing several 
rounds of consulta�ons with all the stakeholders and communi�es in the affected areas, resulted in a 
comprehensive report that covers eight sectors, cross cu�ng issues and a recovery strategy. 

This PDNA is not just a document; it is a dedica�on to those who suffered during this calamity. We extend 
our hear�elt gra�tude to everyone who contributed to its crea�on. The report outlies a vision of 
recovery that goes beyond rebuilding Sikkim, aiming to create a more resilient and sustainable future. 
This vision centers around integrated communica�on for risk informed prac�ces, mainstreaming 
disaster risk reduc�on in development planning, community centered reconstruc�on and technology 
Integra�on for early warning. 

As we move forward, we look forward to working with all the stakeholders in the implementa�on of the 
recovery programmes proposed in this PDNA report. Together we strive towards a resilient and 
sustainable Sikkim. 

Sd/-
Chief Secretary 
Government of Sikkim.


  
The state of Sikkim is prone to frequent disasters owing to the various hazards like Earthquake, 
Landslides, GLOF & Flashfloods, Lightning, Forest Fire, etc. Every monsoon, the state experiences mass 

rd
th
destruc�on due to heavy and sporadic rainfall. The flashflood of Oct 3  & 4  2023 owing to the Landslide 
in the South Lhonak lake resulted to spill over of water in the Teesa River induced massive destruc�on of 
proper�es, loss of human and animal lives. The total road network of Mangan District was badly affected 
by the flashflood. Other Districts which were affected are Gangtok, Namchi and Pakyong. 

  
In view of recovery and reconstruc�on, the Govt. of Sikkim requested NDMA for assistance to 
carry out Post Disaster Needs Assessment (PDNA) in the State. NDMA provided required technical 
support for conduc�ng the exercise and comple�ng it early. The Govt. of Sikkim, SSDMA expresses its 
gra�tude for technical support extended by NDMA, especially the personal interven�on and guidance 
from Shri. Kamal Kishore, Member Secretary, NDMA and Shri Kunal Satyarthi, IFS, Joint Secretary (PP) 
NDMA, in collabora�on with Na�onal & Interna�onal Agencies like UNDP, CDRI, NIDM, UNICEF, IIT and 
Central as well as State Expert Group members for their coordina�on and support. Special men�on goes 
to the four Districts Disaster Management Authori�es and Line Departments for assis�ng the expert 
teams in proper assessment of damages. 

Acknowledgement 

Sd/-
Shri Anil Raj Rai (IAS) 
State Relief Com-cum-Secretary 
Land Rev. & Disaster Mgt. Dep�. 

Govt. of Sikkim 


Contents

Message 
Acknowledgement 
List of Tables 
1.Preliminaries
 
1.1. Background 
 
1.2. Ra�onale for Post Disaster Needs Assessment 
 
1.3. Overview of the assessment process and methodology 
 
1.4. Limita�ons of the assessments 

2. Overview
 
2.1. Profile of the State 
 
2.2. Disaster Profile 
 
2.3. Disaster Event 
  
2.4. District Wise Impact of the Disaster 
 
2.5. Response of the State Government and District Administra�on 
 
2.6. Recovery Vision 
 
2.7. Specific Recovery Objec�ves 
 
2.8. Recovery Principles 

3. Social Sector 
 
3.1. Housing 
 
3.2. Educa�on 
 
3.3. Health, Anganwadi and Community Buildings 

4. Produc�ve Sector 
 
4.1. Agriculture and Hor�culture 
 
4.2. Animal Husbandry and Livestock 
 
4.3. Tourism 

5. Infrastructure Sector 
 
5.1. Roads and Transport 
 
5.2. Drinking Water and Sanita�on 

6. Cross Cu�ng Issues 
 
6.1. Forest and Environment 
 
6.2. Disaster Risk Reduc�on 

7. Resource Mobiliza�on, Implementa�on, Monitoring and Evalua�on of the plan 
 
7.1. Resource Mobiliza�on 
 
7.2. Program Implementa�on 
 
7.3. Program Monitoring and Evalua�on 


List of Tables 

Table 1. Profile of the State 

Table 2. Timeline of the Events 

Table 3. District wise impact of disaster 

Table 4. Summary of Damage, Losses and R&R needs. 

Table 5. Housing: Damage to Housing Sector 

Table 6. Housing: Exis�ng floor areas of pucca, semi-pucca and kutcha buildings 

Table 7. Housing: Basic unit costs, areas and number of floods or pucca. Semi-Pucca and kuccha buildings 

Table 8. Housing: Par�ally damage building cost: Built-up area by housing type, Covered Area – "like for like" 

Table 9. Housing: Damage Cost Es�mates 

Table 10. Quan��es and cost of debris management 

Table 11. Reconstruc�on: Unit Csor, Area per unit and Built-Up area 

Table 12. Repair and retrofi�ng: Unit-cost, area, number of HH's per floods and number of stories 

Table 13. Housing and se�lement recovery cost, cost of damage and loss 

Table 14. Educa�on Sector Profile 

Table 15. Educa�on Sector Policies 

Table 16. Impact of Disaster 

Table 17. Damage in Educa�on Sector 

Table 18. Educa�on Sector: Damage Es�mate 

Table 19. Educa�on Sector: Component wise assump�on of damage es�mate 

Table 20. Recovery and Reconstruc�on Needs for educa�on Sector 

Table 21. Educa�on Sector: Component wise recovery of ATTC 

Table 22. Educa�on Sector: Implementa�on Framework 

Table 23. Health Sector: Key Health Indicators highligh�ng performance of Sikkim Health Sector 

Table 24. Health Sector: Key Health Indicators for Sikkim on Non-Communicable Disease 

Table 25. Health Sector: Summary of Capacity of Health Infrastructure in Sikkim 

Table 26. Health Sector: Summary of Anganwadi and Community Buildings that reported Damages 

Table 27. Health Sector: Summary of ownership of Anganwadi from reported buildings 

Table 28. Health Sector: Pa�ent Load on Singtam District during disaster (IPD capacity 150 beds) 

Table 29. Health Sector: District wise impact on access of health services. 

Table 30. Health Sector: Impact of Disaster on Anganwadi 7 

Table 31. Health Sector: Damage Assessment of Anganwadi's 

Table 32. Health Sector: Assump�on for Damage es�mate for Health Sector 

Table 33. Health Sector: Damage Es�mate for health Sector 

Table 34. Health Sector: Item wise assump�on for damage es�mate in Anganwadi's 

Table 35. Health Sector: Component and District wise damage es�mate for Anganwadi's 

Table 36. Health Sector: Total Damage Es�mate for Anganwadi 

Table 37. Health Sector: Total Economic Losses (in Crore) based on inputs from Health Department 

Table 38. Health Sector: overall reconstruc�on cost es�mates for Health Sector 

Table 39. Health Sector: Overall recovery need es�mate for health sector 

Table 40. Recovery and Reconstruc�on Needs for Anganwadi and Community Buildings 

Table 41. Agriculture Sector: Details of Damage to Land 

Table 42. Agriculture Sector: Overall Damage Numbers in Hectare


Table 43. Agriculture Sector: Overall Damage Cost Es�mate in Crore 

Table 44. Agriculture Sector: Overall Economic Loss Es�mate in Crore 

Table 45. Agriculture Sector: Number of Farmers affected 

Table 46. Agriculture Sector: Components of Damages and Losses (In Crore) 

Table 47. Agriculture Sector: Reconstruc�on Cost es�mate (In Crore) 

Table 48. Agriculture Sector: Recovery Cost Es�mate (In Crore) 

Table 49. Agriculture Sector: Implementa�on mechanism 

Table 50. Animal Husbandry and Livestock: Profile 

Table 51. Animal Husbandry and Livestock: Damages in Animal Husbandry and Fisheries Sector 

Table 52. Animal Husbandry and Livestock: District Wise Damage and Replacement Cost (In crore) 

Table 53. Animal Husbandry and Livestock: Replacement Cost Fisheries (In crore) 

Table 54. Animal Husbandry and Livestock: Overall Infrastructure Damage (In crore) 

Table 55. Animal Husbandry and Livestock: Economic Losses in AH& L (In crore) 

Table 56. Animal Husbandry and Livestock: Unit Cost assump�on for replacement cost 

Table 57. Animal Husbandry and Livestock: Methodology for assump�on for Economic Loss 

Table 58. Tourism: Tenta�ve revenue Loss in hotel Sector (In Rupees) 

Table 59. Tourism: Tenta�ve revenue Loss in Homestay Sector (In Rupees) 

Table 60. Tourism: Tenta�ve revenue Loss in Tours and Travels Sector (In Rupees) 

Table 61. Roads and Transport: Damaged Road Infrastructure 

Table 62. Roads and Transport: Total Damage, Recovery es�mate for Road Sector 

Table 63. Roads and Transport: Primary Road Network in Sikkim 8 

Table 64. Roads and Transport: Road Sector Damage w.r.t Asset Type 

Table 65. Roads and Transport: Damage Es�mate (In lakh) 

Table 66. Roads and Transport: Unit Cost for Road and Bridge Works 

Table 67. Roads and Transport: Asset-wise Reconstruc�on and Recovery Cost Es�mate for Sikkim (Short      to  

Medium term) 

Table 68. Roads and Transport: Recovery Framework 

Table 69. Drinking Water and Sanita�on: Recovery Framework 

Table 70. Drinking Water and Sanita�on: Summary of Covered Popula�on 

Table 71. Drinking Water and Sanita�on: Details of Sewage Treatment Plants in Sikkim 

Table 72. Drinking Water and Sanita�on: Sectoral Policies and Departments 

Table 73. Drinking Water and Sanita�on: Overall Damage numbers 

Table 74. Drinking Water and Sanita�on: Damage Cost Es�mate 

Table 75. Drinking Water and Sanita�on: District Wise Damage Es�mate 

Table 76. Drinking Water and Sanita�on: Component Wise Damage Es�mate 

Table 77. Drinking Water and Sanita�on: District Wise Loss Es�mate 

Table 78. Drinking Water and Sanita�on: Recovery and Reconstruc�on Needs Assessment

Table 79. Drinking Water and Sanita�on: Reconstruc�on Cost Es�mate - Water (In Crore) 

Table 80. Drinking Water and Sanita�on: Reconstruc�on Cost Es�mate – Sanita�on (In Crore) 

Table 81. Drinking Water and Sanita�on: Reconstruc�on Cost Es�mate - Summary of R&R needs 

Table 82. Drinking Water and Sanita�on: Recovery Framework 

Table 83. Forest and Environment: Affected Protected Forest Area land under Forest and Environment 

Department along Teesta River  

Table 84. Forest and Environment: Damage Es�mate as per NPV 

Table 85. Forest and Environment: Damage to Nurseries of the Forest and Environment Department.


Table 86. Forest and Environment: Damage to Forest Department Built up Infrastructure 

Table 87. Forest and Environment: Damage to Malli Sheds 

Table 88. Forest and Environment: Damage to Eco-Tourism Infrastructure 

Table 89. Forest and Environment: Loss to collec�on sites for sand, stone and loose boulders- loss of revenue 

for department 

Table 90. Forest and Environment: Loss to collec�on sites for sand, stone and loose boulders- loss of 

individuals with tenders. 

Table 91. Forest and Environment: Summary of total Loss to collec�on sites. 

Table 92. Forest and Environment: Summary of damage and Loss to collec�on sites. 

Table 93. Forest and Environment: Summary of forest restora�on. 

Table 94. Forest and Environment: Reestablishment of the Nurseries 9 

Table 95. Forest and Environment: Reconstruc�on of Infrastructure damages 

Table 96. Forest and Environment: Reconstruc�on of Malli Sheds 

Table 97. Forest and Environment: Es�ma�on for restora�on and upgrada�on for communica�on systems 

Table 98. Forest and Environment: Reconstruc�on of Eco-Tourism 

Table 99. Forest and Environment: Summary of Reconstruc�on cost 

Table 100. Forest and Environment: Cost es�mate for Recovery interven�ons 

Table 101. Forest and Environment: Reconstruc�on and recovery Framework 

Table 102. Disaster Risk Reduc�on: Cost Es�mate - Monitoring and Early Warning System 

Table 103. Disaster Risk Reduc�on: Cost Es�mate - Flood Forecas�ng Systems 

Table 104. Disaster Risk Reduc�on: Cost Es�mate - Structural Mi�ga�on measures 

Table 105. Disaster Risk Reduc�on: Cost Es�mate - Non-Structural Mi�ga�on measures 

Table 106. Disaster Risk Reduc�on: Cost Es�mate - CBDRR Measures 

Table 107. Disaster Risk Reduc�on: Cost Es�mate - Emergency Response Planning 

Table 108. Disaster Risk Reduc�on: Summary of cost Es�mate for DRR measures 

Table 109. Program Implementa�on: Members of State Execu�ve Commi�ee 

Table 110. Program Implementa�on: Technical Appraisal Commi�ee 

Table 111. Program Implementa�on: Monitoring and Evalua�on framework 


1.1. Background

nd
Sikkim, the 22
 state of the Indian Union is located in the foothills of the Eastern Himalayas and it has a 
mountainous terrain with eleva�ons ranging from 280 meters to 8585 meters. About one third of the 
state is covered by forests. It has 28 peaks and more than 400 glaciers with similar number of high 
al�tude glacial lakes. Due to its unique terrain and loca�on, it is suscep�ble to mul� hazards like 

rd
earthquake, landslides, GLOF, lightning, thunder, hailstorms and so on. On the night of 3  October, 2023, 
a huge landmass slipped into the South Lhonak, located in the north western part of the state, which 
caused the lake to overflow. The water from the lake flowed into the Teesta River which caused the 
water level to rise beyond 15 feet. This led to surge in the flow of the river causing widespread damages 
to lives and proper�es at the downstream loca�ons.

Sikkim State Disaster Management Authority / SSDMA in consulta�on with State departments of
Government of Sikkim and stakeholders conducted ini�al damage assessment and has submi�ed
interim memorandums seeking for addi�onal financial assistance from NDRF for sector wise damage for
recent Sikkim Flash Floods 2023 to the Central Government under;
a. Immediate Restora�on amoun�ng to Rs 776 Cr
b. Long term Restora�on amoun�ng to Rs 25000 Cr

th
The 15  Finance Commission has recommended that a disaster event must be assessed using a PDNA 
tool to comprehensively assess damages, losses and recovery needs. The data assessed through PDNA is 
the basis for alloca�on of funds from the recovery and reconstruc�on window of NDRF.

1.2. Ra�onale for Post Disaster Needs Assessment

Post disaster needs assessment (PDNA) is crucial for evalua�ng losses and damages encompassing 
infrastructure, services and outcomes. These assessments, as outlined in NDMA dra� guidelines on 
Recovery & Reconstruc�on serve as a pivotal link between disasters and long-term recovery. A 
qualita�ve analysis underscores the significance of understanding the mul�-faceted impact, aiding in 
strategic planning and resource alloca�on. The exercise will guide priori�za�on of interven�ons, 
facilita�on of restora�on of essen�al services and infrastructure, thereby steering post – disaster 
ini�a�ves towards effec�ve, targeted and informed development.

1.3. Overview of the assessment process and methodology

This PDNA exercise was led by the State Government of Sikkim jointly supported by NDMA, NIDM, 
relevant departments, na�onal and interna�onal agencies and other stakeholders. The following 
process was followed for PDNA:

1. Preliminaries 

Ÿ
Se�ng up the Team, Prepara�on and Coordina�on: SSDMA cons�tuted a mul� stakeholder 
state level coordina�on team consis�ng of sector experts, representa�ves from the 
government, interna�onal organiza�ons and other stakeholders. 
Ÿ
Training Program: Experts from NDMA conducted a training program for cons�tuted teams 
focusing on the process, data collec�on, analysis, recovery needs and report wri�ng for 
PDNA. 

1


1.4. Limita�ons of the assessments

The PDNA has faced limita�on in relevance due to delays in assessment and submission of reports owing 
to Government holidays. Methodological challenges include standardiza�on issues and balancing 
qualita�ve and quan�ta�ve data. There have been resource constraints in terms of skilled workforce 
which has limited comprehensive assessments of certain sectors. At some areas, the team was unable to 
reach the area of impact due to damage in road infrastructure. The team faced technical challenges in 
using the templates for data collec�on leading to insufficient data input in certain sectors.

Ÿ
Sectoral Assessments: Detailed sectoral assessments were done by sectoral teams 
cons�tuted by the State. The district team supported the Sector experts in the provision of 
baseline informa�on, damage data, GPS loca�ons etc.
Ÿ
Dra�ing of PDNA report: Following the collec�on of data, the team prepared the report 
presen�ng sector wise damage. The cost es�mates of all the damage including the cost of 
damage, unit cost is included in the report.
Ÿ
Sectoral Expert Group (SEG): The SEG consisted of members from NDMA, NIDM, na�onal 
and interna�onal organiza�ons. The SEG was responsible for data analysis and assessment, 
iden�fica�on of recovery needs, development of recovery framework and formula�on of 
sectoral reports.

2


2.1. Profile of the State
Sikkim is a land-lock hilly state and its strategic loca�on confines with Darjeeling district of West Bengal 
which is delineated by major rivers that flows from within the state. It shares its state border with three 
sovereign na�ons, Nepal in the West, Bhutan in the East and vast stretches of Tibetan plateau of China in 

o
o
o
the North. The state is situated between 27 04’ 46” and 28 07’48” north la�tudes and 88 00’58” and 

o
88 55’25” east longitudes. The state extends approximately 114 km from north to south and 64 km from 
east to west and has a total geographical area of 7,096 sq km. Rivers and mountains define the 
boundaries of Sikkim.

2. Overview

Feature
 
 
Descrip�on

Area
7096 sq.km

Loca�on

Borders/ Neighboring
Countries

Major Rivers
Teesta River and Rangit River

Forest Covers

Popula�on
610,577 (Census 2011)

Sub-divisions
16

Sex Ra�o
890 females per 1,000 males (Census 2011)

Popula�on Density
86 persons per sq.km (Census 2011)

Popula�on share
0.05% (Census 2011)

Climate
i. Cold Weather Season (December-February)
ii. Spring Season (March-May)
iii. South West Monsoon (June-September)
iv. Period of Retrea�ng Monsoon (October-November)

1
Table 1.       Profile of the State

Situated between the latitude of 27º04’ North to 28º07’East and the
longitude of 88º01East to 88º55’East on the Tibetan Plateau.

North: China
South: West Bengal
East: China and Bhutan
West: Nepal

584 (Area in hectares)
(82.31 percent of the total geographical area of the State)

6 Districts (Gangtok, Mangan, Namchi, Pakyong, Gyalshing, Soreng) 
Districts

1 Sikkim General Profile:
Reference:www.census2011.co.in/census/state/sikkim.html,www.sikkimtourism.gov.in/Webforms/General/SikkimAtAGlance
/Climate.aspx

3


State of Sikkim due to its physiographic and clima�c condi�on is one of the most disaster-prone areas of 
the country. With the natural factors, various human induced ac�vi�es like increasing demographic 
pressure, deteriora�ng environmental condi�ons, deforesta�on, unscien�fic development, faulty 
agricultural prac�ces and grazing, unplanned urbaniza�on, construc�on of large
dams on river channels etc. are also responsible for accelerated impact and increase in frequency of
disasters in the country.

Earthquake
The State falls within the seismic Zone IV of Seismic Vulnerability Atlas of India and is prone to frequent 

th
earthquakes. The major earthquakes felt by the State are the ones of 1986 of 5.3 magnitude, 14  Feb 

th
2006 of 5.3 magnitude and the most recent one of 18  September 2011 of 6.8 magnitude. Widespread 
human and materials losses, destruc�on and damages of infrastructures and services are the major 
consequence of the earthquakes.

Landslides (mud slide and snow avalanche)
The state of Sikkim is suscep�ble to landslides owing to geological characteris�cs, tectonic ac�vity,
slope instability, weak composi�on of the soil or rocks. Some of the factors causing slope instability
are rain, flooding, seismic events, removal of vegeta�on, construc�on ac�vi�es, etc. Scien�fic 
observa�ons in North Sikkim clearly recall that there is an average of 2 landslides one sq.km. This
means the rate of land loss is to the tune of 120m/km/year and annual soil loss is about 2500
tons/sq.km. The unprecedented rain triggers frequent landslides which causes severe damage to the
vital road networks, essen�al public proper�es and other agricultural crops.

Snow avalanches are common in three districts of the state; Mangan, Gangtok, Gyalshing Districts.
The avalanches are reported of killing army personnel and damaging roads and causing serious damages 

th
of roads and se�lements falling in its way. The recent most devasta�ng one is the snow slide of 4  April 
2023 at 17th mile on Jawaharlal Nehru Road connec�ng Gangtok to Nathu-La pass which took nine lives 
including those of five foreign na�onals.

Fire
The South-Western part of the State is prone to forest fire triggered by dry winter spells. Domes�c fire 
occurrences are also on the rise due to human induced errors. Fire can also be the secondary effect of a 
disaster like an earthquake. Secondary fires a�er a disaster like earthquakes cons�tute a substan�al and 
heavy risk. Damage to natural gas systems during an earthquake can lead to major fires and explosions. 
Damages to electrical systems during a disaster can ignite major fires. Varying risk scenarios need 
different approaches and interven�on.

The forest fire incidence is on rise in areas under Gyalshing, Gangtok, and Namchi districts of the State. 
The steady increase of forest fire is largely a�ributed to the impending effect of environmental 
degrada�on and climate change, resul�ng in a long hall of dry spell in the months star�ng from October 
�ll March.

Wind and Storm
The State of Sikkim generally witnesses cyclone induced windstorms origina�ng from North Bay of
Bengal with their impact compara�vely high and devasta�ng. The wind storm occurs in the months of 
April and May. Whereas cold windstorms are prevalent in higher ridges of Mangan and Gangtok
Districts origina�ng due to forma�on of pressure belts in Tibetan Plateau region. Wind storms have
been destroying the Rabi crops.

2.2. Disaster Profile

4


Thunderstorm and Lightning
Thunderstorms and lightning occur round the year in different parts of the State. However, their 
frequency and intensity are maximum in the spring (March to June) season.

Hailstorm
Sikkim is among the states in the country with the highest frequency of hail. The hailstorms are mainly 
observed in the winter and pre-monsoon seasons with virtually no events a�er the onset of the 
southwest monsoon. At �mes, it causes considerable crop damage though the spell lasts a few
minutes. Hail is o�en associated with thunderstorm ac�vity and changing weather fronts. As a 
thunderstorm moves along, it deposits its hail in a long narrow band (o�en several kilometers wide
and about 10 kilometers long) known as a hail-streak or hail-swath. If the storm remains almost
sta�onary for some �me, substan�al accumula�on of hail is possible. Its size and shape depend on how 
fast the storm is moving and how strong the updra�s are inside the storm.

Cloudburst and Flash Flood
The higher reaches of the state have a catchment area which is suscep�ble to high precipita�on
resul�ng in cloud burst which in turn causes flash flood along the river basin causing damages to life,
livestock and proper�es. During the monsoon season cloudburst resul�ng in flash floods are frequent 
occurrences in all districts of the State. The state receives rainfall star�ng from May �ll late October. 
Cloudbursts are prevalent through the state that triggers widespread flash floods causing loss of human 
lives and severe damage to public u�li�es and other cul�vable crops.

 

5


Glacial Lake Outburst Flood (GLOF)
The Sikkim Himalayan Region (HR) is facing important challenges in view of coping with the adverse
effects of climate change. Physically, the shrinking of mountain glaciers and expansion of Glacial Lakes 
are amongst the most recognizable and dynamic impacts of climate warming in this environment. In 
combina�on with this altered stability of surrounding rock and ice walls, the poten�al threat from 
Glacial Lake Outburst Flood (GLOF) is evolving over �me. For the month of October, 2023, a total of 902 
Glacial Lakes and Water Bodies have been monitored. It includes 477 Glacial Lakes & Water Bodies, with 
water spread area greater than 50 ha, which are being monitored since 2011. All Glacial Lakes with size 
of 10 ha and above as per NRSC inventory, 2009 have been monitored.

Human Induced Hazards:
With the establishment of industries in the State, hydel power projects, pharmaceu�cal companies
and other related industries along the river basins the state is vulnerable to human-induced hazards
also such as:

Ÿ
 Chemical and Industrial Disasters,
Ÿ
 Nuclear and Radiological Emergencies (NRE),
Ÿ
 Biological and Public Health Emergencies (BPHE)

2.3. Disaster Event

Descrip�on:
The Sikkim State Council of Science and Technology an autonomous organiza�on of Science and
Technology Department, Government of Sikkim in collabora�on with Space Applica�ons Centre (SAC), 
ISRO has published a ‘Glacier Atlas of Sikkim’ way back in the year 1998. In the later years, the State 
Council also prepared the ‘Land use Landcover Map of Sikkim’, ‘Wetland Map of Sikkim’ with the 
support of SAC. It is through such engagements; the growth of glacial lakes came in no�ce of the state 
government. The growth of glacial lakes and associated risks was found to have accelerated from 1990s. 
So, it was established that the major reason behind such growth was due to the fast mel�ng of the 
glaciers on account of ongoing climate change.

South Lhonak Lake located in extreme North Western part of Sikkim was one of the fastest growing
glacial lakes in Sikkim Himalayas as the parent glacier is mel�ng rapidly. In addi�on, the melt water
from Lhonak Lake and North Lhonak glacier is also draining the South Lhonak Lake. The first field visit
to the South Lhonak Lake by the State Council was carried out in April 2012 to ascertain the status of
the outlet of the lake under a collabora�ve project with CDAC, Pune. In 2013, a request was made by
DST, Sikkim to Department of Science and Technology, Government of India to help and support
for the study and mi�ga�on of glacial threat in South Lhonak Lake. In response to the request, a
Working Group was cons�tuted by DST, Government of India under the chairmanship of the then
Director SASE to suggest the mi�ga�on measures in South Lhonak Lake. The other members of the
Working Group consisted of glaciologists working in different organiza�on of India.

The Working Group suggested for both short term and long-term mi�ga�on measures in the mee�ng
held in Gangtok. Based on the sugges�ons of the Working Group, the State Council with the support
of DST, GoI, carried out the bathymetry survey in order to es�mate the volume of the lake and
electrical resis�vity survey of the moraine dam to understand the subsurface features of moraine
damming the lake in the year 2014. With the outcome of the survey report, the Working Group further 
suggested to carry out the siphoning of the lake and installa�on of early warning sensor. In 2016, 3 
number of pipelines installed in the lake to siphon the water of the lake with the technical support of 
SECMOL, Ladakh and the logis�c support of Land Revenue and Disaster Management Department, 
Government of Sikkim. The siphoning helped to release about 150 liters of water per seconds, in 

6


addi�on to the natural discharge from the outlet. An experimental real �me water level sensor 
developed by CDAC, Pune was also installed in the lake. However, the system was damaged a�er 6
months of installa�on probably by the floa�ng ice masses generated through calving by the glacier’s
snout.

Controlled widening of the outlet was one of the mi�ga�on measures suggested by the working group. 
In 2018, a mul� departmental team headed by Special Secretary, Land Revenue and Disaster
Management Department from state government visited the lake.

Possible triggers
The failure of the side wall of the lake towards the North Western side of the lake produced massive
calving of Ice blocks from the snout of the South Lhonak Glacier measuring about 600 m x 50 m. Both 
processes generated extensive waves in the lake that eventually produced massive floods downstream 

th
on 4  October 2023. This massive wave in the lake with huge volume of water eroded the outlet making 
it much wider and deeper. This event results in draining of huge volume of water from the lake to the 
downstream areas. The side wall which plunged down to the lake is the part of the end or dead moraine 
of the two glaciers, the North Lhonak and the Lhonak glacier located in the area. The end moraines were 
once supported by the South Lhonak Glacier, however with the mel�ng of the glacial ice, the moraines 
base was exposed to the lake water and most probably it disturbed the stability of the moraine and it 
plunged down to the lake. (Source: Department of Science & Technology, Govt of Sikkim)
The State Government is in the process of forming an Expert Commi�ee:

th
Ÿ
To look into the cause of the disaster that struck the state on 4  October, 2023
Ÿ
To suggest suitable mi�ga�on measures for future events

Figure 1. Sen�nel image 25 December 2023

7


Figure 2. The pre- and post-flood satellite images interpreta�on of the South Lhonak Lake

Figure 3. Schema�c representa�on of Pre and post flood condi�ons of South Lhonak Lake. Figures
are based on field survey (pre flood) as well as Remote Sensing image interpreta�on (Image source:
Remote Sensing Division, DST- Sikkim)

8


Date 
 
 
Events

03.10.2023
Ÿ
District authori�es were informed & siren along with public announcements were 
made to alert residents at downstream areas along the Teesta Basin
Ÿ
First Incident Report was sent from State EOC therea�er hourly reports were sent to 
MHA, NDMA etc.
Ÿ
Immediate evacua�on of residents from vulnerable areas to higher ground was 
ordered
Ÿ
State Police, SDRF, NDRF, Forest Guards & QRTs with community volunteers ac�vated 
for search & rescue opera�ons
Ÿ
Dam authori�es were directed to give �mely updates of water discharge

04.10.2023
Ÿ
Reports of loss of lives and public property along with major bridges and vital 
installa�ons along the Teesta Basin being washed away was received
Ÿ
HCM, Council of Ministers, CS, DGP & other senior officers along with elected 
representa�ves visited the affected areas under Pakyong, Namchi & Gangtok Districts 
in the morning hours.
Ÿ
State Execu�ve Commi�ee, SSDMA under the chairmanship of CS declared the event 
as  a Disaster.
Ÿ
Time to �me situa�onal report of Disaster event was sent to MHA
Ÿ
Relief Camps were set-up at 30 loca�ons accommoda�ng about 7000 evacuees
Ÿ
District Hospital Emergency units were ac�vated
Ÿ
State Incident Response System (IRS) was ac�vated, Incident Command Post (ICP) was 
established at Teesta lounge, Tashiling Secretariat and Emergency Opera�ons Centre 
of Sikkim State Disaster Management Authority (SSDMA)
Ÿ
District IRS was simultaneously ac�vated, following ICPs was established: a) Pakyong 
ICP – Rangpo tourist Lodge, b) Gangtok ICP – Singtam Police Sta�on, c) Mangan ICP – 
Chungthang Police Sta�on
Ÿ
Relief Camps were set up at 30 loca�ons in the affected areas of the state

5.10.2023
Ÿ
Tourists were evacuated from affected districts
Ÿ
Relief materials were dispatched to affected districts
Ÿ
Electricity and communica�ons were restored

6.10.2023
Ÿ
Na�onal Crisis Management Commi�ee chaired by Cabinet Secretary met on 
5.10.2023 & 9.10.2023

7.10.2023
Ÿ
Director General, BRO visited the affected areas on

Ÿ
Union Minister of State for Home Affairs visited the affected areas on 7.10.2023

8.10.2023 &

9.10.2023

Ÿ
Inter-Ministerial Central Team visited the affected areas on 8.10.2023 & 
9.10.2023

Ÿ
Chief of Army Staff visited the affected areas on 9.10.2023

18.10.2023
Ÿ
NDMA team led by Member Secretary visited the affected areas on 18.10.2023

Ÿ
Union Power Minister chaired a meeting on 18.10.2023

Table 2.       Timeline of the Events

9


District
Villages 
Affected 

Family
displaced

People
Died

People
displaced

No of
damaged
houses

No of
relief
camps
opened

No of
people
missing

Mangan
50
588
4
2350
568
7
23

Pakyong
7
419
10+7
1677
635
10
27

Gangtok
19
477
16+15
(Indian 
Army)

1910
319
5
20

Namchi
24
272
3
1088
482
8
4

Sikkim
100
1756
55
7025
2004
30
74

2
Table 3.       District wise impact of disaster

2.4. District Wise Impact of the Disaster

2.5. Response of the State Government and District Administra�on

Search & Rescue - Mangan District

Ÿ
ITBP posted at Pegong along with Sikkim Fire & Emergency services commenced evacua�on & 
rescue on 4.10.2023.
Ÿ
Team of Sikkim Police led by DIG/Range/North & East was the first to reach Chungthang by foot 
on 5.10.2023.
Ÿ
SDRF reached Chungthang by foot on 6.10.2023.
Ÿ
One team of NDRF reached Chungthang by foot on 7.10.2023 and started opera�ons. Another 
team of NDRF reached Mangan on 8.10.2023 and proceeded to Chungthang on 9.10.2023 while 
the third team of NDRF was airli�ed on 9.10.2023 and started opera�on.
Ÿ
Heptars were deployed for Air Evacua�on of stranded tourists, workers & locals from 9.10.2023
Ÿ
Teams led by District Authori�es including Sikkim Police, Sikkim Fire & Emergency Services, 
NDRF, SDRF, ITBP, Army, Forest Guards, QRTs and local volunteers-ini�ated search & rescue 
opera�ons from the morning hours of 4.10.2023.
Ÿ
District control room numbers were widely disseminated on 4.10.23.
Ÿ
District Hospital emergency units were ac�vated on the morning hours of 4.10.2023
Ÿ
Electricity and communica�ons were restored on 5.10.2023.

Relief Measures

Ÿ
Se�ng of 30 Relief Camps for 7025 affected people: Gangtok District: 10 Relief Camps for 1910 
inmates, Pakyong District: 5 Relief Camps for 1677 inmates, Namchi District: 8 Relief Camps for 
1088 inmates, Mangan District: 7 Relief Camps for 2350 inmates.
Ÿ
Ex-Gra�a to next of kin of deceased and injured disbursed.
Ÿ
Relief with Essen�al Commodi�es disbursed to affected people. Distribu�on of clean water to 
affected areas.

2www.census2011.co.in/census/state/sikkim.html,www.sikkimtourism.gov.in/Webforms/General/Si
kkimAtAGlance/Climate.aspx

10


Ÿ
Transporta�on to daily wage earners and tourists arranged.
Ÿ
Psychosocial care and counselling provided to trauma vic�ms
Ÿ
Construc�on of gender segregated washrooms set up at affected areas
Ÿ
De-fogging, sani�za�on & cleaning drives of affected areas frequently done

Immediate recovery & restora�on measures towards rehabilita�on 

Ÿ
Re-issuance of lost documents and school uniform with textbooks ini�ated. 
Ÿ
Debris clearance at affected areas ini�ated. 
Ÿ
Construc�on of tradi�onal log bridges completed. Construc�on of Bailey Bridge over 
Sangkhalang, Chungthang & Zema completed by BRO. 
Ÿ
Controlled detona�on of ammuni�on by Army ini�ated. 
Ÿ
Communica�ons re-established at key loca�ons with TSPs and VSATs. 
Ÿ
Electricity, Water Supply restored at affected loca�ons. 
Ÿ
Vital road linkages re-established. 

Emergency Cabinet announcement by Government of Sikkim 

Ÿ
Sikkim Punarwas Awas Yojana in which 2100 new houses are to be constructed. 
Ÿ
Sikkim Janta Housing Colony in which 2000 houses are to be constructed for tenants. 
Relief camp inmates will be granted at Rs. 5000/month for three months. 
Ÿ
Affected students to be provided a one-�me grant of Rs. 10000 for purchase of books & 
uniforms.
Ÿ
To cons�tute a Technical Commi�ee consis�ng of experts to look into the cause of the recent 
disaster and mi�ga�on measures thereof. 
Ÿ
Loan moratorium for affected business owners. 

Government of Sikkim's ini�a�ves on GLOF Management: Sikkim State Disaster Management 
Authority with the District Disaster Management Authori�es and other stakeholders has conducted: 

Ÿ
Awareness and sensi�sa�on programmes at all vulnerable downstream loca�ons: Chungthang, 
Phidang, Mangan, Dikchu, Singtam, Rangpo & Melli 
Ÿ
Basic Search, Rescue and First Aid Training was imparted to volunteers 
Ÿ
Par�cipatory Rural Appraisal to map the hazards and associated risks was completed 
Ÿ
Evacua�on maps were prepared and shared with all key stakeholders 
Ÿ
State Level Mock exercise on earthquake triggered GLOF was conducted on May, 2023 
Ÿ
Chungthang Sub-Division Office with SUL conducted Mock Drill on GLOF on 18.09.2023 

2.6. Recovery Vision
The recovery vision for Sikkim Flash Floods 2023 envisions a holis�c and resilient transforma�on 
focusing on: 

a.  Integrated communica�on for risk informed prac�ces: Foster collabora�on and communica�on 

between government agencies, NGOs, private sector and local communi�es, pooling resources 
and exper�se for a coordinated and sustainable recovery effort 
b.  Mainstreaming Disaster Risk Reduc�on in Development Planning: Review and update exis�ng 

policies related to disaster management, land use and environmental protec�on, adapt to 
changing condi�ons and enhance resilience against future disasters. 
c.   Community Centered Reconstruc�on
d.  Technology Integra�on for Early Warning: Enhance and expand early warning systems through 

the integra�on of cu�ng- edge technologies, providing �mely alerts and ensuring effec�ve 
preparedness for future disasters

11


This recovery vision aims not only to rebuild Sikkim but to create a more resilient and sustainable future, 
fostering a sense of community empowerment and environmental stewardship.

2.7. Specific Recovery Objec�ves

Ÿ
Infrastructure Rehabilita�on: Priori�ze the reconstruc�on of damaged roads, bridges, and 
buildings to restore connec�vity and essen�al services for affected communi�es 
Ÿ
Community Rese�lement and Housing: Develop a plan for the safe and sustainable 
rese�lement of displaced families, ensuring access to adequate housing and basic ameni�es 
Ÿ
Livelihood Restora�on: Implement programs to revive local economies, suppor�ng farmers, 
businesses etc. affected by the flash floods 
Ÿ
Healthcare Strengthening: Enhance healthcare facili�es and services in the region, addressing 
immediate health needs and building resilience against poten�al disease outbreaks. 
Ÿ
Educa�on Recovery: Rebuild damaged schools and educa�onal ins�tu�ons, providing 
resources for students and teachers to resume learning ac�vi�es 
Ÿ
Environmental Rehabilita�on: Undertake ini�a�ves for watershed management, soil 
conserva�on and afforesta�on to reduce the risk of future flash floods and enhance 
environmental sustainability 
Ÿ
Community Empowerment and Training: Conduct training programs to educate communi�es 
on disaster preparedness, early warning systems, and response strategies, empowering them 
to handle future emergencies effec�vely 
Ÿ
Technology Integra�on: Integrate advanced technologies for early warning systems, 
monitoring and data analysis to improve disaster preparedness and response capabili�es 
Ÿ
Government Policy Review: Evaluate exis�ng policies related to land use, construc�on and 
environmental protec�on to enhance resilience and mi�gate future disaster risks in Sikkim. 

2.8. Recovery Principles

Ÿ
Community - Centric Approach: Priori�ze the ac�ve involvement and empowerment of local 
communi�es in decision making processes to ensure that recovery efforts align with their needs 
and priori�es 
Ÿ
Sustainability and Resilience: Embed principles of sustainability in recovery projects, focusing 
on eco - friendly infrastructure, resilient urban planning, and long-term environmental 
conserva�on 
Ÿ
Inclusive Recovery: Ensure that vulnerable groups, such as women, children and elderly, are 
specifically addressed in recovery plans, with targeted support to meet their unique needs 
Ÿ
Partnership and Collabora�on: Foster collabora�on between government agencies, NGOs, 
private sector and interna�onal organiza�ons to pool resources, exper�se and ensure a 
coordinated and effec�ve recovery effort 
Ÿ
Transparency and Accountability: Maintain transparency in resource alloca�on, project 
implementa�on, and decision-making processes, and establish mechanisms for accountability 
to build trust among stakeholders 
Ÿ
Innova�ve Technology Integra�on: Embrace innova�ve technologies for efficient data 
collec�on, early warning systems, and informa�on dissemina�on to enhance preparedness and 
response capabili�es 
Ÿ
Cultural Sensi�vity: Respect and integrate local cultural prac�ces, belief and tradi�ons into 
recovery efforts recognizing their importance in fostering community cohesion and resilience
Ÿ
Adap�ve Planning: Develop flexible and adap�ve recovery plans that can evolve based on 
changing circumstances and emerging challenges  

12


Ÿ
Capacity Building: Invest in training and skill development programs for local communi�es, 
local officials and responders to enhance their capacity to cope with and respond to future 
disasters
Ÿ
Risk Reduc�on and Preparedness: Integrate risk reduc�on measures into recovery plans, 
emphasizing early warning systems, land use planning and infrastructure design that mi�gate 
the impact of future flash floods. 

2.9. Sectoral Specific Findings on Damages, Losses and Recovery Need 

Sector
 Sub-Sector
Damages
 Losses 

Damage + 

Losses

Recovery and 
Reconstruc�on

Recovery & 
Reconstruc�on 
Needs (%)

Social
Housing 
560.73 
30.52
591.25 
670.3
30.57%

Health
1.15
3.783 
4.933
9.11
0.42%

Educa�on 
27.94
1.843 
29.783
30.68 
1.40%

Community Buildings
4.92
0
4.92
9.13 
0.42%

Social Total
594.74
36.146 
630.886
719.22 
32.81%

Produc�ve
Tourism
0
241.53
241.53
241.53 
11.02%

Animal Husbandry, 
Livestock and Fisheries 

23.38
11.38 
34.76 
39.51
1.80%

Agriculture and 
Hor�culture 

26.47 
53.97 
80.44 
31.22
1.42%

Produc�ve Total 
49.85 
306.88 
356.73 
312.26
14..24%

Infrastructure 
Roads and Transport 
163.52 
41.87 
205.4 
395.38
18.03%

Drinking Water and 
Sanita�on 

37.9 
3.49 
41.39 
45.21 
2.06% 

Infrastructure Total
201.42 
45.36 
246.79 
440.59 
20.09% 

Crosscu�ng 
Forest and Environment 
202.69 
42.97 
245.66 
245.77 
11.21% 

Disaster Risk 
Reduc�on 

0
0
0
474.5 
21.65% 

Crosscu�ng Total 
202.69 
42.97 
245.66 
720.52 
32.86% 

Grand Total 
1048.7 
431.37 
1480.066 
2192.59 
100.00% 

Table 4.       Summary of Damage, Losses and R&R needs. 

13


3. Social Sector

3.1. Housing 

Basic Profile of the Sector
 Sikkim's popula�on was 6.1 lakh (Census, 2011) with a total 1,51,772 houses. About 66% of the houses 
were of CGI/metal/Asbestos sheet followed by 26% RCC roofs. About 42% of the houses were with 
brick/concrete block walls, 58% of the walls were either kutcha or of vernacular materials and 24% of 
the houses had mud flooring. The present projected popula�on of the state is about 6.9 lakh (2023) and 
Sikkim has a significant number of migrant workers from the neighbouring states who come to Sikkim 
for livelihood. A significant percentage of both the Sikkimese and people from other states live in rented 
premises which are 5-6 storied RCC framed structure buildings owned by the local people. 

Sikkim has its rich vernacular architecture which was evolved over �me in a holis�c manner and acts as 
the cultural con�nuity and iden�ty of the people. Unfortunately, lack of awareness and knowledge on 
the technical aspects of this architecture has pushed it on the verge of ex�nc�on. The engineering and 
architecture colleges do not teach this type of architecture. While these houses have the required 
seismic resilience, such technologies should be revitalized based on the latest building safety codes and 
reintroduced in the government buildings to encourage people to adopt these. Recovery would be a 
good opportunity for adop�ng these technologies. 

Sectoral Policies 
In 2010, "Chief Minister's Rural Housing Mission" (CMRHM) was launched under the State Plan with the 
target of conver�ng the exis�ng 6,000 kutcha dwellings to single storey, earthquake resistant pucca 
houses and become the first kutcha house free state in the country. Sikkim had a�ained its target of rural 
housing under the Pradhan Mantri Awas Yojana Grameen and Urban programmes in 2017. The state has 
an ongoing programme; Sikkim Garib Awas Yojana that provides pucca houses to the families who 
cannot afford one. The divisional engineer of RDD, Sikkim reported that the target of the scheme is to 
construct 10,000 houses. Sikkim Housing and Development Board is currently construc�ng 38 houses 
for the people. Apart from these schemes, there are contractors, promoters and local engineers who 
have been construc�ng houses for the economically well-off people primarily in the urban areas. A 
significant number of HHs live in rented houses. Recently the GoS has launched Janta Housing Colony 
scheme for construc�ng a Housing Colony for those who do not have their own homes. For the affected 
persons to live in the Janta Housing Colony, they will not have to pay any rent to the government for the 
next three years. 

Damages in the Sector
 It may be noted that 79% of the damaged housing stock due to the flash flood was well built RCC 
structures. While the major cause of damage was the excep�onal water load on them due to their close 
proximity to the river (clear viola�on of safety norm), it must also be noted that the flash flood in 
October was unprecedented; never experienced before in Sikkim; not even exist in the Sikkimese 
folklore. During the field visits it was observed that majority of the buildings by the roadside were of RCC 
framed structures. Many of them were 5 or more storied with CGI sheet or metal track deck as the top 
floor roof. There were load bearing brick masonry and hybrid buildings as well. Most of the RC framed 
buildings in some places were found to be in good condi�on even a�er facing the huge water load during 
the flash flood. Only the ground and first floor were affected by the flash flood. 

14


One of the prime causes of the devasta�on was; buildings located close to the river bed or at less than 
6m above the river water level. Most of the RCC framed structures were 4-5 storied. This was followed 
by load bearing stone/brick wall structure (10%) and �mber framed structure (12%). The water level was 
excep�onally higher than one would expect, and no one had even seen before such height and current 
of water in the river. Many buildings on the slope facing the river simply got washed away or badly 
damaged. Scouring of soil and buildings on steep slope were also the causes of building damage. Some 
of the kutcha houses, which were built on the riverbed (IBM) got washed away. Non-compliance with 
safety norm caused a massive destruc�on. Building Bye laws are not mandatory in most of the places 
visited, which is a major cause of the disaster. Building permit is required only in the TCP area. People 
reported that obtaining a building permit is complex and �me consuming.

A huge quan�ty of debris is the major issue that made the process of ge�ng back to the normal life slow 
and expensive. The sep�c tanks have been damaged. However, the major issue is that they are now 
buried under debris brought by the flash flood and removal is both �me consuming and expensive. The 
following Tables show the damage pa�ern across the four districts of Sikkim.

Table 5.      Housing: Damage to Housing Sector 

Housing 

Sub-Sector 
Items 

A. Pucca Houses

B. Semi-Pucca

c. Hut/ Kuccha

C. Ca�le Sheds

128

77

138

168

511

511

303

26

35

0

364

364

858

48

23

103

1032

1032

1289

151

196

271

1907

1907

1_Totally 
Damaged 

2_Severly 
Damaged 

3_Par�ally 
Damaged

Grand Total 

Table 6.       Housing: Exis�ng floor areas of pucca, semi-pucca and kutcha buildings 

Total Built-

 up Area

 (sqm) 

Av. Built-up 
area/house (sqm) 

Average number 

of stories 

Av 
area/floor 

(sqm) 

Total Number of 

Buildings 

Pucca

Semipucca

Hut/Kutcha

Total

570215

32317

20326

622858

442.370

214.020

103.704

3.365

1.397

1.194

131.48

153.16

86.86

1289

151

196

1636

15


Damage cost 
The cost of housing damage is calculated based on the current replacement cost of a building by its 
structure-type, e.g., pucca, semi-pucca and kutcha, since their unit construc�on costs are different. The 
classifica�on of damage categories is done based on the required repair/retrofi�ng cost of a building of 
a par�cular structure type to get back to its pre-disaster condi�on. This is expressed as a percentage of 
the current replacement cost of a building. For example, 30% damage means that the building requires a 
repair that would cost 30% of its current replacement cost. The damage categories adopted in Sikkim 
are: a) damage <30%, b) damage >30%<50%, c) damage >50%<70% and d) damage >70% or destroyed. 
The damage category "b" and "c" have been clubbed together as >...