# Methods

## Study geometry and event marker

The event marker is `2026-08-26T02:52:10Z`, the reviewed USGS mass-movement time.[6] Catalog queries use bbox `[85.34, 28.23, 85.55, 28.32]`. Raster processing uses `[85.35, 28.24, 85.56, 28.32]`, which contains the government-mapped source and Rasuwagadhi corridor.[2]

## Data discovery and timing

`scripts/query_acquisitions.py` queries CMR UMM-JSON for Sentinel-1D SLC, NISAR provisional RSLC/GCOV/GUNW/GOFF, NISAR urgent-response L2, OPERA RTC-S1, OPERA DSWx-S1, ALOS-2, SAOCOM and RCM. It writes exact IDs and query URLs to `data/acquisition_timeline.csv`.

Two intervals are reported separately:

1. **Acquisition offset:** acquisition start minus event time.
2. **Event-to-archive time:** CMR provider insertion time minus event time.

Neither metric is called warning time. Catalog presence is not proof of geometry, quality or operational delivery.

## OPERA RTC inputs

OPERA RTC-S1 supplies 30 m UTM gamma-0 power COGs without a speckle filter.[25] The final run downloaded authenticated subsets for three Sentinel-1D relative-orbit views:

| Path / burst | Quiet-pre | Event-pre | Event-post |
|---|---|---|---|
| 19 / `T019_039570_IW1` | 12 Aug | 24 Aug | 5 Sep |
| 85 / `T085_180590_IW2` | 4 Aug | 16 Aug | 28 Aug |
| 121 / `T121_258660_IW3` | 7 Aug | 19 Aug | 31 Aug |

Every exact product ID and source URL is in `data/raw/opera_rtc_fetch.json`. Signed download URLs were not retained.

## Terrain and independent reference

The public Copernicus GLO-30 tile `Copernicus_DSM_COG_10_N28_00_E085_00_DEM` was window-read as a COG and reprojected bilinearly to each radar grid. GLO-30 Public is a 30 m DSM distributed as COGs.[19]

The independent detachment polygon was fetched from UNOSAT's live `UNOSAT_Analysis_V2/MapServer/7` layer. UNOSAT derived the wider event impact assessment from 26 August PlanetScope and 27 August Sentinel-2 and explicitly labels it preliminary/not field validated.[20] The polygon is therefore validation evidence, not ground truth.

## Backscatter-change statistic

For each track and interval:

1. Require OPERA mask class 0 on both dates. Per-acquisition masks were used because pass-specific layover/shadow can differ.[25]
2. Require finite, positive VV/VH power, a valid DEM cell and slope ≤70°.
3. Compute $\Delta_{dB}=10\log_{10}(post)-10\log_{10}(pre)$ separately for VV and VH.
4. Apply a 3×3 NaN-aware median filter (effective support up to 90 m) because no speckle filter is present in RTC.[25]
5. Define stable reference pixels as valid cells outside a 300 m buffer of the detachment and with DEM slope 5–60°.
6. For each polarization, calculate $z=(\Delta-median_{ref})/(1.4826\,MAD_{ref})$.
7. Combine channels as $S=\sqrt{(z_{VV}^2+z_{VH}^2)/2}$.
8. Flag $S\ge3.0$ and remove 8-connected components smaller than 25 pixels. At 30 m, MMU = **0.0225 km²**.
9. Reproject each binary result to the path-19 grid and require a flag in at least two tracks, with at least two tracks geometrically valid.

The output class is **calibrated surface backscatter change**. It is not labeled flood, debris depth, deformation, unsafe terrain or a warning.

## Validation and uncertainty

- **Independent product/sensor evidence:** compare with the UNOSAT optical detachment polygon and the Copernicus Sentinel-2 interpretation of post-event channel widening and sediment.[20][22]
- **Second geometry:** paths 85 and 121 test whether the path-19 pattern survives different look directions.
- **Null test:** run the identical method on the immediately preceding same-burst 12-day pair for each path, over the future detachment polygon.
- **False alarms:** report flags outside the reference polygon over all valid cells; this is conservative because the reference polygon is not a complete map of every true surface change.
- **Threshold sensitivity:** rerun the consensus at `k=2.5, 3.0, 3.5, 4.0` with the same MMU.
- **Coverage:** report the AOI and reference-polygon fraction that has at least two valid views. Invalid means unknown, not unchanged.

No low-coherence mask was applied because RTC amplitude products contain no coherence observable. A coherence/InSAR claim requires SLC/GUNW processing and its own phase-quality masks; that analysis is kept separate below.

## Connected-system AOI and 24-month inventory

The primary AOI is the unsimplified union of 37 HydroBASINS level-12 units draining to `HYBAS_ID=4120833490`, immediately upstream of the first unit shared with Tadi Khola. Its geodesic area is **4,774.048 km²**. A separate 750 m buffer follows 15.270 km of five HydroRIVERS reaches toward Devighat; it is infrastructure/context geometry and is excluded from catchment area. Five disjoint catchment subareas plus the supplement are saved in `data/scouting/aoi/`.

The catalog window is `2024-11-15T00:00:00Z` through `2026-11-15T23:59:59Z`. Discovery used a declared rectangular superset, CMR Search-After pagination, and ASF count-checked partitions. `scripts/scouting/inventory_stats.py` then parsed every CMR UMM polygon/rectangle, intersected it with the hydrologic AOI, and assigned all intersecting subareas. The source snapshot contains 12,931 unique CMR concepts; exact post-filtering retained 6,803 rows. Statistics distinguish product granules from unique source-observation dates and group repeat geometry by mission/product, relative track, frame, direction, beam/swath, polarization, bandwidth, burst, or MGRS tile as applicable.

For pair products, both reference and secondary source dates contribute to acquisition counts. The longest same-geometry date sequence and its median adjacent temporal baseline are computed after maturity/revision deduplication. Monsoon counts use June–September 2026 and separate dates before versus on/after 26 August. Footprint intersection is not treated as coherent or geometry-valid target coverage.

## NISAR L-band range-read analysis

The NISAR event products are provisional; ASF describes provisional products as calibrated but validated at a limited set of sites.[23] GUNW provides geocoded unwrapped phase, coherence, connected components and ionosphere fields at 80 m posting.[24]

`_subagents2/nisar/scripts/extract_subsets.py` authenticates through Earthdata netrc, follows signed redirects only in memory, and passes a seekable `fsspec` block-cached file object to `h5py`. Eight GUNW/GOFF/GCOV science files totaling 35.46 GB were opened with range requests; no complete science HDF5 was written. Saved source and exploratory-control subsets are EPSG:32645 GeoTIFF/NPZ pairs with exact product IDs, grid coordinates, mask layers and SHA-256 verification.

The quiet pair is 14–26 July 2026 and the event pair is 19–31 August 2026 on NISAR track 98. Track 48 was separately range-tested. Phase validity requires sample-valid encoded masks and a nonzero connected component; no phase-to-displacement conversion is performed. GOFF layers remain explicitly raw, unculled and unfiltered. GCOV output is `10 log10(secondary) - 10 log10(reference)` for common-valid HH/HV gamma-0 pixels and is labeled backscatter change only.

## Sentinel-1D HyP3 coherence analysis

Two `INSAR_ISCE_BURST` jobs used burst `085_180590_IW2`, VV polarization, 20×4 looks, water masking, and adjacent 12-day pairs: 4–16 August (quiet) and 16–28 August (event). HyP3 documents Sentinel-1D burst support, 80 m pixel spacing at 20×4 looks, and normalized coherence on a 0–1 scale.[26] Both jobs succeeded, consumed one credit each, and were downloaded, extracted, hashed and read back.

Quiet coherence is bilinearly reprojected by one 80 m northing cell to the event grid; categorical masks use nearest-neighbour resampling. Paired comparisons require land and finite coherence in both products. The independent preliminary UNOSAT detachment polygon, a 0.3–1.5 km local control ring, and the wider fixed AOI are summarized separately. Unwrapped phases from the two independently referenced interferograms are never subtracted.

The control-calibrated screen uses the 5th percentile of event-minus-quiet coherence outside a 300 m detachment buffer (`−0.1261619925`) and removes 8-connected components smaller than four 80 m pixels. MMU is **0.0256 km²**. False alarms are retained and reported over all valid control pixels. The burst bundle did not include an explicit layover/shadow layer, so the screen is medium-low-confidence retrospective evidence, not a complete terrain-valid map.

## Cross-band comparison and exposure context

Only target-versus-control change is compared within each sensor. Absolute L- and C-band coherence is not ranked because dates, wavelength, polarization, geometry, masks and terrain observability differ. OSM settlement, bridge and hydropower-context feature centres within 20 km are assigned transparent distance bands; proximity is not population, damage, failure probability or risk.

## GPM IMERG and POWER

`scripts/fetch_hydro_context.py` queried CMR, authenticated through `~/.netrc`, downloaded the event-containing Early and Late V07C HDF5 files and sampled the nearest native cell. IMERG merges estimates into half-hourly 0.1° fields.[17] Random error, precipitation quality and probability-liquid fields were retained.

The same script fetched POWER daily IMERG, MERRA-2/GEOS meteorology and wetness variables. POWER's meteorology grid is 0.5°×0.625°, and its daily IMERG stream is 0.1°.[15] Missing volumetric moisture values (`-999`) were stored as null, never zero.

## Reproducibility and provenance

- Environment: Python 3.12; exact direct dependencies in `requirements.txt`.
- Exact local rerun commands: `METHOD_CARD.md`; top-level verified wrapper: `scripts/run_all.sh`.
- Unit tests: `python -m unittest discover -s tests -v`.
- `data/manifest.csv` records every released input/scouting/processed file; every GeoTIFF row carries SHA-256, source IDs/URL, parameters, CRS, shape, nodata and a provenance label.
- `game_handoff/provenance.json` hashes and classifies every web asset.
- Credentials are read only by Earthdata/HyP3 clients; tokens, cookies and signed query strings are never written.

## Sources

[2] https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR_hnmns6o.pdf — Government of Nepal CHWRR Assessment Report II: Rasuwa-Bhote Koshi Flood Event, 2026
    > "An extreme and rapid-onset flood occurred in the Lhende Khola–Bhote Koshi–Trishuli–Narayani river system on 10 Bhadra 2083 (26 August 2026)."
    > "Study of available satellite images (Landsat 9, Planet Labs) shows that a hanging glacier located on the northern side of Langtang-Lirung mountain in Rasuwa district, at an elevation of approximately 5200 masl (approximately 28.291242°N, 85.528066°E), collapsed, causing a huge ice–rock avalanche which fell onto a debris-covered glacier located approximately 3800 masl."
    > "However, no rainfall was recorded around the slope failure area or flood-initiated area during the time of the flood These observations indicate that the extreme flood was likely generated as a cascading consequence of the ice-rock avalanche and subsequent displacement of the debris mass, rather than by rainfall-induced runoff."
[6] https://earthquake.usgs.gov/earthquakes/eventpage/us7000tbwb — USGS M 5.2 Landslide — 55 km NW of Kodari, Nepal
    > "This event was initially reported as a magnitude 4.4 earthquake. Additional analysis of long period seismic waves indicate that the seismic energy was instead generated by a glacial collapse and debris flow."
[15] https://power.larc.nasa.gov/docs/methodology/data/sources — NASA POWER Data Sources
    > "The POWER Project provides data at the native sources resolution from the data providers; primary solar resolution is a global 1° x 1° latitude/longitude grid from CERES SYN1deg while the meteorological data sources are ½° x ⅝° latitude/longitude grid from GMAO MERRA-2."
[17] https://www.earthdata.nasa.gov/data/catalog/ges-disc-gpm-3imerghhe-07 — GPM IMERG Early V07 catalog
    > "The precipitation estimates from the various precipitation-relevant satellite passive microwave (PMW) sensors comprising the GPM constellation are computed using the 2021 version of the Goddard Profiling Algorithm (GPROF2021), then gridded, intercalibrated to the GPM Combined Ku Radar-Radiometer Algorithm (CORRA) product, and merged into half-hourly 0.1°x0.1° (roughly 10x10 km) fields."
[19] https://copernicus-dem-30m.s3.amazonaws.com/readme.html — Copernicus DEM GLO-30 public COG readme
    > "GLO-30 Public provides limited worldwide coverage at 30 meters because a small subset of tiles covering specific countries are not yet released to the public by the Copernicus Programme."
[20] https://unosat.org/products/4259 — UNOSAT Rasuwa-Nuwakot impact assessment 4259
    > "This map illustrates the cumulative satellite-detected mudflow/rockflow extent derived from Sentinel-2 imagery acquired on 27 August 2026 and PlanetScope imagery acquired on 26 August 2026."
[22] https://eu-space.europa.eu/components/earth-observation-copernicus/image-of-the-day/aftermath-nepal-flash-flood — Copernicus aftermath of Nepal flash flood
    > "By 27 August 2026, the river course appeared markedly wider, with extensive pale brown sediment deposits visible."
[23] https://nisar-docs.asf.alaska.edu/availability-overview — Available NISAR Data
    > "NISAR PROVISIONAL datasets were released July 20, 2026. These products are fully calibrated and have undergone validation at a limited set of sites around the world."
[24] https://nisar-docs.asf.alaska.edu/gunw — NISAR Geocoded Unwrapped Interferogram guide
    > "The GUNW product is an L2 product derived from the RIFG and RUNW products by geocoding the unwrapped phase and associated data layers (i.e., coherence magnitude, ionospheric phase screen) on a geographical grid at 80 m posting."
[25] https://hyp3-docs.asf.alaska.edu/guides/opera_rtc_product_guide — ASF OPERA RTC-S1 product guide
    > "The pixel values of the products represent gamma-0 power. The pixel spacing is 30 meters, and no speckle filter has been applied."
    > "For investigating the layover/shadow impacts for a specific RTC product, users will generally be better served by using the validity mask delivered with that product rather than the mask available as a static layer."
[26] https://raw.githubusercontent.com/ASFHyP3/hyp3-docs/4e3545b5b6bed39ee3c7d557c4649c4968215868/docs/guides/burst_insar_product_guide.md — ASF HyP3 Sentinel-1 Burst InSAR Product Guide
    > "ISCE2 has been updated to support processing of data collected by Sentinel-1D."
    > "Images are resampled to a pixel size that reflects the resolution of the output image based on the requested number of looks: 80 meters for 20x4 looks, 40 meters for 10x2 looks, and 20 meters for 5x1 looks."
    > "The *normalized coherence* file contains pixel values that range from 0.0 to 1.0, with 0.0 being completely non-coherent and 1.0 being perfectly coherent."
