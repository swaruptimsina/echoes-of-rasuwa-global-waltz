# Rasuwa–Bhotekoshi SAR data-richness research package

Retrospective, reproducible analysis of the 26 August 2026 Langtang Lirung rock–ice failure and Bhote Koshi–Trishuli flood/debris cascade. The package contains real CMR/ASF metadata, a hydrologically defined cross-border AOI, authenticated NASA/partner subsets, HyP3 Sentinel-1D products, null/control tests, false alarms, and explicit failures. It is **not a forecast or warning system**.

## Main conclusions

- The connected system is **catalog-rich**: the exact AOI retained 6,803 of 12,931 CMR product records, including long 12-day Sentinel-1 and NISAR chains.
- Sentinel-1D showed localized event-spanning coherence loss inside a preliminary independent optical detachment; the control-calibrated/MMU mask flagged 158/307 target pixels and 1,225/30,161 control pixels.
- NISAR also decorrelated at the source, but connected event phase survived in only 9/528 pixels. No displacement, velocity, acceleration, or precursor claim is made.
- The earlier multi-view OPERA amplitude method detected a terrain-observable subset and passed a matched quiet null, but it did not map the complete disturbance.
- No validated precursor feature exists in the release.

## Main documents

- `FINDINGS.md` — concise observations, interpretations, confidence and plain-language result.
- `site_selection.md` — final nine-site scorecard and primary-site decision.
- `AGENCY_BRIEF.md` — one-page research brief for DHM/NDRRMA/ICIMOD/local government.
- `METHOD_CARD.md` — exact commands for a free-tool rerun.
- `00_event_facts.md`, `01_questions.md`, `methods.md`.
- `negative_results.md`, `limitations.md`, `expert_review_questions.md`.

## Data and provenance

- `inventory.csv` — canonical 6,803-row exact-AOI metadata inventory.
- `data/scouting/aoi/` — 4,774.048 km² connected catchment, six analysis subareas, outlet/pour points, source metadata and report.
- `data/scouting/inventory/` — 12,931-row bbox snapshot, exact inventory copy, collection/archive status, validation and per-subarea sensor statistics.
- `data/scouting/site_scout/` — nine-candidate catalog/evidence sweep with 59 quote-backed sources.
- `data/processed/nisar_lband/` — verified range-read GUNW/GOFF/GCOV subsets and failure diagnostics.
- `data/processed/s1d_hyp3/` — two successful Sentinel-1D HyP3 jobs, products, hashes and coherence analysis.
- `data/scouting/impact/` — latency, cross-band comparison, subtle-change results, exposure proximity and screening GeoJSON.
- `data/manifest.csv` — 263 released files. Every GeoTIFF row contains SHA-256, exact source IDs/URL, processing parameters, CRS, shape, nodata and provenance.
- `game_handoff/` — 24 web-ready assets plus a complete checksum/provenance manifest.

Raw catalog responses and large AOI source caches remain under `_subagents2/`; they are retained for audit but excluded from the release manifest.

## Reproduce

Prerequisites: Python 3.12, network access for live refreshes, and Earthdata Login configured through `EARTHDATA_TOKEN` or `~/.netrc`. Never place credentials in this directory.

```bash
cd /home/safal0715/Documents/research
./scripts/run_all.sh
```

The wrapper installs pinned requirements, runs the tests, rebuilds local analyses from the retained snapshot/products, regenerates manifests, and runs the tests again. It does **not** resubmit HyP3 jobs. See `METHOD_CARD.md` for stage-by-stage commands and live catalog/range-read refresh routes.

## Interpretation guardrails

- Red coherence/backscatter pixels are retrospective observables, not unsafe areas, water depth, debris thickness, displacement or predicted failure.
- Transparent/invalid terrain is unknown, not unchanged.
- Acquisition, product-generation, archive-insertion and research-processing times are separate clocks; none is warning time.
- OSM distance bands are proximity context, not population, damage, accessibility, probability or risk.
- RCM, SAOCOM and NISAR S-band availability remains incomplete/UNVERIFIED rather than zero.
