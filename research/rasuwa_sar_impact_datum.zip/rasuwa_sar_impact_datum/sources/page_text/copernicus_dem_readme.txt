URL: https://copernicus-dem-30m.s3.amazonaws.com/readme.html

Copernicus Digital Elevation Model datasets
Copernicus Digital Elevation Model datasets
The Copernicus DEM is a Digital Surface Model (DSM) which represents the surface of the Earth including
        buildings, infrastructure and vegetation. We provide two instances of Copernicus DEM named GLO-30 Public and
        GLO-90. GLO-90 provides worldwide coverage at 90 meters. GLO-30 Public provides limited worldwide coverage at 30
        meters because a small subset of tiles covering specific countries are not yet released to the public by the
        Copernicus Programme. Note that in both cases ocean areas do not have tiles, there one can assume height values
        equal to zero. Data is provided as Cloud Optimized GeoTIFFs.
For source data, we used the COP-DEM_GLO-30-DGED dataset for 30 meters, and the COP-DEM_GLO-90-DGED dataset for 90 meters DEM. For more info about the source datasets, check out this
page
.
Data processing
Original tiles share one row or column with neighboring tiles, and have sizes such as 3601 by 3601 pixels, 2401 by 2401 pixels, 1801 by 1801 pixels, or something else, depending on the longitude. We removed these shared rows and columns on east and south edges to got the dimensions that are nicely divisible by two, so we could create nice COG overviews.

      The common properties of COG files are:
DEFLATE compression using predictor for floating points (PREDICTOR=3)
average downsampling
GLO-30 Public
The properties of COG files specific to this dataset:
original height: 3601 pixels
COG height: 3600 pixels
TIFF tile size: 1024 * 1024 pixels
Longitude spacing
Latitude spacing
original width
COG width
overview widths
0 - 50
1x
3601
3600
1800, 900, 450
50 - 60
1.5x
2401
2400
1200, 600, 300
60 - 70
2x
1801
1800
900, 450, 225
70 - 80
3x
1201
1200
600, 300, 150
80 - 85
5x
721
720
360, 180, 90
85 - 90
10x
361
360
180, 90, 45
GLO-90
The properties of COG files specific to this dataset:
original height: 1201 pixels
COG height: 1200 pixels
TIFF tile size: 2048 * 2048 pixels
Longitude spacing
Latitude spacing
original width
COG width
overview widths
0 - 50
1x
1201
1200
600, 300
50 - 60
1.5x
801
800
400, 200
60 - 70
2x
601
600
300, 150
70 - 80
3x
401
400
200, 100
80 - 85
5x
241
240
100, 50
85 - 90
10x
121
120
50, 25
Data structure
Each file is its own object in Amazon S3. The data are organised per tiles in
original
          1x1 degree grid
(latest Shapefiles for
GLO-30 Public
and
GLO-90
).
        The basic data format is the following:
Copernicus_DSM_COG_[resolution]_[northing]_[easting]_DEM/
For example, the files for individual tile are available in the following location:
s3://copernicus-dem-90m/Copernicus_DSM_COG_30_S90_00_W178_00_DEM/
Where:
[resolution]
- resolution in arc seconds (not meters!), which is
10
for GLO-30,
            and
30
for GLO-90.
[northing]
= e.g.
S50_00
- decimal degrees where the decimal part is always
00
.
In original files, this is the northing of the center of the bottom-most pixels, while in our files, because we removed the bottom-most pixels, the center of the new bottom-most pixels is one pixel-length (resolution) away to north.
[easting]
= e.g.
w125_00
- decimal degrees where the decimal part is always
00
.
The easting of of the center of the left-most pixels.
Metadata
The list of tiles is saved in each bucket as
tileList.txt
.
Accessing the Copernicus Digital Elevation Model
If you use the AWS Command Line Interface, you can list data in the bucket with the “ls” command:
aws s3 ls s3://copernicus-dem-30m/
and
aws s3 ls s3://copernicus-dem-90m/
Contact
If you have questions about the data, please use
Sentinel Hub
          forum
License
GLO-30 Public and GLO-90 are available on a free basis for the general public under the terms and conditions of
        the Licence found
here
.
AWS Public Datasets
