# Negative results and dead ends

## OPERA DSWx-S1 event test: unavailable

- **Tried:** live CMR history queries for `OPERA_L3_DSWX-S1_V1` over the fixed AOI.
- **Result:** zero products from 1 August through 11 September 2026; latest pre 25 June, first post 12 September, 78.9996-day gap.
- **Diagnosis:** the long interval, seasonal change and Sentinel-1A→Sentinel-1D transition cannot isolate 26 August.
- **What would be needed:** an acquisition-matched DSWx product or an independently run classifier from event-adjacent RTC bursts, validated against high-resolution optical/field labels.

## Complete amplitude-change footprint: failed

- **Tried:** three same-burst OPERA views, robust stable-reference calibration, terrain masks, multi-view consensus and a matched quiet null.
- **Result:** real event/null separation, but only 29.13% recall inside the observable reference and 48.15% two-view coverage of the projected detachment polygon.
- **Diagnosis:** severe layover/shadow/steep-slope censoring, 30 m posting, C-band scattering ambiguity, speckle and different post-event dates.
- **What would be needed:** high-resolution optical/UAV mapping, field observations, NISAR L-band comparison, per-track local-incidence analysis and a larger independently mapped disturbance inventory.

## Precursor / event-source InSAR: tested, but displacement failed

ICIMOD reports up to 40 cm Sentinel-1 LOS change before failure but lists precursor deformation, glacier motion, atmosphere and geometry as unresolved alternatives.[9][11]

- **Tried:** authenticated range reads from same-track NISAR GUNW/GOFF/GCOV products, quiet and event pairs, a spatial control, an alternate look, connected components, encoded masks and ionosphere fields.
- **Result:** event-source connected phase survived in only 9/528 pixels; the near-time-matched track-48 look had zero source pixels passing both subswath-validity conditions.
- **Diagnosis:** source decorrelation and geometry/quality censoring prevent a defensible LOS displacement or velocity result. The exploratory control remained coherent, so this is a localized failure rather than a broken reader.
- **What would be needed:** a larger connected multi-epoch network, per-acquisition terrain geometry, stable references, validated reprocessing, atmosphere/ionosphere/DEM corrections, both looks, and expert review of the exact mask bits.

## ALOS-2, SAOCOM and RCM event-window coverage: not found in queried catalogs

- ALOS-2 returned zero event-window records; the latest AOI ScanSAR record was 28 March 2025.
- The selected SAOCOM and RCM CMR collection stubs returned zero granules, and ASF rejected the dataset names.
- **Interpretation limit:** this is catalog non-discovery, not proof that no national, commercial or partner holding exists.

## NASA Earth Observatory event page: not found

Targeted searches found no NASA Earth Observatory article specific to the July 2025 or August 2026 Rasuwa events. The available 2015 Langtang avalanche page concerns a different disaster and was excluded from event validation.

## Optical visual inspection: tool blocked

The public Sentinel-2/Landsat COGs, cloud masks and independent agency interpretations were accessible, but two direct image-vision checks returned HTTP 401 from the vision service. The result was not replaced with invented visual observations. Usability statements therefore rely on reproducible SCL/QA statistics, successful COG reads and opened agency products.

## HyP3 Sentinel-1D processing: succeeded, with a terrain-mask limitation

- **Tried:** two minimal single-burst `INSAR_ISCE_BURST` jobs (quiet and event), identical 20×4 looks and water masking.
- **Result:** both jobs succeeded, consumed two credits, and were downloaded and hashed. Sentinel-1D support is therefore verified for this workflow.
- **Remaining failure:** the delivered burst bundle had no explicit layover/shadow or local-incidence validity layer. The coherence result is descriptive and cannot be called a complete steep-terrain validation.
- **What would be needed:** an independent per-acquisition terrain-geometry mask and at least one more matched pair for the preregistered three-pair coherence-quality score.

## NISAR S-band and national mission archives: not enumerated

- CMR/ASF NISAR granules are L-SAR products; `jointObservation=true` is a companion-observation flag, not an S-band product file.
- Bhoonidhi S-band enumeration was not completed. RCM and SAOCOM provider archives were not searchable through the fetched CMR/ASF routes.
- **Interpretation limit:** availability is **UNVERIFIED**, not zero.

## Rainfall limitations, not a dead end

Native IMERG access initially failed anonymously but succeeded through the existing Earthdata netrc. The exact event half-hour was extracted. The remaining failure is spatial inference: a 0.1° grid cannot resolve a hanging-glacier slope, and NASA advises caution in orographic terrain.[17][18]

## Sources

[9] https://www.icimod.org/press-releases/second-major-himalayan-flood-in-seven-weeks-raises-new-questions-about-mountain-risk — Second major Himalayan flood in seven weeks raises alarm over compounding mountain hazards
    > "Sentinel-1 satellite radar detected up to 40 cm of ground deformation between 7 July and 24 August 2026, during the 48 day before the collapse."
[11] https://doi.org/10.53055/ICIMOD.1150 — Understanding the Gyirong–Rasuwa disaster of 26 August 2026: A preliminary synthesis
    > "The source of the event was a bedrock failure that sheared away part of a hanging glacier; this has been established through seismic, satellite, and drone evidence."
[17] https://www.earthdata.nasa.gov/data/catalog/ges-disc-gpm-3imerghhe-07 — GPM IMERG Early V07 catalog
    > "The precipitation estimates from the various precipitation-relevant satellite passive microwave (PMW) sensors comprising the GPM constellation are computed using the 2021 version of the Goddard Profiling Algorithm (GPROF2021), then gridded, intercalibrated to the GPM Combined Ku Radar-Radiometer Algorithm (CORRA) product, and merged into half-hourly 0.1°x0.1° (roughly 10x10 km) fields."
[18] https://gpm.nasa.gov/sites/default/files/2025-02/FAQ%20for%20IMERG%20V07%20Applications%20Users_202502.pdf — IMERG V07 Applications FAQ
    > "Greater uncertainty near orographic regions may lead to underestimated precipitation rates."
