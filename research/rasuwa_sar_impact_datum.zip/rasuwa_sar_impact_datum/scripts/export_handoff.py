#!/usr/bin/env python3
"""Export compact, explicit-provenance files for a web/game handoff."""
from __future__ import annotations

import argparse
import csv
import json
import shutil
import sys
from pathlib import Path

import numpy as np
import rasterio

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.core import sha256_file

TIMELINE_FIELDS = (
    "mission", "collection_short_name", "producer_granule_id", "granule_concept_id",
    "begin_datetime", "end_datetime", "event_role", "acquisition_offset_days",
    "provider_insert_datetime", "event_to_archive_days", "track_path", "direction",
)


def run_length_encode(mask: np.ndarray) -> list[list[int]]:
    """Encode a uint8 mask in row-major [value, run_length] pairs."""
    values = np.asarray(mask, dtype="uint8").ravel()
    if values.size == 0:
        return []
    runs: list[list[int]] = []
    current = int(values[0])
    length = 1
    for value in values[1:]:
        integer = int(value)
        if integer == current:
            length += 1
        else:
            runs.append([current, length])
            current, length = integer, 1
    runs.append([current, length])
    return runs


def optional_float(value: str | None) -> float | None:
    return float(value) if value not in (None, "") else None


def timeline_handoff_rows(rows: list[dict[str, str]]) -> list[dict]:
    """Keep the exact identifiers and the timing fields useful to a web client."""
    output = []
    for row in rows:
        item = {field: row.get(field) or None for field in TIMELINE_FIELDS}
        item["acquisition_offset_days"] = optional_float(row.get("acquisition_offset_days"))
        item["event_to_archive_days"] = optional_float(row.get("event_to_archive_days"))
        output.append(item)
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeline", type=Path, default=Path("data/acquisition_timeline.csv"))
    parser.add_argument("--change-mask", type=Path, default=Path("data/processed/opera_change/consensus_event_change_mask.tif"))
    parser.add_argument("--output", type=Path, default=Path("game_handoff"))
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    with args.timeline.open(newline="") as stream:
        timeline_rows = timeline_handoff_rows(list(csv.DictReader(stream)))
    timeline_json = args.output / "acquisition_timeline.json"
    timeline_json.write_text(json.dumps({
        "provenance_label": "catalog observation",
        "event_utc": "2026-08-26T02:52:10Z",
        "aoi_bbox_wsen": [85.34, 28.23, 85.55, 28.32],
        "entries": timeline_rows,
        "limitations": "Acquisition and archive times do not establish scientific usability or operational delivery.",
    }, indent=2) + "\n")
    timeline_csv = args.output / "acquisition_timeline.csv"
    shutil.copyfile(args.timeline, timeline_csv)

    with rasterio.open(args.change_mask) as source:
        mask = source.read(1)
        mask = np.where(mask == 1, 1, 0).astype("uint8")
        bounds = list(source.bounds)
        transform = list(source.transform)
        crs = str(source.crs)
    mask_json = args.output / "change_mask.json"
    mask_json.write_text(json.dumps({
        "provenance_label": "model output",
        "observable": "OPERA RTC-S1 calibrated VV/VH backscatter-change consensus",
        "width": int(mask.shape[1]),
        "height": int(mask.shape[0]),
        "crs": crs,
        "bounds": bounds,
        "transform": transform,
        "encoding": "row-major run-length [value,count]",
        "classes": {"0": "not flagged or insufficient consensus", "1": "flagged in at least two valid radar views"},
        "runs": run_length_encode(mask),
        "source_raster": str(args.change_mask),
        "source_raster_sha256": sha256_file(args.change_mask),
        "limitations": "This is surface backscatter change, not a flood/debris extent, depth, displacement, or hazard map.",
    }, separators=(",", ":")) + "\n")

    expected_assets = [
        "sar_change_overlay.png", "sar_change_overlay.webp", "sar_change_overlay.provenance.json",
        "rainfall_timeseries.json", "acquisition_timeline.json", "acquisition_timeline.csv", "change_mask.json",
    ]
    for name in expected_assets:
        if not (args.output / name).exists():
            raise RuntimeError(f"missing handoff asset: {name}")
    provenance = {
        "study": "26 August 2026 Rasuwa–Bhotekoshi event",
        "non_operational": True,
        "assets": [
            {
                "file": name,
                "sha256": sha256_file(args.output / name),
                "bytes": (args.output / name).stat().st_size,
                "provenance_label": (
                    "model output" if name.startswith(("sar_change", "change_mask"))
                    else "observation/model context" if name == "rainfall_timeseries.json"
                    else "catalog observation"
                ),
            }
            for name in expected_assets
        ],
    }
    provenance_path = args.output / "provenance.json"
    provenance_path.write_text(json.dumps(provenance, indent=2) + "\n")
    readme = args.output / "README.md"
    readme.write_text(
        "# Game handoff\n\n"
        "These files are retrospective research assets, not forecasts or warnings. "
        "Every asset is labeled as observation, model output, or mixed context in `provenance.json`. "
        "The red SAR overlay/change mask means calibrated backscatter change in at least two valid views; "
        "it does not mean flood depth, debris thickness, or unsafe terrain.\n",
        encoding="utf-8",
    )
    print(json.dumps({"assets": len(expected_assets) + 2, "provenance": str(provenance_path)}, indent=2))


if __name__ == "__main__":
    main()
