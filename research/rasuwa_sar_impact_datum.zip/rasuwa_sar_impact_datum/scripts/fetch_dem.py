#!/usr/bin/env python3
"""Fetch a public Copernicus GLO-30 DEM crop for the study AOI."""
from __future__ import annotations

import argparse
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import rasterio
from rasterio.windows import from_bounds

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.core import sha256_file

DEFAULT_BBOX = (85.35, 28.24, 85.56, 28.32)


def copernicus_tile_id(longitude: float, latitude: float) -> str:
    """Return the Copernicus GLO-30 tile containing a lon/lat point."""
    lon_floor = math.floor(longitude)
    lat_floor = math.floor(latitude)
    lon_hemisphere = "E" if lon_floor >= 0 else "W"
    lat_hemisphere = "N" if lat_floor >= 0 else "S"
    return (
        "Copernicus_DSM_COG_10_"
        f"{lat_hemisphere}{abs(lat_floor):02d}_00_"
        f"{lon_hemisphere}{abs(lon_floor):03d}_00_DEM"
    )


def copernicus_tile_url(tile_id: str) -> str:
    """Return the documented public S3 HTTPS URL for a DEM tile."""
    return f"https://copernicus-dem-30m.s3.amazonaws.com/{tile_id}/{tile_id}.tif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bbox", type=float, nargs=4, default=DEFAULT_BBOX, metavar=("W", "S", "E", "N"))
    parser.add_argument("--output", type=Path, default=Path("data/inputs/dem/copernicus_glo30.tif"))
    parser.add_argument("--metadata", type=Path, default=Path("data/raw/copernicus_dem_fetch.json"))
    args = parser.parse_args()
    bbox = tuple(float(value) for value in args.bbox)
    tile_ids = {
        copernicus_tile_id(bbox[0], bbox[1]),
        copernicus_tile_id(math.nextafter(bbox[2], bbox[0]), math.nextafter(bbox[3], bbox[1])),
    }
    if len(tile_ids) != 1:
        raise RuntimeError("this compact fetcher requires an AOI contained in one one-degree tile")
    tile_id = tile_ids.pop()
    url = copernicus_tile_url(tile_id)
    args.output.parent.mkdir(parents=True, exist_ok=True)

    with rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN="EMPTY_DIR", CPL_VSIL_CURL_ALLOWED_EXTENSIONS=".tif"):
        with rasterio.open(url) as source:
            window = from_bounds(*bbox, transform=source.transform).round_offsets().round_lengths()
            data = source.read(1, window=window, masked=True)
            profile = source.profile.copy()
            profile.update(
                driver="GTiff",
                count=1,
                height=data.shape[0],
                width=data.shape[1],
                transform=source.window_transform(window),
                compress="DEFLATE",
                predictor=3,
                tiled=True,
                blockxsize=256,
                blockysize=256,
            )
            nodata = profile.get("nodata")
            if nodata is None:
                nodata = -9999.0
                profile["nodata"] = nodata
            with rasterio.open(args.output, "w", **profile) as destination:
                destination.write(data.filled(nodata), 1)
                destination.update_tags(
                    source_url=url,
                    source_tile=tile_id,
                    subset_bbox_wsen=",".join(str(value) for value in bbox),
                    provenance_class="observation",
                )
            source_record = {
                "url": url,
                "tile_id": tile_id,
                "crs": str(source.crs),
                "shape": [source.height, source.width],
                "bounds": list(source.bounds),
                "resolution": list(source.res),
            }

    values = data.compressed().astype("float64")
    metadata = {
        "retrieved_utc": datetime.now(timezone.utc).isoformat(),
        "bbox_wsen": list(bbox),
        "source": source_record,
        "output": {
            "path": str(args.output),
            "bytes": args.output.stat().st_size,
            "sha256": sha256_file(args.output),
            "shape": list(data.shape),
            "valid_pixels": int(values.size),
            "minimum_m": float(np.min(values)),
            "maximum_m": float(np.max(values)),
        },
    }
    args.metadata.parent.mkdir(parents=True, exist_ok=True)
    args.metadata.write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps(metadata["output"], indent=2))


if __name__ == "__main__":
    main()
