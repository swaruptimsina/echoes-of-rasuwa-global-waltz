#!/usr/bin/env python3
"""Calibrate, null-test, and cross-track validate OPERA RTC-S1 change.

The output is a terrain-screened backscatter-change observation, not a flood,
debris-depth, volume, or hazard map.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import rasterio
from PIL import Image
from pyproj import Transformer
from rasterio.enums import Resampling
from rasterio.features import rasterize
from rasterio.warp import reproject
from scipy import ndimage
from shapely.geometry import shape
from shapely.ops import transform as shapely_transform

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.core import (
    apply_mmu,
    binary_metrics,
    confusion_counts,
    nanmedian_filter,
    pixel_area_km2,
    robust_change_score,
    sha256_file,
    slope_degrees,
)

TRACKS = {
    "t019": {
        "burst": "T019_039570_IW1",
        "quiet_pre": "t019_quiet_pre",
        "event_pre": "t019_event_pre",
        "event_post": "t019_event_post",
        "direction": "DESCENDING",
    },
    "t085": {
        "burst": "T085_180590_IW2",
        "quiet_pre": "t085_quiet_pre",
        "event_pre": "t085_event_pre",
        "event_post": "t085_event_post",
        "direction": "ASCENDING",
    },
    "t121": {
        "burst": "T121_258660_IW3",
        "quiet_pre": "t121_quiet_pre",
        "event_pre": "t121_event_pre",
        "event_post": "t121_event_post",
        "direction": "DESCENDING",
    },
}
UNOSAT_LAYER_URL = "https://unosatgis.cern.ch/rapidmapping/rest/services/FL20260826NPL/UNOSAT_Analysis_V2/MapServer/7"


def db_difference(pre_power: np.ndarray, post_power: np.ndarray, valid_mask: np.ndarray) -> np.ndarray:
    """Compute post-minus-pre power change in dB, leaving invalid/nonpositive cells missing."""
    pre = np.asarray(pre_power, dtype="float64")
    post = np.asarray(post_power, dtype="float64")
    valid = np.asarray(valid_mask, dtype=bool) & np.isfinite(pre) & np.isfinite(post) & (pre > 0) & (post > 0)
    output = np.full(pre.shape, np.nan, dtype="float64")
    output[valid] = 10.0 * np.log10(post[valid]) - 10.0 * np.log10(pre[valid])
    return output


def evaluate_change(flags: np.ndarray, observed: np.ndarray, valid: np.ndarray, pixel_area: float) -> dict:
    """Evaluate overlap with an independent reference and report explicit denominators."""
    prediction = np.asarray(flags, dtype=bool)
    reference = np.asarray(observed, dtype=bool)
    evaluation = np.asarray(valid, dtype=bool)
    counts = confusion_counts(prediction, reference, evaluation)
    return {
        "counts": counts,
        **binary_metrics(counts),
        "valid_pixels": int(evaluation.sum()),
        "unusable_pixels": int((~evaluation).sum()),
        "unusable_fraction": float((~evaluation).sum() / evaluation.size),
        "flagged_pixels": int((prediction & evaluation).sum()),
        "flagged_area_km2": float((prediction & evaluation).sum() * pixel_area),
        "observed_valid_pixels": int((reference & evaluation).sum()),
        "observed_valid_area_km2": float((reference & evaluation).sum() * pixel_area),
        "overlap_area_km2": float((prediction & reference & evaluation).sum() * pixel_area),
        "agreement_caveat": "Reference polygon is incomplete event evidence; precision treats all change outside it as false alarm and is therefore conservative.",
    }


def consensus_count(flags: list[np.ndarray], valid: list[np.ndarray]) -> tuple[np.ndarray, np.ndarray]:
    """Count per-pixel detections and valid observations across aligned tracks."""
    if len(flags) != len(valid) or not flags:
        raise ValueError("flags and valid lists must be non-empty and equally long")
    shape0 = flags[0].shape
    if any(array.shape != shape0 for array in [*flags, *valid]):
        raise ValueError("all arrays must have the same shape")
    count = np.zeros(shape0, dtype="uint8")
    observations = np.zeros(shape0, dtype="uint8")
    for track_flags, track_valid in zip(flags, valid):
        valid_bool = np.asarray(track_valid, dtype=bool)
        observations += valid_bool.astype("uint8")
        count += (np.asarray(track_flags, dtype=bool) & valid_bool).astype("uint8")
    return count, observations


def read_layer(path: Path) -> tuple[np.ma.MaskedArray, dict, dict]:
    with rasterio.open(path) as source:
        return source.read(1, masked=True), source.profile.copy(), source.tags()


def write_raster(path: Path, array: np.ndarray, profile: dict, dtype: str, nodata, tags: dict[str, str]) -> dict:
    path.parent.mkdir(parents=True, exist_ok=True)
    output_profile = profile.copy()
    output_profile.update(driver="GTiff", count=1, dtype=dtype, nodata=nodata, compress="DEFLATE", tiled=True)
    if np.dtype(dtype).kind == "f":
        output_profile["predictor"] = 3
    with rasterio.open(path, "w", **output_profile) as destination:
        destination.write(np.asarray(array, dtype=dtype), 1)
        destination.update_tags(**tags)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256_file(path)}


def projected_geometry(geojson_path: Path, target_crs) -> tuple[object, dict]:
    payload = json.loads(geojson_path.read_text())
    if len(payload.get("features", [])) != 1:
        raise RuntimeError("detachment reference must contain exactly one feature")
    feature = payload["features"][0]
    geometry = shape(feature["geometry"])
    transformer = Transformer.from_crs("EPSG:4326", target_crs, always_xy=True)
    return shapely_transform(transformer.transform, geometry), feature.get("properties", {})


def grid_geometry_mask(geometry, profile: dict, all_touched: bool = False) -> np.ndarray:
    return rasterize(
        [(geometry, 1)],
        out_shape=(profile["height"], profile["width"]),
        transform=profile["transform"],
        fill=0,
        all_touched=all_touched,
        dtype="uint8",
    ).astype(bool)


def aligned_dem_and_slope(dem_path: Path, profile: dict) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    dem = np.full((profile["height"], profile["width"]), np.nan, dtype="float32")
    with rasterio.open(dem_path) as source:
        source_data = source.read(1, masked=True)
        reproject(
            source=source_data.filled(source.nodata if source.nodata is not None else -9999.0),
            destination=dem,
            src_transform=source.transform,
            src_crs=source.crs,
            src_nodata=source.nodata,
            dst_transform=profile["transform"],
            dst_crs=profile["crs"],
            dst_nodata=np.nan,
            resampling=Resampling.bilinear,
        )
    dem_valid = np.isfinite(dem)
    slope = np.full(dem.shape, np.nan, dtype="float64")
    filled = dem.astype("float64")
    if not np.all(dem_valid):
        nearest_indices = ndimage.distance_transform_edt(~dem_valid, return_distances=False, return_indices=True)
        filled = filled[tuple(nearest_indices)]
    slope[dem_valid] = slope_degrees(
        filled,
        abs(float(profile["transform"].a)),
        abs(float(profile["transform"].e)),
    )[dem_valid]
    return dem, slope, dem_valid


def mask_counts(array: np.ma.MaskedArray) -> dict[str, int]:
    return {str(key): int(value) for key, value in sorted(Counter(array.compressed().tolist()).items())}


def load_track(input_dir: Path, config: dict) -> tuple[dict[str, dict[str, np.ma.MaskedArray]], dict, dict[str, dict]]:
    arrays: dict[str, dict[str, np.ma.MaskedArray]] = {}
    tags: dict[str, dict] = {}
    reference_profile = None
    for time_label in ("quiet_pre", "event_pre", "event_post"):
        prefix = config[time_label]
        arrays[time_label] = {}
        tags[time_label] = {}
        for layer in ("VV", "VH", "mask"):
            path = input_dir / f"{prefix}_{config['burst']}_{layer}.tif"
            array, profile, layer_tags = read_layer(path)
            arrays[time_label][layer] = array
            tags[time_label][layer] = layer_tags
            signature = (profile["crs"], profile["transform"], profile["height"], profile["width"])
            if reference_profile is None:
                reference_profile = profile
                reference_signature = signature
            elif signature != reference_signature:
                raise RuntimeError(f"grid mismatch for {path}")
    assert reference_profile is not None
    return arrays, reference_profile, tags


def interval_result(
    first: dict[str, np.ma.MaskedArray],
    second: dict[str, np.ma.MaskedArray],
    slope: np.ndarray,
    dem_valid: np.ndarray,
    observed: np.ndarray,
    exclusion: np.ndarray,
    k: float,
    minimum_pixels: int,
    filter_size: int,
    maximum_slope: float,
) -> dict:
    mask_valid = (
        (~np.ma.getmaskarray(first["mask"]))
        & (~np.ma.getmaskarray(second["mask"]))
        & (first["mask"].filled(255) == 0)
        & (second["mask"].filled(255) == 0)
    )
    valid = mask_valid & dem_valid & np.isfinite(slope) & (slope <= maximum_slope)
    changes = {}
    for polarization in ("VV", "VH"):
        raw = db_difference(first[polarization].filled(np.nan), second[polarization].filled(np.nan), valid)
        filtered = nanmedian_filter(raw, size=filter_size)
        filtered[~valid] = np.nan
        changes[polarization] = filtered
    valid &= np.isfinite(changes["VV"]) & np.isfinite(changes["VH"])
    reference = valid & (~exclusion) & (slope >= 5.0) & (slope <= 60.0)
    calibrated = robust_change_score(changes["VV"], changes["VH"], valid, reference)
    raw_flags = valid & (calibrated["score"] >= k)
    flags = apply_mmu(raw_flags, minimum_pixels=minimum_pixels)
    return {
        "valid": valid,
        "reference": reference,
        "vv_change_db": changes["VV"],
        "vh_change_db": changes["VH"],
        "zvv": calibrated["zvv"],
        "zvh": calibrated["zvh"],
        "score": calibrated["score"],
        "flags": flags,
        "raw_flags": raw_flags,
        "calibration": {
            "centers_db": calibrated["centers"],
            "robust_scales_db": calibrated["scales"],
            "reference_pixels": calibrated["reference_count"],
        },
        "observed_score": {
            "median": float(np.nanmedian(calibrated["score"][observed & valid])) if np.any(observed & valid) else None,
            "p90": float(np.nanpercentile(calibrated["score"][observed & valid], 90)) if np.any(observed & valid) else None,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path("data/inputs/opera_rtc"))
    parser.add_argument("--dem", type=Path, default=Path("data/inputs/dem/copernicus_glo30.tif"))
    parser.add_argument("--reference", type=Path, default=Path("data/inputs/validation/unosat_detachment.geojson"))
    parser.add_argument("--output", type=Path, default=Path("data/processed/opera_change"))
    parser.add_argument("--game-output", type=Path, default=Path("game_handoff"))
    parser.add_argument("--k", type=float, default=3.0)
    parser.add_argument("--mmu-pixels", type=int, default=25)
    parser.add_argument("--filter-size", type=int, default=3)
    parser.add_argument("--maximum-slope", type=float, default=70.0)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    args.game_output.mkdir(parents=True, exist_ok=True)

    summary = {
        "method": {
            "observable": "OPERA RTC-S1 VV/VH gamma-0 post-minus-pre dB change",
            "filter": f"{args.filter_size}x{args.filter_size} NaN-aware median",
            "threshold_k_robust_sigma": args.k,
            "minimum_mapping_unit_pixels": args.mmu_pixels,
            "minimum_mapping_unit_km2": None,
            "validity": f"OPERA mask class 0 on both dates; finite positive backscatter; Copernicus DEM; slope <= {args.maximum_slope} degrees",
            "stable_reference": "valid pixels outside a 300 m buffer of the UNOSAT detachment, with slope 5–60 degrees",
            "reference_url": UNOSAT_LAYER_URL,
            "interpretation_limit": "Classification is surface backscatter change, not flood/debris extent, depth, displacement, or hazard.",
        },
        "tracks": {},
        "files": [],
    }
    track_results = {}

    for track, config in TRACKS.items():
        arrays, profile, tags = load_track(args.input, config)
        pixel_area = pixel_area_km2(profile["transform"].a, profile["transform"].e)
        summary["method"]["minimum_mapping_unit_km2"] = args.mmu_pixels * pixel_area
        geometry, properties = projected_geometry(args.reference, profile["crs"])
        observed = grid_geometry_mask(geometry, profile, all_touched=False)
        exclusion = grid_geometry_mask(geometry.buffer(300.0), profile, all_touched=True)
        dem, slope, dem_valid = aligned_dem_and_slope(args.dem, profile)
        event = interval_result(
            arrays["event_pre"], arrays["event_post"], slope, dem_valid, observed, exclusion,
            args.k, args.mmu_pixels, args.filter_size, args.maximum_slope,
        )
        quiet = interval_result(
            arrays["quiet_pre"], arrays["event_pre"], slope, dem_valid, observed, exclusion,
            args.k, args.mmu_pixels, args.filter_size, args.maximum_slope,
        )
        event_metrics = evaluate_change(event["flags"], observed, event["valid"], pixel_area)
        quiet_metrics = evaluate_change(quiet["flags"], observed, quiet["valid"], pixel_area)
        source_products = {
            label: tags[label]["VV"].get("source_product")
            for label in ("quiet_pre", "event_pre", "event_post")
        }
        acquisition_times = {
            label: tags[label]["VV"].get("source_acquisition_utc")
            for label in ("quiet_pre", "event_pre", "event_post")
        }
        track_summary = {
            "burst_id": config["burst"],
            "direction": config["direction"],
            "source_products": source_products,
            "acquisition_utc": acquisition_times,
            "grid": {
                "crs": str(profile["crs"]),
                "shape": [profile["height"], profile["width"]],
                "pixel_area_km2": pixel_area,
            },
            "reference": {
                "properties": properties,
                "polygon_area_km2": float(geometry.area / 1_000_000.0),
                "raster_pixels": int(observed.sum()),
            },
            "mask_class_counts": {
                label: mask_counts(arrays[label]["mask"])
                for label in ("quiet_pre", "event_pre", "event_post")
            },
            "event": {
                "calibration": event["calibration"],
                "observed_score": event["observed_score"],
                "metrics": event_metrics,
            },
            "quiet_null": {
                "calibration": quiet["calibration"],
                "observed_score": quiet["observed_score"],
                "metrics": quiet_metrics,
            },
        }
        summary["tracks"][track] = track_summary
        track_results[track] = {
            "profile": profile,
            "observed": observed,
            "event": event,
            "quiet": quiet,
            "slope": slope,
            "dem": dem,
        }

        common_tags = {
            "provenance_class": "model_output",
            "source_products": " | ".join(value for value in source_products.values() if value),
            "reference_url": UNOSAT_LAYER_URL,
            "threshold_k": str(args.k),
            "mmu_pixels": str(args.mmu_pixels),
            "interpretation_limit": summary["method"]["interpretation_limit"],
        }
        outputs = {
            f"{track}_event_vv_change_db.tif": (np.nan_to_num(event["vv_change_db"], nan=-9999.0), "float32", -9999.0, {**common_tags, "units": "dB"}),
            f"{track}_event_vh_change_db.tif": (np.nan_to_num(event["vh_change_db"], nan=-9999.0), "float32", -9999.0, {**common_tags, "units": "dB"}),
            f"{track}_event_score.tif": (np.nan_to_num(event["score"], nan=-9999.0), "float32", -9999.0, {**common_tags, "units": "robust_sigma_magnitude"}),
            f"{track}_event_change_mask.tif": (event["flags"].astype("uint8"), "uint8", 255, common_tags),
            f"{track}_quiet_change_mask.tif": (quiet["flags"].astype("uint8"), "uint8", 255, common_tags),
            f"{track}_valid_mask.tif": (event["valid"].astype("uint8"), "uint8", 255, {**common_tags, "meaning": "1 valid, 0 unusable"}),
            f"{track}_slope_degrees.tif": (np.nan_to_num(slope, nan=-9999.0), "float32", -9999.0, {**common_tags, "units": "degrees", "source_dem": str(args.dem)}),
            f"{track}_unosat_detachment_reference.tif": (observed.astype("uint8"), "uint8", 255, {"provenance_class": "observation", "source_product": "UNOSAT_Analysis_V2_MapServer_7", "reference_url": UNOSAT_LAYER_URL, "meaning": "1 independent UNOSAT detachment reference, 0 outside"}),
        }
        for filename, (array, dtype, nodata, output_tags) in outputs.items():
            summary["files"].append(write_raster(args.output / filename, array, profile, dtype, nodata, output_tags))

    reference_track = "t019"
    reference_profile = track_results[reference_track]["profile"]
    aligned_event_flags = []
    aligned_quiet_flags = []
    aligned_event_valid = []
    for track, result in track_results.items():
        for key, target in (
            ("event_flags", aligned_event_flags),
            ("quiet_flags", aligned_quiet_flags),
            ("event_valid", aligned_event_valid),
        ):
            if key == "event_flags":
                source_array = result["event"]["flags"].astype("uint8")
            elif key == "quiet_flags":
                source_array = result["quiet"]["flags"].astype("uint8")
            else:
                source_array = result["event"]["valid"].astype("uint8")
            destination = np.zeros((reference_profile["height"], reference_profile["width"]), dtype="uint8")
            reproject(
                source=source_array,
                destination=destination,
                src_transform=result["profile"]["transform"],
                src_crs=result["profile"]["crs"],
                dst_transform=reference_profile["transform"],
                dst_crs=reference_profile["crs"],
                src_nodata=0,
                dst_nodata=0,
                resampling=Resampling.nearest,
            )
            target.append(destination.astype(bool))

    event_count, valid_count = consensus_count(aligned_event_flags, aligned_event_valid)
    quiet_count, _ = consensus_count(aligned_quiet_flags, aligned_event_valid)
    consensus_valid = valid_count >= 2
    event_consensus = consensus_valid & (event_count >= 2)
    quiet_consensus = consensus_valid & (quiet_count >= 2)
    observed_reference = track_results[reference_track]["observed"]
    consensus_pixel_area = pixel_area_km2(reference_profile["transform"].a, reference_profile["transform"].e)
    summary["consensus"] = {
        "rule": "changed in at least 2 of 3 Sentinel-1D relative-orbit views and valid in at least 2 views",
        "event": evaluate_change(event_consensus, observed_reference, consensus_valid, consensus_pixel_area),
        "quiet_null": evaluate_change(quiet_consensus, observed_reference, consensus_valid, consensus_pixel_area),
    }
    all_source_products = sorted({
        product_id
        for track in TRACKS
        for product_id in summary["tracks"][track]["source_products"].values()
        if product_id
    })
    consensus_tags = {
        "provenance_class": "model_output",
        "source_products": " | ".join(all_source_products),
        "rule": summary["consensus"]["rule"],
        "reference_url": UNOSAT_LAYER_URL,
        "threshold_k": str(args.k),
        "mmu_pixels_per_track": str(args.mmu_pixels),
        "interpretation_limit": summary["method"]["interpretation_limit"],
    }
    for filename, array, meaning in (
        ("consensus_event_change_mask.tif", event_consensus.astype("uint8"), "1 changed, 0 not changed/insufficient consensus"),
        ("consensus_quiet_change_mask.tif", quiet_consensus.astype("uint8"), "1 changed during pre-event null interval"),
        ("consensus_event_track_count.tif", event_count, "number of tracks flagging change"),
        ("consensus_valid_track_count.tif", valid_count, "number of geometrically valid tracks"),
    ):
        summary["files"].append(write_raster(args.output / filename, array, reference_profile, "uint8", 255, {**consensus_tags, "meaning": meaning}))

    sensitivity_rows = []
    for threshold in (2.5, 3.0, 3.5, 4.0):
        flags_for_threshold = []
        valid_for_threshold = []
        quiet_for_threshold = []
        for track, result in track_results.items():
            event_flags = apply_mmu(result["event"]["valid"] & (result["event"]["score"] >= threshold), args.mmu_pixels)
            quiet_flags = apply_mmu(result["quiet"]["valid"] & (result["quiet"]["score"] >= threshold), args.mmu_pixels)
            for source_array, destination_list in ((event_flags, flags_for_threshold), (quiet_flags, quiet_for_threshold), (result["event"]["valid"], valid_for_threshold)):
                destination = np.zeros((reference_profile["height"], reference_profile["width"]), dtype="uint8")
                reproject(
                    source=source_array.astype("uint8"), destination=destination,
                    src_transform=result["profile"]["transform"], src_crs=result["profile"]["crs"],
                    dst_transform=reference_profile["transform"], dst_crs=reference_profile["crs"],
                    resampling=Resampling.nearest,
                )
                destination_list.append(destination.astype(bool))
        threshold_count, threshold_valid_count = consensus_count(flags_for_threshold, valid_for_threshold)
        threshold_quiet_count, _ = consensus_count(quiet_for_threshold, valid_for_threshold)
        threshold_valid = threshold_valid_count >= 2
        threshold_flags = threshold_valid & (threshold_count >= 2)
        threshold_quiet = threshold_valid & (threshold_quiet_count >= 2)
        event_evaluation = evaluate_change(threshold_flags, observed_reference, threshold_valid, consensus_pixel_area)
        quiet_evaluation = evaluate_change(threshold_quiet, observed_reference, threshold_valid, consensus_pixel_area)
        sensitivity_rows.append({
            "k": threshold,
            "event_flagged_area_km2": event_evaluation["flagged_area_km2"],
            "event_overlap_area_km2": event_evaluation["overlap_area_km2"],
            "event_reference_recall": event_evaluation["recall"],
            "event_outside_false_positive_rate": event_evaluation["false_positive_rate"],
            "quiet_flagged_area_km2": quiet_evaluation["flagged_area_km2"],
            "quiet_reference_recall": quiet_evaluation["recall"],
            "quiet_outside_false_positive_rate": quiet_evaluation["false_positive_rate"],
        })
    sensitivity_path = args.output / "threshold_sensitivity.csv"
    with sensitivity_path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(sensitivity_rows[0]))
        writer.writeheader()
        writer.writerows(sensitivity_rows)
    summary["files"].append({"path": str(sensitivity_path), "bytes": sensitivity_path.stat().st_size, "sha256": sha256_file(sensitivity_path)})
    summary["threshold_sensitivity"] = sensitivity_rows

    figure_path = args.output / "opera_change_validation.png"
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5), constrained_layout=True)
    score = track_results[reference_track]["event"]["score"]
    score_image = axes[0].imshow(np.ma.masked_invalid(score), cmap="magma", vmin=0, vmax=6)
    axes[0].contour(observed_reference, levels=[0.5], colors="cyan", linewidths=1.1)
    axes[0].set_title("Track 19 event score\ncyan: UNOSAT detachment")
    fig.colorbar(score_image, ax=axes[0], shrink=0.8, label="robust σ magnitude")
    axes[1].imshow(event_consensus, cmap="Reds", vmin=0, vmax=1)
    axes[1].contour(observed_reference, levels=[0.5], colors="cyan", linewidths=1.1)
    axes[1].set_title("≥2-track event consensus")
    axes[2].imshow(quiet_consensus, cmap="Blues", vmin=0, vmax=1)
    axes[2].contour(observed_reference, levels=[0.5], colors="cyan", linewidths=1.1)
    axes[2].set_title("≥2-track quiet null")
    for axis in axes:
        axis.set_axis_off()
    fig.suptitle("OPERA RTC-S1 calibrated surface-change validation (not flood extent)")
    fig.savefig(figure_path, dpi=180)
    plt.close(fig)
    summary["files"].append({"path": str(figure_path), "bytes": figure_path.stat().st_size, "sha256": sha256_file(figure_path)})

    rgba = np.zeros((*event_consensus.shape, 4), dtype="uint8")
    rgba[event_consensus] = (255, 74, 48, 190)
    rgba[observed_reference & ~event_consensus] = (255, 210, 0, 110)
    png_path = args.game_output / "sar_change_overlay.png"
    webp_path = args.game_output / "sar_change_overlay.webp"
    Image.fromarray(rgba, mode="RGBA").save(png_path, optimize=True)
    Image.fromarray(rgba, mode="RGBA").save(webp_path, format="WEBP", lossless=True)
    handoff_metadata = {
        "asset": png_path.name,
        "alternate_asset": webp_path.name,
        "provenance_label": "model output",
        "observable": "OPERA RTC-S1 calibrated VV/VH backscatter change consensus",
        "bounds_crs": str(reference_profile["crs"]),
        "bounds": list(rasterio.transform.array_bounds(reference_profile["height"], reference_profile["width"], reference_profile["transform"])),
        "pixel_size_m": [abs(reference_profile["transform"].a), abs(reference_profile["transform"].e)],
        "legend": {"red": "changed in at least 2 valid radar views", "yellow": "UNOSAT detachment not flagged by consensus", "transparent": "not flagged or unusable"},
        "parameters": summary["method"],
        "source_products": {track: summary["tracks"][track]["source_products"] for track in TRACKS},
        "reference_url": UNOSAT_LAYER_URL,
        "limitations": summary["method"]["interpretation_limit"],
    }
    handoff_metadata_path = args.game_output / "sar_change_overlay.provenance.json"
    handoff_metadata_path.write_text(json.dumps(handoff_metadata, indent=2) + "\n")
    for path in (png_path, webp_path, handoff_metadata_path):
        summary["files"].append({"path": str(path), "bytes": path.stat().st_size, "sha256": sha256_file(path)})

    summary_path = args.output / "analysis_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({
        "summary": str(summary_path),
        "consensus_event": summary["consensus"]["event"],
        "consensus_quiet_null": summary["consensus"]["quiet_null"],
    }, indent=2))


if __name__ == "__main__":
    main()
