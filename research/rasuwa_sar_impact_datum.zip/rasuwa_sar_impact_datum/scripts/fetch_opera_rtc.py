#!/usr/bin/env python3
"""Fetch a three-track OPERA RTC-S1 time series as small authenticated COG crops.

Credentials are read only through earthaccess/netrc. Signed URLs are never saved.
"""
from __future__ import annotations

import argparse
import json
import sys
import urllib.parse
import urllib.request
from pathlib import Path
from urllib.parse import urlsplit

import earthaccess
import numpy as np
import rasterio
from rasterio.warp import transform_bounds
from rasterio.windows import from_bounds

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.core import sha256_file

ASF_QUERY = "https://api.daac.asf.alaska.edu/services/search/param"
DEFAULT_AOI = (85.35, 28.24, 85.56, 28.32)
PRODUCT_SPECS = {
    "t019_quiet_pre": ("T019_039570_IW1", "2026-08-12"),
    "t019_event_pre": ("T019_039570_IW1", "2026-08-24"),
    "t019_event_post": ("T019_039570_IW1", "2026-09-05"),
    "t085_quiet_pre": ("T085_180590_IW2", "2026-08-04"),
    "t085_event_pre": ("T085_180590_IW2", "2026-08-16"),
    "t085_event_post": ("T085_180590_IW2", "2026-08-28"),
    "t121_quiet_pre": ("T121_258660_IW3", "2026-08-07"),
    "t121_event_pre": ("T121_258660_IW3", "2026-08-19"),
    "t121_event_post": ("T121_258660_IW3", "2026-08-31"),
}
LAYERS = ("VV", "VH", "mask")


def select_opera_products(features: list[dict], specs: dict[str, tuple[str, str]]) -> dict[str, dict]:
    """Select exactly one catalog product for each burst/date specification."""
    selected: dict[str, dict] = {}
    for label, (burst, date) in specs.items():
        matches = [
            feature["properties"]
            for feature in features
            if feature.get("properties", {}).get("operaBurstID") == burst
            and str(feature["properties"].get("startTime", "")).startswith(date)
        ]
        if len(matches) != 1:
            raise RuntimeError(f"{label}: expected exactly one {burst} product on {date}, found {len(matches)}")
        selected[label] = matches[0]
    return selected


def layer_url(product: dict, layer: str) -> str:
    """Return the unique HTTPS TIFF URL for one OPERA layer."""
    suffix = f"_{layer}.tif"
    matches = [
        url for url in product.get("additionalUrls", [])
        if url.startswith(("http://", "https://")) and url.endswith(suffix)
    ]
    if len(matches) != 1:
        raise RuntimeError(f"{product.get('fileID', '<unknown>')} {layer}: expected exactly one TIFF URL, found {len(matches)}")
    return matches[0]


def public_path(url: str) -> str:
    """Strip query strings so temporary signed credentials cannot enter logs."""
    parsed = urlsplit(url)
    return f"{parsed.scheme}://{parsed.netloc}{parsed.path}"


def fetch_catalog(path: Path) -> str:
    """Fetch the public ASF OPERA catalog response and return the exact query URL."""
    parameters = {
        "dataset": "OPERA-S1",
        "processingLevel": "RTC",
        "intersectsWith": "POINT(85.528066 28.291242)",
        "start": "2026-07-15T00:00:00Z",
        "end": "2026-10-15T23:59:59Z",
        "maxResults": "500",
        "output": "geojson",
    }
    query_url = f"{ASF_QUERY}?{urllib.parse.urlencode(parameters)}"
    request = urllib.request.Request(query_url, headers={"User-Agent": "rasuwa-sar-research/1.0"})
    with urllib.request.urlopen(request, timeout=120) as response:
        payload = response.read()
    parsed = json.loads(payload)
    if not isinstance(parsed.get("features"), list):
        raise RuntimeError("ASF response has no feature list")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    return query_url


def resolve_signed_url(session, url: str) -> str:
    """Follow the Earthdata redirect without exposing its signed query string."""
    response = session.get(url, headers={"Range": "bytes=0-0"}, stream=True, timeout=120)
    response.raise_for_status()
    final_url = response.url
    response.close()
    return final_url


def crop_layer(session, url: str, bbox: tuple[float, float, float, float]) -> tuple[np.ma.MaskedArray, dict, dict]:
    """Read only the requested WGS84 bbox from a protected cloud-optimized GeoTIFF."""
    signed_url = resolve_signed_url(session, url)
    with rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN="EMPTY_DIR", CPL_VSIL_CURL_ALLOWED_EXTENSIONS=".tif"):
        with rasterio.open(signed_url) as source:
            projected = transform_bounds("EPSG:4326", source.crs, *bbox, densify_pts=21)
            intersection = (
                max(projected[0], source.bounds.left),
                max(projected[1], source.bounds.bottom),
                min(projected[2], source.bounds.right),
                min(projected[3], source.bounds.top),
            )
            if intersection[0] >= intersection[2] or intersection[1] >= intersection[3]:
                raise RuntimeError(f"AOI does not intersect {public_path(url)}")
            window = from_bounds(*intersection, transform=source.transform).round_offsets().round_lengths()
            array = source.read(1, window=window, masked=True)
            profile = source.profile.copy()
            profile.update(
                driver="GTiff",
                count=1,
                height=array.shape[0],
                width=array.shape[1],
                transform=source.window_transform(window),
                compress="DEFLATE",
                tiled=True,
                blockxsize=256,
                blockysize=256,
            )
            metadata = {
                "source_url": public_path(url),
                "resolved_host_path": public_path(signed_url),
                "source_crs": str(source.crs),
                "source_shape": [source.height, source.width],
                "source_bounds": list(source.bounds),
                "crop_shape": list(array.shape),
            }
    return array, profile, metadata


def write_crop(path: Path, array: np.ma.MaskedArray, profile: dict, tags: dict[str, str]) -> None:
    """Write one compressed crop with explicit source tags."""
    path.parent.mkdir(parents=True, exist_ok=True)
    output_profile = profile.copy()
    nodata = output_profile.get("nodata")
    if nodata is None:
        nodata = 255 if np.issubdtype(array.dtype, np.integer) else -9999.0
        output_profile["nodata"] = nodata
    if np.issubdtype(array.dtype, np.floating):
        output_profile["predictor"] = 3
    with rasterio.open(path, "w", **output_profile) as destination:
        destination.write(array.filled(nodata), 1)
        destination.update_tags(**tags)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", type=Path, default=Path("data/raw/asf_opera_rtc.json"))
    parser.add_argument("--output", type=Path, default=Path("data/inputs/opera_rtc"))
    parser.add_argument("--metadata", type=Path, default=Path("data/raw/opera_rtc_fetch.json"))
    parser.add_argument("--bbox", type=float, nargs=4, default=DEFAULT_AOI, metavar=("W", "S", "E", "N"))
    parser.add_argument("--reuse-catalog", action="store_true")
    args = parser.parse_args()

    if args.reuse_catalog and args.catalog.exists():
        query_url = None
    else:
        query_url = fetch_catalog(args.catalog)
    catalog = json.loads(args.catalog.read_text())
    products = select_opera_products(catalog["features"], PRODUCT_SPECS)

    auth = earthaccess.login(strategy="netrc")
    if not auth.authenticated:
        raise RuntimeError("Earthdata Login authentication failed; configure ~/.netrc without copying credentials into this project")
    session = auth.get_session()
    bbox = tuple(float(value) for value in args.bbox)
    result = {
        "catalog_query_url": query_url,
        "catalog_path": str(args.catalog),
        "bbox_wsen": list(bbox),
        "authentication": "Earthdata Login via netrc; no secrets stored",
        "products": {},
        "files": [],
    }

    for label, product in products.items():
        burst = product["operaBurstID"]
        product_record = {
            "file_id": product["fileID"],
            "acquisition_utc": product["startTime"],
            "burst_id": burst,
            "track": product.get("pathNumber"),
            "direction": product.get("flightDirection"),
            "platform": product.get("platform"),
            "product_version": product.get("productVersion"),
            "pge_version": product.get("pgeVersion"),
            "layers": {},
        }
        for layer in LAYERS:
            source_url = layer_url(product, layer)
            array, profile, metadata = crop_layer(session, source_url, bbox)
            output_path = args.output / f"{label}_{burst}_{layer}.tif"
            write_crop(
                output_path,
                array,
                profile,
                {
                    "source_product": product["fileID"],
                    "source_acquisition_utc": product["startTime"],
                    "source_url": public_path(source_url),
                    "subset_bbox_wsen": ",".join(str(value) for value in bbox),
                    "provenance_class": "observation",
                },
            )
            file_record = {
                "path": str(output_path),
                "bytes": output_path.stat().st_size,
                "sha256": sha256_file(output_path),
                **metadata,
            }
            product_record["layers"][layer] = file_record
            result["files"].append(file_record)
        result["products"][label] = product_record

    args.metadata.parent.mkdir(parents=True, exist_ok=True)
    args.metadata.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"products": len(result["products"]), "files": len(result["files"]), "metadata": str(args.metadata)}, indent=2))


if __name__ == "__main__":
    main()
