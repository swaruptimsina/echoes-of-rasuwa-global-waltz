#!/usr/bin/env python3
"""Query CMR for SAR acquisitions over the verified Rasuwa source AOI."""
from __future__ import annotations

import argparse
import csv
import json
import sys
import urllib.parse
import urllib.request
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.catalog import dswx_event_gap, parse_utc
from scripts.core import latency_days, sha256_file

CMR = "https://cmr.earthdata.nasa.gov/search/granules.umm_json"
BBOX = "85.34,28.23,85.55,28.32"
WINDOW = "2026-07-01T00:00:00Z,2026-10-15T23:59:59Z"
EVENT = datetime(2026, 8, 26, 2, 52, 10, tzinfo=timezone.utc)
QUERY_SPECS = [
    ("Sentinel-1", "C4175278193-ASF", "SENTINEL-1D_SLC", None),
    ("NISAR", "C2853145197-ASF", "NISAR_L1_RSLC_PROVISIONAL_V1", None),
    ("NISAR", None, "NISAR_L2_GCOV_PROVISIONAL_V1", None),
    ("NISAR", None, "NISAR_L2_GUNW_PROVISIONAL_V1", None),
    ("NISAR", None, "NISAR_L2_GOFF_PROVISIONAL_V1", None),
    ("NISAR urgent response", "C2887502657-ASF", "NISAR_UR_L2_GUNW", ("PRODUCT_TYPE", "GUNW")),
    ("NISAR urgent response", "C2887502657-ASF", "NISAR_UR_L2_GOFF", ("PRODUCT_TYPE", "GOFF")),
    ("OPERA", "C2777436413-ASF", "OPERA_L2_RTC-S1_V1", None),
    ("OPERA", "C2949811996-POCLOUD", "OPERA_L3_DSWX-S1_V1", None),
    ("ALOS-2", "C3315903479-ASF", "ALOS2_L1_PSR2", None),
    ("SAOCOM", "C3571117379-ESA", "SAOCOM.data.products", None),
    ("RCM", "C2204659595-CCMEO", "CWIC_REG_RCM", None),
]


def first_attribute(attributes: dict[str, list[str]], names: tuple[str, ...]) -> str | None:
    for name in names:
        values = attributes.get(name)
        if values:
            return str(values[0])
    return None


def normalize_cmr_item(item: dict, mission: str, collection_id: str | None, short_name: str) -> dict[str, str | None]:
    """Normalize exact CMR identifiers and acquisition metadata without repairing values."""
    umm = item["umm"]
    meta = item["meta"]
    temporal = umm.get("TemporalExtent", {}).get("RangeDateTime", {})
    attributes = {
        entry.get("Name", ""): [str(value) for value in entry.get("Values", [])]
        for entry in umm.get("AdditionalAttributes", [])
    }
    provider_dates = {entry.get("Type"): entry.get("Date") for entry in umm.get("ProviderDates", [])}
    orbits = umm.get("OrbitCalculatedSpatialDomains", [])
    platforms = "|".join(str(entry.get("ShortName")) for entry in umm.get("Platforms", []) if entry.get("ShortName"))
    return {
        "mission": mission,
        "collection_concept_id": collection_id,
        "collection_short_name": short_name,
        "producer_granule_id": umm.get("GranuleUR"),
        "granule_concept_id": meta.get("concept-id"),
        "begin_datetime": temporal.get("BeginningDateTime"),
        "end_datetime": temporal.get("EndingDateTime"),
        "provider_insert_datetime": provider_dates.get("Insert"),
        "revision_datetime": meta.get("revision-date"),
        "platforms": platforms or None,
        "orbit_number": str(orbits[0].get("OrbitNumber")) if orbits and orbits[0].get("OrbitNumber") is not None else first_attribute(attributes, ("ABSOLUTE_ORBIT_NUMBER", "ORBIT_NUMBER")),
        "track_path": first_attribute(attributes, ("PATH_NUMBER", "TRACK_NUMBER", "RELATIVE_ORBIT_NUMBER")),
        "frame": first_attribute(attributes, ("FRAME_NUMBER", "FRAME")),
        "direction": first_attribute(attributes, ("ASCENDING_DESCENDING", "FLIGHT_DIRECTION", "DIRECTION")),
    }


def query_url(collection_id: str | None, short_name: str, attribute: tuple[str, str] | None, temporal: str | None = WINDOW, page_size: int = 2000, descending: bool = False) -> str:
    parameters: list[tuple[str, str]] = [("bounding_box", BBOX)]
    if collection_id:
        parameters.append(("collection_concept_id", collection_id))
    else:
        parameters.append(("short_name", short_name))
    if temporal:
        parameters.append(("temporal", temporal))
    parameters.extend([("page_size", str(page_size)), ("sort_key", "-start_date" if descending else "start_date")])
    if attribute:
        parameters.append(("attribute[]", f"string,{attribute[0]},{attribute[1]}"))
    return f"{CMR}?{urllib.parse.urlencode(parameters)}"


def fetch(url: str, path: Path) -> tuple[dict, int]:
    request = urllib.request.Request(url, headers={"User-Agent": "rasuwa-sar-research/1.0", "Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=180) as response:
        body = response.read()
        count = int(response.headers.get("CMR-Hits", "0"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(body)
    return json.loads(body), count


def classify_row(row: dict) -> str:
    begin = parse_utc(row["begin_datetime"])
    end = parse_utc(row["end_datetime"] or row["begin_datetime"])
    if begin < EVENT < end and (end - begin).total_seconds() > 86400:
        return "spans_event"
    return "pre_event" if begin < EVENT else "post_event"


def dswx_gap_from_payloads(pre_payload: dict, post_payload: dict) -> dict:
    """Compute the event catalog gap from explicit pre/post DSWx history queries."""
    times = []
    for payload in (pre_payload, post_payload):
        for item in payload.get("items", []):
            times.append(item["umm"]["TemporalExtent"]["RangeDateTime"]["BeginningDateTime"])
    return dswx_event_gap(times, EVENT)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw", type=Path, default=Path("data/raw/acquisitions"))
    parser.add_argument("--timeline", type=Path, default=Path("data/acquisition_timeline.csv"))
    parser.add_argument("--summary", type=Path, default=Path("data/acquisition_timeline_summary.json"))
    args = parser.parse_args()
    rows = []
    queries = []
    for mission, collection_id, short_name, attribute in QUERY_SPECS:
        slug = short_name.replace("/", "_").replace(".", "_")
        url = query_url(collection_id, short_name, attribute)
        payload, hits = fetch(url, args.raw / f"{slug}.json")
        items = payload.get("items", [])
        if len(items) != hits:
            raise RuntimeError(f"{short_name}: CMR-Hits {hits} but response has {len(items)} items")
        for item in items:
            row = normalize_cmr_item(item, mission, collection_id, short_name)
            row["event_role"] = classify_row(row)
            begin = parse_utc(row["begin_datetime"])
            row["acquisition_offset_days"] = latency_days(begin, EVENT)
            row["archive_latency_days"] = (
                latency_days(parse_utc(row["provider_insert_datetime"]), begin)
                if row["provider_insert_datetime"] else None
            )
            row["event_to_archive_days"] = (
                latency_days(parse_utc(row["provider_insert_datetime"]), EVENT)
                if row["provider_insert_datetime"] else None
            )
            row["query_url"] = url
            rows.append(row)
        queries.append({"mission": mission, "short_name": short_name, "url": url, "count": hits})

    alos_context_url = query_url("C3315903479-ASF", "ALOS2_L1_PSR2", None, temporal=None, page_size=5, descending=True)
    alos_payload, alos_hits = fetch(alos_context_url, args.raw / "ALOS2_L1_PSR2_latest_context.json")
    alos_context = [normalize_cmr_item(item, "ALOS-2", "C3315903479-ASF", "ALOS2_L1_PSR2") for item in alos_payload.get("items", [])]

    rows.sort(key=lambda row: (parse_utc(row["begin_datetime"]), str(row["mission"]), str(row["producer_granule_id"])))
    fieldnames = [
        "mission", "collection_concept_id", "collection_short_name", "producer_granule_id", "granule_concept_id",
        "begin_datetime", "end_datetime", "event_role", "acquisition_offset_days", "provider_insert_datetime",
        "archive_latency_days", "event_to_archive_days", "revision_datetime", "platforms", "orbit_number", "track_path", "frame", "direction", "query_url",
    ]
    args.timeline.parent.mkdir(parents=True, exist_ok=True)
    with args.timeline.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    nearest = {}
    for mission in sorted({str(row["mission"]) for row in rows}):
        mission_rows = [row for row in rows if row["mission"] == mission]
        pre = [row for row in mission_rows if row["event_role"] == "pre_event"]
        post = [row for row in mission_rows if row["event_role"] == "post_event"]
        nearest[mission] = {
            "nearest_pre": max(pre, key=lambda row: parse_utc(row["begin_datetime"])) if pre else None,
            "nearest_post": min(post, key=lambda row: parse_utc(row["begin_datetime"])) if post else None,
            "spanning_count": sum(row["event_role"] == "spans_event" for row in mission_rows),
        }
    dswx_pre_url = query_url(
        "C2949811996-POCLOUD", "OPERA_L3_DSWX-S1_V1", None,
        temporal="2024-09-01T00:00:00Z,2026-08-26T02:52:10Z", page_size=500,
    )
    dswx_post_url = query_url(
        "C2949811996-POCLOUD", "OPERA_L3_DSWX-S1_V1", None,
        temporal="2026-08-26T02:52:10Z,2026-10-25T23:59:59Z", page_size=500,
    )
    dswx_pre_payload, dswx_pre_hits = fetch(dswx_pre_url, args.raw / "OPERA_L3_DSWX-S1_V1_pre_history.json")
    dswx_post_payload, dswx_post_hits = fetch(dswx_post_url, args.raw / "OPERA_L3_DSWX-S1_V1_post_history.json")
    dswx_gap = dswx_gap_from_payloads(dswx_pre_payload, dswx_post_payload)
    summary = {
        "retrieved_utc": datetime.now(timezone.utc).isoformat(),
        "event_utc": EVENT.isoformat().replace("+00:00", "Z"),
        "aoi_bbox_wsen": [float(value) for value in BBOX.split(",")],
        "row_count": len(rows),
        "unique_granule_concept_ids": len({row["granule_concept_id"] for row in rows}),
        "counts_by_collection": dict(Counter(row["collection_short_name"] for row in rows)),
        "queries": queries,
        "nearest_by_mission": nearest,
        "dswx_event_gap": {
            **dswx_gap,
            "pre_history_query_url": dswx_pre_url,
            "pre_history_count": dswx_pre_hits,
            "post_history_query_url": dswx_post_url,
            "post_history_count": dswx_post_hits,
        },
        "alos2_aoi_total_hits_all_time": alos_hits,
        "alos2_latest_five": alos_context,
        "timeline": {"path": str(args.timeline), "bytes": args.timeline.stat().st_size, "sha256": sha256_file(args.timeline)},
        "caveat": "Catalog presence establishes acquisition/product availability, not usability in steep terrain or operational delivery time.",
    }
    args.summary.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({
        "row_count": summary["row_count"],
        "counts_by_collection": summary["counts_by_collection"],
        "dswx_event_gap": summary["dswx_event_gap"],
        "alos2_latest": alos_context[0] if alos_context else None,
    }, indent=2))


if __name__ == "__main__":
    main()
