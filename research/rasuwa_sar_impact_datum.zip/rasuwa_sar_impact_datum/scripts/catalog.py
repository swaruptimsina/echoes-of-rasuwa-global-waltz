"""Pure catalog/timeline logic shared by live query scripts."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Iterable


def parse_utc(value: str | datetime) -> datetime:
    if isinstance(value, datetime):
        parsed = value
    else:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def classify_timeline(records: Iterable[dict], event: datetime) -> dict[str, str]:
    """Classify records relative to an event without inventing acquisition times."""
    event = parse_utc(event)
    materialized = list(records)
    roles: dict[str, str] = {}
    simple_pre: list[tuple[datetime, str]] = []
    simple_post: list[tuple[datetime, str]] = []
    for record in materialized:
        record_id = str(record["id"])
        begin = parse_utc(record["begin"])
        secondary = record.get("secondary_begin")
        if secondary is not None and begin < event < parse_utc(secondary):
            roles[record_id] = "spans_event"
        elif begin < event:
            roles[record_id] = "other_pre"
            simple_pre.append((begin, record_id))
        else:
            roles[record_id] = "other_post"
            simple_post.append((begin, record_id))
    if simple_pre:
        roles[max(simple_pre)[1]] = "nearest_pre"
    if simple_post:
        roles[min(simple_post)[1]] = "nearest_post"
    return roles


def same_geometry_pairs(
    records: Iterable[dict],
    repeat_days: float,
    tolerance_seconds: float = 2.0,
) -> list[dict]:
    """Return pairs matching track and direction at a declared repeat interval."""
    rows = sorted(list(records), key=lambda row: parse_utc(row["begin"]))
    target_seconds = repeat_days * 86400.0
    pairs: list[dict] = []
    for index, pre in enumerate(rows):
        pre_time = parse_utc(pre["begin"])
        for post in rows[index + 1 :]:
            if pre.get("track") != post.get("track") or pre.get("direction") != post.get("direction"):
                continue
            post_time = parse_utc(post["begin"])
            elapsed = (post_time - pre_time).total_seconds()
            if abs(elapsed - target_seconds) <= tolerance_seconds:
                pairs.append(
                    {
                        "pre_id": str(pre["id"]),
                        "post_id": str(post["id"]),
                        "track": pre.get("track"),
                        "direction": pre.get("direction"),
                        "pre_begin": pre_time.isoformat().replace("+00:00", "Z"),
                        "post_begin": post_time.isoformat().replace("+00:00", "Z"),
                        "repeat_days": elapsed / 86400.0,
                    }
                )
    return pairs


def dswx_event_gap(
    acquisition_times: Iterable[str | datetime],
    event: datetime,
    before_days: float = 25.0,
    after_days: float = 16.0,
) -> dict:
    """Summarize the DSWx catalog gap around the event marker."""
    event = parse_utc(event)
    times = sorted(parse_utc(value) for value in acquisition_times)
    pre = [value for value in times if value < event]
    post = [value for value in times if value >= event]
    latest_pre = max(pre) if pre else None
    first_post = min(post) if post else None
    start = event - timedelta(days=before_days)
    end = event + timedelta(days=after_days)
    in_window = [value for value in times if start <= value <= end]
    return {
        "window_start": start.isoformat().replace("+00:00", "Z"),
        "window_end": end.isoformat().replace("+00:00", "Z"),
        "event_window_count": len(in_window),
        "latest_pre": latest_pre.isoformat().replace("+00:00", "Z") if latest_pre else None,
        "first_post": first_post.isoformat().replace("+00:00", "Z") if first_post else None,
        "gap_days": (
            (first_post - latest_pre).total_seconds() / 86400.0
            if latest_pre is not None and first_post is not None
            else None
        ),
    }
