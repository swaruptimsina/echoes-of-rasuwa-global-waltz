"""Small, testable numerical and provenance helpers."""
from __future__ import annotations

import hashlib
from datetime import datetime
from pathlib import Path

import numpy as np
from scipy import ndimage

MAD_TO_SIGMA = 1.4826


def robust_location_scale(values: np.ndarray) -> tuple[float, float]:
    """Return finite-value median and Gaussian-equivalent MAD scale."""
    finite = np.asarray(values, dtype="float64")
    finite = finite[np.isfinite(finite)]
    if finite.size == 0:
        raise ValueError("reference contains no finite values")
    center = float(np.median(finite))
    scale = float(MAD_TO_SIGMA * np.median(np.abs(finite - center)))
    if not np.isfinite(scale) or scale <= 0.0:
        raise ValueError("reference has zero robust scale")
    return center, scale


def robust_change_score(
    vv_change_db: np.ndarray,
    vh_change_db: np.ndarray,
    valid_mask: np.ndarray,
    reference_mask: np.ndarray,
) -> dict:
    """Calibrate VV/VH changes on a stable reference and return robust z-score magnitude."""
    vv = np.asarray(vv_change_db, dtype="float64")
    vh = np.asarray(vh_change_db, dtype="float64")
    valid = np.asarray(valid_mask, dtype=bool)
    reference = np.asarray(reference_mask, dtype=bool)
    if vv.shape != vh.shape or vv.shape != valid.shape or vv.shape != reference.shape:
        raise ValueError("all arrays must have the same shape")
    reference = reference & valid & np.isfinite(vv) & np.isfinite(vh)
    vv_center, vv_scale = robust_location_scale(vv[reference])
    vh_center, vh_scale = robust_location_scale(vh[reference])
    zvv = np.full(vv.shape, np.nan, dtype="float64")
    zvh = np.full(vh.shape, np.nan, dtype="float64")
    output_valid = valid & np.isfinite(vv) & np.isfinite(vh)
    zvv[output_valid] = (vv[output_valid] - vv_center) / vv_scale
    zvh[output_valid] = (vh[output_valid] - vh_center) / vh_scale
    score = np.full(vv.shape, np.nan, dtype="float64")
    score[output_valid] = np.sqrt((zvv[output_valid] ** 2 + zvh[output_valid] ** 2) / 2.0)
    return {
        "zvv": zvv,
        "zvh": zvh,
        "score": score,
        "centers": {"vv": vv_center, "vh": vh_center},
        "scales": {"vv": vv_scale, "vh": vh_scale},
        "reference_count": int(reference.sum()),
        "valid_count": int(output_valid.sum()),
    }


def apply_mmu(flags: np.ndarray, minimum_pixels: int) -> np.ndarray:
    """Keep only 8-connected True components meeting a minimum mapping unit."""
    mask = np.asarray(flags, dtype=bool)
    if minimum_pixels < 1:
        raise ValueError("minimum_pixels must be at least one")
    labels, component_count = ndimage.label(mask, structure=np.ones((3, 3), dtype=np.uint8))
    if component_count == 0:
        return np.zeros_like(mask)
    sizes = np.bincount(labels.ravel())
    keep = sizes >= minimum_pixels
    keep[0] = False
    return keep[labels]


def confusion_counts(predicted: np.ndarray, observed: np.ndarray, evaluate: np.ndarray) -> dict[str, int]:
    """Return binary confusion counts inside an explicit evaluation mask."""
    pred = np.asarray(predicted, dtype=bool)
    obs = np.asarray(observed, dtype=bool)
    mask = np.asarray(evaluate, dtype=bool)
    if pred.shape != obs.shape or pred.shape != mask.shape:
        raise ValueError("all arrays must have the same shape")
    return {
        "tp": int(np.sum(mask & pred & obs)),
        "fp": int(np.sum(mask & pred & ~obs)),
        "fn": int(np.sum(mask & ~pred & obs)),
        "tn": int(np.sum(mask & ~pred & ~obs)),
    }


def binary_metrics(counts: dict[str, int]) -> dict[str, float | None]:
    """Derive precision, recall, IoU and false-positive rate without zero division."""
    tp, fp, fn, tn = (int(counts[key]) for key in ("tp", "fp", "fn", "tn"))

    def ratio(numerator: int, denominator: int) -> float | None:
        return numerator / denominator if denominator else None

    return {
        "precision": ratio(tp, tp + fp),
        "recall": ratio(tp, tp + fn),
        "iou": ratio(tp, tp + fp + fn),
        "false_positive_rate": ratio(fp, fp + tn),
        "specificity": ratio(tn, tn + fp),
    }


def nanmedian_filter(values: np.ndarray, size: int = 3) -> np.ndarray:
    """Median-filter a floating grid while treating non-finite samples as missing."""
    data = np.asarray(values, dtype="float64")
    if size < 1 or size % 2 == 0:
        raise ValueError("size must be a positive odd integer")

    def finite_median(window: np.ndarray) -> float:
        finite = window[np.isfinite(window)]
        return float(np.median(finite)) if finite.size else np.nan

    return ndimage.generic_filter(data, finite_median, size=size, mode="constant", cval=np.nan)


def pixel_area_km2(x_resolution: float, y_resolution: float) -> float:
    """Return projected pixel area in square kilometres."""
    return abs(float(x_resolution) * float(y_resolution)) / 1_000_000.0


def slope_degrees(dem: np.ndarray, x_resolution: float, y_resolution: float) -> np.ndarray:
    """Compute planar slope in degrees from a projected elevation grid."""
    elevation = np.asarray(dem, dtype="float64")
    if elevation.ndim != 2:
        raise ValueError("DEM must be two-dimensional")
    if x_resolution <= 0 or y_resolution <= 0:
        raise ValueError("resolutions must be positive")
    dz_dy, dz_dx = np.gradient(elevation, y_resolution, x_resolution)
    return np.degrees(np.arctan(np.hypot(dz_dx, dz_dy)))


def latency_days(acquisition: datetime, event: datetime) -> float:
    """Return signed acquisition offset from an event in 24-hour days."""
    if acquisition.tzinfo is None or event.tzinfo is None:
        raise ValueError("datetimes must be timezone-aware")
    return (acquisition - event).total_seconds() / 86400.0


def sha256_file(path: str | Path, chunk_size: int = 1024 * 1024) -> str:
    """Hash a file without loading it all into memory."""
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()
