#!/usr/bin/env python3
"""Create a deterministic SHA-256 manifest for research inputs and outputs."""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import rasterio

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.core import sha256_file

PARAMETER_TAGS = (
    "threshold_k",
    "threshold_rule",
    "threshold_value",
    "mmu_pixels",
    "mmu_area_km2",
    "mmu_pixels_per_track",
    "units",
    "operation",
    "valid_mask",
    "meaning",
    "rule",
    "subset_bbox_wsen",
)


def describe_file(
    path: Path,
    root: Path,
    source_override: str | None = None,
    provenance_override: str | None = None,
    source_url_override: str | None = None,
    parameters_override: str | None = None,
) -> dict[str, str | int]:
    """Return one stable manifest row, reading GeoTIFF tags where available."""
    row: dict[str, str | int] = {
        "path": str(path.relative_to(root)),
        "bytes": path.stat().st_size,
        "sha256": sha256_file(path),
        "file_type": path.suffix.lower().lstrip("."),
        "provenance_label": provenance_override or "",
        "source_granule_ids": source_override or "",
        "source_url": source_url_override or "",
        "processing_parameters": parameters_override or "",
        "crs": "",
        "shape": "",
        "nodata": "",
    }
    if path.suffix.lower() in {".tif", ".tiff"}:
        with rasterio.open(path) as dataset:
            tags = dataset.tags()
            source_ids = tags.get("source_products") or tags.get("source_product") or source_override or ""
            parameters = [f"{name}={tags[name]}" for name in PARAMETER_TAGS if tags.get(name) is not None]
            if parameters_override:
                parameters.insert(0, parameters_override)
            row.update(
                file_type="GeoTIFF",
                provenance_label=tags.get("provenance_class", provenance_override or ""),
                source_granule_ids=source_ids,
                source_url=tags.get("source_url", tags.get("reference_url", source_url_override or "")),
                processing_parameters="; ".join(parameters),
                crs=str(dataset.crs) if dataset.crs else "",
                shape=f"{dataset.height}x{dataset.width}x{dataset.count}",
                nodata="" if dataset.nodata is None else str(dataset.nodata),
            )
    return row


def source_maps(data_root: Path) -> tuple[dict[str, str], dict[str, str]]:
    sources: dict[str, str] = {}
    provenance: dict[str, str] = {}
    hydro_path = data_root / "processed/hydro_context/hydro_context_summary.json"
    if hydro_path.exists():
        hydro = json.loads(hydro_path.read_text())
        for record in hydro.get("imerg", []):
            file_path = Path(record["file"]["path"])
            sources[str(file_path)] = record["producer_granule_id"]
            provenance[str(file_path)] = "observation"
    return sources, provenance


def scientific_metadata_maps(data_root: Path) -> tuple[dict[str, str], dict[str, str], dict[str, str], dict[str, str]]:
    """Map processed rasters to exact product IDs, stable URLs, and processing parameters."""
    sources: dict[str, str] = {}
    provenance: dict[str, str] = {}
    urls: dict[str, str] = {}
    parameters: dict[str, str] = {}

    nisar_summary_path = data_root / "processed/nisar_lband/outputs/subset_summary.json"
    if nisar_summary_path.exists():
        summary = json.loads(nisar_summary_path.read_text(encoding="utf-8"))
        for pair_name, pair in summary.get("pairs", {}).items():
            products = pair.get("products", {})
            for region_name in ("source", "null"):
                for product_key, suffix, label in (
                    ("gunw", "gunw", "observation-derived NISAR range subset"),
                    ("goff", "goff", "observation-derived NISAR range subset"),
                ):
                    product = products.get(product_key, {})
                    path = data_root / f"processed/nisar_lband/subsets/{pair_name}_{region_name}_{suffix}.tif"
                    sources[str(path)] = product.get("product_id", "")
                    urls[str(path)] = product.get("range_access", {}).get("original_https_url", "")
                    provenance[str(path)] = label
                    parameters[str(path)] = (
                        f"range_read=true; full_download=false; pair={pair_name}; region={region_name}; "
                        f"maturity={pair.get('maturity', '')}; crid={pair.get('crid', '')}"
                    )
                reference = products.get("gcov_reference", {})
                secondary = products.get("gcov_secondary", {})
                path = data_root / f"processed/nisar_lband/subsets/{pair_name}_{region_name}_gcov_change.tif"
                sources[str(path)] = " | ".join(
                    value for value in (reference.get("product_id", ""), secondary.get("product_id", "")) if value
                )
                urls[str(path)] = " | ".join(
                    value
                    for value in (
                        reference.get("range_access", {}).get("original_https_url", ""),
                        secondary.get("range_access", {}).get("original_https_url", ""),
                    )
                    if value
                )
                provenance[str(path)] = "observation-derived NISAR calibrated gamma-0 change"
                parameters[str(path)] = (
                    f"range_read=true; full_download=false; pair={pair_name}; region={region_name}; "
                    "operation=10log10(secondary)-10log10(reference); validity=common GCOV mask"
                )

    hyp3_root = data_root / "processed/s1d_hyp3"
    job_plan_path = hyp3_root / "job_plan.json"
    product_manifest_path = hyp3_root / "product_manifest.json"
    if job_plan_path.exists() and product_manifest_path.exists():
        plan = json.loads(job_plan_path.read_text(encoding="utf-8"))
        manifest = json.loads(product_manifest_path.read_text(encoding="utf-8"))
        jobs_by_role = {"quiet": plan.get("jobs", [{}])[0] if plan.get("jobs") else {}, "event": plan.get("jobs", [{}, {}])[1] if len(plan.get("jobs", [])) > 1 else {}}
        job_ids_by_role = {}
        for item in manifest.get("jobs", []):
            name = item.get("name", "")
            role = "quiet" if "quiet" in name else "event" if "event" in name else ""
            if role:
                job_ids_by_role[role] = item.get("job_id", "")
        all_bursts = []
        all_job_urls = []
        for role, job in jobs_by_role.items():
            bursts = job.get("job_parameters", {}).get("granules", [])
            all_bursts.extend(bursts)
            job_id = job_ids_by_role.get(role, "")
            stable_url = f"https://hyp3-api.asf.alaska.edu/jobs/{job_id}" if job_id else ""
            if stable_url:
                all_job_urls.append(stable_url)
            date_token = "20260804_20260816" if role == "quiet" else "20260816_20260828"
            for path in (hyp3_root / "products/extracted").rglob("*.tif") if (hyp3_root / "products/extracted").exists() else []:
                if date_token not in path.name:
                    continue
                sources[str(path)] = " | ".join(bursts)
                urls[str(path)] = stable_url
                provenance[str(path)] = "HyP3 observation-derived product"
                params = job.get("job_parameters", {})
                parameters[str(path)] = (
                    f"job_type={job.get('job_type', '')}; pair={role}; looks={params.get('looks', '')}; "
                    f"apply_water_mask={str(params.get('apply_water_mask', '')).lower()}; processor=hyp3_isce2_3.0.2/ISCE_2.6.5"
                )
        source_text = " | ".join(dict.fromkeys(all_bursts))
        url_text = " | ".join(dict.fromkeys(all_job_urls))
        analysis_dir = hyp3_root / "analysis"
        analysis_params = {
            "coherence_event_minus_quiet.tif": "operation=event_coherence-quiet_coherence; quiet_reprojection=bilinear; grid=event_80m; valid=paired_land_nodata_screen",
            "coherence_pair_valid_mask.tif": "operation=paired_validity_mask; grid=event_80m; mask=land_and_both_coherence_valid",
            "coherence_loss_screening_mask.tif": "operation=control_calibrated_coherence_loss; control_quantile=0.05; exclusion_buffer_m=300; mmu_pixels=4; grid=80m",
        }
        for filename, value in analysis_params.items():
            path = analysis_dir / filename
            sources[str(path)] = source_text
            urls[str(path)] = url_text
            provenance[str(path)] = "observation-derived retrospective screening"
            parameters[str(path)] = value

    dem_path = data_root / "inputs/dem/copernicus_glo30.tif"
    sources[str(dem_path)] = "Copernicus_DSM_COG_10_N28_00_E085_00_DEM"
    urls[str(dem_path)] = (
        "https://copernicus-dem-30m.s3.amazonaws.com/"
        "Copernicus_DSM_COG_10_N28_00_E085_00_DEM/"
        "Copernicus_DSM_COG_10_N28_00_E085_00_DEM.tif"
    )
    provenance[str(dem_path)] = "observation-derived elevation context"
    parameters[str(dem_path)] = "window_read=true; source=Copernicus_GLO-30_DSM"
    return sources, provenance, urls, parameters


def collect_manifest_files(data_root: Path) -> list[Path]:
    """Collect release inputs, processed products, and scouting outputs, excluding raw caches."""
    files: list[Path] = []
    for relative_root in ("inputs", "processed", "scouting"):
        directory = data_root / relative_root
        if directory.exists():
            files.extend(path for path in directory.rglob("*") if path.is_file())
    for extra in (data_root / "acquisition_timeline.csv", data_root / "acquisition_timeline_summary.json"):
        if extra.exists():
            files.append(extra)
    return sorted(set(files))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-root", type=Path, default=Path("data"))
    parser.add_argument("--output", type=Path, default=Path("data/manifest.csv"))
    args = parser.parse_args()
    sources, provenance = source_maps(args.data_root)
    scientific_sources, scientific_provenance, source_urls, processing_parameters = scientific_metadata_maps(args.data_root)
    sources.update(scientific_sources)
    provenance.update(scientific_provenance)
    files = collect_manifest_files(args.data_root)
    rows = [
        describe_file(
            path,
            root=args.data_root,
            source_override=sources.get(str(path)),
            provenance_override=provenance.get(str(path)),
            source_url_override=source_urls.get(str(path)),
            parameters_override=processing_parameters.get(str(path)),
        )
        for path in sorted(set(files))
    ]
    fieldnames = [
        "path", "bytes", "sha256", "file_type", "provenance_label", "source_granule_ids",
        "source_url", "processing_parameters", "crs", "shape", "nodata",
    ]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(json.dumps({"manifest": str(args.output), "files": len(rows), "sha256": sha256_file(args.output)}, indent=2))


if __name__ == "__main__":
    main()
