#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ ! -x .venv/bin/python ]]; then
  python3 -m venv .venv
fi
if .venv/bin/python -m pip --version >/dev/null 2>&1; then
  .venv/bin/python -m pip install --requirement requirements.txt
elif command -v uv >/dev/null 2>&1; then
  uv pip install --python .venv/bin/python --requirement requirements.txt
else
  .venv/bin/python -m ensurepip --upgrade
  .venv/bin/python -m pip install --requirement requirements.txt
fi

.venv/bin/python -m unittest discover -s tests -v

# Optional live refresh of the original event products. The default rebuild uses
# retained, hashed inputs and never resubmits HyP3 jobs.
if [[ "${REFRESH_REMOTE:-0}" == "1" ]]; then
  .venv/bin/python scripts/query_acquisitions.py
  .venv/bin/python scripts/fetch_opera_rtc.py
  .venv/bin/python scripts/fetch_dem.py
  .venv/bin/python scripts/fetch_hydro_context.py
fi

.venv/bin/python scripts/analyze_opera_change.py
.venv/bin/python scripts/export_handoff.py

.venv/bin/python scripts/scouting/inventory_stats.py \
  --source data/scouting/inventory/bbox_inventory.csv \
  --aoi data/scouting/aoi/connected_system_analysis_aoi.geojson \
  --subareas data/scouting/aoi/subareas_with_corridor.geojson \
  --inventory inventory.csv \
  --stats data/scouting/inventory/subarea_sensor_stats.csv \
  --summary data/scouting/inventory/exact_filter_summary.json \
  --event-date 2026-08-26
cp inventory.csv data/scouting/inventory/inventory.csv

.venv/bin/python scripts/scouting/build_coherence_mask.py \
  --delta data/processed/s1d_hyp3/analysis/coherence_event_minus_quiet.tif \
  --reference data/inputs/validation/unosat_detachment.geojson \
  --output-tif data/processed/s1d_hyp3/analysis/coherence_loss_screening_mask.tif \
  --output-json data/processed/s1d_hyp3/analysis/coherence_loss_screening_mask.json \
  --output-png game_handoff/coherence_loss_screening_mask.png \
  --output-webp game_handoff/coherence_loss_screening_mask.webp \
  --bbox 85.34,28.23,85.55,28.32 \
  --control-quantile 0.05 \
  --exclusion-buffer-m 300 \
  --mmu-pixels 4

.venv/bin/python scripts/scouting/build_impact_outputs.py \
  --inventory inventory.csv \
  --nisar data/processed/nisar_lband/outputs/subset_findings.json \
  --cband data/processed/s1d_hyp3/analysis/coherence_comparison.json \
  --output data/scouting/impact \
  --game-output game_handoff \
  --event 2026-08-26T02:52:10Z

.venv/bin/python scripts/scouting/build_screening_map.py \
  --osm-context _subagents2/aoi/outputs/osm_named_context.geojson \
  --detachment data/inputs/validation/unosat_detachment.geojson \
  --mask-summary data/processed/s1d_hyp3/analysis/coherence_loss_screening_mask.json \
  --nisar-findings data/processed/nisar_lband/outputs/subset_findings.json \
  --exposure-output data/scouting/impact/exposure_context_20km.geojson \
  --exposure-csv data/scouting/impact/exposure_context_20km.csv \
  --screening-output data/scouting/impact/hazard_screening.geojson
cp data/scouting/impact/hazard_screening.geojson game_handoff/hazard_screening.geojson
cp data/scouting/impact/exposure_context_20km.geojson game_handoff/exposure_context_20km.geojson

.venv/bin/python scripts/build_manifest.py
.venv/bin/python scripts/scouting/build_game_manifest.py --root game_handoff
.venv/bin/python scripts/scouting/validate_release.py --root . --output release_validation.json
.venv/bin/python -m unittest discover -s tests -v
