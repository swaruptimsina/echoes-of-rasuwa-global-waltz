#!/usr/bin/env python3
"""Create a control-calibrated, non-operational coherence-loss mask."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import rasterio
from PIL import Image
from pyproj import Transformer
from rasterio.features import geometry_mask
from scipy import ndimage
from shapely.geometry import box, mapping, shape
from shapely.ops import transform as shapely_transform


def remove_small_components(mask: np.ndarray, min_pixels: int) -> np.ndarray:
    """Keep 8-connected boolean components meeting the minimum pixel count."""
    if min_pixels <= 1:
        return mask.astype(bool, copy=True)
    labels, count = ndimage.label(mask, structure=np.ones((3, 3), dtype=np.uint8))
    if count == 0:
        return np.zeros_like(mask, dtype=bool)
    sizes = np.bincount(labels.ravel())
    keep = sizes >= min_pixels
    keep[0] = False
    return keep[labels]


def parse_bbox(value: str) -> tuple[float, float, float, float]:
    parts = tuple(float(item) for item in value.split(","))
    if len(parts) != 4:
        raise argparse.ArgumentTypeError("bbox must be west,south,east,north")
    return parts


def build_mask(
    delta_path: Path,
    reference_path: Path,
    output_tif: Path,
    output_json: Path,
    output_png: Path,
    output_webp: Path,
    fixed_bbox_wsen: tuple[float, float, float, float],
    control_quantile: float,
    exclusion_buffer_m: float,
    mmu_pixels: int,
) -> dict:
    reference = json.loads(reference_path.read_text(encoding="utf-8"))
    feature = reference["features"][0]
    target_wgs84 = shape(feature["geometry"])

    with rasterio.open(delta_path) as source:
        delta = source.read(1).astype("float64")
        valid = np.isfinite(delta)
        if source.nodata is not None and np.isfinite(source.nodata):
            valid &= delta != source.nodata
        transformer = Transformer.from_crs("EPSG:4326", source.crs, always_xy=True).transform
        target = shapely_transform(transformer, target_wgs84)
        fixed = shapely_transform(transformer, box(*fixed_bbox_wsen))
        target_mask = geometry_mask([mapping(target)], out_shape=source.shape, transform=source.transform, invert=True)
        fixed_mask = geometry_mask([mapping(fixed)], out_shape=source.shape, transform=source.transform, invert=True)
        excluded = geometry_mask(
            [mapping(target.buffer(exclusion_buffer_m))],
            out_shape=source.shape,
            transform=source.transform,
            invert=True,
        )
        control_mask = valid & fixed_mask & ~excluded
        target_valid = valid & target_mask
        if not np.any(control_mask):
            raise RuntimeError("control mask has no valid pixels")
        threshold = float(np.quantile(delta[control_mask], control_quantile))
        raw_anomaly = valid & fixed_mask & (delta <= threshold)
        filtered_anomaly = remove_small_components(raw_anomaly, mmu_pixels)

        output_tif.parent.mkdir(parents=True, exist_ok=True)
        classified = np.full(source.shape, 255, dtype=np.uint8)
        classified[valid & fixed_mask] = 0
        classified[filtered_anomaly] = 1
        profile = source.profile.copy()
        profile.update(dtype="uint8", count=1, nodata=255, compress="deflate")
        with rasterio.open(output_tif, "w", **profile) as destination:
            destination.write(classified, 1)
            destination.set_band_description(1, "coherence_loss_screening_mask")
            destination.update_tags(
                observable="Sentinel-1D event-minus-quiet normalized coherence",
                threshold_rule=f"control quantile {control_quantile}",
                threshold_value=f"{threshold:.12g}",
                mmu_pixels=str(mmu_pixels),
                interpretation_limit="screening observable; not deformation, cause, hazard probability, or prediction",
            )

        pixel_area_km2 = abs(source.transform.a * source.transform.e) / 1_000_000
        target_raw = raw_anomaly & target_valid
        target_filtered = filtered_anomaly & target_valid
        control_raw = raw_anomaly & control_mask
        control_filtered = filtered_anomaly & control_mask
        summary = {
            "observable": "Sentinel-1D VV event-minus-quiet normalized coherence",
            "source_raster": str(delta_path),
            "independent_reference": str(reference_path),
            "reference_role": "preliminary independent optical detachment polygon; not field ground truth",
            "analysis_bbox_wsen": list(fixed_bbox_wsen),
            "control_definition": f"valid land pixels in analysis bbox outside a {exclusion_buffer_m:g} m detachment buffer",
            "threshold_rule": f"{control_quantile:.3f} lower quantile of control event-minus-quiet coherence",
            "threshold": threshold,
            "mmu_pixels": mmu_pixels,
            "mmu_area_km2": mmu_pixels * pixel_area_km2,
            "pixel_area_km2": pixel_area_km2,
            "target_valid_pixels": int(target_valid.sum()),
            "target_raw_anomaly_pixels": int(target_raw.sum()),
            "target_filtered_anomaly_pixels": int(target_filtered.sum()),
            "target_filtered_anomaly_fraction": float(target_filtered.sum() / target_valid.sum()) if target_valid.any() else None,
            "control_valid_pixels": int(control_mask.sum()),
            "control_raw_false_alarm_pixels": int(control_raw.sum()),
            "control_raw_false_alarm_fraction": float(control_raw.sum() / control_mask.sum()),
            "control_filtered_false_alarm_pixels": int(control_filtered.sum()),
            "control_filtered_false_alarm_fraction": float(control_filtered.sum() / control_mask.sum()),
            "full_fixed_aoi_valid_pixels": int((valid & fixed_mask).sum()),
            "limitations": [
                "The HyP3 burst bundle supplied water/nodata masks but no explicit layover-shadow mask; steep-terrain geometry remains an unresolved censoring issue.",
                "The threshold is calibrated to this one temporal null/event comparison and is not a transferable hazard threshold.",
                "Coherence loss is an observable, not unique evidence of movement; snow, moisture, surface disruption, atmosphere, and processing differences remain possible.",
                "The map is retrospective screening support, not a forecast or operational warning product.",
            ],
        }

    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    rgba = np.zeros((*classified.shape, 4), dtype=np.uint8)
    rgba[classified == 1] = np.array([226, 61, 74, 225], dtype=np.uint8)
    image = Image.fromarray(rgba, mode="RGBA")
    output_png.parent.mkdir(parents=True, exist_ok=True)
    image.save(output_png, optimize=True)
    image.save(output_webp, format="WEBP", lossless=True, method=6)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a control-calibrated coherence-loss screening mask.")
    parser.add_argument("--delta", type=Path, required=True, help="event-minus-quiet coherence GeoTIFF")
    parser.add_argument("--reference", type=Path, required=True, help="independent detachment GeoJSON")
    parser.add_argument("--output-tif", type=Path, required=True)
    parser.add_argument("--output-json", type=Path, required=True)
    parser.add_argument("--output-png", type=Path, required=True)
    parser.add_argument("--output-webp", type=Path, required=True)
    parser.add_argument("--bbox", type=parse_bbox, default=parse_bbox("85.34,28.23,85.55,28.32"))
    parser.add_argument("--control-quantile", type=float, default=0.05)
    parser.add_argument("--exclusion-buffer-m", type=float, default=300.0)
    parser.add_argument("--mmu-pixels", type=int, default=4)
    args = parser.parse_args()
    result = build_mask(
        args.delta,
        args.reference,
        args.output_tif,
        args.output_json,
        args.output_png,
        args.output_webp,
        args.bbox,
        args.control_quantile,
        args.exclusion_buffer_m,
        args.mmu_pixels,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
