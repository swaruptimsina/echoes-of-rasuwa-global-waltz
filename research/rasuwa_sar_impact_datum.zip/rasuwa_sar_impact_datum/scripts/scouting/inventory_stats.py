#!/usr/bin/env python3
"""Post-filter SAR metadata to the hydrologic AOI and summarize repeat coverage."""

from __future__ import annotations

import argparse
import csv
import json
import statistics
from collections import defaultdict
from datetime import date
from pathlib import Path
from typing import Any, Mapping

from shapely.geometry import Polygon, box, shape
from shapely.ops import unary_union


def cmr_spatial_geometry(value: str):
    """Return a Shapely geometry from a CMR UMM spatial-extent JSON string."""
    extent: dict[str, Any] = json.loads(value)
    geometry = extent.get("HorizontalSpatialDomain", {}).get("Geometry", {})
    parts = []
    for item in geometry.get("GPolygons", []):
        points = item.get("Boundary", {}).get("Points", [])
        coordinates = [
            (float(point["Longitude"]), float(point["Latitude"]))
            for point in points
            if "Longitude" in point and "Latitude" in point
        ]
        if len(coordinates) >= 3:
            polygon = Polygon(coordinates)
            if not polygon.is_valid:
                polygon = polygon.buffer(0)
            if not polygon.is_empty:
                parts.append(polygon)
    for item in geometry.get("BoundingRectangles", []):
        parts.append(
            box(
                float(item["WestBoundingCoordinate"]),
                float(item["SouthBoundingCoordinate"]),
                float(item["EastBoundingCoordinate"]),
                float(item["NorthBoundingCoordinate"]),
            )
        )
    if not parts:
        raise ValueError("CMR spatial extent contains no supported polygon or rectangle")
    return unary_union(parts)


def observation_dates(row: Mapping[str, str]) -> list[str]:
    """Return unique source-observation UTC dates represented by one product."""
    pair_dates = [row.get("reference_begin_utc", ""), row.get("secondary_begin_utc", "")]
    values = [value for value in pair_dates if value]
    if not values and row.get("acquisition_begin_utc", ""):
        values = [row["acquisition_begin_utc"]]
    return sorted({value[:10] for value in values if len(value) >= 10})


def geometry_key(row: Mapping[str, str]) -> str:
    """Build a repeat-geometry key without acquisition-specific platform/orbit fields."""
    product_type = row.get("product_type", "").upper()
    group = row.get("group_stack_burst_id", "") if product_type in {"BURST", "RTC"} else ""
    if "|" in group:
        group = group.rsplit("|", 1)[-1]
    fields = (
        row.get("mission", ""),
        row.get("product_type", ""),
        row.get("track_path", ""),
        row.get("frame", ""),
        row.get("direction", ""),
        row.get("beam_mode", ""),
        row.get("swath", ""),
        row.get("polarization", ""),
        row.get("range_bandwidth_mhz", ""),
        group,
        row.get("mgrs_tile_id", ""),
    )
    return "|".join(str(value).strip().upper() for value in fields)


def summarize_rows(rows: list[Mapping[str, str]], event_date: str) -> dict[str, Any]:
    """Summarize unique source dates and the densest same-geometry sequence."""
    dates_by_geometry: dict[str, set[str]] = defaultdict(set)
    all_dates: set[str] = set()
    for row in rows:
        dates = observation_dates(row)
        all_dates.update(dates)
        dates_by_geometry[geometry_key(row)].update(dates)

    ranked = sorted(dates_by_geometry.items(), key=lambda item: (-len(item[1]), item[0]))
    selected_key, selected_values = ranked[0] if ranked else ("", set())
    selected_dates = sorted(selected_values)
    parsed = [date.fromisoformat(value) for value in selected_dates]
    gaps = [(later - earlier).days for earlier, later in zip(parsed, parsed[1:])]
    baseline = float(statistics.median(gaps)) if gaps else None

    event = date.fromisoformat(event_date)
    parsed_all = [date.fromisoformat(value) for value in sorted(all_dates)]
    monsoon = [value for value in parsed_all if 6 <= value.month <= 9 and value.year == event.year]
    return {
        "unique_observation_dates": len(all_dates),
        "longest_same_geometry_chain_dates": len(selected_dates),
        "longest_same_geometry_key": selected_key,
        "longest_same_geometry_start": selected_dates[0] if selected_dates else "",
        "longest_same_geometry_end": selected_dates[-1] if selected_dates else "",
        "median_adjacent_baseline_days": baseline,
        "monsoon_dates_before_event": sum(value < event for value in monsoon),
        "monsoon_dates_after_event": sum(value >= event for value in monsoon),
    }


def _geojson_features(path: Path) -> list[tuple[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    features = payload.get("features", []) if payload.get("type") == "FeatureCollection" else [payload]
    result = []
    for index, feature in enumerate(features):
        properties = feature.get("properties") or {}
        identifier = str(
            properties.get("subarea_id")
            or properties.get("site_id")
            or properties.get("id")
            or feature.get("id")
            or properties.get("name")
            or f"feature_{index + 1}"
        )
        result.append((identifier, shape(feature["geometry"])))
    return result


def _quality_note(row: Mapping[str, str]) -> str:
    product = row.get("product_type", "").upper()
    if product in {"GUNW", "RIFG", "RUNW"}:
        return "Cloud not applicable; product includes interferometric quality/coherence fields, not assessed for every granule in this metadata inventory."
    if product in {"SLC", "BURST", "RSLC", "GSLC"}:
        return "Cloud not applicable; coherence requires matched-pair processing and is not a catalog field."
    if product in {"RTC", "GCOV", "GRD_HD", "DIST-ALERT-S1", "DSWX-S1"}:
        return "Cloud not applicable to SAR; no pair coherence value is asserted by this inventory."
    return "Metadata inventory only; no per-granule coherence or cloud metric was computed."


def build_outputs(
    source_csv: Path,
    aoi_geojson: Path,
    subareas_geojson: Path,
    output_inventory_csv: Path,
    output_stats_csv: Path,
    event_date: str,
) -> dict[str, Any]:
    """Exact-postfilter the bbox inventory and write per-subarea coverage statistics."""
    aoi_parts = _geojson_features(aoi_geojson)
    aoi = unary_union([geometry for _, geometry in aoi_parts])
    subareas = _geojson_features(subareas_geojson)
    exact_rows: list[dict[str, str]] = []
    unparsed: list[str] = []

    with source_csv.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        source_fields = list(reader.fieldnames or [])
        source_rows = 0
        for original in reader:
            source_rows += 1
            try:
                footprint = cmr_spatial_geometry(original.get("spatial_extent_json", ""))
            except Exception:
                unparsed.append(original.get("inventory_id", f"row_{source_rows}"))
                continue
            if not footprint.intersects(aoi):
                continue
            overlaps = [identifier for identifier, geometry in subareas if footprint.intersects(geometry)]
            row = dict(original)
            row["subarea_ids"] = ";".join(overlaps)
            row["cloud_coherence_notes"] = _quality_note(row)
            exact_rows.append(row)

    output_inventory_csv.parent.mkdir(parents=True, exist_ok=True)
    inventory_fields = source_fields + [
        field for field in ("subarea_ids", "cloud_coherence_notes") if field not in source_fields
    ]
    with output_inventory_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=inventory_fields)
        writer.writeheader()
        writer.writerows(exact_rows)

    grouped: dict[tuple[str, str, str, str, str, str], list[dict[str, str]]] = defaultdict(list)
    for row in exact_rows:
        identifiers = ["__whole_system__"] + [value for value in row["subarea_ids"].split(";") if value]
        product_key = (
            row.get("mission", ""),
            row.get("platform", ""),
            row.get("band", ""),
            row.get("instrument", ""),
            row.get("product_type", ""),
        )
        for identifier in identifiers:
            grouped[(identifier, *product_key)].append(row)

    stats_rows: list[dict[str, Any]] = []
    for key in sorted(grouped):
        identifier, mission, platform, band, instrument, product_type = key
        rows = grouped[key]
        summary = summarize_rows(rows, event_date)
        stats_rows.append(
            {
                "subarea_id": identifier,
                "mission": mission,
                "platform": platform,
                "band": band,
                "instrument": instrument,
                "product_type": product_type,
                "product_granules": len(rows),
                **summary,
            }
        )

    stats_fields = [
        "subarea_id",
        "mission",
        "platform",
        "band",
        "instrument",
        "product_type",
        "product_granules",
        "unique_observation_dates",
        "longest_same_geometry_chain_dates",
        "median_adjacent_baseline_days",
        "longest_same_geometry_start",
        "longest_same_geometry_end",
        "monsoon_dates_before_event",
        "monsoon_dates_after_event",
        "longest_same_geometry_key",
    ]
    output_stats_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_stats_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=stats_fields)
        writer.writeheader()
        writer.writerows(stats_rows)

    return {
        "source_rows": source_rows,
        "exact_aoi_rows": len(exact_rows),
        "unparsed_spatial_rows": len(unparsed),
        "unparsed_inventory_ids": unparsed,
        "stats_rows": len(stats_rows),
        "subarea_ids": [identifier for identifier, _ in subareas],
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Post-filter a CMR/ASF bbox inventory to a hydrologic AOI and summarize repeat coverage."
    )
    parser.add_argument("--source", type=Path, required=True, help="bbox-superset inventory CSV")
    parser.add_argument("--aoi", type=Path, required=True, help="canonical AOI GeoJSON")
    parser.add_argument("--subareas", type=Path, required=True, help="named subareas GeoJSON")
    parser.add_argument("--inventory", type=Path, required=True, help="exact-AOI output inventory CSV")
    parser.add_argument("--stats", type=Path, required=True, help="per-subarea coverage output CSV")
    parser.add_argument("--summary", type=Path, help="optional machine-readable run summary JSON")
    parser.add_argument("--event-date", default="2026-08-26", help="UTC event date (YYYY-MM-DD)")
    args = parser.parse_args()
    result = build_outputs(
        args.source,
        args.aoi,
        args.subareas,
        args.inventory,
        args.stats,
        args.event_date,
    )
    if args.summary:
        args.summary.parent.mkdir(parents=True, exist_ok=True)
        args.summary.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
