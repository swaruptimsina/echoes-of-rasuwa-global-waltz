#!/usr/bin/env python3
"""Build non-operational latency, cross-band, and game-handoff evidence files."""

from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

from shapely.geometry import Point

try:
    from scripts.scouting.inventory_stats import cmr_spatial_geometry
except ModuleNotFoundError:  # direct script-path execution
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from scripts.scouting.inventory_stats import cmr_spatial_geometry


def latency_values(
    event: datetime,
    acquisition: datetime,
    insertion: datetime | None,
    production: datetime | None = None,
) -> dict[str, float | None]:
    """Return acquisition, generation, and archive delays without conflating them."""
    acquisition_days = (acquisition - event).total_seconds() / 86_400
    production_days = (production - event).total_seconds() / 86_400 if production else None
    insertion_days = (insertion - event).total_seconds() / 86_400 if insertion else None
    archive_reference = production or acquisition
    return {
        "acquisition_offset_days": acquisition_days,
        "product_generation_offset_days": production_days,
        "archive_insertion_offset_days": insertion_days,
        "processing_to_archive_days": (insertion - archive_reference).total_seconds() / 86_400 if insertion else None,
    }


def coherence_comparison(
    *,
    l_quiet_target: float,
    l_event_target: float,
    l_quiet_control: float,
    l_event_control: float,
    c_target_delta: float,
    c_control_delta: float,
) -> dict[str, Any]:
    """Compare target-vs-control changes within each sensor, never absolute bands."""
    l_target_delta = l_event_target - l_quiet_target
    l_control_delta = l_event_control - l_quiet_control
    return {
        "l_band_target_delta": l_target_delta,
        "l_band_control_delta": l_control_delta,
        "l_band_difference_of_changes": l_target_delta - l_control_delta,
        "c_band_target_delta": c_target_delta,
        "c_band_control_delta": c_control_delta,
        "c_band_difference_of_changes": c_target_delta - c_control_delta,
        "absolute_coherence_directly_comparable": False,
    }


def parse_utc(value: str) -> datetime | None:
    if not value:
        return None
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _point_rows(inventory_path: Path, lon: float, lat: float) -> list[dict[str, str]]:
    point = Point(lon, lat)
    result = []
    with inventory_path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            try:
                footprint = cmr_spatial_geometry(row.get("spatial_extent_json", ""))
            except Exception:
                continue
            if footprint.intersects(point):
                result.append(row)
    return result


def _represented_post_time(row: dict[str, str]) -> datetime | None:
    return parse_utc(row.get("secondary_begin_utc") or row.get("acquisition_begin_utc") or "")


def _first_post(
    rows: list[dict[str, str]],
    event: datetime,
    mission: str,
    product_type: str,
    preferred_polarization: str | None = None,
) -> dict[str, str] | None:
    matches = [
        row
        for row in rows
        if row.get("mission") == mission
        and row.get("product_type") == product_type
        and (preferred_polarization is None or row.get("polarization") == preferred_polarization)
        and _represented_post_time(row)
        and _represented_post_time(row) >= event
    ]
    return min(matches, key=lambda row: _represented_post_time(row)) if matches else None


def build_timeline_rows(rows: list[dict[str, str]], event: datetime) -> list[dict[str, Any]]:
    """Build a compact point-acquisition timeline from single-epoch product families."""
    allowed = {
        ("Sentinel-1", "SLC"),
        ("NISAR", "GCOV"),
        ("ALOS-2", "ALOS2_L1_PSR2"),
        ("OPERA", "RTC"),
        ("OPERA", "DSWx-S1"),
    }
    deduplicated: dict[tuple[str, str, str, str, str], dict[str, Any]] = {}
    for row in rows:
        family = (row.get("mission", ""), row.get("product_type", ""))
        if family not in allowed:
            continue
        acquisition = parse_utc(row.get("acquisition_begin_utc", ""))
        if acquisition is None:
            continue
        key = (
            family[0],
            family[1],
            acquisition.date().isoformat(),
            row.get("track_path", ""),
            row.get("direction", ""),
        )
        if key in deduplicated:
            continue
        offset = (acquisition - event).total_seconds() / 86_400
        deduplicated[key] = {
            "acquisition_utc": acquisition.isoformat().replace("+00:00", "Z"),
            "event_offset_days": offset,
            "relation_to_event": "before" if offset < 0 else "after",
            "mission": family[0],
            "platform": row.get("platform", ""),
            "product_type": family[1],
            "track_path": row.get("track_path", ""),
            "direction": row.get("direction", ""),
            "producer_granule_id": row.get("producer_granule_id", ""),
            "provenance_label": "catalog observation",
        }
    return sorted(deduplicated.values(), key=lambda item: (item["acquisition_utc"], item["mission"], item["product_type"]))


def _latency_row(
    label: str,
    row: dict[str, str] | None,
    event: datetime,
    usability: str,
    interpretation: str,
) -> dict[str, Any]:
    if row is None:
        return {
            "mission_product": label,
            "first_post_acquisition_utc": "",
            "acquisition_offset_days": None,
            "product_generation_utc": "",
            "product_generation_offset_days": None,
            "cmr_archive_insertion_utc": "",
            "archive_insertion_offset_days": None,
            "processing_to_archive_days": None,
            "producer_granule_id": "",
            "maturity": "",
            "usability_for_this_study": usability,
            "interpretation": interpretation,
        }
    acquisition = _represented_post_time(row)
    production = parse_utc(row.get("production_datetime_utc", ""))
    insertion = parse_utc(row.get("cmr_insert_datetime_utc", ""))
    values = latency_values(event, acquisition, insertion, production)
    return {
        "mission_product": label,
        "first_post_acquisition_utc": acquisition.isoformat().replace("+00:00", "Z"),
        **values,
        "product_generation_utc": row.get("production_datetime_utc", ""),
        "cmr_archive_insertion_utc": row.get("cmr_insert_datetime_utc", ""),
        "producer_granule_id": row.get("producer_granule_id", ""),
        "maturity": row.get("maturity", ""),
        "usability_for_this_study": usability,
        "interpretation": interpretation,
    }


def build_outputs(
    inventory_path: Path,
    nisar_path: Path,
    cband_path: Path,
    output_dir: Path,
    game_dir: Path,
    event_text: str,
) -> dict[str, Any]:
    event = parse_utc(event_text)
    if event is None:
        raise ValueError("event timestamp is required")
    point_rows = _point_rows(inventory_path, 85.528066, 28.291242)
    specs = [
        (
            "Sentinel-1D SLC",
            "Sentinel-1",
            "SLC",
            "usable for the processed HyP3 event pair",
            "First post-event image used in the successful C-band coherence analysis.",
        ),
        (
            "Sentinel-1D burst",
            "Sentinel-1",
            "BURST",
            "usable for the processed HyP3 event pair",
            "Burst input used by HyP3; acquisition delay is not warning time.",
        ),
        (
            "OPERA RTC-S1",
            "OPERA",
            "RTC",
            "catalogued amplitude product; not processed in the final coherence result",
            "The first matching acquisition was early, but its CMR archive insertion was much later.",
        ),
        (
            "OPERA DSWx-S1",
            "OPERA",
            "DSWx-S1",
            "not validated at the source in this study",
            "Catalog latency only; no water-detection accuracy claim is made.",
        ),
        (
            "NISAR L-band GCOV",
            "NISAR",
            "GCOV",
            "catalogued source footprint; earliest track-48 pixels were not inspected",
            "The later track-98 GCOV was range-read for calibrated backscatter change.",
        ),
        (
            "NISAR L-band GUNW",
            "NISAR",
            "GUNW",
            "not usable for source displacement in the earliest post pair",
            "Track 48 had zero source pixels passing both subswath-validity conditions.",
        ),
        (
            "NISAR L-band GOFF",
            "NISAR",
            "GOFF",
            "not usable for subtle offsets without culling/modeling",
            "Raw offset layers were outlier-dominated at the source.",
        ),
        (
            "ALOS-2 PALSAR-2 ScanSAR",
            "ALOS-2",
            "ALOS2_L1_PSR2",
            "no post-event granule in the 24-month inventory through 2026-11-15",
            "This is a catalog gap, not evidence that the mission made no acquisition.",
        ),
    ]
    latency_rows = [
        _latency_row(
            label,
            _first_post(
                point_rows,
                event,
                mission,
                product,
                preferred_polarization="VV" if product == "BURST" else None,
            ),
            event,
            usability,
            interpretation,
        )
        for label, mission, product, usability, interpretation in specs
    ]
    latency_rows.extend(
        [
            _latency_row(
                "NISAR S-band",
                None,
                event,
                "not distributed by CMR/ASF; Bhoonidhi enumeration not completed",
                "No S-band latency can be claimed from the fetched catalogs.",
            ),
            _latency_row(
                "RADARSAT Constellation Mission",
                None,
                event,
                "CMR stub had zero global granules and ASF rejected the probe",
                "Unsupported catalog access is not zero acquisition evidence.",
            ),
            _latency_row(
                "SAOCOM",
                None,
                event,
                "CMR stub had zero global granules and ASF rejected the probe",
                "Unsupported catalog access is not zero acquisition evidence.",
            ),
        ]
    )

    nisar = json.loads(nisar_path.read_text(encoding="utf-8"))
    cband = json.loads(cband_path.read_text(encoding="utf-8"))
    l_quiet_target = nisar["pairs"]["quiet"]["regions"]["source"]["gunw"]["coherence_median"]
    l_event_target = nisar["pairs"]["event"]["regions"]["source"]["gunw"]["coherence_median"]
    l_quiet_control = nisar["pairs"]["quiet"]["regions"]["null"]["gunw"]["coherence_median"]
    l_event_control = nisar["pairs"]["event"]["regions"]["null"]["gunw"]["coherence_median"]
    c_regions = cband["paired_on_event_grid"]["regions"]
    c_target_delta = c_regions["detachment"]["event_minus_quiet_coherence"]["median"]
    c_control_delta = c_regions["local_control_ring_approx_0.3_to_1.5_km"]["event_minus_quiet_coherence"]["median"]
    crossband = coherence_comparison(
        l_quiet_target=l_quiet_target,
        l_event_target=l_event_target,
        l_quiet_control=l_quiet_control,
        l_event_control=l_event_control,
        c_target_delta=c_target_delta,
        c_control_delta=c_control_delta,
    )
    crossband.update(
        {
            "provenance_label": "observation-derived descriptive comparison",
            "l_band": {
                "sensor": "NISAR L-SAR HH",
                "quiet_pair": ["2026-07-14", "2026-07-26"],
                "event_pair": ["2026-08-19", "2026-08-31"],
                "target_region": [85.511, 28.282, 85.531, 28.297],
                "control_region": [85.491, 28.3505, 85.5075, 28.3653],
                "quiet_target_median": l_quiet_target,
                "event_target_median": l_event_target,
                "quiet_control_median": l_quiet_control,
                "event_control_median": l_event_control,
                "target_fraction_ge_0_3_quiet": nisar["pairs"]["quiet"]["regions"]["source"]["gunw"]["coherence_fraction_ge_0_3"],
                "target_fraction_ge_0_3_event": nisar["pairs"]["event"]["regions"]["source"]["gunw"]["coherence_fraction_ge_0_3"],
                "event_phase_valid_pixels": nisar["pairs"]["event"]["regions"]["source"]["gunw"]["phase_valid_pixels"],
                "event_phase_total_pixels": nisar["pairs"]["event"]["regions"]["source"]["gunw"]["sample_valid_pixels"],
            },
            "c_band": {
                "sensor": "Sentinel-1D VV HyP3 Burst InSAR",
                "quiet_pair": ["2026-08-04", "2026-08-16"],
                "event_pair": ["2026-08-16", "2026-08-28"],
                "target_region": "independent preliminary UNOSAT detachment polygon",
                "control_region": "0.3–1.5 km local ring",
                "quiet_target_median": c_regions["detachment"]["quiet_coherence_reprojected"]["median"],
                "event_target_median": c_regions["detachment"]["event_coherence"]["median"],
                "target_valid_pixels": c_regions["detachment"]["pair_valid_pixels"],
                "target_fraction_event_lower_than_quiet": c_regions["detachment"]["fraction_event_lower_than_quiet"],
            },
            "comparison_limit": "Only within-sensor event-minus-quiet target/control contrasts are compared. Absolute L/C coherence is not interchangeable because dates, geometry, wavelength, polarization, masks, and terrain observability differ.",
        }
    )

    mask_path = cband_path.parent / "coherence_loss_screening_mask.json"
    mask_summary = json.loads(mask_path.read_text(encoding="utf-8")) if mask_path.exists() else None
    subtle = {
        "event_utc": event_text,
        "results": [
            {
                "id": "cband_localized_coherence_loss",
                "status": "validated descriptive result",
                "confidence": "medium-low",
                "observation": f"Paired-pixel median coherence change was {c_target_delta:.4f} in the preliminary detachment polygon versus {c_control_delta:+.4f} in the local control ring.",
                "validation": "Independent preliminary optical detachment polygon, temporal null pair, local ring, and control-calibrated 5th-percentile/MMU mask.",
                "false_alarm_accounting": mask_summary,
                "interpretation": "Localized event-spanning coherence loss is supported; unique cause, precursor motion, displacement, and prediction are not.",
            },
            {
                "id": "nisar_gunw_displacement",
                "status": "diagnosed failure",
                "confidence": "high for the failure diagnosis",
                "observation": "Event-pair source phase coverage fell to 9 of 528 80 m pixels (1.70%), while the exploratory control retained 420 of 420.",
                "validation": "Quiet pair, spatial control, track-48 alternative-look test, encoded masks, connected components, and ionosphere flags.",
                "interpretation": "No defensible LOS displacement or pre-event rate is reported.",
            },
            {
                "id": "nisar_goff_subtle_offsets",
                "status": "diagnosed failure",
                "confidence": "high for the failure diagnosis",
                "observation": "Raw, unculled event-source GOFF layer-1 offsets had correlation median 0.2206 and extreme p05/p95 ranges of hundreds of metres.",
                "validation": "Quiet and control subsets were processed with the same range-read code; control correlation remained about 0.86.",
                "interpretation": "The raw layers cannot support a sub-metre subtle-motion claim without culling, stable-reference modeling, and uncertainty estimation.",
            },
            {
                "id": "nisar_gcov_backscatter_change",
                "status": "exploratory observable",
                "confidence": "low for event attribution",
                "observation": "Event-source HH gamma-0 change widened to p05/p95 −6.69/+5.77 dB, while the event control was −3.19/+3.14 dB.",
                "validation": "Matched quiet and control windows were range-read from provisional GCOV products.",
                "interpretation": "This is calibrated backscatter change only; it is not classified as debris, water, or movement.",
            },
        ],
    }

    hooks = [
        {
            "id": "cband_coherence",
            "provenance_label": "observation-derived",
            "sentences": [
                "A Sentinel-1D pair spanning the event lost coherence inside an independently mapped detachment while the nearby control ring gained coherence.",
                f"After a control-calibrated threshold and four-pixel minimum area, {mask_summary['target_filtered_anomaly_pixels'] if mask_summary else 'UNVERIFIED'} of 307 target pixels were flagged, versus {mask_summary['control_filtered_false_alarm_pixels'] if mask_summary else 'UNVERIFIED'} false alarms among {mask_summary['control_valid_pixels'] if mask_summary else 'UNVERIFIED'} control pixels.",
                "The pattern is retrospective evidence of localized surface change, not proof of a precursor, cause, displacement, or warning capability.",
            ],
        },
        {
            "id": "lband_limit",
            "provenance_label": "observation-derived diagnosed failure",
            "sentences": [
                f"NISAR L-band median coherence fell from {l_quiet_target:.3f} in the quiet pair to {l_event_target:.3f} in the event pair, while the exploratory control changed only from {l_quiet_control:.3f} to {l_event_control:.3f}.",
                "Only 9 of 528 source pixels retained connected unwrapped phase in the event pair.",
                "The satellite saw decorrelation, but the data do not support a displacement map or a claim that the slope was moving beforehand.",
            ],
        },
        {
            "id": "latency",
            "provenance_label": "catalog observation",
            "sentences": [
                "The first Sentinel-1D image used here was acquired 2.395 days after the event.",
                "Its CMR insertion was 3.254 days after the event, while the matching OPERA RTC product was inserted about 46.379 days after the event in this archive snapshot.",
                "These are retrospective acquisition and archive delays, not warning time or operational delivery guarantees.",
            ],
        },
    ]
    timeline = build_timeline_rows(point_rows, event)

    output_dir.mkdir(parents=True, exist_ok=True)
    game_dir.mkdir(parents=True, exist_ok=True)
    latency_fields = list(latency_rows[0].keys())
    for directory in (output_dir, game_dir):
        with (directory / "latency_table.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=latency_fields)
            writer.writeheader()
            writer.writerows(latency_rows)
        (directory / "latency_table.json").write_text(json.dumps({"event_utc": event_text, "rows": latency_rows}, indent=2) + "\n", encoding="utf-8")
        (directory / "l_vs_c_coherence.json").write_text(json.dumps(crossband, indent=2) + "\n", encoding="utf-8")
        (directory / "subtle_change_results.json").write_text(json.dumps(subtle, indent=2) + "\n", encoding="utf-8")
        (directory / "story_hooks.json").write_text(json.dumps(hooks, indent=2) + "\n", encoding="utf-8")
        timeline_fields = list(timeline[0].keys()) if timeline else []
        with (directory / "acquisition_timeline.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=timeline_fields)
            if timeline_fields:
                writer.writeheader()
                writer.writerows(timeline)
        (directory / "acquisition_timeline.json").write_text(
            json.dumps(
                {
                    "event_utc": event_text,
                    "point_lon_lat": [85.528066, 28.291242],
                    "provenance_label": "catalog observation",
                    "deduplication": "mission + product + UTC day + track + direction",
                    "rows": timeline,
                },
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
    return {
        "latency_rows": len(latency_rows),
        "timeline_rows": len(timeline),
        "point_inventory_rows": len(point_rows),
        "subtle_change_results": len(subtle["results"]),
        "story_hooks": len(hooks),
        "crossband": crossband,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Build latency and subtle-change handoff files from verified inventory and processed summaries."
    )
    parser.add_argument("--inventory", type=Path, required=True)
    parser.add_argument("--nisar", type=Path, required=True, help="NISAR subset_findings.json")
    parser.add_argument("--cband", type=Path, required=True, help="HyP3 coherence_comparison.json")
    parser.add_argument("--output", type=Path, required=True, help="research output directory")
    parser.add_argument("--game-output", type=Path, required=True, help="game_handoff output directory")
    parser.add_argument("--event", default="2026-08-26T02:52:10Z")
    args = parser.parse_args()
    result = build_outputs(
        args.inventory,
        args.nisar,
        args.cband,
        args.output,
        args.game_output,
        args.event,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
