"""Data-richness scouting modules."""
