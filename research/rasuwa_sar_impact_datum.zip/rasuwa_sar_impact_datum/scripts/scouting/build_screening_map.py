#!/usr/bin/env python3
"""Build a retrospective screening layer and transparent exposure proximity table."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from pathlib import Path

from pyproj import Transformer
from shapely.geometry import box, mapping, shape
from shapely.ops import transform as shapely_transform


def distance_band(distance_m: float) -> str:
    if distance_m < 1_000:
        return "0–1 km"
    if distance_m < 5_000:
        return "1–5 km"
    if distance_m < 20_000:
        return "5–20 km"
    return ">20 km"


def classify_osm_feature(properties: dict) -> str | None:
    feature_class = properties.get("class")
    name = " ".join(str(properties.get(key, "")) for key in ("name", "name:en")).lower()
    if any(token in name for token in ("hydro", "hydropower", "power house", "powerhouse")):
        return "hydropower_context"
    if properties.get("waterway") == "dam" or properties.get("water") == "reservoir":
        return "hydropower_context"
    if feature_class == "bridge":
        return "bridge"
    if feature_class == "settlement":
        return "settlement"
    return None


def build_outputs(
    osm_context_path: Path,
    detachment_path: Path,
    mask_summary_path: Path,
    nisar_findings_path: Path,
    exposure_output: Path,
    exposure_csv: Path,
    screening_output: Path,
) -> dict:
    osm = json.loads(osm_context_path.read_text(encoding="utf-8"))
    detachment_fc = json.loads(detachment_path.read_text(encoding="utf-8"))
    detachment_feature = detachment_fc["features"][0]
    detachment = shape(detachment_feature["geometry"])
    mask_summary = json.loads(mask_summary_path.read_text(encoding="utf-8"))
    nisar = json.loads(nisar_findings_path.read_text(encoding="utf-8"))
    transformer = Transformer.from_crs("EPSG:4326", "EPSG:32645", always_xy=True).transform
    detachment_utm = shapely_transform(transformer, detachment)

    retained = []
    csv_rows = []
    for feature in osm.get("features", []):
        properties = dict(feature.get("properties") or {})
        feature_type = classify_osm_feature(properties)
        if feature_type is None:
            continue
        geometry = shape(feature["geometry"])
        distance_m = float(shapely_transform(transformer, geometry).distance(detachment_utm))
        if distance_m >= 20_000:
            continue
        properties.update(
            {
                "screening_feature_type": feature_type,
                "distance_to_preliminary_detachment_m": round(distance_m, 1),
                "distance_band": distance_band(distance_m),
                "proximity_limit": "proximity is not population, damage, risk, or predicted impact",
                "provenance_label": "OSM context observation",
            }
        )
        retained.append({"type": "Feature", "id": feature.get("id"), "properties": properties, "geometry": feature["geometry"]})
        coordinates = list(geometry.coords)[0] if geometry.geom_type == "Point" else geometry.centroid.coords[0]
        csv_rows.append(
            {
                "osm_type": properties.get("osm_type", ""),
                "osm_id": properties.get("osm_id", ""),
                "name": properties.get("name:en") or properties.get("name") or "",
                "feature_type": feature_type,
                "longitude": coordinates[0],
                "latitude": coordinates[1],
                "distance_to_preliminary_detachment_m": round(distance_m, 1),
                "distance_band": distance_band(distance_m),
                "osm_base_timestamp": properties.get("osm_base_timestamp", ""),
                "osm_url": properties.get("osm_url", ""),
            }
        )

    retained.sort(key=lambda feature: feature["properties"]["distance_to_preliminary_detachment_m"])
    csv_rows.sort(key=lambda row: row["distance_to_preliminary_detachment_m"])
    exposure_fc = {
        "type": "FeatureCollection",
        "name": "Rasuwa retrospective exposure-proximity context within 20 km",
        "metadata": {
            "purpose": "context-only exposure screening",
            "warning": "proximity is not population, damage, risk, or predicted impact",
            "source": str(osm_context_path),
            "detachment_reference": str(detachment_path),
        },
        "features": retained,
    }
    exposure_output.parent.mkdir(parents=True, exist_ok=True)
    exposure_output.write_text(json.dumps(exposure_fc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    fields = [
        "osm_type",
        "osm_id",
        "name",
        "feature_type",
        "longitude",
        "latitude",
        "distance_to_preliminary_detachment_m",
        "distance_band",
        "osm_base_timestamp",
        "osm_url",
    ]
    with exposure_csv.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(csv_rows)

    within_5km = Counter(
        row["feature_type"] for row in csv_rows if row["distance_to_preliminary_detachment_m"] < 5_000
    )
    within_20km = Counter(row["feature_type"] for row in csv_rows)
    quiet = nisar["pairs"]["quiet"]["regions"]["source"]["gunw"]
    event = nisar["pairs"]["event"]["regions"]["source"]["gunw"]
    screening_features = [
        {
            "type": "Feature",
            "id": "cband-event-coherence-detachment",
            "properties": {
                "screening_rank": 1,
                "finding_type": "event-spanning localized coherence loss",
                "confidence": "medium-low",
                "precursor_deformation_validated": False,
                "target_filtered_anomaly_pixels": mask_summary["target_filtered_anomaly_pixels"],
                "target_valid_pixels": mask_summary["target_valid_pixels"],
                "control_filtered_false_alarm_pixels": mask_summary["control_filtered_false_alarm_pixels"],
                "control_valid_pixels": mask_summary["control_valid_pixels"],
                "threshold": mask_summary["threshold"],
                "mmu_area_km2": mask_summary["mmu_area_km2"],
                "exposure_context_within_5km": dict(within_5km),
                "exposure_context_within_20km": dict(within_20km),
                "source_products": [
                    "S1_180590_IW2_20260804T122147_VV_F90B-BURST",
                    "S1_180590_IW2_20260816T122147_VV_0444-BURST",
                    "S1_180590_IW2_20260828T122148_VV_93F8-BURST",
                ],
                "provenance_label": "observation-derived screening",
                "operational_limit": "retrospective screening only; not prediction, warning, or unique cause attribution",
            },
            "geometry": detachment_feature["geometry"],
        },
        {
            "type": "Feature",
            "id": "nisar-lband-source-decorrelation-window",
            "properties": {
                "screening_rank": 2,
                "finding_type": "event-pair L-band decorrelation and phase-coverage failure",
                "confidence": "high for failure diagnosis; low for event attribution",
                "precursor_deformation_validated": False,
                "quiet_coherence_median": quiet["coherence_median"],
                "event_coherence_median": event["coherence_median"],
                "quiet_phase_valid_pixels": quiet["phase_valid_pixels"],
                "event_phase_valid_pixels": event["phase_valid_pixels"],
                "total_pixels": event["sample_valid_pixels"],
                "source_products": [
                    nisar["pairs"]["quiet"]["products"]["gunw"]["product_id"],
                    nisar["pairs"]["event"]["products"]["gunw"]["product_id"],
                ],
                "provenance_label": "observation-derived diagnosed failure",
                "operational_limit": "no LOS displacement, velocity, precursor, or prediction is reported",
            },
            "geometry": mapping(box(85.511, 28.282, 85.531, 28.297)),
        },
    ]
    screening_fc = {
        "type": "FeatureCollection",
        "name": "Rasuwa non-operational SAR screening findings",
        "metadata": {
            "validated_precursor_feature_count": 0,
            "event_spanning_change_feature_count": 1,
            "diagnosed_failure_feature_count": 1,
            "warning": "Ranks order evidence confidence for retrospective review, not failure probability or urgency.",
        },
        "features": screening_features,
    }
    screening_output.parent.mkdir(parents=True, exist_ok=True)
    screening_output.write_text(json.dumps(screening_fc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {
        "exposure_features_within_20km": len(retained),
        "exposure_types_within_5km": dict(within_5km),
        "exposure_types_within_20km": dict(within_20km),
        "screening_features": len(screening_features),
        "validated_precursor_features": 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Build retrospective screening and exposure-proximity layers.")
    parser.add_argument("--osm-context", type=Path, required=True)
    parser.add_argument("--detachment", type=Path, required=True)
    parser.add_argument("--mask-summary", type=Path, required=True)
    parser.add_argument("--nisar-findings", type=Path, required=True)
    parser.add_argument("--exposure-output", type=Path, required=True)
    parser.add_argument("--exposure-csv", type=Path, required=True)
    parser.add_argument("--screening-output", type=Path, required=True)
    args = parser.parse_args()
    result = build_outputs(
        args.osm_context,
        args.detachment,
        args.mask_summary,
        args.nisar_findings,
        args.exposure_output,
        args.exposure_csv,
        args.screening_output,
    )
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
