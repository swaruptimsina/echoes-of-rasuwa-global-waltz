"""HydroBASINS topology helpers for the expanded Rasuwa AOI."""
from __future__ import annotations


def upstream_ids(next_down: dict[int, int], outlet_id: int) -> set[int]:
    """Return all basin IDs whose downstream chain reaches outlet_id, including it."""
    reverse: dict[int, list[int]] = {}
    for basin_id, downstream_id in next_down.items():
        reverse.setdefault(int(downstream_id), []).append(int(basin_id))
    selected: set[int] = set()
    stack = [int(outlet_id)]
    while stack:
        basin_id = stack.pop()
        if basin_id in selected:
            continue
        selected.add(basin_id)
        stack.extend(reverse.get(basin_id, []))
    return selected


def downstream_chain(next_down: dict[int, int], start_id: int, stop_id: int | None = None) -> list[int]:
    """Follow NEXT_DOWN until zero/missing or an explicit stop, rejecting cycles."""
    chain: list[int] = []
    seen: set[int] = set()
    current = int(start_id)
    while current:
        if current in seen:
            raise ValueError(f"cycle detected at basin {current}")
        seen.add(current)
        chain.append(current)
        if stop_id is not None and current == int(stop_id):
            return chain
        current = int(next_down.get(current, 0) or 0)
    if stop_id is not None:
        raise ValueError(f"stop basin {stop_id} is not downstream of {start_id}")
    return chain
