#!/usr/bin/env python3
"""Build the HydroBASINS/HydroRIVERS-justified Rasuwa connected-system AOI."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import geopandas as gpd
from shapely.geometry import Point, mapping

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from scripts.core import sha256_file
from scripts.scouting.aoi import downstream_chain, upstream_ids

ROOT = Path(__file__).resolve().parents[2]
HYBAS = ROOT / "data/scouting/hydrography/raw/hybas_l8/hybas_as_lev08_v1c.shp"
RIVERS = ROOT / "data/scouting/hydrography/raw/hydrorivers/HydroRIVERS_v10_as_shp/HydroRIVERS_v10_as.shp"
COUNTRIES = ROOT / "data/scouting/hydrography/raw/naturalearth_admin0/ne_10m_admin_0_countries.shp"
OUT = ROOT / "data/scouting/aoi"
OUTLET_BASIN = 4080835120  # contains Betrawati/Rasuwagadhi reach at HydroBASINS level 8
DEVGHAT_BASIN = 4080843520
RASUWAGADHI_REACH = 40771762
DEVGHAT_REACH = 40806527
ANALYSIS_CRS = "EPSG:32645"
SOURCES = {
    "hydrobasins": "https://data.hydrosheds.org/file/hydrobasins/standard/hybas_as_lev08_v1c.zip",
    "hydrorivers": "https://data.hydrosheds.org/file/HydroRIVERS/HydroRIVERS_v10_as_shp.zip",
    "countries": "https://naturalearth.s3.amazonaws.com/10m_cultural/ne_10m_admin_0_countries.zip",
}
SUBAREA_SPECS = [
    ("langtang_lirung_source", "Langtang Lirung 2026 source slopes", 85.528066, 28.291242, 8000, "Government-mapped 2026 source"),
    ("purepu_lhende_headwaters", "Purepu/Lhende cross-border headwaters", 85.6469, 28.4043, 12000, "DHM 2025 supraglacial-lake coordinate"),
    ("rasuwagadhi_timure", "Rasuwagadhi–Timure border gorge", 85.3777789, 28.2777749, 7000, "OSM/Nominatim Rasuwagadhi node"),
    ("betrawati_bidur", "Betrawati–Bidur Trishuli corridor", 85.1859528, 27.9731085, 7000, "OSM/Nominatim Betrawati node"),
    ("galchhi", "Galchhi Trishuli corridor", 85.0004606, 27.7973963, 7000, "OSM/Nominatim Galchhi node"),
    ("malekhu", "Malekhu Trishuli corridor", 84.82724, 27.813705, 7000, "OSM/Nominatim Malekhu node"),
]


def write_geojson(gdf: gpd.GeoDataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    gdf.to_file(path, driver="GeoJSON")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    basins = gpd.read_file(HYBAS)
    next_down = {int(a): int(b) for a, b in zip(basins.HYBAS_ID, basins.NEXT_DOWN)}
    core_ids = upstream_ids(next_down, OUTLET_BASIN)
    corridor_ids = downstream_chain(next_down, OUTLET_BASIN, DEVGHAT_BASIN)
    selected_ids = core_ids | set(corridor_ids)
    selected = basins[basins.HYBAS_ID.isin(selected_ids)].copy()
    projected = selected.to_crs(ANALYSIS_CRS)
    connected_geometry = projected.geometry.union_all().buffer(0)
    connected = gpd.GeoDataFrame(
        [{
            "aoi_id": "rasuwa_connected_system_v1",
            "method": "HydroBASINS L8 upstream topology to Betrawati/Rasuwagadhi basin plus incremental downstream basin chain to Devghat",
            "core_ids": "|".join(str(value) for value in sorted(core_ids)),
            "corridor_ids": "|".join(str(value) for value in corridor_ids),
            "area_km2": connected_geometry.area / 1_000_000.0,
            "geometry": connected_geometry,
        }],
        crs=ANALYSIS_CRS,
    ).to_crs(4326)
    write_geojson(connected, OUT / "rasuwa_connected_system.geojson")
    write_geojson(selected.to_crs(4326), OUT / "hydrobasins_selected.geojson")

    river_subset = gpd.read_file(RIVERS, bbox=tuple(connected.total_bounds))
    river_next = {int(a): int(b) for a, b in zip(river_subset.HYRIV_ID, river_subset.NEXT_DOWN)}
    river_ids = downstream_chain(river_next, RASUWAGADHI_REACH, DEVGHAT_REACH)
    mainstem = river_subset[river_subset.HYRIV_ID.isin(river_ids)].copy()
    write_geojson(mainstem, OUT / "rasuwagadhi_to_devghat_mainstem.geojson")

    aoi_projected = connected.to_crs(ANALYSIS_CRS).geometry.iloc[0]
    subarea_rows = []
    for site_id, name, lon, lat, radius_m, source in SUBAREA_SPECS:
        point = gpd.GeoSeries([Point(lon, lat)], crs=4326).to_crs(ANALYSIS_CRS).iloc[0]
        geometry = point.buffer(radius_m).intersection(aoi_projected)
        subarea_rows.append({
            "site_id": site_id,
            "name": name,
            "center_lon": lon,
            "center_lat": lat,
            "radius_m": radius_m,
            "coordinate_source": source,
            "area_km2": geometry.area / 1_000_000.0,
            "geometry": geometry,
        })
    subareas = gpd.GeoDataFrame(subarea_rows, crs=ANALYSIS_CRS).to_crs(4326)
    write_geojson(subareas, OUT / "subareas.geojson")

    countries = gpd.read_file(COUNTRIES)
    name_field = "ADM0_A3"
    countries = countries[countries[name_field].isin(["NPL", "CHN"])].to_crs(ANALYSIS_CRS)
    country_areas = {}
    for _, row in countries.iterrows():
        country_areas[row[name_field]] = row.geometry.intersection(connected_geometry).area / 1_000_000.0
    classified = sum(country_areas.values())

    metadata = {
        "aoi_id": "rasuwa_connected_system_v1",
        "generated_from": SOURCES,
        "source_files": {
            "hydrobasins_zip_sha256": sha256_file(ROOT / "data/scouting/hydrography/raw/hybas_as_lev08_v1c.zip"),
            "hydrorivers_zip_sha256": sha256_file(ROOT / "data/scouting/hydrography/raw/HydroRIVERS_v10_as_shp.zip"),
            "naturalearth_zip_sha256": sha256_file(ROOT / "data/scouting/hydrography/raw/ne_10m_admin_0_countries.zip"),
        },
        "topology": {
            "outlet_basin_id": OUTLET_BASIN,
            "devghat_basin_id": DEVGHAT_BASIN,
            "core_upstream_basin_ids": sorted(core_ids),
            "downstream_basin_chain": corridor_ids,
            "selected_basin_count": len(selected_ids),
            "mainstem_start_reach": RASUWAGADHI_REACH,
            "mainstem_end_reach": DEVGHAT_REACH,
            "mainstem_reach_count": len(river_ids),
            "mainstem_length_km": float(mainstem.LENGTH_KM.sum()),
        },
        "geometry": {
            "crs": "EPSG:4326",
            "analysis_crs": ANALYSIS_CRS,
            "area_km2": connected_geometry.area / 1_000_000.0,
            "bbox_wsen": connected.total_bounds.tolist(),
            "country_intersection_km2": country_areas,
            "country_classified_fraction": classified / (connected_geometry.area / 1_000_000.0),
        },
        "subarea_count": len(subareas),
        "files": {
            name: {"path": str(path), "sha256": sha256_file(path)}
            for name, path in {
                "aoi": OUT / "rasuwa_connected_system.geojson",
                "basins": OUT / "hydrobasins_selected.geojson",
                "mainstem": OUT / "rasuwagadhi_to_devghat_mainstem.geojson",
                "subareas": OUT / "subareas.geojson",
            }.items()
        },
        "limitations": [
            "HydroBASINS level 8 generalizes drainage boundaries and may not resolve glacier-scale divides.",
            "Downstream AOI uses only incremental basins on the Trishuli/Narayani main chain; large tributary headwaters are intentionally excluded.",
            "Natural Earth country boundaries are cartographic, not a legal border survey.",
            "Circular subareas are analysis windows clipped to the hydrologic AOI, not hazard polygons.",
        ],
    }
    (OUT / "aoi_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
