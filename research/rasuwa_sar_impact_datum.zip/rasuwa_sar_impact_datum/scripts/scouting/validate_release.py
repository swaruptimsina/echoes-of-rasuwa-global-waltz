#!/usr/bin/env python3
"""Validate the complete local research release and emit a machine report."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_csv_manifest_hashes(root: Path, manifest_path: Path) -> list[str]:
    failures = []
    with manifest_path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            path = root / row["path"]
            if not path.is_file():
                failures.append(f"missing file: {row['path']}")
            elif sha256_file(path) != row["sha256"]:
                failures.append(f"hash mismatch: {row['path']}")
    return failures


def verify_game_manifest(root: Path) -> list[str]:
    failures = []
    manifest_path = root / "provenance.json"
    payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    listed = {item["file"]: item for item in payload.get("assets", [])}
    actual = {
        str(path.relative_to(root))
        for path in root.rglob("*")
        if path.is_file() and path.name != "provenance.json"
    }
    if set(listed) != actual:
        failures.append(f"game asset set mismatch: listed={len(listed)} actual={len(actual)}")
    if payload.get("asset_count") != len(listed):
        failures.append("game asset_count does not match enumerated assets")
    for relative, item in listed.items():
        path = root / relative
        if path.is_file() and sha256_file(path) != item.get("sha256"):
            failures.append(f"game hash mismatch: {relative}")
        if item.get("provenance_label", "").startswith("unclassified"):
            failures.append(f"unclassified game asset: {relative}")
    return failures


def credential_hits(root: Path) -> list[str]:
    patterns = [
        re.compile(r"X-Amz-(?:Signature|Credential|Security-Token)=", re.I),
        re.compile(r"CloudFront-(?:Policy|Signature|Key-Pair-Id)=", re.I),
        re.compile(r"Authorization:\s*Bearer\s+[A-Za-z0-9._~+/-]{20,}", re.I),
        re.compile(r"machine\s+urs\.earthdata\.nasa\.gov\s+login\s+\S+\s+password\s+\S+", re.I),
        re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
        re.compile(r"EARTHDATA_TOKEN\s*=\s*['\"]?[A-Za-z0-9._~-]{20,}", re.I),
    ]
    include_roots = [root / "scripts", root / "data", root / "game_handoff"]
    text_suffixes = {".py", ".sh", ".md", ".txt", ".json", ".csv", ".geojson", ".yaml", ".yml", ".toml"}
    hits = []
    for base in include_roots:
        if not base.exists():
            continue
        for path in base.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in text_suffixes:
                continue
            try:
                with path.open(encoding="utf-8", errors="ignore") as handle:
                    for line_number, line in enumerate(handle, 1):
                        if any(pattern.search(line) for pattern in patterns):
                            hits.append(f"{path.relative_to(root)}:{line_number}")
            except OSError as exc:
                hits.append(f"scan error {path.relative_to(root)}: {exc}")
    return hits


def validate_release(root: Path) -> dict:
    failures = []
    checks = {}

    required = [
        "FINDINGS.md",
        "site_selection.md",
        "AGENCY_BRIEF.md",
        "METHOD_CARD.md",
        "methods.md",
        "negative_results.md",
        "limitations.md",
        "expert_review_questions.md",
        "inventory.csv",
        "data/manifest.csv",
        "game_handoff/provenance.json",
    ]
    missing_required = [path for path in required if not (root / path).is_file()]
    checks["required_files_missing"] = missing_required
    failures.extend(f"missing required file: {path}" for path in missing_required)

    data_manifest = root / "data/manifest.csv"
    manifest_failures = verify_csv_manifest_hashes(root / "data", data_manifest)
    checks["data_manifest_hash_failures"] = manifest_failures
    failures.extend(manifest_failures)
    with data_manifest.open(newline="", encoding="utf-8") as handle:
        manifest_rows = list(csv.DictReader(handle))
    geotiffs = [row for row in manifest_rows if row.get("file_type") == "GeoTIFF"]
    required_geotiff_fields = (
        "sha256",
        "provenance_label",
        "source_granule_ids",
        "source_url",
        "processing_parameters",
        "crs",
        "shape",
        "nodata",
    )
    incomplete_geotiffs = [
        row["path"]
        for row in geotiffs
        if any(not row.get(field, "") for field in required_geotiff_fields)
    ]
    checks["manifest_rows"] = len(manifest_rows)
    checks["geotiff_rows"] = len(geotiffs)
    checks["incomplete_geotiff_rows"] = incomplete_geotiffs
    failures.extend(f"incomplete GeoTIFF manifest row: {path}" for path in incomplete_geotiffs)

    game_failures = verify_game_manifest(root / "game_handoff")
    checks["game_manifest_failures"] = game_failures
    failures.extend(game_failures)

    with (root / "inventory.csv").open(newline="", encoding="utf-8") as handle:
        inventory_rows = list(csv.DictReader(handle))
    inventory_ids = [row["inventory_id"] for row in inventory_rows]
    exact_summary = json.loads((root / "data/scouting/inventory/exact_filter_summary.json").read_text(encoding="utf-8"))
    checks["inventory_rows"] = len(inventory_rows)
    checks["inventory_unique_ids"] = len(set(inventory_ids))
    checks["inventory_summary_rows"] = exact_summary.get("exact_aoi_rows")
    checks["inventory_unparsed_spatial_rows"] = exact_summary.get("unparsed_spatial_rows")
    if len(inventory_rows) != len(set(inventory_ids)):
        failures.append("inventory IDs are not unique")
    if len(inventory_rows) != exact_summary.get("exact_aoi_rows"):
        failures.append("inventory row count disagrees with exact-filter summary")
    if exact_summary.get("unparsed_spatial_rows") != 0:
        failures.append("inventory contains unparsed spatial rows")
    if sha256_file(root / "inventory.csv") != sha256_file(root / "data/scouting/inventory/inventory.csv"):
        failures.append("root and data/scouting inventory copies differ")

    nisar_verification = json.loads(
        (root / "data/processed/nisar_lband/outputs/verification.json").read_text(encoding="utf-8")
    )
    checks["nisar_verification_status"] = nisar_verification.get("status")
    if nisar_verification.get("status") != "PASS":
        failures.append("NISAR output verification is not PASS")

    hyp3_status = json.loads((root / "data/processed/s1d_hyp3/job_status_final.json").read_text(encoding="utf-8"))
    hyp3_jobs = hyp3_status.get("jobs", hyp3_status.get("results", []))
    status_values = [job.get("status_code") or job.get("status") for job in hyp3_jobs]
    checks["hyp3_job_statuses"] = status_values
    if status_values and any(status != "SUCCEEDED" for status in status_values):
        failures.append(f"HyP3 job not succeeded: {status_values}")

    screening = json.loads((root / "data/scouting/impact/hazard_screening.geojson").read_text(encoding="utf-8"))
    precursor_count = screening.get("metadata", {}).get("validated_precursor_feature_count")
    checks["validated_precursor_feature_count"] = precursor_count
    if precursor_count != 0:
        failures.append("screening precursor count is not the expected honest zero")

    hooks = json.loads((root / "game_handoff/story_hooks.json").read_text(encoding="utf-8"))
    bad_hooks = [item.get("id", "") for item in hooks if len(item.get("sentences", [])) != 3]
    checks["story_hook_count"] = len(hooks)
    checks["story_hooks_not_three_sentences"] = bad_hooks
    failures.extend(f"story hook does not have three sentences: {item}" for item in bad_hooks)

    secret_hits = credential_hits(root)
    checks["credential_or_signed_url_hits"] = secret_hits
    failures.extend(f"credential/signed URL pattern: {item}" for item in secret_hits)

    return {
        "status": "PASS" if not failures else "FAIL",
        "failures": failures,
        "checks": checks,
        "data_manifest_sha256": sha256_file(data_manifest),
        "game_manifest_sha256": sha256_file(root / "game_handoff/provenance.json"),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate the Rasuwa research release.")
    parser.add_argument("--root", type=Path, default=Path("."))
    parser.add_argument("--output", type=Path, default=Path("release_validation.json"))
    args = parser.parse_args()
    result = validate_release(args.root.resolve())
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
