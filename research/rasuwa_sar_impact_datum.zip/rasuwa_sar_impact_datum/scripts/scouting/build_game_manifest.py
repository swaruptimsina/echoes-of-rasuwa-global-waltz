#!/usr/bin/env python3
"""Build a complete checksum/provenance manifest for game handoff assets."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def classify_asset(path: Path) -> str:
    name = path.name.lower()
    if name.startswith("acquisition_timeline") or name.startswith("latency_table"):
        return "catalog observation"
    if name.startswith("lband_coherence") or name.startswith("cband_coherence"):
        return "observation-derived visualization"
    if name.startswith("coherence_loss_screening_mask") or name.startswith("hazard_screening"):
        return "model output from observations"
    if name.startswith("sar_change_overlay") or name == "change_mask.json":
        return "model output from observations"
    if name in {"l_vs_c_coherence.json", "subtle_change_results.json"}:
        return "observation-derived analysis"
    if name == "story_hooks.json":
        return "narrative derived from observations"
    if name in {"connected_system_aoi.geojson", "subareas.geojson"}:
        return "model/context geometry"
    if name.startswith("exposure_context") or name.startswith("rainfall_timeseries"):
        return "observation/model context"
    if name == "readme.md":
        return "documentation"
    return "unclassified—review required"


def interpretation_limit(label: str) -> str:
    limits = {
        "catalog observation": "Acquisition and archive timestamps are not warning time or delivery guarantees.",
        "observation-derived visualization": "Rendered observables are not unique physical classes, displacement, or prediction.",
        "model output from observations": "Retrospective screening output; not hazard probability, unsafe terrain, or warning.",
        "observation-derived analysis": "Descriptive research comparison with the limitations carried in the file.",
        "narrative derived from observations": "Use all three sentences together; do not extract a predictive claim.",
        "model/context geometry": "Analysis/context boundary; not a legal, hazard, inundation, or jurisdiction boundary.",
        "observation/model context": "Context only; proximity or coarse grids are not local risk or field measurement.",
        "documentation": "Read before using any asset.",
        "unclassified—review required": "Do not publish until provenance is classified.",
    }
    return limits[label]


def build_manifest(root: Path) -> dict:
    assets = []
    for path in sorted(item for item in root.rglob("*") if item.is_file() and item.name != "provenance.json"):
        label = classify_asset(path)
        assets.append(
            {
                "file": str(path.relative_to(root)),
                "sha256": sha256_file(path),
                "bytes": path.stat().st_size,
                "provenance_label": label,
                "interpretation_limit": interpretation_limit(label),
            }
        )
    result = {
        "study": "26 August 2026 Rasuwa–Bhotekoshi event",
        "non_operational": True,
        "asset_count": len(assets),
        "assets": assets,
    }
    (root / "provenance.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Build game-handoff checksums and provenance labels.")
    parser.add_argument("--root", type=Path, default=Path("game_handoff"))
    args = parser.parse_args()
    result = build_manifest(args.root)
    print(json.dumps({"root": str(args.root), "asset_count": result["asset_count"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
