#!/usr/bin/env python3
"""Build a topology-led connected AOI for upper Trishuli system.

Inputs are retained under ../raw. Outputs are candidate—not official—AOI
products, with a narrow non-catchment corridor supplement kept separate.
"""
from __future__ import annotations

import collections
import csv
import hashlib
import json
import math
import os
import sqlite3
import struct
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parents[1]
os.environ.setdefault("MPLCONFIGDIR", str(ROOT / ".cache" / "matplotlib"))
os.environ.setdefault("XDG_CACHE_HOME", str(ROOT / ".cache"))
import sys
sys.path.insert(0, str(ROOT / "pydeps"))

import shapefile  # vendored pyshp 3.1.8
import numpy as np
import rasterio
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from pyproj import CRS, Geod, Transformer
from rasterio.enums import Resampling
from rasterio.features import geometry_mask
from rasterio.merge import merge as raster_merge
from shapely import from_wkb, make_valid
from shapely.geometry import (
    GeometryCollection,
    LineString,
    MultiLineString,
    MultiPolygon,
    Point,
    Polygon,
    mapping,
    shape,
)
from shapely.ops import transform as shapely_transform
from shapely.ops import unary_union

RAW = ROOT / "raw"
OUT = ROOT / "outputs"
INTERMEDIATE = ROOT / "intermediate"
OUT.mkdir(parents=True, exist_ok=True)
INTERMEDIATE.mkdir(parents=True, exist_ok=True)

GENERATED_UTC = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
GEOD = Geod(ellps="WGS84")
NODATA = -9999.0

HYBAS_SHP = RAW / "hybas_as_lev12" / "hybas_as_lev12_v1c"
POUR_SHP = RAW / "hybas_pour_lev12" / "hybas_pour_lev12_v1"
RIVERS_SHP = RAW / "hydrorivers_as" / "HydroRIVERS_v10_as_shp" / "HydroRIVERS_v10_as"
NE_COUNTRIES_SHP = RAW / "ne_10m_admin_0_countries" / "ne_10m_admin_0_countries"
GLO_GPKG = RAW / "GLO_S2_2017_2024_unique_lakes_v1.02.gpkg"
DEM_PATHS = sorted(RAW.glob("Copernicus_DSM_COG_10_*_DEM.tif"))

# The level-12 unit whose official pour point lies on the Trishuli immediately
# upstream of its shared downstream unit with the Tadi Khola branch.
SYSTEM_OUTLET_HYBAS = 4120833490
KYIRONG_OUTLET_HYBAS = 4120821280
LHENDE_OUTLET_HYBAS = 4120821290
LANGTANG_OUTLET_HYBAS = 4120825270
UPPER_CORRIDOR_CONTROL_HYBAS = 4120827620
COMBINED_BORDER_HYBAS = 4120824370
TADI_OUTLET_HYBAS = 4120833730
DOWNSTREAM_CONFLUENCE_HYBAS = 4120835140


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def md5(path: Path) -> str:
    h = hashlib.md5()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def file_timestamp(path: Path) -> str:
    return datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).replace(microsecond=0).isoformat()


def polygonal(geom):
    """Repair a geometry and retain only polygonal components."""
    if geom.is_empty:
        return geom
    geom = make_valid(geom)
    if isinstance(geom, (Polygon, MultiPolygon)):
        return geom
    if isinstance(geom, GeometryCollection):
        polys = []
        for g in geom.geoms:
            if isinstance(g, Polygon):
                polys.append(g)
            elif isinstance(g, MultiPolygon):
                polys.extend(g.geoms)
        return unary_union(polys) if polys else Polygon()
    return Polygon()


def geodesic_area_km2(geom) -> float:
    if geom.is_empty:
        return 0.0
    area, _ = GEOD.geometry_area_perimeter(geom)
    return abs(area) / 1_000_000.0


def fc(features: list[dict[str, Any]], name: str, metadata: dict[str, Any] | None = None) -> dict[str, Any]:
    obj: dict[str, Any] = {"type": "FeatureCollection", "name": name, "features": features}
    if metadata:
        obj["metadata"] = metadata
    return obj


def feat(geom, props: dict[str, Any]) -> dict[str, Any]:
    return {"type": "Feature", "properties": props, "geometry": mapping(geom)}


def write_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write("\n")


def collect_upstream(start: int, children: dict[int, list[int]]) -> set[int]:
    selected: set[int] = set()
    stack = [start]
    while stack:
        hid = stack.pop()
        if hid in selected:
            continue
        selected.add(hid)
        stack.extend(children.get(hid, []))
    return selected


def iter_polygons(geom):
    if isinstance(geom, Polygon):
        yield geom
    elif isinstance(geom, MultiPolygon):
        yield from geom.geoms


def iter_lines(geom):
    if isinstance(geom, LineString):
        yield geom
    elif isinstance(geom, MultiLineString):
        yield from geom.geoms
    elif isinstance(geom, GeometryCollection):
        for g in geom.geoms:
            yield from iter_lines(g)


def load_hydrobasins():
    reader = shapefile.Reader(str(HYBAS_SHP))
    records: dict[int, dict[str, Any]] = {}
    children: dict[int, list[int]] = collections.defaultdict(list)
    for record in reader.iterRecords():
        d = record.as_dict()
        hid = int(d["HYBAS_ID"])
        d = {k: (int(v) if k in {"HYBAS_ID", "NEXT_DOWN", "NEXT_SINK", "MAIN_BAS", "PFAF_ID", "ENDO", "COAST", "ORDER", "SORT"} else float(v)) for k, v in d.items()}
        records[hid] = d
        children[int(d["NEXT_DOWN"])].append(hid)

    full_ids = collect_upstream(SYSTEM_OUTLET_HYBAS, children)
    kyirong_ids = collect_upstream(KYIRONG_OUTLET_HYBAS, children)
    lhende_ids = collect_upstream(LHENDE_OUTLET_HYBAS, children)
    langtang_ids = collect_upstream(LANGTANG_OUTLET_HYBAS, children)
    upper_ids = collect_upstream(UPPER_CORRIDOR_CONTROL_HYBAS, children)
    corridor_ids = upper_ids - kyirong_ids - lhende_ids - langtang_ids
    lower_ids = full_ids - upper_ids

    named_sets = collections.OrderedDict(
        [
            (
                "kyirong_headwaters",
                {
                    "name": "Kyirong Tsangpo cross-border headwaters",
                    "short_name": "Kyirong headwaters",
                    "ids": kyirong_ids,
                    "control_hybas_id": KYIRONG_OUTLET_HYBAS,
                    "kind": "tributary catchment",
                },
            ),
            (
                "lhende_chhochen_headwaters",
                {
                    "name": "Lhende–Chhochen glaciated headwaters",
                    "short_name": "Lhende–Chhochen",
                    "ids": lhende_ids,
                    "control_hybas_id": LHENDE_OUTLET_HYBAS,
                    "kind": "tributary catchment",
                },
            ),
            (
                "langtang_khola",
                {
                    "name": "Langtang Khola headwaters and valley",
                    "short_name": "Langtang Khola",
                    "ids": langtang_ids,
                    "control_hybas_id": LANGTANG_OUTLET_HYBAS,
                    "kind": "tributary catchment",
                },
            ),
            (
                "rasuwa_upper_corridor",
                {
                    "name": "Rasuwagadhi–Syabrubesi–Dhunche corridor and local slopes",
                    "short_name": "Rasuwa upper corridor",
                    "ids": corridor_ids,
                    "control_hybas_id": UPPER_CORRIDOR_CONTROL_HYBAS,
                    "kind": "incremental interbasin partition",
                },
            ),
            (
                "lower_trishuli_corridor",
                {
                    "name": "Mailung–Betrawati–Bidur lower upper-Trishuli corridor and slopes",
                    "short_name": "Lower upper-Trishuli corridor",
                    "ids": lower_ids,
                    "control_hybas_id": SYSTEM_OUTLET_HYBAS,
                    "kind": "incremental interbasin partition",
                },
            ),
        ]
    )

    all_parts = [set(v["ids"]) for v in named_sets.values()]
    assert set().union(*all_parts) == full_ids
    for i, a in enumerate(all_parts):
        for b in all_parts[i + 1 :]:
            assert not (a & b)

    unit_geoms: dict[int, Any] = {}
    bbox = [84.85, 27.80, 85.90, 29.08]
    for sr in reader.iterShapeRecords(bbox=bbox):
        hid = int(sr.record["HYBAS_ID"])
        if hid in full_ids or hid in {TADI_OUTLET_HYBAS, DOWNSTREAM_CONFLUENCE_HYBAS}:
            unit_geoms[hid] = polygonal(shape(sr.shape.__geo_interface__))
    missing = full_ids - unit_geoms.keys()
    assert not missing, f"Missing HydroBASINS geometries: {sorted(missing)}"

    full_geom = polygonal(unary_union([unit_geoms[i] for i in full_ids]))
    for value in named_sets.values():
        value["geometry"] = polygonal(unary_union([unit_geoms[i] for i in value["ids"]]))
    return records, children, full_ids, named_sets, unit_geoms, full_geom


def load_pour_points(ids: Iterable[int]) -> dict[int, tuple[float, float]]:
    wanted = set(ids)
    found: dict[int, tuple[float, float]] = {}
    reader = shapefile.Reader(str(POUR_SHP))
    for sr in reader.iterShapeRecords(bbox=[84.8, 27.75, 85.9, 29.1]):
        hid = int(sr.record["HYBAS_ID"])
        if hid in wanted and hid not in found:
            x, y = sr.shape.points[0]
            found[hid] = (float(x), float(y))
    missing = wanted - found.keys()
    assert not missing, f"Missing pour points: {sorted(missing)}"
    return found


def load_natural_earth_countries() -> dict[str, Any]:
    result: dict[str, Any] = {}
    reader = shapefile.Reader(str(NE_COUNTRIES_SHP))
    for sr in reader.iterShapeRecords(bbox=[84.0, 27.0, 86.5, 30.0]):
        d = sr.record.as_dict()
        code = d.get("ADM0_A3")
        if code in {"NPL", "CHN"}:
            result[code] = polygonal(shape(sr.shape.__geo_interface__))
    assert set(result) == {"NPL", "CHN"}
    return result


def load_geoboundaries_comparison() -> dict[str, Any]:
    out = {}
    for code in ("NPL", "CHN"):
        data = json.loads((RAW / f"geoboundaries_{code}_ADM0.geojson").read_text(encoding="utf-8"))
        out[code] = polygonal(unary_union([shape(f["geometry"]) for f in data["features"]]))
    return out


def merge_dem(full_geom):
    assert len(DEM_PATHS) == 5, f"Expected five Copernicus tiles, found {len(DEM_PATHS)}"
    sources = [rasterio.open(p) for p in DEM_PATHS]
    try:
        arr3, transform = raster_merge(sources, bounds=full_geom.bounds, nodata=NODATA, dtype="float32")
        arr = arr3[0]
        crs = sources[0].crs
        tile_meta = []
        for p, src in zip(DEM_PATHS, sources):
            tile_meta.append(
                {
                    "file": p.name,
                    "width": src.width,
                    "height": src.height,
                    "crs": str(src.crs),
                    "bounds": [float(v) for v in src.bounds],
                    "dtype": src.dtypes[0],
                    "nodata": src.nodata,
                    "transform": [float(v) for v in src.transform[:6]],
                }
            )
    finally:
        for src in sources:
            src.close()

    full_mask = geometry_mask([mapping(full_geom)], out_shape=arr.shape, transform=transform, invert=True)
    valid = full_mask & np.isfinite(arr) & (arr > -1000) & (arr < 9000)
    masked = np.where(valid, arr, NODATA).astype("float32")
    dem_out = OUT / "copernicus_glo30_connected_system_masked.tif"
    profile = {
        "driver": "GTiff",
        "height": arr.shape[0],
        "width": arr.shape[1],
        "count": 1,
        "dtype": "float32",
        "crs": crs,
        "transform": transform,
        "nodata": NODATA,
        "compress": "DEFLATE",
        "predictor": 3,
        "tiled": True,
        "blockxsize": 512,
        "blockysize": 512,
        "BIGTIFF": "IF_SAFER",
    }
    with rasterio.open(dem_out, "w", **profile) as dst:
        dst.write(masked, 1)
        factors = [f for f in (2, 4, 8, 16) if min(arr.shape) // f >= 64]
        dst.build_overviews(factors, Resampling.average)
        dst.update_tags(
            source="Copernicus DEM GLO-30 Public (2021 release via AWS open-data bucket)",
            aoi="candidate connected upper Bhote Koshi–Lhende–Langtang–Trishuli system",
            generated_utc=GENERATED_UTC,
            note="DSM masked to HydroBASINS-derived candidate; not a hydrologically conditioned DEM",
        )
    return arr, valid, transform, crs, tile_meta, dem_out


def dem_values_for_geom(arr, transform, geom) -> np.ndarray:
    mask = geometry_mask([mapping(geom)], out_shape=arr.shape, transform=transform, invert=True)
    valid = mask & np.isfinite(arr) & (arr > -1000) & (arr < 9000)
    return arr[valid]


def stats_for_values(vals: np.ndarray) -> dict[str, Any]:
    vals = vals.astype("float64", copy=False)
    return {
        "valid_pixel_count": int(vals.size),
        "min_m": round(float(np.min(vals)), 1),
        "p10_m": round(float(np.percentile(vals, 10)), 1),
        "median_m": round(float(np.median(vals)), 1),
        "mean_m": round(float(np.mean(vals)), 1),
        "p90_m": round(float(np.percentile(vals, 90)), 1),
        "max_m": round(float(np.max(vals)), 1),
        "pct_ge_3000m": round(float(np.mean(vals >= 3000) * 100), 2),
        "pct_ge_4000m": round(float(np.mean(vals >= 4000) * 100), 2),
        "pct_ge_5000m": round(float(np.mean(vals >= 5000) * 100), 2),
    }


def sample_dem(arr, transform, lon: float, lat: float) -> float | None:
    row, col = rasterio.transform.rowcol(transform, lon, lat)
    if 0 <= row < arr.shape[0] and 0 <= col < arr.shape[1]:
        val = float(arr[row, col])
        if math.isfinite(val) and -1000 < val < 9000:
            return round(val, 1)
    # Control points just downstream of the catchment can lie outside the
    # analytical mosaic bounds. Sample the retained source COGs directly.
    for path in DEM_PATHS:
        with rasterio.open(path) as src:
            if src.bounds.left <= lon <= src.bounds.right and src.bounds.bottom <= lat <= src.bounds.top:
                val = float(next(src.sample([(lon, lat)]))[0])
                if math.isfinite(val) and -1000 < val < 9000:
                    return round(val, 1)
    return None


def boundary_dem_stats(full_geom, outlet_xy, arr, transform):
    to_utm = Transformer.from_crs(4326, 32645, always_xy=True)
    to_wgs = Transformer.from_crs(32645, 4326, always_xy=True)
    geom_utm = shapely_transform(to_utm.transform, full_geom)
    outlet_utm = shapely_transform(to_utm.transform, Point(*outlet_xy))
    samples = []
    samples_excluding_outlet = []
    for poly in iter_polygons(geom_utm):
        line = poly.exterior
        for distance in np.arange(0, line.length, 1000.0):
            p_utm = line.interpolate(float(distance))
            p = shapely_transform(to_wgs.transform, p_utm)
            z = sample_dem(arr, transform, p.x, p.y)
            if z is None:
                continue
            samples.append(z)
            if p_utm.distance(outlet_utm) >= 5000.0:
                samples_excluding_outlet.append(z)
    result = stats_for_values(np.asarray(samples, dtype="float32"))
    result["spacing_m"] = 1000
    result["sample_count"] = len(samples)
    result["outlet_exclusion_radius_m"] = 5000
    result["excluding_outlet_neighbourhood"] = stats_for_values(np.asarray(samples_excluding_outlet, dtype="float32"))
    return result


def gpkg_geometry(blob: bytes):
    if blob[:2] != b"GP":
        raise ValueError("Not a GeoPackage geometry blob")
    flags = blob[3]
    envelope_code = (flags >> 1) & 0x07
    envelope_bytes = {0: 0, 1: 32, 2: 48, 3: 48, 4: 64}.get(envelope_code)
    if envelope_bytes is None:
        raise ValueError(f"Unsupported GeoPackage envelope code {envelope_code}")
    return from_wkb(blob[8 + envelope_bytes :])


def process_glo_lakes(full_geom, named_sets, arr, transform):
    con = sqlite3.connect(GLO_GPKG)
    table = "s2_20172024_ntb_gloid_uniquelakes_v1.02"
    srs_wkt = con.execute("SELECT definition FROM gpkg_spatial_ref_sys WHERE srs_id=102025").fetchone()[0]
    transformer = Transformer.from_crs(CRS.from_wkt(srs_wkt), 4326, always_xy=True)
    minx, miny, maxx, maxy = full_geom.bounds
    query = f'''SELECT fid, geom, GLO_ID, COUNTRY, BASIN, CONNECTIVITY,
                       ELEVATION_MEAN, ELEVATION_MIN, ELEVATION_MEDIAN,
                       DATA_SOURCE, REF_MSTAT, LONGITUDE, LATITUDE,
                       EXPANSION_RATE, EXPANSION_UNCERTAINTY,
                       EXPANSION_RATE_SIG, AREA_DISSOLVED, PERIMETER_DISSOLVED
                FROM "{table}"
                WHERE LONGITUDE BETWEEN ? AND ? AND LATITUDE BETWEEN ? AND ?'''
    rows = con.execute(query, (minx, maxx, miny, maxy)).fetchall()
    con.close()
    features = []
    lake_geoms = []
    counters = {
        "country": collections.Counter(),
        "connectivity": collections.Counter(),
        "basin": collections.Counter(),
        "subarea": collections.Counter(),
    }
    area_total = 0.0
    significant_expansion = 0
    for row in rows:
        (
            fid,
            geom_blob,
            glo_id,
            country,
            basin,
            connectivity,
            elev_mean,
            elev_min,
            elev_median,
            data_source,
            ref_mstat,
            lon,
            lat,
            expansion_rate,
            expansion_uncertainty,
            expansion_rate_sig,
            area_dissolved,
            perimeter_dissolved,
        ) = row
        p = Point(float(lon), float(lat))
        if not full_geom.covers(p):
            continue
        geom_src = gpkg_geometry(geom_blob)
        geom_wgs = polygonal(shapely_transform(transformer.transform, geom_src))
        subarea_id = None
        for sid, item in named_sets.items():
            if item["geometry"].covers(p):
                subarea_id = sid
                break
        if subarea_id is None:
            # Boundary precision fallback; select the nearest sub-area.
            subarea_id = min(named_sets, key=lambda sid: named_sets[sid]["geometry"].distance(p))
        cop_z = sample_dem(arr, transform, float(lon), float(lat))
        delta = None if cop_z is None or elev_mean is None else round(cop_z - float(elev_mean), 1)
        props = {
            "glo_id": glo_id,
            "source_fid": int(fid),
            "country": country,
            "basin_label_source": basin,
            "connectivity": connectivity,
            "alos_elevation_mean_m": round(float(elev_mean), 1) if elev_mean is not None else None,
            "alos_elevation_min_m": round(float(elev_min), 1) if elev_min is not None else None,
            "alos_elevation_median_m": round(float(elev_median), 1) if elev_median is not None else None,
            "copernicus_centroid_elevation_m": cop_z,
            "copernicus_minus_alos_mean_m": delta,
            "longitude": float(lon),
            "latitude": float(lat),
            "data_source": data_source,
            "reference_match_status": ref_mstat,
            "area_dissolved_km2": round(float(area_dissolved), 6),
            "perimeter_dissolved_km": round(float(perimeter_dissolved), 6),
            "expansion_rate_km2_per_year": round(float(expansion_rate), 6) if expansion_rate is not None else None,
            "expansion_uncertainty_km2_per_year": round(float(expansion_uncertainty), 6) if expansion_uncertainty is not None else None,
            "expansion_rate_significant": expansion_rate_sig,
            "subarea_id": subarea_id,
            "membership_rule": "GLO representative coordinate within connected-system polygon",
            "source_url": "https://zenodo.org/api/records/19370146/files/S2_20172024_NTB_GLOID_UniqueLakes_v1.02.gpkg/content",
        }
        features.append(feat(geom_wgs, props))
        lake_geoms.append((geom_wgs, connectivity, p))
        counters["country"][country] += 1
        counters["connectivity"][connectivity] += 1
        counters["basin"][basin] += 1
        counters["subarea"][subarea_id] += 1
        area_total += float(area_dissolved)
        if str(expansion_rate_sig).upper() == "TRUE":
            significant_expansion += 1
    metadata = {
        "generated_utc": GENERATED_UTC,
        "source": "Glacial Lake Observatory v1.02 Sentinel-2 unique lake maximum extents, 2017–2024",
        "source_crs": "ESRI:102025",
        "output_crs": "RFC 7946 WGS 84 longitude/latitude",
        "selection": "representative GLO coordinate within candidate connected-system polygon",
        "limitations": "Maximum observed/dissolved extents, not one-date water surfaces; classification and seasonal/frozen-water limitations apply.",
    }
    write_json(OUT / "glacial_lakes_glo_s2_2017_2024.geojson", fc(features, "GLO lakes within candidate system", metadata))
    return {
        "feature_count": len(features),
        "candidate_rows_in_bbox": len(rows),
        "area_dissolved_sum_km2": round(area_total, 4),
        "significant_expansion_count": significant_expansion,
        **{k: dict(v) for k, v in counters.items()},
    }, lake_geoms


def load_hydrorivers(full_ids: set[int], full_geom):
    reader = shapefile.Reader(str(RIVERS_SHP))
    minx, miny, maxx, maxy = full_geom.bounds
    bbox = [minx - 0.25, miny - 0.15, maxx + 0.25, maxy + 0.15]
    local: dict[int, tuple[dict[str, Any], Any]] = {}
    selected: dict[int, tuple[dict[str, Any], Any]] = {}
    for sr in reader.iterShapeRecords(bbox=bbox):
        d0 = sr.record.as_dict()
        d: dict[str, Any] = {}
        for k, v in d0.items():
            if k in {"HYRIV_ID", "NEXT_DOWN", "MAIN_RIV", "ENDORHEIC", "ORD_STRA", "ORD_CLAS", "ORD_FLOW", "HYBAS_L12"}:
                d[k] = int(v)
            else:
                d[k] = float(v)
        rid = d["HYRIV_ID"]
        geom = shape(sr.shape.__geo_interface__)
        local[rid] = (d, geom)
        if d["HYBAS_L12"] in full_ids:
            selected[rid] = (d, geom)
    selected_ids = set(selected)
    egress = [rid for rid, (d, _) in selected.items() if d["NEXT_DOWN"] not in selected_ids and d["NEXT_DOWN"] != 0]
    egress_sorted = sorted(egress, key=lambda rid: selected[rid][0]["UPLAND_SKM"], reverse=True)
    assert egress_sorted, "No HydroRIVERS egress found"
    outlet_reach = egress_sorted[0]
    downstream = []
    next_id = selected[outlet_reach][0]["NEXT_DOWN"]
    cumulative = 0.0
    visited = set()
    while next_id and next_id in local and next_id not in visited and cumulative < 15.0:
        visited.add(next_id)
        d, g = local[next_id]
        downstream.append((d, g))
        cumulative += d["LENGTH_KM"]
        next_id = d["NEXT_DOWN"]

    river_features = []
    for rid, (d, geom) in selected.items():
        props = {k.lower(): v for k, v in d.items()}
        props["source"] = "HydroRIVERS v1.0 Asia"
        props["source_url"] = "https://data.hydrosheds.org/file/HydroRIVERS/HydroRIVERS_v10_as_shp.zip"
        river_features.append(feat(geom, props))
    write_json(
        OUT / "hydrorivers_connected_network.geojson",
        fc(
            river_features,
            "HydroRIVERS reaches within candidate system",
            {
                "generated_utc": GENERATED_UTC,
                "selection": "HYBAS_L12 belongs to upstream closure of outlet 4120833490",
                "crs": "WGS 84",
            },
        ),
    )

    extension_features = []
    for i, (d, geom) in enumerate(downstream, 1):
        props = {k.lower(): v for k, v in d.items()}
        props.update(
            {
                "extension_sequence": i,
                "supplement_only": True,
                "source": "HydroRIVERS v1.0 Asia",
                "source_url": "https://data.hydrosheds.org/file/HydroRIVERS/HydroRIVERS_v10_as_shp.zip",
            }
        )
        extension_features.append(feat(geom, props))
    write_json(
        OUT / "downstream_corridor_centerline.geojson",
        fc(
            extension_features,
            "Downstream HydroRIVERS centerline supplement",
            {
                "generated_utc": GENERATED_UTC,
                "warning": "Non-catchment context only; excluded from connected-system area.",
            },
        ),
    )

    downstream_line = unary_union([g for _, g in downstream]) if downstream else Point()
    to_utm = Transformer.from_crs(4326, 32645, always_xy=True)
    to_wgs = Transformer.from_crs(32645, 4326, always_xy=True)
    corridor_utm = shapely_transform(to_utm.transform, downstream_line).buffer(750.0)
    corridor = polygonal(shapely_transform(to_wgs.transform, corridor_utm))
    corridor_props = {
        "name": "Devighat downstream river-corridor supplement",
        "supplement_type": "HydroRIVERS centerline buffer",
        "buffer_m": 750,
        "downstream_centerline_length_km": round(cumulative, 3),
        "hydrorivers_reach_count": len(downstream),
        "included_in_catchment_area": False,
        "warning": "This is a non-catchment observation/infrastructure corridor, not a watershed polygon and not a hand-drawn box.",
        "source": "HydroRIVERS v1.0 Asia",
        "generated_utc": GENERATED_UTC,
    }
    write_json(OUT / "downstream_corridor_supplement.geojson", fc([feat(corridor, corridor_props)], "Downstream corridor supplement"))

    # Network checks: every selected reach should ultimately leave through an egress
    # or terminate at 0; cycles are counted explicitly.
    cycles = 0
    exits = collections.Counter()
    for rid in selected_ids:
        seen = set()
        cur = rid
        while cur in selected_ids:
            if cur in seen:
                cycles += 1
                break
            seen.add(cur)
            cur = selected[cur][0]["NEXT_DOWN"]
        exits[cur] += 1
    return (
        {
            "selected_reach_count": len(selected),
            "selected_length_km": round(sum(d["LENGTH_KM"] for d, _ in selected.values()), 2),
            "egress_reach_ids": egress_sorted,
            "egress_count": len(egress_sorted),
            "primary_outlet_reach_id": outlet_reach,
            "primary_outlet_upstream_area_km2": selected[outlet_reach][0]["UPLAND_SKM"],
            "cycles_detected": cycles,
            "terminal_exit_counts": {str(k): v for k, v in exits.items()},
            "downstream_extension_reach_count": len(downstream),
            "downstream_extension_length_km": round(cumulative, 3),
        },
        [g for _, g in selected.values()],
        corridor,
        downstream_line,
    )


def osm_point(element: dict[str, Any]) -> Point | None:
    if "lon" in element and "lat" in element:
        return Point(float(element["lon"]), float(element["lat"]))
    center = element.get("center") or {}
    if "lon" in center and "lat" in center:
        return Point(float(center["lon"]), float(center["lat"]))
    geom = element.get("geometry") or []
    if geom:
        return Point(
            sum(float(p["lon"]) for p in geom) / len(geom),
            sum(float(p["lat"]) for p in geom) / len(geom),
        )
    return None


def process_osm_context(full_geom, corridor_geom):
    context = json.loads((RAW / "osm_context_response.json").read_text(encoding="utf-8"))
    water = json.loads((RAW / "osm_water_response.json").read_text(encoding="utf-8"))
    footprint = polygonal(full_geom.union(corridor_geom))
    features = []
    counts = collections.Counter()
    key_tags = {
        "name",
        "name:en",
        "name:ne",
        "name:zh",
        "alt_name",
        "place",
        "bridge",
        "bridge:structure",
        "highway",
        "waterway",
        "natural",
        "water",
        "wikidata",
        "wikipedia",
        "damage:event",
        "destroyed:highway",
        "destroyed:natural",
        "ele",
    }
    for element in context.get("elements", []):
        tags = element.get("tags", {})
        if "bridge" in tags:
            klass = "bridge"
        elif "place" in tags:
            klass = "settlement"
        elif "waterway" in tags and tags.get("name"):
            klass = "named_waterway"
        else:
            continue
        p = osm_point(element)
        if p is None or not footprint.covers(p):
            continue
        within_catchment = full_geom.covers(p)
        props = {k: v for k, v in tags.items() if k in key_tags}
        props.update(
            {
                "class": klass,
                "osm_type": element["type"],
                "osm_id": int(element["id"]),
                "osm_url": f"https://www.openstreetmap.org/{element['type']}/{element['id']}",
                "within_catchment": within_catchment,
                "corridor_supplement_only": bool(not within_catchment and corridor_geom.covers(p)),
                "geometry_note": "OSM element centre; not original line/polygon geometry",
                "osm_base_timestamp": context.get("osm3s", {}).get("timestamp_osm_base"),
            }
        )
        features.append(feat(p, props))
        counts[klass] += 1

    # Named OSM water bodies are included as centre points for toponyms only.
    for element in water.get("elements", []):
        tags = element.get("tags", {})
        if not tags.get("name"):
            continue
        p = osm_point(element)
        if p is None or not footprint.covers(p):
            continue
        within_catchment = full_geom.covers(p)
        props = {k: v for k, v in tags.items() if k in key_tags}
        props.update(
            {
                "class": "named_waterbody",
                "osm_type": element["type"],
                "osm_id": int(element["id"]),
                "osm_url": f"https://www.openstreetmap.org/{element['type']}/{element['id']}",
                "within_catchment": within_catchment,
                "corridor_supplement_only": bool(not within_catchment and corridor_geom.covers(p)),
                "geometry_note": "OSM element centre; source waterbody geometry is retained in raw Overpass JSON",
                "osm_base_timestamp": water.get("osm3s", {}).get("timestamp_osm_base"),
            }
        )
        features.append(feat(p, props))
        counts["named_waterbody"] += 1

    metadata = {
        "generated_utc": GENERATED_UTC,
        "source": "OpenStreetMap via Overpass API",
        "endpoint": "https://overpass-api.de/api/interpreter",
        "context_osm_base_timestamp": context.get("osm3s", {}).get("timestamp_osm_base"),
        "water_osm_base_timestamp": water.get("osm3s", {}).get("timestamp_osm_base"),
        "geometry_note": "Points are element centres used only as contextual toponyms/infrastructure markers.",
        "license": "OpenStreetMap data © OpenStreetMap contributors, ODbL 1.0",
    }
    write_json(OUT / "osm_named_context.geojson", fc(features, "OSM named context within catchment/corridor", metadata))
    return {
        "feature_count": len(features),
        "counts": dict(counts),
        "context_osm_base_timestamp": context.get("osm3s", {}).get("timestamp_osm_base"),
        "water_osm_base_timestamp": water.get("osm3s", {}).get("timestamp_osm_base"),
    }, features


def plot_preview(full_geom, named_sets, arr, transform, river_geoms, lake_geoms, pour_features, osm_features):
    fig, ax = plt.subplots(figsize=(10.5, 11.5), constrained_layout=True)
    # Downsample display only; the analytical raster remains full resolution.
    stride = max(1, int(max(arr.shape) / 1600))
    view = arr[::stride, ::stride]
    view = np.where((view > -1000) & (view < 9000), view, np.nan)
    left = transform.c
    top = transform.f
    right = left + transform.a * arr.shape[1]
    bottom = top + transform.e * arr.shape[0]
    im = ax.imshow(view, extent=[left, right, bottom, top], origin="upper", cmap="terrain", vmin=500, vmax=6500, alpha=0.88)
    colors = ["#4c78a8", "#e45756", "#72b7b2", "#f2cf5b", "#b279a2"]
    for (sid, item), color in zip(named_sets.items(), colors):
        geom = item["geometry"]
        for poly in iter_polygons(geom):
            x, y = poly.exterior.xy
            ax.fill(x, y, color=color, alpha=0.19, linewidth=0)
            ax.plot(x, y, color=color, linewidth=1.15)
    for line_geom in river_geoms:
        for line in iter_lines(line_geom):
            x, y = line.xy
            ax.plot(x, y, color="#1769aa", linewidth=0.38, alpha=0.65)
    for geom, connectivity, p in lake_geoms:
        color = "#00e5ff" if connectivity == "Glacier-fed" else "#7fdbff"
        ax.scatter([p.x], [p.y], s=6 if connectivity == "Glacier-fed" else 4, c=color, edgecolors="none", alpha=0.85)
    for f in pour_features:
        p = shape(f["geometry"])
        if f["properties"]["role"] == "system_outlet":
            ax.scatter([p.x], [p.y], marker="*", s=145, c="#d7191c", edgecolors="white", linewidths=0.7, zorder=8)
    wanted_labels = {
        "Rasuwa Gadhi",
        "Timure",
        "Dhunche",
        "Mailung",
        "Betrawati",
        "Bidur",
        "Devighat",
        "Langtang",
        "Thulo Syābru",
        "Gosaikunda",
    }
    labelled = set()
    for f in osm_features:
        p = shape(f["geometry"])
        props = f["properties"]
        name = props.get("name:en") or props.get("name")
        if name in wanted_labels and name not in labelled:
            labelled.add(name)
            ax.scatter([p.x], [p.y], s=15, c="#111111", edgecolors="white", linewidths=0.4, zorder=7)
            ax.annotate(name, (p.x, p.y), xytext=(3, 3), textcoords="offset points", fontsize=7.2, color="#111111", path_effects=[])
    for poly in iter_polygons(full_geom):
        x, y = poly.exterior.xy
        ax.plot(x, y, color="black", linewidth=2.0, zorder=6)
    cbar = fig.colorbar(im, ax=ax, fraction=0.032, pad=0.015)
    cbar.set_label("Copernicus GLO-30 DSM elevation (m)")
    ax.set_title("Candidate connected upper Bhote Koshi–Lhende–Langtang–Trishuli system\nHydroBASINS L12 topology, HydroRIVERS, GLO lakes, Copernicus DEM", fontsize=12)
    ax.set_xlabel("Longitude (°E)")
    ax.set_ylabel("Latitude (°N)")
    minx, miny, maxx, maxy = full_geom.bounds
    ax.set_xlim(minx - 0.025, maxx + 0.025)
    ax.set_ylim(miny - 0.025, maxy + 0.025)
    ax.set_aspect(1.0 / math.cos(math.radians((miny + maxy) / 2)))
    legend = [Patch(facecolor=c, edgecolor=c, alpha=0.45, label=item["short_name"]) for c, item in zip(colors, named_sets.values())]
    legend.extend(
        [
            Line2D([0], [0], color="#1769aa", lw=1.2, label="HydroRIVERS"),
            Line2D([0], [0], marker="o", color="none", markerfacecolor="#00e5ff", markersize=5, label="GLO glacier-fed lake"),
            Line2D([0], [0], marker="*", color="none", markerfacecolor="#d7191c", markersize=10, label="System outlet"),
        ]
    )
    ax.legend(handles=legend, loc="lower left", fontsize=7.2, framealpha=0.92, ncol=1)
    ax.text(
        0.995,
        0.008,
        "Catchment polygon only; downstream corridor supplement not shown.\nCandidate for review—not an official operational boundary.",
        transform=ax.transAxes,
        ha="right",
        va="bottom",
        fontsize=7,
        bbox=dict(facecolor="white", edgecolor="#555", alpha=0.9, boxstyle="round,pad=0.35"),
    )
    fig.savefig(OUT / "connected_system_preview.png", dpi=220)
    plt.close(fig)


def source_record(local_rel: str, url: str, product: str, version: str, license_text: str, role: str, extra: dict[str, Any] | None = None):
    path = ROOT / local_rel
    rec = {
        "product": product,
        "version": version,
        "role": role,
        "download_url": url,
        "local_path": str(path),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
        "md5": md5(path),
        "retrieved_utc_approx_file_mtime": file_timestamp(path),
        "license": license_text,
    }
    if extra:
        rec.update(extra)
    return rec


def build_source_metadata(osm_meta: dict[str, Any], dem_tile_meta: list[dict[str, Any]]):
    records = [
        source_record(
            "raw/hybas_as_lev12_v1c.zip",
            "https://data.hydrosheds.org/file/HydroBASINS/standard/hybas_as_lev12_v1c.zip",
            "HydroBASINS Asia level 12",
            "v1c",
            "HydroSHEDS license; free for scientific, educational and commercial use subject to terms",
            "primary basin polygons and NEXT_DOWN topology",
        ),
        source_record(
            "raw/hybas_pour_lev12_v1_shp.zip",
            "https://data.hydrosheds.org/file/hydrobasins/pour_point/hybas_pour_lev12_v1_shp.zip",
            "HydroBASINS Pour Points level 12",
            "v1",
            "HydroSHEDS license",
            "official 15-arc-second sub-basin pour points",
        ),
        source_record(
            "raw/HydroRIVERS_v10_as_shp.zip",
            "https://data.hydrosheds.org/file/HydroRIVERS/HydroRIVERS_v10_as_shp.zip",
            "HydroRIVERS Asia",
            "v1.0",
            "HydroSHEDS license; free for scientific, educational and commercial use subject to terms",
            "connected river-network corroboration",
        ),
        source_record(
            "raw/GLO_S2_2017_2024_unique_lakes_v1.02.gpkg",
            "https://zenodo.org/api/records/19370146/files/S2_20172024_NTB_GLOID_UniqueLakes_v1.02.gpkg/content",
            "Glacial Lake Observatory Sentinel-2 unique lakes",
            "v1.02 (2017–2024 maximum dissolved extents)",
            "CC BY 4.0",
            "glacial-lake evidence",
            {"provider_md5": "24e0e2c4285adec641a9b3725255433a"},
        ),
        source_record(
            "raw/ne_10m_admin_0_countries.zip",
            "https://naturalearth.s3.amazonaws.com/10m_cultural/ne_10m_admin_0_countries.zip",
            "Natural Earth Admin 0 Countries",
            "5.1.1, 1:10m",
            "Public domain",
            "mutually exclusive de facto Nepal/China area split",
        ),
        source_record(
            "raw/geoboundaries_NPL_ADM0.geojson",
            "https://github.com/wmgeolab/geoBoundaries/raw/9469f09/releaseData/gbOpen/NPL/ADM0/geoBoundaries-NPL-ADM0.geojson",
            "geoBoundaries Nepal ADM0",
            "commit 9469f09; boundary year 2019",
            "CC BY 4.0",
            "boundary-source sensitivity comparison only",
        ),
        source_record(
            "raw/geoboundaries_CHN_ADM0.geojson",
            "https://github.com/wmgeolab/geoBoundaries/raw/9469f09/releaseData/gbOpen/CHN/ADM0/geoBoundaries-CHN-ADM0.geojson",
            "geoBoundaries China ADM0",
            "commit 9469f09; boundary year 2019",
            "Public Domain (per API metadata)",
            "boundary-source sensitivity comparison only",
        ),
        source_record(
            "source_pages/CHWRR_Bhotekoshi_2026.pdf",
            "https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR_hnmns6o.pdf",
            "CHWRR Assessment Report II, Rasuwa–Bhote Koshi Flood Event",
            "13 September 2026",
            "License not stated on downloaded report; used as cited public evidence",
            "event-corridor naming and source-branch rationale",
        ),
    ]
    records.extend(
        [
            source_record(
                "source_pages/HydroBASINS_product.html",
                "https://www.hydrosheds.org/products/hydrobasins",
                "HydroBASINS product page",
                "retrieved 2026-11-15",
                "HydroSHEDS license information on page",
                "product description, resolution, licence and citation",
            ),
            source_record(
                "source_pages/HydroBASINS_TechDoc_v1c.pdf",
                "https://data.hydrosheds.org/file/technical-documentation/HydroBASINS_TechDoc_v1c.pdf",
                "HydroBASINS technical documentation",
                "v1c",
                "HydroSHEDS license",
                "topology fields, projection and methodological limitations",
            ),
            source_record(
                "source_pages/HydroBASINS_PourPoint_TechDoc_v1.pdf",
                "https://data.hydrosheds.org/file/hydrobasins/pour_point/HydroBASINS_PourPoint_TechDoc_v1.pdf",
                "HydroBASINS Pour Points technical documentation",
                "v1",
                "HydroSHEDS license",
                "pour-point definition",
            ),
            source_record(
                "source_pages/HydroRIVERS_product.html",
                "https://www.hydrosheds.org/products/hydrorivers",
                "HydroRIVERS product page",
                "v1.0",
                "HydroSHEDS license",
                "network thresholds, licence and citation",
            ),
            source_record(
                "source_pages/HydroRIVERS_TechDoc_v10.pdf",
                "https://data.hydrosheds.org/file/technical-documentation/HydroRIVERS_TechDoc_v10.pdf",
                "HydroRIVERS technical documentation",
                "v1.0",
                "HydroSHEDS license",
                "network attributes and methodology",
            ),
            source_record(
                "source_pages/copernicus_dem_registry.html",
                "https://registry.opendata.aws/copernicus-dem/",
                "Copernicus DEM AWS Registry page",
                "GLO-30 Public, 2021 release",
                "Copernicus DEM licence",
                "DSM definition, access and bucket metadata",
            ),
            source_record(
                "source_pages/overpass_api_wiki.html",
                "https://wiki.openstreetmap.org/wiki/Overpass_API",
                "Overpass API documentation page",
                "retrieved 2026-11-15",
                "Page content under OpenStreetMap wiki terms; OSM data ODbL 1.0",
                "query method and API limitations",
            ),
            source_record(
                "source_pages/GLO_README_v1.02.md",
                "https://zenodo.org/api/records/19370146/files/README.md/content",
                "Glacial Lake Observatory README",
                "v1.02",
                "CC BY 4.0",
                "attributes, CRS, quality and limitations",
                {"provider_md5": "0936ab19750e02f2c1bbf98c9947e4b2"},
            ),
            source_record(
                "source_pages/zenodo_19370146_metadata.json",
                "https://zenodo.org/api/records/19370146",
                "Glacial Lake Observatory Zenodo metadata",
                "record 19370146, version v2",
                "CC BY 4.0",
                "versioned file metadata and provider checksums",
            ),
            source_record(
                "source_pages/ESSD_Glacial_Lake_Observatory_2026.pdf",
                "https://essd.copernicus.org/articles/18/5143/2026/essd-18-5143-2026.pdf",
                "Glacial Lake Observatory data-description article",
                "ESSD 18, 5143–5165 (2026)",
                "CC BY 4.0",
                "scientific method and validation context",
            ),
            source_record(
                "source_pages/NaturalEarth_admin0_countries.html",
                "https://www.naturalearthdata.com/downloads/10m-cultural-vectors/10m-admin-0-countries/",
                "Natural Earth Admin 0 Countries product page",
                "5.1.1",
                "Public domain",
                "scale and de facto boundary representation",
            ),
            source_record(
                "source_pages/geoBoundaries_api.html",
                "https://www.geoboundaries.org/api.html",
                "geoBoundaries API documentation",
                "retrieved 2026-11-15",
                "API documentation; boundary licences are source-specific",
                "API/version metadata",
            ),
            source_record(
                "raw/geoboundaries_NPL_ADM0_api.json",
                "https://www.geoboundaries.org/api/current/gbOpen/NPL/ADM0/",
                "geoBoundaries Nepal ADM0 API record",
                "current endpoint resolved 2026-11-15",
                "CC BY 4.0",
                "boundary provenance and static download URL",
            ),
            source_record(
                "raw/geoboundaries_CHN_ADM0_api.json",
                "https://www.geoboundaries.org/api/current/gbOpen/CHN/ADM0/",
                "geoBoundaries China ADM0 API record",
                "current endpoint resolved 2026-11-15",
                "Public Domain (per API record)",
                "boundary provenance and static download URL",
            ),
        ]
    )
    for p in DEM_PATHS:
        stem = p.stem
        url = f"https://copernicus-dem-30m.s3.amazonaws.com/{stem}/{p.name}"
        records.append(
            source_record(
                str(p.relative_to(ROOT)),
                url,
                "Copernicus DEM GLO-30 Public",
                "2021 release COG",
                "Copernicus DEM licence; free basis for general public subject to licence terms",
                "independent DSM terrain/elevation evidence",
            )
        )
    records.extend(
        [
            source_record(
                "raw/osm_context_response.json",
                "https://overpass-api.de/api/interpreter",
                "OpenStreetMap context extract",
                f"OSM base {osm_meta['context_osm_base_timestamp']}",
                "ODbL 1.0; © OpenStreetMap contributors",
                "named settlements, bridges and waterways",
                {
                    "request_method": "POST",
                    "query_local_path": str(ROOT / "raw/osm_context_query.ql"),
                    "query_sha256": sha256(ROOT / "raw/osm_context_query.ql"),
                },
            ),
            source_record(
                "raw/osm_water_response.json",
                "https://overpass-api.de/api/interpreter",
                "OpenStreetMap water extract",
                f"OSM base {osm_meta['water_osm_base_timestamp']}",
                "ODbL 1.0; © OpenStreetMap contributors",
                "named lake/waterbody toponyms",
                {
                    "request_method": "POST",
                    "query_local_path": str(ROOT / "raw/osm_water_query.ql"),
                    "query_sha256": sha256(ROOT / "raw/osm_water_query.ql"),
                },
            ),
        ]
    )
    metadata = {
        "generated_utc": GENERATED_UTC,
        "working_directory": str(ROOT),
        "crs_policy": "Vector outputs RFC 7946 WGS 84 lon/lat; area computed geodesically on WGS84; DEM output EPSG:4326.",
        "sources": records,
        "dem_tiles": dem_tile_meta,
    }
    write_json(OUT / "source_metadata.json", metadata)
    return metadata


def main():
    records, children, full_ids, named_sets, unit_geoms, full_geom = load_hydrobasins()
    assert full_geom.is_valid and not full_geom.is_empty

    pour_ids = {
        SYSTEM_OUTLET_HYBAS,
        KYIRONG_OUTLET_HYBAS,
        LHENDE_OUTLET_HYBAS,
        LANGTANG_OUTLET_HYBAS,
        UPPER_CORRIDOR_CONTROL_HYBAS,
        COMBINED_BORDER_HYBAS,
        TADI_OUTLET_HYBAS,
        DOWNSTREAM_CONFLUENCE_HYBAS,
    }
    pours = load_pour_points(pour_ids)
    outlet_xy = pours[SYSTEM_OUTLET_HYBAS]

    countries = load_natural_earth_countries()
    gb = load_geoboundaries_comparison()

    arr, valid, dem_transform, dem_crs, dem_tile_meta, dem_out = merge_dem(full_geom)
    full_dem_stats = stats_for_values(arr[valid])
    boundary_stats = boundary_dem_stats(full_geom, outlet_xy, arr, dem_transform)

    full_area = geodesic_area_km2(full_geom)
    nepal_area = geodesic_area_km2(full_geom.intersection(countries["NPL"]))
    china_area = geodesic_area_km2(full_geom.intersection(countries["CHN"]))
    country_overlap = geodesic_area_km2(full_geom.intersection(countries["NPL"]).intersection(countries["CHN"]))
    country_unassigned = geodesic_area_km2(full_geom.difference(countries["NPL"].union(countries["CHN"])))
    gb_overlap = geodesic_area_km2(full_geom.intersection(gb["NPL"]).intersection(gb["CHN"]))

    full_props = {
        "candidate_id": "UBKLLT_CONNECTED_SYSTEM_V1",
        "name": "Upper Bhote Koshi–Lhende–Langtang–Trishuli connected system",
        "status": "candidate for technical review; not an official operational boundary",
        "method": "HydroBASINS v1c level-12 upstream closure using NEXT_DOWN topology",
        "outlet_hybas_id": SYSTEM_OUTLET_HYBAS,
        "outlet_lon": round(outlet_xy[0], 12),
        "outlet_lat": round(outlet_xy[1], 12),
        "outlet_description": "Official HydroBASINS pour point on upper Trishuli immediately upstream of the shared downstream unit with Tadi Khola at Devighat",
        "hydrobasins_unit_count": len(full_ids),
        "hydrobasins_up_area_km2": records[SYSTEM_OUTLET_HYBAS]["UP_AREA"],
        "hydrobasins_sum_sub_area_km2": round(sum(records[i]["SUB_AREA"] for i in full_ids), 1),
        "geodesic_area_km2": round(full_area, 3),
        "natural_earth_nepal_area_km2": round(nepal_area, 3),
        "natural_earth_china_area_km2": round(china_area, 3),
        "natural_earth_nepal_pct": round(nepal_area / full_area * 100, 2),
        "natural_earth_china_pct": round(china_area / full_area * 100, 2),
        "included_major_branches": ["Kyirong Tsangpo", "Lhende–Chhochen", "Langtang Khola", "upper Trishuli and local Rasuwa slopes"],
        "excluded_major_branches": ["Tadi Khola", "lower Trishuli/Narayani downstream of Devighat", "nearby endorheic Tibetan basins"],
        "dem_min_m": full_dem_stats["min_m"],
        "dem_median_m": full_dem_stats["median_m"],
        "dem_max_m": full_dem_stats["max_m"],
        "generated_utc": GENERATED_UTC,
        "source_hydrobasins": "https://data.hydrosheds.org/file/HydroBASINS/standard/hybas_as_lev12_v1c.zip",
        "source_dem": "https://registry.opendata.aws/copernicus-dem/",
    }
    write_json(
        OUT / "connected_system_aoi.geojson",
        fc(
            [feat(full_geom, full_props)],
            "Candidate connected-system catchment",
            {
                "crs": "RFC 7946 WGS 84 longitude/latitude",
                "area_method": "WGS84 ellipsoidal geodesic area",
                "warning": "Catchment polygon only; downstream corridor supplement is a separate file and excluded from area.",
            },
        ),
    )
    simplified = polygonal(full_geom.simplify(0.0005, preserve_topology=True))
    simple_props = dict(full_props)
    simple_props.update(
        {
            "geometry_variant": "display-simplified",
            "simplification_tolerance_degrees": 0.0005,
            "unsimplified_file": "connected_system_aoi.geojson",
            "geodesic_area_after_simplification_km2": round(geodesic_area_km2(simplified), 3),
        }
    )
    write_json(OUT / "connected_system_aoi_simplified.geojson", fc([feat(simplified, simple_props)], "Display-simplified candidate catchment"))

    sub_features = []
    summary_rows = []
    subarea_dem = {}
    for order, (sid, item) in enumerate(named_sets.items(), 1):
        geom = item["geometry"]
        area = geodesic_area_km2(geom)
        vals = dem_values_for_geom(arr, dem_transform, geom)
        dstats = stats_for_values(vals)
        subarea_dem[sid] = dstats
        npl = geodesic_area_km2(geom.intersection(countries["NPL"]))
        chn = geodesic_area_km2(geom.intersection(countries["CHN"]))
        ctrl = pours[item["control_hybas_id"]]
        props = {
            "subarea_id": sid,
            "order": order,
            "name": item["name"],
            "kind": item["kind"],
            "method": "Union of disjoint HydroBASINS v1c level-12 units; five features partition the connected system",
            "control_hybas_id": item["control_hybas_id"],
            "control_lon": round(ctrl[0], 12),
            "control_lat": round(ctrl[1], 12),
            "control_dem_elevation_m": sample_dem(arr, dem_transform, *ctrl),
            "hydrobasins_unit_count": len(item["ids"]),
            "hydrobasins_unit_ids": sorted(item["ids"]),
            "hydrobasins_sum_sub_area_km2": round(sum(records[i]["SUB_AREA"] for i in item["ids"]), 1),
            "geodesic_area_km2": round(area, 3),
            "nepal_area_km2": round(npl, 3),
            "china_area_km2": round(chn, 3),
            "nepal_pct": round(npl / area * 100, 2),
            "china_pct": round(chn / area * 100, 2),
            "dem_min_m": dstats["min_m"],
            "dem_median_m": dstats["median_m"],
            "dem_max_m": dstats["max_m"],
            "generated_utc": GENERATED_UTC,
        }
        sub_features.append(feat(geom, props))
        summary_rows.append(props)
    write_json(
        OUT / "named_subareas.geojson",
        fc(
            sub_features,
            "Five named connected-system sub-areas",
            {
                "partition_complete": True,
                "partition_disjoint_by_hydrobasins_unit": True,
                "crs": "RFC 7946 WGS 84 longitude/latitude",
            },
        ),
    )
    with (OUT / "subareas_summary.csv").open("w", newline="", encoding="utf-8") as f:
        fields = [
            "subarea_id",
            "order",
            "name",
            "kind",
            "control_hybas_id",
            "control_lon",
            "control_lat",
            "control_dem_elevation_m",
            "hydrobasins_unit_count",
            "hydrobasins_sum_sub_area_km2",
            "geodesic_area_km2",
            "nepal_area_km2",
            "china_area_km2",
            "nepal_pct",
            "china_pct",
            "dem_min_m",
            "dem_median_m",
            "dem_max_m",
        ]
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(summary_rows)

    pour_spec = [
        ("system_outlet", "Upper Trishuli system outlet (upstream of Tadi/Devighat confluence)", SYSTEM_OUTLET_HYBAS, "system_outlet"),
        ("kyirong_pour", "Kyirong Tsangpo branch pour point", KYIRONG_OUTLET_HYBAS, "tributary_pour_point"),
        ("lhende_pour", "Lhende–Chhochen branch pour point", LHENDE_OUTLET_HYBAS, "tributary_pour_point"),
        ("combined_border_control", "Combined Kyirong/Lhende border-headwaters control", COMBINED_BORDER_HYBAS, "network_control_point"),
        ("langtang_pour", "Langtang Khola branch pour point", LANGTANG_OUTLET_HYBAS, "tributary_pour_point"),
        ("upper_corridor_control", "Rasuwa upper-corridor downstream control", UPPER_CORRIDOR_CONTROL_HYBAS, "partition_control_point"),
        ("tadi_excluded_pour", "Tadi Khola excluded branch pour point", TADI_OUTLET_HYBAS, "excluded_tributary_pour_point"),
        ("shared_downstream_unit", "First shared downstream HydroBASINS unit below Trishuli and Tadi", DOWNSTREAM_CONFLUENCE_HYBAS, "downstream_reference_point"),
    ]
    pour_features = []
    for pid, label, hid, role in pour_spec:
        x, y = pours[hid]
        d = records[hid]
        props = {
            "point_id": pid,
            "name": label,
            "role": role,
            "hybas_id": hid,
            "next_down_hybas_id": d["NEXT_DOWN"],
            "upstream_area_km2": d["UP_AREA"],
            "subbasin_area_km2": d["SUB_AREA"],
            "lon": round(x, 12),
            "lat": round(y, 12),
            "copernicus_dem_elevation_m": sample_dem(arr, dem_transform, x, y),
            "source": "HydroBASINS Pour Points v1 level 12",
            "source_url": "https://data.hydrosheds.org/file/hydrobasins/pour_point/hybas_pour_lev12_v1_shp.zip",
        }
        pour_features.append(feat(Point(x, y), props))
    write_json(OUT / "outlet_and_pour_points.geojson", fc(pour_features, "System outlet and branch/control pour points"))

    hydro_diag, river_geoms, corridor_geom, downstream_line = load_hydrorivers(full_ids, full_geom)
    glo_diag, lake_geoms = process_glo_lakes(full_geom, named_sets, arr, dem_transform)
    osm_diag, osm_features = process_osm_context(full_geom, corridor_geom)

    # Partition verification is geometric as well as ID-based.
    sub_geoms = [item["geometry"] for item in named_sets.values()]
    sub_union = polygonal(unary_union(sub_geoms))
    symmetric_difference_area = geodesic_area_km2(full_geom.symmetric_difference(sub_union))
    overlaps = {}
    keys = list(named_sets)
    for i, a in enumerate(keys):
        for b in keys[i + 1 :]:
            val = geodesic_area_km2(named_sets[a]["geometry"].intersection(named_sets[b]["geometry"]))
            overlaps[f"{a}__{b}"] = round(val, 9)

    diagnostics = {
        "generated_utc": GENERATED_UTC,
        "system": {
            "outlet_hybas_id": SYSTEM_OUTLET_HYBAS,
            "outlet_coordinates": [outlet_xy[0], outlet_xy[1]],
            "outlet_copernicus_dem_elevation_m": sample_dem(arr, dem_transform, *outlet_xy),
            "unit_count": len(full_ids),
            "unit_ids": sorted(full_ids),
            "hydrobasins_up_area_km2": records[SYSTEM_OUTLET_HYBAS]["UP_AREA"],
            "hydrobasins_sum_sub_area_km2": round(sum(records[i]["SUB_AREA"] for i in full_ids), 1),
            "geodesic_area_km2": round(full_area, 6),
            "bounds": [round(v, 12) for v in full_geom.bounds],
            "geometry_type": full_geom.geom_type,
            "geometry_valid": full_geom.is_valid,
        },
        "outlet_logic": {
            "trishuli_outlet_next_down": records[SYSTEM_OUTLET_HYBAS]["NEXT_DOWN"],
            "tadi_outlet_hybas_id": TADI_OUTLET_HYBAS,
            "tadi_upstream_area_km2": records[TADI_OUTLET_HYBAS]["UP_AREA"],
            "tadi_next_down": records[TADI_OUTLET_HYBAS]["NEXT_DOWN"],
            "shared_downstream_hybas_id": DOWNSTREAM_CONFLUENCE_HYBAS,
            "shared_downstream_up_area_km2": records[DOWNSTREAM_CONFLUENCE_HYBAS]["UP_AREA"],
            "tadi_excluded": records[SYSTEM_OUTLET_HYBAS]["NEXT_DOWN"] == records[TADI_OUTLET_HYBAS]["NEXT_DOWN"] == DOWNSTREAM_CONFLUENCE_HYBAS,
        },
        "partition": {
            "subarea_count": len(named_sets),
            "subarea_unit_counts": {sid: len(item["ids"]) for sid, item in named_sets.items()},
            "symmetric_difference_with_full_km2": round(symmetric_difference_area, 9),
            "pairwise_overlap_km2": overlaps,
            "id_partition_complete": set().union(*(item["ids"] for item in named_sets.values())) == full_ids,
        },
        "country_split_natural_earth": {
            "nepal_km2": round(nepal_area, 6),
            "china_km2": round(china_area, 6),
            "nepal_pct": round(nepal_area / full_area * 100, 4),
            "china_pct": round(china_area / full_area * 100, 4),
            "overlap_km2": round(country_overlap, 9),
            "unassigned_km2": round(country_unassigned, 9),
            "source": "Natural Earth 1:10m Admin 0 Countries v5.1.1, de facto boundary representation",
        },
        "country_boundary_sensitivity": {
            "geoboundaries_independent_layer_overlap_within_aoi_km2": round(gb_overlap, 6),
            "decision": "Do not sum independently authored geoBoundaries NPL/CHN intersections; use Natural Earth mutually exclusive de facto polygons for reported split.",
        },
        "dem": {
            "source": "Copernicus DEM GLO-30 Public DSM",
            "masked_raster": str(dem_out),
            "crs": str(dem_crs),
            "stats_full": full_dem_stats,
            "stats_boundary": boundary_stats,
            "stats_subareas": subarea_dem,
        },
        "hydrorivers": hydro_diag,
        "glo_lakes": glo_diag,
        "osm_context": osm_diag,
    }
    write_json(OUT / "selection_diagnostics.json", diagnostics)
    write_json(
        OUT / "dem_evidence.json",
        {
            "generated_utc": GENERATED_UTC,
            "dataset": "Copernicus DEM GLO-30 Public (DSM)",
            "source_url": "https://registry.opendata.aws/copernicus-dem/",
            "full_system": full_dem_stats,
            "sampled_catchment_boundary": boundary_stats,
            "subareas": subarea_dem,
            "pour_point_elevations": {f["properties"]["point_id"]: f["properties"]["copernicus_dem_elevation_m"] for f in pour_features},
            "limitations": [
                "Copernicus DEM is a digital surface model, not a hydrologically conditioned bare-earth DEM.",
                "It independently corroborates relief and divide elevations; HydroBASINS topology, not the Copernicus DEM, defines the candidate boundary.",
                "Pixel summaries are unweighted by latitude over this compact AOI; geodesic area is calculated separately.",
            ],
        },
    )
    build_source_metadata(osm_diag, dem_tile_meta)
    plot_preview(full_geom, named_sets, arr, dem_transform, river_geoms, lake_geoms, pour_features, osm_features)

    # Verify every generated GeoJSON parses and every geometry is valid/non-empty.
    geojson_checks = {}
    for path in sorted(OUT.glob("*.geojson")):
        data = json.loads(path.read_text(encoding="utf-8"))
        bad = 0
        empty = 0
        for feature in data.get("features", []):
            geom = shape(feature["geometry"])
            bad += int(not geom.is_valid)
            empty += int(geom.is_empty)
        geojson_checks[path.name] = {"features": len(data.get("features", [])), "invalid_geometries": bad, "empty_geometries": empty}
    write_json(OUT / "geojson_validation.json", {"generated_utc": GENERATED_UTC, "files": geojson_checks})
    if any(v["invalid_geometries"] or v["empty_geometries"] for v in geojson_checks.values()):
        raise RuntimeError(f"GeoJSON validation failed: {geojson_checks}")

    print(json.dumps({
        "system_area_km2": round(full_area, 3),
        "hydrobasins_up_area_km2": records[SYSTEM_OUTLET_HYBAS]["UP_AREA"],
        "unit_count": len(full_ids),
        "subarea_count": len(named_sets),
        "nepal_km2": round(nepal_area, 3),
        "china_km2": round(china_area, 3),
        "dem": full_dem_stats,
        "hydrorivers": hydro_diag,
        "glo": glo_diag,
        "osm": osm_diag,
        "geojson_checks": geojson_checks,
    }, indent=2))


if __name__ == "__main__":
    main()
