#!/usr/bin/env python3
"""Fetch native GPM IMERG and NASA POWER context at the verified source point.

Earthdata credentials are consumed only through earthaccess/netrc. Redirected
signed URLs are never written to disk or printed.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

import earthaccess
import h5py
import numpy as np

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.core import sha256_file

LATITUDE = 28.291242
LONGITUDE = 85.528066
EVENT_UTC = datetime(2026, 8, 26, 2, 52, 10, tzinfo=timezone.utc)
CMR = "https://cmr.earthdata.nasa.gov/search/granules.umm_json"
IMERG_COLLECTIONS = {
    "early": "C2723758340-GES_DISC",
    "late": "C2723754845-GES_DISC",
}
VARIABLES = (
    "precipitation",
    "randomError",
    "precipitationQualityIndex",
    "probabilityLiquidPrecipitation",
    "MWprecipitation",
    "IRprecipitation",
    "IRinfluence",
)


def nearest_index(values: np.ndarray, target: float) -> int:
    """Return the index of the finite coordinate closest to target."""
    coordinates = np.asarray(values, dtype="float64")
    if coordinates.ndim != 1 or not np.any(np.isfinite(coordinates)):
        raise ValueError("coordinates must be a finite one-dimensional array")
    return int(np.nanargmin(np.abs(coordinates - target)))


def decode_attribute(value) -> str | float | int | None:
    if value is None:
        return None
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, np.ndarray) and value.size == 1:
        return decode_attribute(value.item())
    if isinstance(value, np.generic):
        return value.item()
    return str(value) if not isinstance(value, (str, int, float)) else value


def dataset_point(dataset, lon_index: int, lat_index: int, lon_length: int, lat_length: int) -> float | None:
    """Sample a dataset whose dimension order is inferred from coordinate lengths."""
    shape = dataset.shape
    lon_axes = [index for index, length in enumerate(shape) if length == lon_length]
    lat_axes = [index for index, length in enumerate(shape) if length == lat_length]
    if len(lon_axes) != 1 or len(lat_axes) != 1 or lon_axes[0] == lat_axes[0]:
        raise RuntimeError(f"cannot infer lon/lat axes for {dataset.name} shape {shape}")
    indices = [0] * len(shape)
    indices[lon_axes[0]] = lon_index
    indices[lat_axes[0]] = lat_index
    raw = float(dataset[tuple(indices)])
    fill_values = [dataset.attrs.get(name) for name in ("_FillValue", "missing_value") if name in dataset.attrs]
    for fill in fill_values:
        fill_value = float(np.asarray(fill).reshape(-1)[0])
        if np.isclose(raw, fill_value, equal_nan=True):
            return None
    scale = float(np.asarray(dataset.attrs.get("scale_factor", 1.0)).reshape(-1)[0])
    offset = float(np.asarray(dataset.attrs.get("add_offset", 0.0)).reshape(-1)[0])
    value = raw * scale + offset
    return float(value) if np.isfinite(value) else None


def extract_imerg_point(path: Path, latitude: float, longitude: float) -> dict:
    """Extract documented IMERG variables at the nearest native 0.1-degree cell."""
    with h5py.File(path, "r") as handle:
        grid = handle["Grid"]
        lon = np.asarray(grid["lon"][:], dtype="float64")
        lat = np.asarray(grid["lat"][:], dtype="float64")
        lon_index = nearest_index(lon, longitude)
        lat_index = nearest_index(lat, latitude)
        variable_records = {}
        for name in VARIABLES:
            if name not in grid:
                continue
            dataset = grid[name]
            variable_records[name] = {
                "value": dataset_point(dataset, lon_index, lat_index, len(lon), len(lat)),
                "units": decode_attribute(dataset.attrs.get("units")),
                "shape": list(dataset.shape),
            }
        return {
            "file": str(path),
            "grid_indices": {"lon": lon_index, "lat": lat_index},
            "grid_center": {"longitude": float(lon[lon_index]), "latitude": float(lat[lat_index])},
            "requested_point": {"longitude": longitude, "latitude": latitude},
            "variables": variable_records,
        }


def fetch_json(url: str, path: Path) -> dict:
    request = urllib.request.Request(url, headers={"User-Agent": "rasuwa-sar-research/1.0", "Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=180) as response:
        payload = response.read()
    parsed = json.loads(payload)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(payload)
    return parsed


def cmr_event_granule(run: str, concept_id: str, raw_dir: Path) -> dict:
    parameters = {
        "collection_concept_id": concept_id,
        "temporal": "2026-08-26T02:30:00Z,2026-08-26T03:00:00Z",
        "page_size": "10",
        "sort_key": "start_date",
    }
    query_url = f"{CMR}?{urllib.parse.urlencode(parameters)}"
    response = fetch_json(query_url, raw_dir / f"cmr_imerg_{run}_event.json")
    matches = []
    for item in response.get("items", []):
        umm = item["umm"]
        temporal = umm["TemporalExtent"]["RangeDateTime"]
        start = datetime.fromisoformat(temporal["BeginningDateTime"].replace("Z", "+00:00"))
        end = datetime.fromisoformat(temporal["EndingDateTime"].replace("Z", "+00:00"))
        if start <= EVENT_UTC <= end:
            urls = [
                link["URL"] for link in umm.get("RelatedUrls", [])
                if link.get("URL", "").endswith((".HDF5", ".h5")) and link.get("Type") == "GET DATA"
            ]
            if len(urls) != 1:
                raise RuntimeError(f"{run}: expected one HDF5 data URL, found {len(urls)}")
            matches.append(
                {
                    "run": run,
                    "collection_concept_id": concept_id,
                    "granule_concept_id": item["meta"]["concept-id"],
                    "producer_granule_id": umm["GranuleUR"],
                    "begin_utc": temporal["BeginningDateTime"],
                    "end_utc": temporal["EndingDateTime"],
                    "data_url": urls[0],
                    "query_url": query_url,
                }
            )
    if len(matches) != 1:
        raise RuntimeError(f"{run}: expected one event-containing granule, found {len(matches)}")
    return matches[0]


def download_authenticated(session, url: str, path: Path) -> dict:
    path.parent.mkdir(parents=True, exist_ok=True)
    with session.get(url, stream=True, timeout=180) as response:
        response.raise_for_status()
        with path.open("wb") as stream:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    stream.write(chunk)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256_file(path), "source_url": url}


def power_url(temporal: str, parameters: str, start: str, end: str) -> str:
    query = {
        "parameters": parameters,
        "community": "AG",
        "longitude": str(LONGITUDE),
        "latitude": str(LATITUDE),
        "start": start,
        "end": end,
        "format": "JSON",
        "time-standard": "UTC",
    }
    return f"https://power.larc.nasa.gov/api/temporal/{temporal}/point?{urllib.parse.urlencode(query, safe=',')}"


def normalized_value(value):
    return None if value is None or float(value) == -999.0 else value


def write_power_tables(raw_dir: Path, processed_dir: Path) -> dict:
    requests = {
        "daily_imerg": power_url("daily", "IMERG_PRECTOT", "20260820", "20260902"),
        "daily_meteorology": power_url("daily", "PRECTOTCORR,T2M,RH2M", "20260820", "20260902"),
        "daily_wetness": power_url("daily", "GWETTOP,GWETROOT,GWETPROF", "20260820", "20260902"),
        "daily_volumetric": power_url("daily", "SFMC,RZMC,PRMC", "20260820", "20260902"),
        "hourly_meteorology": power_url("hourly", "PRECTOTCORR,T2M,RH2M", "20260825", "20260827"),
    }
    payloads = {name: fetch_json(url, raw_dir / f"power_{name}.json") for name, url in requests.items()}
    processed_dir.mkdir(parents=True, exist_ok=True)

    daily_parameters = {
        **payloads["daily_imerg"]["properties"]["parameter"],
        **payloads["daily_meteorology"]["properties"]["parameter"],
        **payloads["daily_wetness"]["properties"]["parameter"],
        **payloads["daily_volumetric"]["properties"]["parameter"],
    }
    daily_fields = [
        "IMERG_PRECTOT", "PRECTOTCORR", "T2M", "RH2M",
        "GWETTOP", "GWETROOT", "GWETPROF", "SFMC", "RZMC", "PRMC",
    ]
    dates = sorted(daily_parameters["IMERG_PRECTOT"])
    daily_path = processed_dir / "power_daily_context.csv"
    with daily_path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["date_utc", *daily_fields])
        for date in dates:
            writer.writerow([
                datetime.strptime(date, "%Y%m%d").date().isoformat(),
                *(normalized_value(daily_parameters[field].get(date)) for field in daily_fields),
            ])

    hourly = payloads["hourly_meteorology"]["properties"]["parameter"]
    precipitation_key = "PRECTOTCORR" if "PRECTOTCORR" in hourly else "PRECTOT"
    timestamps = sorted(hourly[precipitation_key])
    hourly_path = processed_dir / "power_hourly_context.csv"
    with hourly_path.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["time_utc_start", "PRECTOTCORR", "T2M", "RH2M"])
        for stamp in timestamps:
            time_utc = datetime.strptime(stamp, "%Y%m%d%H").replace(tzinfo=timezone.utc)
            writer.writerow([
                time_utc.isoformat().replace("+00:00", "Z"),
                normalized_value(hourly[precipitation_key].get(stamp)),
                normalized_value(hourly["T2M"].get(stamp)),
                normalized_value(hourly["RH2M"].get(stamp)),
            ])
    six_bins = ["2026082521", "2026082522", "2026082523", "2026082600", "2026082601", "2026082602"]
    six_values = [float(hourly[precipitation_key][stamp]) for stamp in six_bins]
    return {
        "request_urls": requests,
        "daily_path": str(daily_path),
        "hourly_path": str(hourly_path),
        "event_day": {field: normalized_value(daily_parameters[field].get("20260826")) for field in daily_fields},
        "pre_event_six_complete_hour_bins": {
            "timestamps": six_bins,
            "values_mm": six_values,
            "sum_mm": float(sum(six_values)),
            "caveat": "Six complete POWER start-hour bins ending at 02:59 UTC; model context, not a gauge or exact rolling six-hour observation.",
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw", type=Path, default=Path("data/raw/hydro_context"))
    parser.add_argument("--input", type=Path, default=Path("data/inputs/imerg"))
    parser.add_argument("--output", type=Path, default=Path("data/processed/hydro_context"))
    parser.add_argument("--game-output", type=Path, default=Path("game_handoff"))
    args = parser.parse_args()
    for directory in (args.raw, args.input, args.output, args.game_output):
        directory.mkdir(parents=True, exist_ok=True)

    auth = earthaccess.login(strategy="netrc")
    if not auth.authenticated:
        raise RuntimeError("Earthdata Login authentication failed; configure ~/.netrc without copying credentials into this project")
    session = auth.get_session()

    imerg_records = []
    imerg_files = []
    for run, concept_id in IMERG_COLLECTIONS.items():
        granule = cmr_event_granule(run, concept_id, args.raw)
        file_path = args.input / f"{run}_{granule['producer_granule_id']}"
        file_record = download_authenticated(session, granule["data_url"], file_path)
        extraction = extract_imerg_point(file_path, LATITUDE, LONGITUDE)
        granule_record = {**granule, "file": file_record, "point": extraction}
        imerg_records.append(granule_record)
        imerg_files.append(file_record)

    imerg_csv = args.output / "imerg_event_point.csv"
    variable_names = sorted({name for record in imerg_records for name in record["point"]["variables"]})
    with imerg_csv.open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "run", "collection_concept_id", "granule_concept_id", "producer_granule_id",
            "begin_utc", "end_utc", "grid_lon", "grid_lat", *variable_names,
        ])
        for record in imerg_records:
            writer.writerow([
                record["run"], record["collection_concept_id"], record["granule_concept_id"],
                record["producer_granule_id"], record["begin_utc"], record["end_utc"],
                record["point"]["grid_center"]["longitude"], record["point"]["grid_center"]["latitude"],
                *(record["point"]["variables"].get(name, {}).get("value") for name in variable_names),
            ])

    power = write_power_tables(args.raw, args.output)
    summary = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "event_utc": EVENT_UTC.isoformat().replace("+00:00", "Z"),
        "point": {"longitude": LONGITUDE, "latitude": LATITUDE},
        "imerg": imerg_records,
        "power": power,
        "files": [
            *imerg_files,
            {"path": str(imerg_csv), "bytes": imerg_csv.stat().st_size, "sha256": sha256_file(imerg_csv)},
            {"path": power["daily_path"], "bytes": Path(power["daily_path"]).stat().st_size, "sha256": sha256_file(power["daily_path"])},
            {"path": power["hourly_path"], "bytes": Path(power["hourly_path"]).stat().st_size, "sha256": sha256_file(power["hourly_path"])},
        ],
        "interpretation_limit": "IMERG is a 0.1-degree satellite estimate and POWER meteorology/wetness is coarser model context; neither resolves the failure slope or proves a trigger.",
    }
    summary_path = args.output / "hydro_context_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2) + "\n")

    daily_rows = []
    with Path(power["daily_path"]).open(newline="") as stream:
        for row in csv.DictReader(stream):
            daily_rows.append(
                {
                    "date_utc": row["date_utc"],
                    "imerg_mm_day": float(row["IMERG_PRECTOT"]) if row["IMERG_PRECTOT"] else None,
                    "power_corrected_mm_day": float(row["PRECTOTCORR"]) if row["PRECTOTCORR"] else None,
                }
            )
    handoff = {
        "provenance_label": "observation/model context",
        "series": daily_rows,
        "native_imerg_event_half_hour": [
            {
                "run": record["run"],
                "granule_id": record["producer_granule_id"],
                "time_start_utc": record["begin_utc"],
                "time_end_utc": record["end_utc"],
                "grid_center": record["point"]["grid_center"],
                "precipitation_rate_mm_hr": record["point"]["variables"]["precipitation"]["value"],
                "random_error_mm_hr": record["point"]["variables"].get("randomError", {}).get("value"),
            }
            for record in imerg_records
        ],
        "sources": {
            "IMERG": [record["data_url"] for record in imerg_records],
            "POWER": power["request_urls"],
        },
        "limitations": summary["interpretation_limit"],
    }
    handoff_path = args.game_output / "rainfall_timeseries.json"
    handoff_path.write_text(json.dumps(handoff, indent=2) + "\n")
    print(json.dumps({
        "summary": str(summary_path),
        "imerg_event_values": handoff["native_imerg_event_half_hour"],
        "power_event_day": power["event_day"],
        "power_six_hour_sum_mm": power["pre_event_six_complete_hour_bins"]["sum_mm"],
    }, indent=2))


if __name__ == "__main__":
    main()
