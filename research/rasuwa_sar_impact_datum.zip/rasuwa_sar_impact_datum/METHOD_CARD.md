# Method card: rerun the Rasuwa SAR screening study

**Purpose:** retrospective research screening with free/open tools. It does **not** predict failure, set an alert threshold, or replace field inspection.

## 1. Environment

```bash
cd /home/safal0715/Documents/research
uv venv .venv --python 3.12
uv pip install --python .venv/bin/python -r requirements.txt
```

Configure Earthdata through `EARTHDATA_TOKEN` or `~/.netrc`. Do not put a token, cookie, signed URL, or password in a command, script, log, notebook, or output file.

## 2. Verify the fetched 24-month catalog snapshot

```bash
.venv/bin/python _subagents2/inventory/scripts/validate_inventory.py
```

The retained snapshot contains the exact CMR Search-After pages, ASF count checks, query URLs, and SHA-256 values. Rebuilding it performs live network queries and may return a newer catalog state:

```bash
.venv/bin/python _subagents2/inventory/scripts/build_inventory.py
.venv/bin/python _subagents2/inventory/scripts/validate_inventory.py
```

## 3. Post-filter the rectangular catalog search to the hydrologic AOI

```bash
.venv/bin/python scripts/scouting/inventory_stats.py \
  --source data/scouting/inventory/bbox_inventory.csv \
  --aoi data/scouting/aoi/connected_system_analysis_aoi.geojson \
  --subareas data/scouting/aoi/subareas_with_corridor.geojson \
  --inventory inventory.csv \
  --stats data/scouting/inventory/subarea_sensor_stats.csv \
  --summary data/scouting/inventory/exact_filter_summary.json \
  --event-date 2026-08-26
```

Counts in the statistics file are source-observation dates; product-granule counts are reported separately.

## 4. Verify the NISAR range-read subsets

The science HDF5 files total 35.46 GB, but the extraction used authenticated byte ranges and saved no full HDF5 file.

```bash
.venv/bin/python _subagents2/nisar/scripts/verify_outputs.py
```

To repeat live catalog discovery and range extraction:

```bash
.venv/bin/python _subagents2/nisar/scripts/query_chain.py
.venv/bin/python _subagents2/nisar/scripts/compare_tracks.py
.venv/bin/python _subagents2/nisar/scripts/extract_subsets.py
.venv/bin/python _subagents2/nisar/scripts/summarize_subsets.py
.venv/bin/python _subagents2/nisar/scripts/verify_outputs.py
```

Inspect `encoded_mask`, `connected_components`, coherence, ionosphere flags, and fill values before interpreting phase. Do not convert unwrapped phase to displacement when connected phase coverage is inadequate.

## 5. Verify the two completed Sentinel-1D HyP3 jobs

Do not resubmit the jobs: their IDs and downloaded products already exist in `data/processed/s1d_hyp3/`.

```bash
.venv/bin/python _subagents2/hyp3/scripts/monitor_download.py --timeout 60 --interval 5
.venv/bin/python _subagents2/hyp3/scripts/analyze_products.py
.venv/bin/python _subagents2/hyp3/scripts/compare_nisar_requirements.py
```

The completed jobs used the same burst, 12-day intervals, 20×4 looks, an 80 m grid, and a water mask. The bundle did not supply an explicit layover/shadow mask.

## 6. Rebuild the control-calibrated coherence-loss mask

```bash
.venv/bin/python scripts/scouting/build_coherence_mask.py \
  --delta data/processed/s1d_hyp3/analysis/coherence_event_minus_quiet.tif \
  --reference data/inputs/validation/unosat_detachment.geojson \
  --output-tif data/processed/s1d_hyp3/analysis/coherence_loss_screening_mask.tif \
  --output-json data/processed/s1d_hyp3/analysis/coherence_loss_screening_mask.json \
  --output-png game_handoff/coherence_loss_screening_mask.png \
  --output-webp game_handoff/coherence_loss_screening_mask.webp \
  --bbox 85.34,28.23,85.55,28.32 \
  --control-quantile 0.05 \
  --exclusion-buffer-m 300 \
  --mmu-pixels 4
```

The threshold is the lower 5th percentile of event-minus-quiet coherence in the valid control footprint. The minimum mapping unit is four 80 m pixels, or 0.0256 km². This is a dataset-specific retrospective screen, not a transferable hazard threshold.

## 7. Rebuild latency, cross-band, exposure, and game files

```bash
.venv/bin/python scripts/scouting/build_impact_outputs.py \
  --inventory inventory.csv \
  --nisar data/processed/nisar_lband/outputs/subset_findings.json \
  --cband data/processed/s1d_hyp3/analysis/coherence_comparison.json \
  --output data/scouting/impact \
  --game-output game_handoff \
  --event 2026-08-26T02:52:10Z

.venv/bin/python scripts/scouting/build_screening_map.py \
  --osm-context _subagents2/aoi/outputs/osm_named_context.geojson \
  --detachment data/inputs/validation/unosat_detachment.geojson \
  --mask-summary data/processed/s1d_hyp3/analysis/coherence_loss_screening_mask.json \
  --nisar-findings data/processed/nisar_lband/outputs/subset_findings.json \
  --exposure-output data/scouting/impact/exposure_context_20km.geojson \
  --exposure-csv data/scouting/impact/exposure_context_20km.csv \
  --screening-output data/scouting/impact/hazard_screening.geojson
```

Distances to OSM feature centres are context only. They are not population, damage, probability, urgency, or risk.

## 8. Tests and manifest

```bash
.venv/bin/python -m unittest discover -s tests -v
.venv/bin/python scripts/build_manifest.py
.venv/bin/python scripts/scouting/build_game_manifest.py --root game_handoff
.venv/bin/python scripts/scouting/validate_release.py --root . --output release_validation.json
```

Before release, confirm that every processed raster has a source product ID, parameters, CRS/nodata metadata, byte size, and SHA-256; scan outputs for credentials and signed URL query strings.
