# Limitations

1. **Non-operational scope.** Every output is retrospective research support. None is an evacuation, warning, hazard forecast or safety classification.
2. **Mechanism remains partly unresolved.** Rock–ice/bedrock failure is well supported, but the exact failure physics, water source and duration of any temporary dam are not closed questions.[8][11]
3. **Reference is not ground truth.** The UNOSAT detachment layer and downstream products are preliminary and not field validated.[20]
4. **Severe observability censoring.** Only 48.15% of the projected detachment reference had at least two valid views. Layover/shadow and slope-screened cells are unknown, not stable.
5. **Amplitude ambiguity.** VV/VH changes can reflect snow/ice, roughness, moisture, geometry, vegetation loss, deposition, erosion or construction. The mask is labeled backscatter change, not flood/debris.
6. **Coherence is a separate observable.** OPERA RTC amplitude has no interferometric coherence. The dedicated HyP3/NISAR comparisons preserve coherence, phase and masks separately; no amplitude layer is relabeled as displacement.
7. **Temporal mixing.** The three event pairs use different pre/post dates. Secondary rain, snow, cleanup or ongoing slope/channel change may enter the signal.
8. **Threshold dependence.** Consensus area changes from 1.7244 to 0.5670 km² across `k=2.5–4.0`. The binary boundary is a model output, not a surveyed edge.
9. **Conservative false-alarm label.** Pixels outside the detachment polygon are counted as false positives even though the polygon is not a complete event inventory.
10. **DSWx gap.** No event-adjacent DSWx product exists in the queried CMR archive. Product performance was not inferred from a 79-day seasonal pair.
11. **NISAR maturity.** Event-period products are PROVISIONAL: calibrated, but validated at a limited set of sites rather than fully validated globally.[23]
12. **Precursor unresolved.** The published up-to-40 cm InSAR figure was not independently reproduced, and its physical interpretation remains open.[9][11]
13. **Precipitation scale.** IMERG's 0.1° cell and POWER's coarser fields cannot resolve orographic enhancement, rain/snow partition or fracture water at the source.[15][17][18]
14. **Archive timestamps are not service guarantees.** CMR provider insertion does not prove when every user or emergency actor could discover, download and analyse the data.
15. **Catalog absence is bounded.** ALOS-2/SAOCOM/RCM findings apply to the exact queried collections and AOI, not every national or commercial archive.
16. **Vision-service failure.** Final PNGs were verified for dimensions, alpha/color classes and file integrity, but automated visual inspection was blocked by an external 401.
17. **No field/community validation.** No interviews, gauge-owner confirmation, GNSS, UAV survey, high-water mark or sediment survey was obtained.
18. **DEM is a DSM.** Copernicus GLO-30 represents the surface, not bare-earth terrain everywhere, although it is adequate for this first slope screen.[19]
19. **Catalog footprint is not valid coverage.** The 6,803-row exact-AOI inventory records footprint intersection. Date and chain counts do not prove target-pixel coherence, phase validity, unshadowed geometry or scientific usability.
20. **C-band terrain mask is incomplete.** The HyP3 burst package supplied water/nodata masks but no explicit layover/shadow layer; the coherence screen therefore has medium-low confidence despite its optical/null validation.
21. **L-band null is exploratory.** The NISAR control window was selected after inspecting two pairs and was not independently field-verified as stable. It supports a failure diagnosis, not a confirmatory deformation estimate.
22. **Two coherence pairs are not SBAS/PS.** The C-band chain has three epochs and two adjacent interferograms. It does not establish a velocity, acceleration, seasonal baseline or precursor time series.
23. **Exposure is proximity only.** OSM feature centres and distance bands do not represent population, damage, accessibility, ownership, failure probability or risk.
24. **Split archives remain incomplete.** NISAR S-band/Bhoonidhi, RCM and SAOCOM holdings were not enumerated. Their availability is UNVERIFIED rather than zero.

## Sources

[8] https://www.icimod.org/kyirong-rasuwa-flood-2026-nepal-china-border — Gyirong-Rasuwa flood 2026
    > "On 26 August, there was no lake found at the origin point, but rather the collapse of a mountain face."
    > "On 8 July 2025, a lake that had formed on top of the Purepu Glacier in Tibet, about 36 km north of the border, drained suddenly and sent a flood down the same Lhende–Bhotekoshi channel."
[9] https://www.icimod.org/press-releases/second-major-himalayan-flood-in-seven-weeks-raises-new-questions-about-mountain-risk — Second major Himalayan flood in seven weeks raises alarm over compounding mountain hazards
    > "Sentinel-1 satellite radar detected up to 40 cm of ground deformation between 7 July and 24 August 2026, during the 48 day before the collapse."
[11] https://doi.org/10.53055/ICIMOD.1150 — Understanding the Gyirong–Rasuwa disaster of 26 August 2026: A preliminary synthesis
    > "The source of the event was a bedrock failure that sheared away part of a hanging glacier; this has been established through seismic, satellite, and drone evidence."
[15] https://power.larc.nasa.gov/docs/methodology/data/sources — NASA POWER Data Sources
    > "The POWER Project provides data at the native sources resolution from the data providers; primary solar resolution is a global 1° x 1° latitude/longitude grid from CERES SYN1deg while the meteorological data sources are ½° x ⅝° latitude/longitude grid from GMAO MERRA-2."
[17] https://www.earthdata.nasa.gov/data/catalog/ges-disc-gpm-3imerghhe-07 — GPM IMERG Early V07 catalog
    > "The precipitation estimates from the various precipitation-relevant satellite passive microwave (PMW) sensors comprising the GPM constellation are computed using the 2021 version of the Goddard Profiling Algorithm (GPROF2021), then gridded, intercalibrated to the GPM Combined Ku Radar-Radiometer Algorithm (CORRA) product, and merged into half-hourly 0.1°x0.1° (roughly 10x10 km) fields."
[18] https://gpm.nasa.gov/sites/default/files/2025-02/FAQ%20for%20IMERG%20V07%20Applications%20Users_202502.pdf — IMERG V07 Applications FAQ
    > "Greater uncertainty near orographic regions may lead to underestimated precipitation rates."
[19] https://copernicus-dem-30m.s3.amazonaws.com/readme.html — Copernicus DEM GLO-30 public COG readme
    > "GLO-30 Public provides limited worldwide coverage at 30 meters because a small subset of tiles covering specific countries are not yet released to the public by the Copernicus Programme."
[20] https://unosat.org/products/4259 — UNOSAT Rasuwa-Nuwakot impact assessment 4259
    > "This map illustrates the cumulative satellite-detected mudflow/rockflow extent derived from Sentinel-2 imagery acquired on 27 August 2026 and PlanetScope imagery acquired on 26 August 2026."
[23] https://nisar-docs.asf.alaska.edu/availability-overview — Available NISAR Data
    > "NISAR PROVISIONAL datasets were released July 20, 2026. These products are fully calibrated and have undergone validation at a limited set of sites around the world."
