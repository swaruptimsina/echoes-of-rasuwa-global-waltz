#!/usr/bin/env python3
"""Range-read real NISAR HDF5 subsets with Earthdata + fsspec + h5py.

No science HDF5 file is downloaded. Each remote file is opened through the
Earthdata-authenticated fsspec HTTPS filesystem, and fsspec's block-cache
counters are recorded to show how many bytes were requested.
"""
from __future__ import annotations

import csv
import hashlib
import importlib.metadata
import io
import json
import math
import platform
from collections import Counter
from pathlib import Path
from typing import Any

import earthaccess
import h5py
import numpy as np
import rasterio
from pyproj import Transformer
from rasterio.transform import Affine

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
SUBSETS = ROOT / "subsets"
QA_DIR = OUT / "qa"
BLOCK_SIZE = 1024 * 1024
REGIONS = {
    "source": (85.5110, 28.2820, 85.5310, 28.2970),
    "null": (85.4910, 28.3505, 85.5075, 28.3653),
}
SELECTED_PAIRS = {
    "quiet": ("2026-07-14", "2026-07-26"),
    "event": ("2026-08-19", "2026-08-31"),
}

GUNW_ROOT = "science/LSAR/GUNW/grids/frequencyA"
GUNW_PATHS = {
    "coherence_magnitude": f"{GUNW_ROOT}/unwrappedInterferogram/HH/coherenceMagnitude",
    "unwrapped_phase_rad": f"{GUNW_ROOT}/unwrappedInterferogram/HH/unwrappedPhase",
    "connected_components": f"{GUNW_ROOT}/unwrappedInterferogram/HH/connectedComponents",
    "gunw_mask": f"{GUNW_ROOT}/unwrappedInterferogram/mask",
    "ionosphere_phase_screen_rad": f"{GUNW_ROOT}/unwrappedInterferogram/HH/ionospherePhaseScreen",
    "ionosphere_phase_uncertainty_rad": f"{GUNW_ROOT}/unwrappedInterferogram/HH/ionospherePhaseScreenUncertainty",
    "blended_along_track_offset_m": f"{GUNW_ROOT}/pixelOffsets/HH/alongTrackOffset",
    "blended_slant_range_offset_m": f"{GUNW_ROOT}/pixelOffsets/HH/slantRangeOffset",
    "blended_offset_correlation_peak": f"{GUNW_ROOT}/pixelOffsets/HH/correlationSurfacePeak",
}
GUNW_GRID_ROOT = f"{GUNW_ROOT}/unwrappedInterferogram"

GOFF_ROOT = "science/LSAR/GOFF/grids/frequencyA/pixelOffsets"
GOFF_GRID_ROOT = GOFF_ROOT
GOFF_PATHS = {"goff_mask": f"{GOFF_ROOT}/mask"}
for layer in (1, 2, 3):
    prefix = f"{GOFF_ROOT}/HH/layer{layer}"
    GOFF_PATHS.update({
        f"layer{layer}_along_track_offset_m": f"{prefix}/alongTrackOffset",
        f"layer{layer}_slant_range_offset_m": f"{prefix}/slantRangeOffset",
        f"layer{layer}_correlation_peak": f"{prefix}/correlationSurfacePeak",
        f"layer{layer}_snr": f"{prefix}/snr",
        f"layer{layer}_along_track_variance_m2": f"{prefix}/alongTrackOffsetVariance",
        f"layer{layer}_slant_range_variance_m2": f"{prefix}/slantRangeOffsetVariance",
        f"layer{layer}_cross_offset_variance_m2": f"{prefix}/crossOffsetVariance",
    })

GCOV_ROOT = "science/LSAR/GCOV/grids/frequencyA"
GCOV_GRID_ROOT = GCOV_ROOT
GCOV_PATHS = {
    "hhhh_gamma0_power": f"{GCOV_ROOT}/HHHH",
    "hvhv_gamma0_power": f"{GCOV_ROOT}/HVHV",
    "gcov_mask": f"{GCOV_ROOT}/mask",
    "input_data_exception_mask": f"{GCOV_ROOT}/inputDataExceptionMask",
    "rtc_gamma_to_sigma_factor": f"{GCOV_ROOT}/rtcGammaToSigmaFactor",
}


def scalar(value: Any) -> Any:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, np.generic):
        return scalar(value.item())
    if isinstance(value, np.ndarray):
        if value.ndim == 0:
            return scalar(value.item())
        if value.size <= 100:
            return [scalar(v) for v in value.tolist()]
        return {"shape": list(value.shape), "dtype": str(value.dtype)}
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as stream:
        return list(csv.DictReader(stream))


def pick_pairs() -> dict[str, dict[str, str]]:
    rows = load_csv(OUT / "canonical_chain.csv")
    selected: dict[str, dict[str, str]] = {}
    for label, (reference_date, secondary_date) in SELECTED_PAIRS.items():
        matches = [
            row for row in rows
            if row["reference_date"] == reference_date and row["secondary_date"] == secondary_date
        ]
        if len(matches) != 1:
            raise RuntimeError(f"expected one canonical edge for {label}, found {len(matches)}")
        selected[label] = matches[0]
    return selected


def product_lookup() -> dict[str, dict[str, str]]:
    return {row["product_id"]: row for row in load_csv(OUT / "catalog_records.csv")}


def bbox_slice(x: np.ndarray, y: np.ndarray, epsg: int, bbox: tuple[float, ...]) -> tuple[slice, slice]:
    transform = Transformer.from_crs(4326, epsg, always_xy=True)
    corners = [
        transform.transform(bbox[0], bbox[1]),
        transform.transform(bbox[0], bbox[3]),
        transform.transform(bbox[2], bbox[1]),
        transform.transform(bbox[2], bbox[3]),
    ]
    xs = [point[0] for point in corners]
    ys = [point[1] for point in corners]
    columns = np.flatnonzero((x >= min(xs)) & (x <= max(xs)))
    rows = np.flatnonzero((y >= min(ys)) & (y <= max(ys)))
    if not len(rows) or not len(columns):
        raise RuntimeError(f"bbox {bbox} does not intersect EPSG:{epsg} grid")
    return slice(int(rows.min()), int(rows.max()) + 1), slice(int(columns.min()), int(columns.max()) + 1)


def describe_dataset(dataset: h5py.Dataset) -> dict:
    wanted = {
        "_FillValue", "description", "units", "grid_mapping", "long_name",
        "min_value", "max_value", "mean_value", "sample_stddev", "valid_min",
        "percentage_water",
    }
    return {
        "shape": list(dataset.shape),
        "dtype": str(dataset.dtype),
        "chunks": list(dataset.chunks) if dataset.chunks else None,
        "compression": dataset.compression,
        "compression_opts": dataset.compression_opts,
        "attrs": {str(k): scalar(v) for k, v in dataset.attrs.items() if str(k) in wanted},
    }


def describe_hdf5(handle: h5py.File) -> dict:
    datasets: dict[str, dict] = {}

    def visitor(name: str, obj: Any) -> None:
        if isinstance(obj, h5py.Dataset):
            datasets[name] = describe_dataset(obj)

    handle.visititems(visitor)
    return {
        "root_groups": list(handle.keys()),
        "dataset_count": len(datasets),
        "datasets": datasets,
    }


def identification(handle: h5py.File, product: str) -> dict:
    # Identification is common to all product types at /science/LSAR/identification.
    root = "science/LSAR/identification"
    if root not in handle:
        return {}
    output: dict[str, Any] = {}
    for name, obj in handle[root].items():
        if isinstance(obj, h5py.Dataset) and obj.size <= 100:
            try:
                output[name] = scalar(obj[()])
            except Exception as exc:
                output[name] = f"{type(exc).__name__}: {exc}"
    return output


def processing_parameters(handle: h5py.File, product: str) -> dict:
    root = f"science/LSAR/{product}/metadata/processingInformation/parameters"
    output: dict[str, Any] = {}
    if root not in handle:
        return output

    def visitor(name: str, obj: Any) -> None:
        if isinstance(obj, h5py.Dataset) and obj.size <= 16:
            try:
                output[name] = {
                    "value": scalar(obj[()]),
                    "units": scalar(obj.attrs.get("units")) if "units" in obj.attrs else None,
                    "description": scalar(obj.attrs.get("description")) if "description" in obj.attrs else None,
                }
            except Exception as exc:
                output[name] = {"error": f"{type(exc).__name__}: {exc}"}

    handle[root].visititems(visitor)
    return output


def array_stats(values: np.ndarray, valid: np.ndarray | None = None) -> dict:
    array = np.asarray(values)
    mask = np.isfinite(array) if np.issubdtype(array.dtype, np.floating) else np.ones(array.shape, dtype=bool)
    if valid is not None:
        mask &= valid
    selected = array[mask]
    output = {
        "total_pixels": int(array.size),
        "valid_pixels": int(selected.size),
        "valid_fraction": float(selected.size / array.size) if array.size else None,
    }
    if not selected.size:
        output.update({key: None for key in ("min", "p05", "median", "mean", "p95", "max", "stddev")})
        return output
    numeric = selected.astype("float64")
    output.update({
        "min": float(np.min(numeric)),
        "p05": float(np.percentile(numeric, 5)),
        "median": float(np.median(numeric)),
        "mean": float(np.mean(numeric)),
        "p95": float(np.percentile(numeric, 95)),
        "max": float(np.max(numeric)),
        "stddev": float(np.std(numeric)),
    })
    return output


def decode_pair_mask(mask: np.ndarray) -> dict[str, np.ndarray]:
    encoded = mask.astype("uint32")
    low = encoded & np.uint32(255)
    return {
        "water_flag": low // np.uint32(100),
        "reference_subswath": (low % np.uint32(100)) // np.uint32(10),
        "secondary_subswath": low % np.uint32(10),
        "anomaly_bits": (encoded >> np.uint32(8)) & np.uint32(65535),
        "ionosphere_interpolated_flag": (encoded >> np.uint32(24)) & np.uint32(1),
    }


def plane_residual_mad(values: np.ndarray, valid: np.ndarray) -> float | None:
    if int(valid.sum()) < 10:
        return None
    rows, columns = np.indices(values.shape)
    matrix = np.column_stack((rows[valid], columns[valid], np.ones(int(valid.sum()))))
    coefficients = np.linalg.lstsq(matrix, values[valid], rcond=None)[0]
    residual = values - (coefficients[0] * rows + coefficients[1] * columns + coefficients[2])
    selected = residual[valid]
    return float(np.median(np.abs(selected - np.median(selected))))


def gunw_quality(arrays: dict[str, np.ndarray]) -> dict:
    decoded = decode_pair_mask(arrays["gunw_mask"])
    sample_valid = (
        (decoded["reference_subswath"] > 0)
        & (decoded["secondary_subswath"] > 0)
        & (decoded["anomaly_bits"] == 0)
    )
    component = arrays["connected_components"]
    phase = arrays["unwrapped_phase_rad"]
    phase_valid = sample_valid & (component > 0) & (component != 65535) & np.isfinite(phase)
    coherence_valid = sample_valid & np.isfinite(arrays["coherence_magnitude"])
    offset_valid = sample_valid & np.isfinite(arrays["blended_offset_correlation_peak"])
    return {
        "sample_valid_pixels": int(sample_valid.sum()),
        "sample_valid_fraction": float(sample_valid.mean()),
        "phase_valid_pixels": int(phase_valid.sum()),
        "phase_valid_fraction": float(phase_valid.mean()),
        "connected_component_counts": {
            str(int(value)): int(count)
            for value, count in zip(*np.unique(component, return_counts=True))
        },
        "encoded_mask_counts": {
            str(int(value)): int(count)
            for value, count in zip(*np.unique(arrays["gunw_mask"], return_counts=True))
        },
        "ionosphere_interpolated_fraction_of_sample_valid": (
            float(decoded["ionosphere_interpolated_flag"][sample_valid].mean()) if sample_valid.any() else None
        ),
        "coherence": array_stats(arrays["coherence_magnitude"], coherence_valid),
        "coherence_fraction_ge_0_3": (
            float((arrays["coherence_magnitude"][coherence_valid] >= 0.3).mean()) if coherence_valid.any() else None
        ),
        "coherence_fraction_ge_0_5": (
            float((arrays["coherence_magnitude"][coherence_valid] >= 0.5).mean()) if coherence_valid.any() else None
        ),
        "unwrapped_phase_rad": array_stats(phase, phase_valid),
        "unwrapped_phase_plane_residual_mad_rad": plane_residual_mad(phase, phase_valid),
        "ionosphere_phase_screen_rad": array_stats(arrays["ionosphere_phase_screen_rad"], sample_valid),
        "ionosphere_phase_uncertainty_rad": array_stats(arrays["ionosphere_phase_uncertainty_rad"], sample_valid),
        "blended_along_track_offset_m": array_stats(arrays["blended_along_track_offset_m"], offset_valid),
        "blended_slant_range_offset_m": array_stats(arrays["blended_slant_range_offset_m"], offset_valid),
        "blended_offset_correlation_peak": array_stats(arrays["blended_offset_correlation_peak"], offset_valid),
    }


def goff_quality(arrays: dict[str, np.ndarray]) -> dict:
    decoded = decode_pair_mask(arrays["goff_mask"])
    sample_valid = (
        (decoded["reference_subswath"] > 0)
        & (decoded["secondary_subswath"] > 0)
        & (decoded["anomaly_bits"] == 0)
    )
    output: dict[str, Any] = {
        "sample_valid_pixels": int(sample_valid.sum()),
        "sample_valid_fraction": float(sample_valid.mean()),
        "encoded_mask_counts": {
            str(int(value)): int(count)
            for value, count in zip(*np.unique(arrays["goff_mask"], return_counts=True))
        },
        "ionosphere_interpolated_fraction_of_sample_valid": (
            float(decoded["ionosphere_interpolated_flag"][sample_valid].mean()) if sample_valid.any() else None
        ),
        "layers_are_raw_unculled_unfiltered": True,
    }
    for layer in (1, 2, 3):
        correlation = arrays[f"layer{layer}_correlation_peak"]
        valid = sample_valid & np.isfinite(correlation)
        output[f"layer{layer}"] = {
            "along_track_offset_m": array_stats(arrays[f"layer{layer}_along_track_offset_m"], valid),
            "slant_range_offset_m": array_stats(arrays[f"layer{layer}_slant_range_offset_m"], valid),
            "correlation_peak": array_stats(correlation, valid),
            "correlation_fraction_ge_0_5": float((correlation[valid] >= 0.5).mean()) if valid.any() else None,
            "snr": array_stats(arrays[f"layer{layer}_snr"], valid),
            "along_track_variance_m2": array_stats(arrays[f"layer{layer}_along_track_variance_m2"], valid),
            "slant_range_variance_m2": array_stats(arrays[f"layer{layer}_slant_range_variance_m2"], valid),
            "cross_offset_variance_m2": array_stats(arrays[f"layer{layer}_cross_offset_variance_m2"], valid),
        }
    return output


def gcov_valid(arrays: dict[str, np.ndarray]) -> np.ndarray:
    mask = arrays["gcov_mask"]
    exception = arrays["input_data_exception_mask"]
    return (
        (mask > 0) & (mask != 255) & (exception == 0)
        & np.isfinite(arrays["hhhh_gamma0_power"]) & (arrays["hhhh_gamma0_power"] > 0)
        & np.isfinite(arrays["hvhv_gamma0_power"]) & (arrays["hvhv_gamma0_power"] > 0)
    )


def grid_transform(x: np.ndarray, y: np.ndarray) -> Affine:
    if len(x) < 2 or len(y) < 2:
        raise RuntimeError("need at least two coordinates for GeoTIFF transform")
    dx = float(np.median(np.diff(x)))
    dy = float(np.median(np.diff(y)))
    return Affine(dx, 0.0, float(x[0] - dx / 2), 0.0, dy, float(y[0] - dy / 2))


def write_geotiff(path: Path, arrays: list[np.ndarray], names: list[str], x: np.ndarray, y: np.ndarray, epsg: int, tags: dict[str, str]) -> None:
    if not arrays:
        return
    for array in arrays:
        if array.shape != arrays[0].shape:
            raise RuntimeError(f"mismatched array shape for {path}")
    profile = {
        "driver": "GTiff",
        "width": arrays[0].shape[1],
        "height": arrays[0].shape[0],
        "count": len(arrays),
        "dtype": "float32",
        "crs": f"EPSG:{epsg}",
        "transform": grid_transform(x, y),
        "compress": "deflate",
        "predictor": 3,
        "tiled": False,
        "nodata": np.nan,
    }
    with rasterio.open(path, "w", **profile) as dataset:
        for index, (array, name) in enumerate(zip(arrays, names), start=1):
            dataset.write(np.asarray(array, dtype="float32"), index)
            dataset.set_band_description(index, name)
        dataset.update_tags(**tags)


def save_npz(path: Path, arrays: dict[str, np.ndarray], x: np.ndarray, y: np.ndarray, epsg: int) -> None:
    np.savez_compressed(path, x_coordinates=x, y_coordinates=y, epsg=np.int32(epsg), **arrays)


def read_remote_subsets(
    fs: Any,
    url: str,
    product_id: str,
    product: str,
    grid_root: str,
    paths: dict[str, str],
    capture_structure: bool,
) -> tuple[dict[str, dict], dict]:
    result: dict[str, dict] = {}
    with fs.open(url, "rb", block_size=BLOCK_SIZE, cache_type="blockcache") as remote:
        with h5py.File(remote, "r", rdcc_nbytes=16 * 1024 * 1024) as handle:
            x = handle[f"{grid_root}/xCoordinates"][:]
            y = handle[f"{grid_root}/yCoordinates"][:]
            epsg = int(handle[f"{grid_root}/projection"].attrs["epsg_code"])
            for region_name, bbox in REGIONS.items():
                rows, columns = bbox_slice(x, y, epsg, bbox)
                arrays = {name: handle[path][rows, columns] for name, path in paths.items()}
                result[region_name] = {
                    "arrays": arrays,
                    "x": x[columns],
                    "y": y[rows],
                    "epsg": epsg,
                    "row_slice": [rows.start, rows.stop],
                    "column_slice": [columns.start, columns.stop],
                    "requested_bbox_wsen": list(bbox),
                }
            structure = describe_hdf5(handle) if capture_structure else None
            id_values = identification(handle, product)
            parameters = processing_parameters(handle, product)
        cache = remote.cache
        access = {
            "product_id": product_id,
            "product": product,
            "original_https_url": url,
            "remote_file_size_bytes": int(remote.size),
            "fsspec_block_size_bytes": int(remote.blocksize),
            "fsspec_cache_type": type(cache).__name__,
            "range_bytes_requested": int(cache.total_requested_bytes),
            "range_request_cache_misses": int(cache.miss_count),
            "range_request_cache_hits": int(cache.hit_count),
            "fraction_of_remote_file_requested": float(cache.total_requested_bytes / remote.size),
            "full_download_avoided": bool(cache.total_requested_bytes < remote.size),
            "structure": structure,
            "identification": id_values,
            "processing_parameters": parameters,
        }
    return result, access


def qa_summary(session: Any, catalog_row: dict[str, str]) -> dict:
    h5_url = catalog_row["https_url"]
    if not h5_url.endswith(".h5"):
        raise RuntimeError(f"not an HDF5 URL: {h5_url}")
    url = h5_url[:-3] + "_QA_SUMMARY.csv"
    response = session.get(url, timeout=180)
    status = response.status_code
    response.raise_for_status()
    payload = response.content
    path = QA_DIR / f"{catalog_row['product_id']}_QA_SUMMARY.csv"
    path.write_bytes(payload)
    rows = list(csv.DictReader(io.StringIO(payload.decode("utf-8-sig"))))
    failures = [row for row in rows if row.get("Result") == "FAIL"]
    return {
        "product_id": catalog_row["product_id"],
        "product": catalog_row["product"],
        "requested_url": url,
        "http_status": status,
        "bytes": len(payload),
        "sha256": hashlib.sha256(payload).hexdigest(),
        "saved_path": str(path.relative_to(ROOT)),
        "result_counts": dict(Counter(row.get("Result") or "BLANK" for row in rows)),
        "failures": failures,
    }


def main() -> None:
    SUBSETS.mkdir(parents=True, exist_ok=True)
    QA_DIR.mkdir(parents=True, exist_ok=True)
    pairs = pick_pairs()
    lookup = product_lookup()
    auth = earthaccess.login(strategy="netrc")
    if not auth.authenticated:
        raise RuntimeError("existing Earthdata netrc did not authenticate")
    fs = earthaccess.get_fsspec_https_session()
    session = auth.get_session()
    session.headers.update({"User-Agent": "rasuwa-nisar-range-subset/1.0"})

    report: dict[str, Any] = {
        "software": {
            "python": platform.python_version(),
            "earthaccess": importlib.metadata.version("earthaccess"),
            "fsspec": importlib.metadata.version("fsspec"),
            "h5py": importlib.metadata.version("h5py"),
            "numpy": np.__version__,
            "rasterio": rasterio.__version__,
        },
        "authentication": {
            "earthdata_netrc_authenticated": True,
            "credentials_persisted_in_outputs": False,
            "method": "earthaccess.login(strategy='netrc') + earthaccess.get_fsspec_https_session()",
        },
        "regions": {name: list(bbox) for name, bbox in REGIONS.items()},
        "region_note": "Null is exploratory/coherence-selected, not independently surveyed as stable.",
        "fsspec_access": [],
        "pairs": {},
        "qa_sidecars": [],
        "files": [],
    }

    qa_products: dict[str, dict[str, str]] = {}
    for pair_label, edge in pairs.items():
        pair_output: dict[str, Any] = {
            "reference_date": edge["reference_date"],
            "secondary_date": edge["secondary_date"],
            "maturity": edge["maturity"],
            "crid": edge["crid"],
            "products": {},
            "regions": {name: {} for name in REGIONS},
        }
        report["pairs"][pair_label] = pair_output

        gunw_id = edge["gunw_product_id"]
        gunw_url = edge["gunw_url"]
        gunw, gunw_access = read_remote_subsets(
            fs, gunw_url, gunw_id, "GUNW", GUNW_GRID_ROOT, GUNW_PATHS,
            capture_structure=(pair_label == "event"),
        )
        report["fsspec_access"].append({key: value for key, value in gunw_access.items() if key not in {"structure", "processing_parameters"}})
        pair_output["products"]["gunw"] = {
            "product_id": gunw_id,
            "concept_id": edge["gunw_concept_id"],
            "file_size_bytes": int(edge["gunw_size_bytes"]),
            "product_version": edge["gunw_product_version"],
            "range_access": {key: value for key, value in gunw_access.items() if key not in {"structure", "identification", "processing_parameters"}},
            "identification": gunw_access["identification"],
        }
        if gunw_access["structure"] is not None:
            structure_path = OUT / "hdf5_structure_gunw.json"
            structure_path.write_text(json.dumps({
                "product_id": gunw_id,
                "structure": gunw_access["structure"],
                "processing_parameters": gunw_access["processing_parameters"],
            }, indent=2) + "\n")
        for region_name, subset in gunw.items():
            arrays = subset["arrays"]
            quality = gunw_quality(arrays)
            pair_output["regions"][region_name]["gunw"] = {
                "shape": list(next(iter(arrays.values())).shape),
                "epsg": subset["epsg"],
                "row_slice": subset["row_slice"],
                "column_slice": subset["column_slice"],
                "quality": quality,
            }
            base = f"{pair_label}_{region_name}_gunw"
            save_npz(SUBSETS / f"{base}.npz", arrays, subset["x"], subset["y"], subset["epsg"])
            decoded = decode_pair_mask(arrays["gunw_mask"])
            sample_valid = (
                (decoded["reference_subswath"] > 0)
                & (decoded["secondary_subswath"] > 0)
                & (decoded["anomaly_bits"] == 0)
            )
            phase_valid = sample_valid & (arrays["connected_components"] > 0) & np.isfinite(arrays["unwrapped_phase_rad"])
            phase_screened = np.where(phase_valid, arrays["unwrapped_phase_rad"], np.nan)
            write_geotiff(
                SUBSETS / f"{base}.tif",
                [
                    arrays["coherence_magnitude"], arrays["unwrapped_phase_rad"], phase_screened,
                    arrays["connected_components"], arrays["gunw_mask"],
                    arrays["ionosphere_phase_screen_rad"], arrays["ionosphere_phase_uncertainty_rad"],
                    arrays["blended_along_track_offset_m"], arrays["blended_slant_range_offset_m"],
                    arrays["blended_offset_correlation_peak"],
                ],
                [
                    "coherence_magnitude", "unwrapped_phase_raw_rad", "unwrapped_phase_quality_screened_rad",
                    "connected_components", "encoded_mask", "ionosphere_phase_screen_rad",
                    "ionosphere_phase_uncertainty_rad", "blended_along_track_offset_m",
                    "blended_slant_range_offset_m", "blended_offset_correlation_peak",
                ],
                subset["x"], subset["y"], subset["epsg"],
                {"source_product": gunw_id, "region": region_name, "pair": pair_label,
                 "interpretation_limit": "Phase corrections are supplied but not applied; quality-screen before interpretation."},
            )
        qa_products[gunw_id] = lookup[gunw_id]

        goff_id = edge["goff_product_id"]
        goff_url = edge["goff_url"]
        goff, goff_access = read_remote_subsets(
            fs, goff_url, goff_id, "GOFF", GOFF_GRID_ROOT, GOFF_PATHS,
            capture_structure=(pair_label == "event"),
        )
        report["fsspec_access"].append({key: value for key, value in goff_access.items() if key not in {"structure", "processing_parameters"}})
        pair_output["products"]["goff"] = {
            "product_id": goff_id,
            "concept_id": edge["goff_concept_id"],
            "file_size_bytes": int(edge["goff_size_bytes"]),
            "product_version": edge["goff_product_version"],
            "range_access": {key: value for key, value in goff_access.items() if key not in {"structure", "identification", "processing_parameters"}},
            "identification": goff_access["identification"],
        }
        if goff_access["structure"] is not None:
            structure_path = OUT / "hdf5_structure_goff.json"
            structure_path.write_text(json.dumps({
                "product_id": goff_id,
                "structure": goff_access["structure"],
                "processing_parameters": goff_access["processing_parameters"],
            }, indent=2) + "\n")
        for region_name, subset in goff.items():
            arrays = subset["arrays"]
            quality = goff_quality(arrays)
            pair_output["regions"][region_name]["goff"] = {
                "shape": list(next(iter(arrays.values())).shape),
                "epsg": subset["epsg"],
                "row_slice": subset["row_slice"],
                "column_slice": subset["column_slice"],
                "quality": quality,
            }
            base = f"{pair_label}_{region_name}_goff"
            save_npz(SUBSETS / f"{base}.npz", arrays, subset["x"], subset["y"], subset["epsg"])
            names = [
                name for name in arrays
                if name == "goff_mask" or any(token in name for token in ("offset_m", "correlation_peak", "snr"))
            ]
            write_geotiff(
                SUBSETS / f"{base}.tif", [arrays[name] for name in names], names,
                subset["x"], subset["y"], subset["epsg"],
                {"source_product": goff_id, "region": region_name, "pair": pair_label,
                 "interpretation_limit": "GOFF layers are raw, unculled and unfiltered; inspect correlation/SNR/variance."},
            )
        qa_products[goff_id] = lookup[goff_id]

        gcov_ids = {
            "reference": edge["reference_gcov_product_id"],
            "secondary": edge["secondary_gcov_product_id"],
        }
        gcov_subsets: dict[str, dict[str, dict]] = {}
        for position, gcov_id in gcov_ids.items():
            catalog = lookup[gcov_id]
            gcov, gcov_access = read_remote_subsets(
                fs, catalog["https_url"], gcov_id, "GCOV", GCOV_GRID_ROOT, GCOV_PATHS,
                capture_structure=(pair_label == "event" and position == "reference"),
            )
            gcov_subsets[position] = gcov
            report["fsspec_access"].append({key: value for key, value in gcov_access.items() if key not in {"structure", "processing_parameters"}})
            pair_output["products"][f"gcov_{position}"] = {
                "product_id": gcov_id,
                "concept_id": catalog["concept_id"],
                "maturity": catalog["maturity"],
                "crid": catalog["crid"],
                "file_size_bytes": int(catalog["size_bytes"]),
                "product_version": catalog["product_version"],
                "range_access": {key: value for key, value in gcov_access.items() if key not in {"structure", "identification", "processing_parameters"}},
                "identification": gcov_access["identification"],
            }
            if gcov_access["structure"] is not None:
                structure_path = OUT / "hdf5_structure_gcov.json"
                structure_path.write_text(json.dumps({
                    "product_id": gcov_id,
                    "structure": gcov_access["structure"],
                    "processing_parameters": gcov_access["processing_parameters"],
                }, indent=2) + "\n")
            qa_products[gcov_id] = catalog

        for region_name in REGIONS:
            reference = gcov_subsets["reference"][region_name]
            secondary = gcov_subsets["secondary"][region_name]
            if not np.array_equal(reference["x"], secondary["x"]) or not np.array_equal(reference["y"], secondary["y"]):
                raise RuntimeError(f"GCOV grids differ for {pair_label}/{region_name}")
            ref_arrays = reference["arrays"]
            sec_arrays = secondary["arrays"]
            ref_valid = gcov_valid(ref_arrays)
            sec_valid = gcov_valid(sec_arrays)
            common_valid = ref_valid & sec_valid
            hhhh_change = np.full(ref_arrays["hhhh_gamma0_power"].shape, np.nan, dtype="float32")
            hvhv_change = np.full(ref_arrays["hvhv_gamma0_power"].shape, np.nan, dtype="float32")
            hhhh_change[common_valid] = 10 * np.log10(
                sec_arrays["hhhh_gamma0_power"][common_valid] / ref_arrays["hhhh_gamma0_power"][common_valid]
            )
            hvhv_change[common_valid] = 10 * np.log10(
                sec_arrays["hvhv_gamma0_power"][common_valid] / ref_arrays["hvhv_gamma0_power"][common_valid]
            )
            quality = {
                "reference_valid_fraction": float(ref_valid.mean()),
                "secondary_valid_fraction": float(sec_valid.mean()),
                "common_valid_fraction": float(common_valid.mean()),
                "reference_mask_counts": {str(int(v)): int(n) for v, n in zip(*np.unique(ref_arrays["gcov_mask"], return_counts=True))},
                "secondary_mask_counts": {str(int(v)): int(n) for v, n in zip(*np.unique(sec_arrays["gcov_mask"], return_counts=True))},
                "hhhh_post_minus_pre_db": array_stats(hhhh_change),
                "hvhv_post_minus_pre_db": array_stats(hvhv_change),
                "observable": "calibrated gamma-0 backscatter change; not a deformation or hazard class",
            }
            pair_output["regions"][region_name]["gcov"] = {
                "shape": list(hhhh_change.shape),
                "epsg": reference["epsg"],
                "quality": quality,
            }
            combined = {
                "reference_hhhh_gamma0_power": ref_arrays["hhhh_gamma0_power"],
                "secondary_hhhh_gamma0_power": sec_arrays["hhhh_gamma0_power"],
                "hhhh_post_minus_pre_db": hhhh_change,
                "reference_hvhv_gamma0_power": ref_arrays["hvhv_gamma0_power"],
                "secondary_hvhv_gamma0_power": sec_arrays["hvhv_gamma0_power"],
                "hvhv_post_minus_pre_db": hvhv_change,
                "reference_mask": ref_arrays["gcov_mask"],
                "secondary_mask": sec_arrays["gcov_mask"],
                "common_valid": common_valid.astype("uint8"),
            }
            base = f"{pair_label}_{region_name}_gcov_change"
            save_npz(SUBSETS / f"{base}.npz", combined, reference["x"], reference["y"], reference["epsg"])
            ref_hhhh_db = np.where(ref_valid, 10 * np.log10(ref_arrays["hhhh_gamma0_power"]), np.nan)
            sec_hhhh_db = np.where(sec_valid, 10 * np.log10(sec_arrays["hhhh_gamma0_power"]), np.nan)
            ref_hvhv_db = np.where(ref_valid, 10 * np.log10(ref_arrays["hvhv_gamma0_power"]), np.nan)
            sec_hvhv_db = np.where(sec_valid, 10 * np.log10(sec_arrays["hvhv_gamma0_power"]), np.nan)
            write_geotiff(
                SUBSETS / f"{base}.tif",
                [ref_hhhh_db, sec_hhhh_db, hhhh_change, ref_hvhv_db, sec_hvhv_db, hvhv_change, common_valid],
                ["reference_HHHH_gamma0_db", "secondary_HHHH_gamma0_db", "HHHH_post_minus_pre_db",
                 "reference_HVHV_gamma0_db", "secondary_HVHV_gamma0_db", "HVHV_post_minus_pre_db",
                 "common_valid_mask"],
                reference["x"], reference["y"], reference["epsg"],
                {"reference_product": gcov_ids["reference"], "secondary_product": gcov_ids["secondary"],
                 "region": region_name, "pair": pair_label,
                 "interpretation_limit": "Backscatter change only; no speckle filtering or class validation applied."},
            )

        # Region contrasts are diagnostics, not displacement estimates.
        source_gunw = pair_output["regions"]["source"]["gunw"]["quality"]
        null_gunw = pair_output["regions"]["null"]["gunw"]["quality"]
        source_goff = pair_output["regions"]["source"]["goff"]["quality"]
        null_goff = pair_output["regions"]["null"]["goff"]["quality"]
        pair_output["source_minus_null_diagnostics"] = {
            "coherence_median_difference": (
                source_gunw["coherence"]["median"] - null_gunw["coherence"]["median"]
                if source_gunw["coherence"]["median"] is not None and null_gunw["coherence"]["median"] is not None else None
            ),
            "unwrapped_phase_median_difference_rad": (
                source_gunw["unwrapped_phase_rad"]["median"] - null_gunw["unwrapped_phase_rad"]["median"]
                if source_gunw["unwrapped_phase_rad"]["median"] is not None and null_gunw["unwrapped_phase_rad"]["median"] is not None else None
            ),
            "unwrapped_phase_source_valid_pixels": source_gunw["phase_valid_pixels"],
            "warning": "Do not interpret the phase difference as LOS displacement without correction, reference-component checks, and sufficient source coverage.",
            "goff_layer1_along_track_median_difference_m": (
                source_goff["layer1"]["along_track_offset_m"]["median"]
                - null_goff["layer1"]["along_track_offset_m"]["median"]
            ),
            "goff_layer1_slant_range_median_difference_m": (
                source_goff["layer1"]["slant_range_offset_m"]["median"]
                - null_goff["layer1"]["slant_range_offset_m"]["median"]
            ),
        }

    for catalog_row in qa_products.values():
        report["qa_sidecars"].append(qa_summary(session, catalog_row))

    # Prove that each science object was materially subset rather than fetched.
    for access in report["fsspec_access"]:
        if not access["full_download_avoided"]:
            raise RuntimeError(f"full download detected for {access['product_id']}")
    report["range_access_conclusion"] = {
        "tested": True,
        "works_with_authenticated_fsspec_h5py": True,
        "science_hdf5_full_downloads": 0,
        "remote_science_files_opened": len(report["fsspec_access"]),
        "total_remote_science_bytes": sum(item["remote_file_size_bytes"] for item in report["fsspec_access"]),
        "total_range_bytes_requested": sum(item["range_bytes_requested"] for item in report["fsspec_access"]),
        "maximum_single_file_fraction_requested": max(item["fraction_of_remote_file_requested"] for item in report["fsspec_access"]),
        "measurement_note": "fsspec BlockCache.total_requested_bytes counts full cache blocks fetched by the file object; it is a conservative transfer proxy, not packet-level accounting.",
    }

    for path in sorted(SUBSETS.glob("*")):
        if path.is_file():
            report["files"].append({
                "path": str(path.relative_to(ROOT)),
                "bytes": path.stat().st_size,
                "sha256": hash_file(path),
            })
    report_path = OUT / "subset_summary.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({
        "output": str(report_path),
        "pairs": list(report["pairs"]),
        "subset_files": len(report["files"]),
        "range_access": report["range_access_conclusion"],
        "qa_failures": [
            {"product_id": item["product_id"], "failures": item["failures"]}
            for item in report["qa_sidecars"] if item["failures"]
        ],
    }, indent=2))


if __name__ == "__main__":
    main()
