#!/usr/bin/env python3
"""Derive concise, machine-checked findings from the NISAR catalog outputs."""
from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"


def rows(name: str) -> list[dict[str, str]]:
    with (OUT / name).open(newline="") as stream:
        return list(csv.DictReader(stream))


def numeric_summary(values: list[int]) -> dict:
    return {
        "count": len(values),
        "min_bytes": min(values) if values else None,
        "max_bytes": max(values) if values else None,
        "sum_bytes": sum(values),
        "min_decimal_gb": round(min(values) / 1e9, 6) if values else None,
        "max_decimal_gb": round(max(values) / 1e9, 6) if values else None,
        "sum_decimal_gb": round(sum(values) / 1e9, 6),
    }


def main() -> None:
    catalog = rows("catalog_records.csv")
    release_edges = rows("pair_graph.csv")
    physical = rows("physical_pair_graph.csv")
    canonical = rows("canonical_chain.csv")
    gcov = rows("gcov_nodes.csv")

    canonical_release_counts = Counter((r["maturity"], r["crid"]) for r in canonical)
    release_counts = Counter((r["maturity"], r["crid"]) for r in release_edges)
    selected_catalog = [r for r in catalog if r["stack_id"] == "098_A_016"]
    normal_validated = [r for r in selected_catalog if r["maturity"] == "VALIDATED"]

    unique_products: dict[str, dict[str, str]] = {}
    for edge in canonical:
        unique_products[edge["gunw_product_id"]] = {
            "product": "GUNW", "size_bytes": edge["gunw_size_bytes"]
        }
        unique_products[edge["goff_product_id"]] = {
            "product": "GOFF", "size_bytes": edge["goff_size_bytes"]
        }
        for position in ("reference", "secondary"):
            product_id = edge[f"{position}_gcov_product_id"]
            unique_products[product_id] = {
                "product": "GCOV", "size_bytes": edge[f"{position}_gcov_size_bytes"]
            }

    # Include the final isolated validated GCOV node (11 Nov) in full available
    # acquisition storage, even though no matching GUNW/GOFF pair exists.
    final_isolated = [
        r for r in gcov
        if r["reference_start"].startswith("2026-11-11") and r["maturity"] == "VALIDATED"
    ]
    for row in final_isolated:
        unique_products[row["product_id"]] = {"product": "GCOV", "size_bytes": row["size_bytes"]}

    bytes_by_product: dict[str, list[int]] = defaultdict(list)
    for item in unique_products.values():
        bytes_by_product[item["product"]].append(int(item["size_bytes"]))

    query_graph = json.loads((OUT / "pair_graph.json").read_text())
    findings = {
        "query_window_utc": query_graph["query_window_utc"],
        "selected_stack": "098_A_016",
        "track": 98,
        "frame": 16,
        "direction": "ASCENDING",
        "physical_acquisition_span": {
            "first": min(r["reference_start"] for r in canonical),
            "last_paired_secondary": max(r["secondary_start"] for r in canonical),
            "last_catalogued_gcov": max(r["reference_start"] for r in gcov),
        },
        "counts": {
            "all_catalog_records_both_regions": len(catalog),
            "selected_stack_catalog_records": len(selected_catalog),
            "pair_release_edges": len(release_edges),
            "physical_pair_edges": len(physical),
            "canonical_complete_gunw_goff_gcov_edges": sum(r["complete_three_product_chain"] == "True" for r in canonical),
            "unique_gcov_acquisition_times": len({r["reference_start"] for r in gcov}),
            "canonical_release_counts": {
                f"{maturity}:{crid}": count
                for (maturity, crid), count in sorted(canonical_release_counts.items())
            },
            "all_release_edge_counts": {
                f"{maturity}:{crid}": count
                for (maturity, crid), count in sorted(release_counts.items())
            },
            "normal_validated_selected_stack": dict(Counter(r["product"] for r in normal_validated)),
        },
        "physical_edges": [
            {
                "reference_start": r["reference_start"],
                "secondary_start": r["secondary_start"],
                "interval_days": float(r["interval_days"]),
                "release_variants": r["release_variants"],
                "canonical_maturity": r["canonical_maturity"],
                "canonical_crid": r["canonical_crid"],
            }
            for r in physical
        ],
        "non_12_day_edges": [
            {
                "reference_start": r["reference_start"],
                "secondary_start": r["secondary_start"],
                "interval_days": float(r["interval_days"]),
            }
            for r in physical if not 11.9 <= float(r["interval_days"]) <= 12.1
        ],
        "missing_neighbor_edges": query_graph["missing_12_day_neighbor_edges"],
        "full_download_storage_for_canonical_chain_plus_isolated_final_gcov": {
            product: numeric_summary(values) for product, values in sorted(bytes_by_product.items())
        },
        "all_unique_selected_files_total": numeric_summary([
            value for values in bytes_by_product.values() for value in values
        ]),
        "file_size_ranges_all_selected_stack_records": {
            product: numeric_summary([
                int(r["size_bytes"]) for r in selected_catalog
                if r["product"] == product and r["size_bytes"]
            ])
            for product in ("GUNW", "GOFF", "GCOV")
        },
        "validated_gap": {
            "normal_validated_gunw_records": sum(r["product"] == "GUNW" for r in normal_validated),
            "normal_validated_goff_records": sum(r["product"] == "GOFF" for r in normal_validated),
            "normal_validated_gcov_records": sum(r["product"] == "GCOV" for r in normal_validated),
            "latest_two_validated_gcov_dates": sorted({
                r["reference_start"] for r in normal_validated if r["product"] == "GCOV"
            }),
        },
        "notes": [
            "Release-edge counts include BETA, supplemental PROVISIONAL X CRIDs, standard PROVISIONAL P CRIDs, and UR alternates.",
            "Physical edges collapse identical reference/secondary acquisition pairs across releases.",
            "The canonical chain chooses a single best available release per physical edge; no cross-CRID pixel-level continuity is implied.",
        ],
    }
    path = OUT / "catalog_findings.json"
    path.write_text(json.dumps(findings, indent=2) + "\n")
    print(json.dumps({
        "output": str(path),
        "physical_edges": findings["counts"]["physical_pair_edges"],
        "canonical_release_counts": findings["counts"]["canonical_release_counts"],
        "full_download_decimal_gb": findings["all_unique_selected_files_total"]["sum_decimal_gb"],
        "validated_gap": findings["validated_gap"],
    }, indent=2))


if __name__ == "__main__":
    main()
