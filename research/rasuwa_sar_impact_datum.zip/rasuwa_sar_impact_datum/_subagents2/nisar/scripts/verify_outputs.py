#!/usr/bin/env python3
"""Verify NISAR catalog, subset, provenance, and credential-safety outputs."""
from __future__ import annotations

import hashlib
import json
import py_compile
from pathlib import Path

import numpy as np
import rasterio

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
SUBSETS = ROOT / "subsets"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    summary = json.loads((OUT / "subset_summary.json").read_text())
    catalog = json.loads((OUT / "catalog_findings.json").read_text())
    subset_files = sorted(path for path in SUBSETS.iterdir() if path.is_file())
    tiffs = [path for path in subset_files if path.suffix == ".tif"]
    npzs = [path for path in subset_files if path.suffix == ".npz"]

    expected = {entry["path"]: entry for entry in summary["files"]}
    file_checks = []
    for path in subset_files:
        relative = str(path.relative_to(ROOT))
        entry = expected[relative]
        file_checks.append({
            "path": relative,
            "bytes_match": path.stat().st_size == entry["bytes"],
            "sha256_match": sha256(path) == entry["sha256"],
        })

    tiff_checks = []
    for path in tiffs:
        with rasterio.open(path) as dataset:
            sample = dataset.read(1)
            tiff_checks.append({
                "path": str(path.relative_to(ROOT)),
                "driver": dataset.driver,
                "epsg": dataset.crs.to_epsg() if dataset.crs else None,
                "shape": [dataset.height, dataset.width],
                "bands": dataset.count,
                "band_descriptions_complete": all(bool(value) for value in dataset.descriptions),
                "finite_or_nan": bool(np.all(np.isfinite(sample) | np.isnan(sample))),
            })

    npz_checks = []
    for path in npzs:
        with np.load(path, allow_pickle=False) as data:
            keys = list(data.keys())
            npz_checks.append({
                "path": str(path.relative_to(ROOT)),
                "array_count": len(keys),
                "has_x_coordinates": "x_coordinates" in data,
                "has_y_coordinates": "y_coordinates" in data,
                "epsg": int(data["epsg"]),
                "object_dtypes": [key for key in keys if data[key].dtype.kind == "O"],
            })

    qa_files = sorted((OUT / "qa").glob("*_QA_SUMMARY.csv"))
    raw_bodies = sorted((ROOT / "raw").glob("*.json"))
    raw_meta = sorted((ROOT / "raw").glob("*.meta.json"))
    science_hdf5_files = [
        str(path.relative_to(ROOT)) for path in ROOT.rglob("*.h5")
        if "QA_STATS" not in path.name
    ]

    forbidden = [
        "secretAccessKey", "sessionToken", "Authorization: Bearer", "password=",
        "machine urs.earthdata.nasa.gov", "BEGIN PRIVATE KEY",
    ]
    leaks = []
    text_suffixes = {".py", ".json", ".csv", ".md", ".log", ".txt"}
    for path in ROOT.rglob("*"):
        if path.resolve() in {Path(__file__).resolve(), (OUT / "verification.json").resolve()}:
            continue
        if not path.is_file() or path.suffix.lower() not in text_suffixes:
            continue
        text = path.read_text(errors="ignore")
        for token in forbidden:
            if token in text:
                leaks.append({"path": str(path.relative_to(ROOT)), "token": token})

    scripts = sorted((ROOT / "scripts").glob("*.py"))
    compile_errors = []
    for script in scripts:
        try:
            py_compile.compile(str(script), doraise=True, cfile=str(ROOT / "outputs" / (script.stem + ".pyc")))
        except Exception as exc:
            compile_errors.append({"script": str(script.relative_to(ROOT)), "error": f"{type(exc).__name__}: {exc}"})
    # Remove verification-only bytecode artifacts after successful compilation.
    for bytecode in OUT.glob("*.pyc"):
        bytecode.unlink()

    checks = {
        "subset_manifest_count_matches": len(expected) == len(subset_files) == 24,
        "all_subset_hashes_match": all(item["bytes_match"] and item["sha256_match"] for item in file_checks),
        "tiff_count": len(tiffs),
        "npz_count": len(npzs),
        "all_tiffs_epsg_32645": all(item["epsg"] == 32645 for item in tiff_checks),
        "all_tiffs_have_band_descriptions": all(item["band_descriptions_complete"] for item in tiff_checks),
        "all_npz_epsg_32645": all(item["epsg"] == 32645 for item in npz_checks),
        "no_npz_object_arrays": all(not item["object_dtypes"] for item in npz_checks),
        "qa_summary_count": len(qa_files),
        "query_raw_body_count": len([path for path in raw_bodies if not path.name.endswith(".meta.json")]),
        "query_meta_count": len(raw_meta),
        "no_local_science_hdf5": not science_hdf5_files,
        "no_forbidden_credential_tokens": not leaks,
        "scripts_compile": not compile_errors,
        "physical_pair_edge_count": catalog["counts"]["physical_pair_edges"],
        "range_access_full_downloads": summary["range_access_conclusion"]["science_hdf5_full_downloads"],
    }
    failures = [key for key, value in checks.items() if isinstance(value, bool) and not value]
    output = {
        "status": "PASS" if not failures else "FAIL",
        "failures": failures,
        "checks": checks,
        "file_checks": file_checks,
        "tiff_checks": tiff_checks,
        "npz_checks": npz_checks,
        "science_hdf5_files": science_hdf5_files,
        "credential_token_hits": leaks,
        "compile_errors": compile_errors,
    }
    path = OUT / "verification.json"
    path.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"output": str(path), "status": output["status"], "checks": checks}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
