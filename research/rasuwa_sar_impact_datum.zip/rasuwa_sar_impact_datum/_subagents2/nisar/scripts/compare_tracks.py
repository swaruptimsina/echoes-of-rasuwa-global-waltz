#!/usr/bin/env python3
"""Compare event-pair phase observability on NISAR tracks 48 and 98."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import earthaccess
import h5py
import numpy as np
from pyproj import Transformer

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
SOURCE = (85.5110, 28.2820, 85.5310, 28.2970)
BLOCK = 1024 * 1024
ROOT_PATH = "science/LSAR/GUNW/grids/frequencyA/unwrappedInterferogram"


def window(x: np.ndarray, y: np.ndarray, epsg: int) -> tuple[slice, slice]:
    transformer = Transformer.from_crs(4326, epsg, always_xy=True)
    points = [transformer.transform(lon, lat) for lon in (SOURCE[0], SOURCE[2]) for lat in (SOURCE[1], SOURCE[3])]
    columns = np.flatnonzero((x >= min(p[0] for p in points)) & (x <= max(p[0] for p in points)))
    rows = np.flatnonzero((y >= min(p[1] for p in points)) & (y <= max(p[1] for p in points)))
    return slice(int(rows.min()), int(rows.max()) + 1), slice(int(columns.min()), int(columns.max()) + 1)


def main() -> None:
    with (OUT / "catalog_records.csv").open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    chosen = {}
    for track in (48, 98):
        matches = [
            row for row in rows
            if row["product"] == "GUNW" and row["maturity"] == "PROVISIONAL"
            and row["crid"] == "P05023" and int(row["track"]) == track
            and row["reference_start"].startswith("2026-08-")
            and row["secondary_start"].startswith("2026-08-")
            and row["reference_start"] < "2026-08-26" < row["secondary_start"]
        ]
        if len(matches) != 1:
            raise RuntimeError(f"expected one event pair on track {track}, got {len(matches)}")
        chosen[track] = matches[0]

    earthaccess.login(strategy="netrc")
    fs = earthaccess.get_fsspec_https_session()
    output = {"source_bbox_wsen": list(SOURCE), "tracks": {}}
    for track, row in chosen.items():
        with fs.open(row["https_url"], "rb", block_size=BLOCK, cache_type="blockcache") as remote:
            with h5py.File(remote, "r") as handle:
                x = handle[f"{ROOT_PATH}/xCoordinates"][:]
                y = handle[f"{ROOT_PATH}/yCoordinates"][:]
                epsg = int(handle[f"{ROOT_PATH}/projection"].attrs["epsg_code"])
                index = window(x, y, epsg)
                mask = handle[f"{ROOT_PATH}/mask"][index].astype("uint32")
                component = handle[f"{ROOT_PATH}/HH/connectedComponents"][index]
                phase = handle[f"{ROOT_PATH}/HH/unwrappedPhase"][index]
                coherence = handle[f"{ROOT_PATH}/HH/coherenceMagnitude"][index]
            low = mask & 255
            reference_subswath = (low % 100) // 10
            secondary_subswath = low % 10
            anomaly = (mask >> 8) & 65535
            sample_valid = (reference_subswath > 0) & (secondary_subswath > 0) & (anomaly == 0)
            phase_valid = sample_valid & (component > 0) & (component != 65535) & np.isfinite(phase)
            output["tracks"][str(track)] = {
                "product_id": row["product_id"],
                "concept_id": row["concept_id"],
                "file_size_bytes": int(row["size_bytes"]),
                "shape": list(phase.shape),
                "encoded_mask_counts": {str(int(v)): int(n) for v, n in zip(*np.unique(mask, return_counts=True))},
                "connected_component_counts": {str(int(v)): int(n) for v, n in zip(*np.unique(component, return_counts=True))},
                "sample_valid_pixels": int(sample_valid.sum()),
                "sample_valid_fraction": float(sample_valid.mean()),
                "phase_valid_pixels": int(phase_valid.sum()),
                "phase_valid_fraction": float(phase_valid.mean()),
                "coherence_median": float(np.median(coherence[sample_valid])) if sample_valid.any() else None,
                "range_bytes_requested": int(remote.cache.total_requested_bytes),
                "remote_file_size_bytes": int(remote.size),
            }
    output["selection"] = {
        "selected_track": 98,
        "reason": "Track 48 has zero source pixels with both reference and secondary subswaths valid; track 98 has limited but nonzero event-pair unwrapped-phase coverage and compatible 40 MHz GCOV acquisitions.",
    }
    path = OUT / "track_comparison.json"
    path.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
