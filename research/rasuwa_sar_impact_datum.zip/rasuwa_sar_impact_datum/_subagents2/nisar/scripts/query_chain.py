#!/usr/bin/env python3
"""Query the complete NISAR L2 chain over Rasuwa and a null box.

Writes raw CMR UMM-JSON responses, an all-record catalog, and a track/frame
pair graph. Catalog access is anonymous; no Earthdata credentials are read.
"""
from __future__ import annotations

import csv
import datetime as dt
import json
import re
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "raw"
OUT = ROOT / "outputs"
CMR = "https://cmr.earthdata.nasa.gov/search/granules.umm_json"
WINDOW = ("2024-11-15T00:00:00Z", "2026-11-15T23:59:59Z")
REGIONS = {
    # Bounds the mapped detachment/source zone rather than only a point.
    "source": (85.5110, 28.2820, 85.5310, 28.2970),
    # Exploratory same-frame null selected for high coherence in two P05023
    # pairs. It is not independently surveyed as stable.
    "null": (85.4910, 28.3505, 85.5075, 28.3653),
}
COLLECTIONS = [
    f"NISAR_L2_{product}_{maturity}_V1"
    for product in ("GUNW", "GOFF", "GCOV")
    for maturity in ("BETA", "PROVISIONAL")
] + [f"NISAR_L2_{product}_V1" for product in ("GUNW", "GOFF", "GCOV")]
# UR is a selective production stream with GUNW/GOFF alternates and some GCOV
# nodes. Keep it supplemental rather than treating it as a maturity level.
SUPPLEMENTAL_COLLECTIONS = ["NISAR_UR_L2"]
TARGET_STACK = "098_A_016"
USER_AGENT = "rasuwa-nisar-feasibility/1.0"


def utcnow() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def safe_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")


def fetch_cmr(short_name: str, region_name: str, bbox: tuple[float, ...]) -> tuple[dict, dict]:
    params = {
        "short_name": short_name,
        "bounding_box": ",".join(str(v) for v in bbox),
        "temporal": ",".join(WINDOW),
        "page_size": "2000",
    }
    url = f"{CMR}?{urllib.parse.urlencode(params)}"
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    started = utcnow()
    with urllib.request.urlopen(request, timeout=180) as response:
        body = response.read()
        status = response.status
        headers = {
            key: value
            for key, value in response.headers.items()
            if key.lower() in {"content-type", "content-length", "cmr-hits", "cmr-took"}
        }
    payload = json.loads(body)
    stem = f"cmr_{region_name}_{safe_name(short_name)}"
    body_path = RAW / f"{stem}.json"
    meta_path = RAW / f"{stem}.meta.json"
    body_path.write_bytes(body)
    meta = {
        "short_name": short_name,
        "region": region_name,
        "bbox_wsen": list(bbox),
        "temporal_utc": list(WINDOW),
        "started_utc": started,
        "finished_utc": utcnow(),
        "request_url": url,
        "status": status,
        "headers": headers,
        "reported_hits": int(headers.get("cmr-hits", payload.get("hits", 0))),
        "returned_items": len(payload.get("items", [])),
        "body_file": str(body_path.relative_to(ROOT)),
        "body_bytes": len(body),
    }
    meta_path.write_text(json.dumps(meta, indent=2) + "\n")
    return payload, meta


def attrs(umm: dict) -> dict[str, Any]:
    output: dict[str, Any] = {}
    for item in umm.get("AdditionalAttributes", []):
        values = item.get("Values", [])
        output[item.get("Name", "")] = values if len(values) != 1 else values[0]
    return output


def first_https_h5(umm: dict, granule_ur: str) -> tuple[str | None, str | None]:
    https = None
    s3 = None
    exact = granule_ur + ".h5"
    for related in umm.get("RelatedUrls", []):
        url = related.get("URL", "")
        if not url.endswith("/" + exact) and not url.endswith(exact):
            continue
        if url.startswith("https://"):
            https = url
        elif url.startswith("s3://"):
            s3 = url
    return https, s3


def main_h5_info(umm: dict, granule_ur: str) -> dict:
    exact = granule_ur + ".h5"
    for item in umm.get("DataGranule", {}).get("ArchiveAndDistributionInformation", []) or []:
        if item.get("Name") == exact:
            checksum = item.get("Checksum") or {}
            return {
                "file_name": exact,
                "size_bytes": item.get("SizeInBytes"),
                "checksum_algorithm": checksum.get("Algorithm"),
                "checksum": checksum.get("Value"),
            }
    return {"file_name": exact, "size_bytes": None, "checksum_algorithm": None, "checksum": None}


def maturity(short_name: str, product_id: str) -> str:
    if short_name == "NISAR_UR_L2" or "_UR_" in product_id:
        return "URGENT_RESPONSE"
    if "_BETA_" in short_name:
        return "BETA"
    if "_PROVISIONAL_" in short_name:
        return "PROVISIONAL"
    return "VALIDATED"


def crid(product_id: str) -> str | None:
    match = re.search(r"_([PX]\d{5})_", product_id)
    return match.group(1) if match else None


def normalize_time(value: Any) -> str | None:
    if value in (None, ""):
        return None
    return str(value)


def parse_record(item: dict, short_name: str, regions: set[str]) -> dict:
    meta = item.get("meta", {})
    umm = item.get("umm", {})
    aa = attrs(umm)
    product_id = umm.get("GranuleUR") or meta.get("native-id")
    product = aa.get("PRODUCT_TYPE")
    if not product:
        match = re.search(r"_L2_(?:PR|UR)_([A-Z0-9]+)_", product_id or "")
        product = match.group(1) if match else None
    temporal = umm.get("TemporalExtent", {}).get("RangeDateTime", {})
    ref_start = normalize_time(aa.get("REFERENCE_ZERO_DOPPLER_START_TIME"))
    ref_end = normalize_time(aa.get("REFERENCE_ZERO_DOPPLER_END_TIME"))
    sec_start = normalize_time(aa.get("SECONDARY_ZERO_DOPPLER_START_TIME"))
    sec_end = normalize_time(aa.get("SECONDARY_ZERO_DOPPLER_END_TIME"))
    if product == "GCOV":
        ref_start = ref_start or temporal.get("BeginningDateTime")
        ref_end = ref_end or temporal.get("EndingDateTime")
    https, s3 = first_https_h5(umm, product_id)
    file_info = main_h5_info(umm, product_id)
    return {
        "product_id": product_id,
        "concept_id": meta.get("concept-id"),
        "revision_id": meta.get("revision-id"),
        "revision_date": meta.get("revision-date"),
        "collection_concept_id": meta.get("collection-concept-id"),
        "short_name": short_name,
        "maturity": maturity(short_name, product_id),
        "product": product,
        "production_pipeline": aa.get("PRODUCTION_PIPELINE"),
        "product_version": aa.get("PRODUCT_VERSION"),
        "crid": crid(product_id),
        "track": int(aa["TRACK_NUMBER"]) if aa.get("TRACK_NUMBER") else None,
        "frame": int(aa["FRAME_NUMBER"]) if aa.get("FRAME_NUMBER") else None,
        "direction": aa.get("ASCENDING_DESCENDING"),
        "stack_id": aa.get("STACK_ID"),
        "frequency_a_polarization": aa.get("FREQUENCY_A_POLARIZATION_CONCAT") or aa.get("FREQUENCY_A_POLARIZATION"),
        "frequency_a_bandwidth_mhz": aa.get("FREQUENCY_A_RANGE_BANDWIDTH"),
        "range_bandwidth_concat": aa.get("RANGE_BANDWIDTH_CONCAT"),
        "reference_start": ref_start,
        "reference_end": ref_end,
        "secondary_start": sec_start,
        "secondary_end": sec_end,
        "temporal_begin": temporal.get("BeginningDateTime"),
        "temporal_end": temporal.get("EndingDateTime"),
        "production_datetime": umm.get("DataGranule", {}).get("ProductionDateTime"),
        "file_name": file_info["file_name"],
        "size_bytes": file_info["size_bytes"],
        "size_decimal_gb": round(file_info["size_bytes"] / 1_000_000_000, 6) if file_info["size_bytes"] else None,
        "checksum_algorithm": file_info["checksum_algorithm"],
        "checksum": file_info["checksum"],
        "https_url": https,
        "s3_url": s3,
        "covers_source_catalog": "source" in regions,
        "covers_null_catalog": "null" in regions,
    }


def preferred(records: list[dict]) -> dict | None:
    if not records:
        return None
    # Standard production P products before experimental X products, then the
    # highest CRID/revision. BETA often has only X products.
    def rank(record: dict) -> tuple:
        cid = record.get("crid") or ""
        return (cid.startswith("P"), cid, record.get("revision_id") or 0, record["product_id"])
    return sorted(records, key=rank, reverse=True)[0]


def edge_key(record: dict) -> tuple:
    return (
        record.get("stack_id"),
        record.get("maturity"),
        record.get("crid"),
        record.get("reference_start"),
        record.get("secondary_start"),
    )


def date_only(value: str | None) -> str | None:
    return value[:10] if value else None


def release_rank(row: dict) -> tuple:
    """Rank alternate releases for one physical acquisition edge."""
    maturity_rank = {
        "VALIDATED": 5,
        "PROVISIONAL": 4,
        "BETA": 2,
        "URGENT_RESPONSE": 1,
    }
    release = row.get("crid") or ""
    # Within PROVISIONAL prefer operational P CRIDs over supplemental X CRIDs.
    standard = int(release.startswith("P"))
    return (
        int(bool(row.get("complete_gunw_goff_edge"))),
        maturity_rank.get(row.get("maturity"), 0),
        standard,
        release,
    )


def choose_gcov_node(candidates: list[dict], edge: dict) -> dict | None:
    """Choose the GCOV node that most closely matches an edge release."""
    if not candidates:
        return None
    maturity_rank = {
        "VALIDATED": 5,
        "PROVISIONAL": 4,
        "BETA": 2,
        "URGENT_RESPONSE": 1,
    }

    def rank(record: dict) -> tuple:
        release = record.get("crid") or ""
        return (
            int(record.get("maturity") == edge.get("maturity")),
            int(release == edge.get("crid")),
            maturity_rank.get(record.get("maturity"), 0),
            int(release.startswith("P")),
            release,
            record.get("revision_id") or 0,
        )

    return sorted(candidates, key=rank, reverse=True)[0]


def write_csv(path: Path, rows: list[dict], columns: list[str] | None = None) -> None:
    if not rows:
        path.write_text("")
        return
    columns = columns or list(rows[0].keys())
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    RAW.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(parents=True, exist_ok=True)
    query_meta: list[dict] = []
    by_identity_regions: dict[tuple[str, str], set[str]] = defaultdict(set)
    raw_items: dict[tuple[str, str], dict] = {}

    for short_name in COLLECTIONS + SUPPLEMENTAL_COLLECTIONS:
        for region_name, bbox in REGIONS.items():
            payload, meta = fetch_cmr(short_name, region_name, bbox)
            query_meta.append(meta)
            for item in payload.get("items", []):
                identity = (short_name, item.get("umm", {}).get("GranuleUR") or item.get("meta", {}).get("native-id"))
                by_identity_regions[identity].add(region_name)
                # Keep the highest CMR revision if a query somehow returns more than one.
                previous = raw_items.get(identity)
                if previous is None or (item.get("meta", {}).get("revision-id") or 0) > (previous.get("meta", {}).get("revision-id") or 0):
                    raw_items[identity] = item

    records = [
        parse_record(item, short_name, by_identity_regions[(short_name, native_id)])
        for (short_name, native_id), item in raw_items.items()
    ]
    records = [r for r in records if r.get("product") in {"GUNW", "GOFF", "GCOV"}]
    records.sort(key=lambda r: (
        r.get("stack_id") or "", r.get("maturity") or "", r.get("reference_start") or "",
        r.get("secondary_start") or "", r.get("product") or "", r.get("crid") or "", r["product_id"],
    ))
    write_csv(OUT / "catalog_records.csv", records)

    common = [r for r in records if r["covers_source_catalog"] and r["covers_null_catalog"]]
    stacks: dict[str, dict] = {}
    for stack_id in sorted({r.get("stack_id") for r in common if r.get("stack_id")}):
        group = [r for r in common if r.get("stack_id") == stack_id]
        stacks[stack_id] = {
            "record_count": len(group),
            "product_counts": dict(Counter(r["product"] for r in group)),
            "maturity_counts": dict(Counter(r["maturity"] for r in group)),
            "crid_counts": dict(Counter(r.get("crid") or "NONE" for r in group)),
            "first_temporal_begin": min(r["temporal_begin"] for r in group if r.get("temporal_begin")),
            "last_temporal_end": max(r["temporal_end"] for r in group if r.get("temporal_end")),
        }

    target = [r for r in common if r.get("stack_id") == TARGET_STACK]
    pair_records = [r for r in target if r["product"] in {"GUNW", "GOFF"} and r.get("secondary_start")]
    grouped_edges: dict[tuple, list[dict]] = defaultdict(list)
    for record in pair_records:
        grouped_edges[edge_key(record)].append(record)

    edge_rows: list[dict] = []
    for key, edge_records in sorted(grouped_edges.items(), key=lambda item: item[0][3:] + item[0][:3]):
        stack_id, mat, release, reference_start, secondary_start = key
        gunw = preferred([r for r in edge_records if r["product"] == "GUNW"])
        goff = preferred([r for r in edge_records if r["product"] == "GOFF"])
        edge_rows.append({
            "stack_id": stack_id,
            "track": (gunw or goff).get("track"),
            "frame": (gunw or goff).get("frame"),
            "direction": (gunw or goff).get("direction"),
            "maturity": mat,
            "crid": release,
            "reference_start": reference_start,
            "secondary_start": secondary_start,
            "reference_date": date_only(reference_start),
            "secondary_date": date_only(secondary_start),
            "interval_days": round((dt.datetime.fromisoformat(secondary_start.replace("Z", "+00:00")) - dt.datetime.fromisoformat(reference_start.replace("Z", "+00:00"))).total_seconds() / 86400, 6),
            "gunw_product_id": gunw["product_id"] if gunw else None,
            "gunw_concept_id": gunw["concept_id"] if gunw else None,
            "gunw_size_bytes": gunw["size_bytes"] if gunw else None,
            "gunw_product_version": gunw["product_version"] if gunw else None,
            "gunw_url": gunw["https_url"] if gunw else None,
            "goff_product_id": goff["product_id"] if goff else None,
            "goff_concept_id": goff["concept_id"] if goff else None,
            "goff_size_bytes": goff["size_bytes"] if goff else None,
            "goff_product_version": goff["product_version"] if goff else None,
            "goff_url": goff["https_url"] if goff else None,
            "complete_gunw_goff_edge": bool(gunw and goff),
        })
    write_csv(OUT / "pair_graph.csv", edge_rows)

    gcov_rows = [r for r in target if r["product"] == "GCOV"]
    write_csv(OUT / "gcov_nodes.csv", gcov_rows)

    # Collapse release/maturity duplicates to the physical acquisition graph,
    # while retaining every alternate release in pair_graph.csv.
    physical_groups: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in edge_rows:
        physical_groups[(row["reference_start"], row["secondary_start"])].append(row)
    canonical_chain: list[dict] = []
    physical_rows: list[dict] = []
    for (reference_start, secondary_start), variants in sorted(physical_groups.items()):
        chosen = sorted(variants, key=release_rank, reverse=True)[0]
        reference_node = choose_gcov_node(
            [r for r in gcov_rows if r.get("reference_start") == reference_start], chosen
        )
        secondary_node = choose_gcov_node(
            [r for r in gcov_rows if r.get("reference_start") == secondary_start], chosen
        )
        enriched = dict(chosen)
        enriched.update({
            "reference_gcov_product_id": reference_node["product_id"] if reference_node else None,
            "reference_gcov_maturity": reference_node["maturity"] if reference_node else None,
            "reference_gcov_crid": reference_node["crid"] if reference_node else None,
            "reference_gcov_size_bytes": reference_node["size_bytes"] if reference_node else None,
            "secondary_gcov_product_id": secondary_node["product_id"] if secondary_node else None,
            "secondary_gcov_maturity": secondary_node["maturity"] if secondary_node else None,
            "secondary_gcov_crid": secondary_node["crid"] if secondary_node else None,
            "secondary_gcov_size_bytes": secondary_node["size_bytes"] if secondary_node else None,
            "complete_three_product_chain": bool(reference_node and secondary_node and chosen["complete_gunw_goff_edge"]),
            "alternate_release_count": len(variants) - 1,
        })
        canonical_chain.append(enriched)
        physical_rows.append({
            "stack_id": TARGET_STACK,
            "reference_start": reference_start,
            "secondary_start": secondary_start,
            "interval_days": chosen["interval_days"],
            "release_variant_count": len(variants),
            "release_variants": " | ".join(
                f"{v['maturity']}:{v['crid']}" for v in sorted(variants, key=release_rank, reverse=True)
            ),
            "canonical_maturity": chosen["maturity"],
            "canonical_crid": chosen["crid"],
            "canonical_gunw_product_id": chosen["gunw_product_id"],
            "canonical_goff_product_id": chosen["goff_product_id"],
            "complete_three_product_chain": enriched["complete_three_product_chain"],
        })
    write_csv(OUT / "physical_pair_graph.csv", physical_rows)
    write_csv(OUT / "canonical_chain.csv", canonical_chain)

    physical_edge_keys = set(physical_groups)
    # Collapse GCOV release duplicates to physical acquisition times, then find
    # consecutive 12-day acquisitions that have no released pair product.
    acquisition_times = sorted({r["reference_start"] for r in gcov_rows if r.get("reference_start")})
    missing_neighbor_edges: list[dict] = []
    for start, end in zip(acquisition_times, acquisition_times[1:]):
        interval = round((dt.datetime.fromisoformat(end.replace("Z", "+00:00")) - dt.datetime.fromisoformat(start.replace("Z", "+00:00"))).total_seconds() / 86400, 6)
        if 11.9 <= interval <= 12.1 and (start, end) not in physical_edge_keys:
            missing_neighbor_edges.append({
                "reference_start": start,
                "secondary_start": end,
                "interval_days": interval,
                "reason": "Both GCOV acquisition nodes exist, but no GUNW/GOFF edge was returned by any queried collection.",
            })

    graph = {
        "generated_utc": utcnow(),
        "query_window_utc": list(WINDOW),
        "mission_launch_utc_date": "2025-07-30",
        "regions": {name: list(bbox) for name, bbox in REGIONS.items()},
        "region_note": "Null is exploratory/coherence-selected, not independently surveyed as stable.",
        "collections": COLLECTIONS,
        "supplemental_collections": SUPPLEMENTAL_COLLECTIONS,
        "queries": query_meta,
        "all_unique_records": len(records),
        "records_covering_both_catalog_regions": len(common),
        "stack_summary": stacks,
        "selected_stack": TARGET_STACK,
        "selected_stack_records": len(target),
        "selected_stack_pair_release_edges": edge_rows,
        "selected_stack_physical_pair_edges": physical_rows,
        "selected_stack_canonical_chain": canonical_chain,
        "selected_stack_gcov_nodes": gcov_rows,
        "selected_stack_unique_gcov_acquisition_times": acquisition_times,
        "missing_12_day_neighbor_edges": missing_neighbor_edges,
        "selection_rule": "Track 98 ascending/frame 16: common source+null coverage, 40 MHz HH pair products, same-mode 40+5 MHz dual-H GCOV around the event, and better source validity than track 48.",
        "canonical_release_rule": "For one physical edge: complete pair first; VALIDATED, then PROVISIONAL, BETA, UR; within PROVISIONAL prefer operational P CRID over supplemental X. Retain every release in pair_graph.csv.",
        "urgent_response_note": "UR is a selective production stream, not a maturity collection. It contains some GCOV nodes and GUNW/GOFF alternates; it is canonical only where no normal maturity pair exists.",
    }
    (OUT / "pair_graph.json").write_text(json.dumps(graph, indent=2) + "\n")

    summary = {
        "generated_utc": graph["generated_utc"],
        "query_count": len(query_meta),
        "http_status_counts": dict(Counter(q["status"] for q in query_meta)),
        "all_unique_records": len(records),
        "common_records": len(common),
        "target_stack_records": len(target),
        "target_pair_release_edge_rows": len(edge_rows),
        "target_physical_pair_edges": len(physical_rows),
        "target_canonical_complete_three_product_edges": sum(row["complete_three_product_chain"] for row in canonical_chain),
        "target_complete_gunw_goff_release_edges": sum(row["complete_gunw_goff_edge"] for row in edge_rows),
        "target_gcov_records": len(gcov_rows),
        "target_unique_gcov_acquisitions": len(acquisition_times),
        "missing_12_day_neighbor_edges": missing_neighbor_edges,
        "outputs": [
            "outputs/catalog_records.csv",
            "outputs/pair_graph.csv",
            "outputs/physical_pair_graph.csv",
            "outputs/canonical_chain.csv",
            "outputs/gcov_nodes.csv",
            "outputs/pair_graph.json",
        ],
    }
    (OUT / "query_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
