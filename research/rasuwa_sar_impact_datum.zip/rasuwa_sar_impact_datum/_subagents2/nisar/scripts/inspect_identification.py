#!/usr/bin/env python3
"""Range-read identification and decisive quality-layer attributes."""
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

import earthaccess
import h5py
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
BLOCK = 1024 * 1024


def scalar(value: Any) -> Any:
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    if isinstance(value, np.generic):
        return scalar(value.item())
    if isinstance(value, np.ndarray):
        return [scalar(v) for v in value.tolist()]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def main() -> None:
    with (OUT / "canonical_chain.csv").open(newline="") as stream:
        edges = list(csv.DictReader(stream))
    edge = next(row for row in edges if row["reference_date"] == "2026-08-19" and row["secondary_date"] == "2026-08-31")
    with (OUT / "catalog_records.csv").open(newline="") as stream:
        catalog = {row["product_id"]: row for row in csv.DictReader(stream)}
    products = {
        "gunw": edge["gunw_product_id"],
        "goff": edge["goff_product_id"],
        "gcov_reference": edge["reference_gcov_product_id"],
        "gcov_secondary": edge["secondary_gcov_product_id"],
    }
    quality_paths = {
        "gunw": [
            "science/LSAR/GUNW/grids/frequencyA/unwrappedInterferogram/mask",
            "science/LSAR/GUNW/grids/frequencyA/unwrappedInterferogram/HH/connectedComponents",
            "science/LSAR/GUNW/grids/frequencyA/unwrappedInterferogram/HH/unwrappedPhase",
            "science/LSAR/GUNW/grids/frequencyA/unwrappedInterferogram/HH/coherenceMagnitude",
            "science/LSAR/GUNW/grids/frequencyA/unwrappedInterferogram/HH/ionospherePhaseScreenUncertainty",
        ],
        "goff": [
            "science/LSAR/GOFF/grids/frequencyA/pixelOffsets/mask",
            "science/LSAR/GOFF/grids/frequencyA/pixelOffsets/HH/layer1/alongTrackOffset",
            "science/LSAR/GOFF/grids/frequencyA/pixelOffsets/HH/layer1/correlationSurfacePeak",
            "science/LSAR/GOFF/grids/frequencyA/pixelOffsets/HH/layer1/snr",
        ],
        "gcov_reference": [
            "science/LSAR/GCOV/grids/frequencyA/mask",
            "science/LSAR/GCOV/grids/frequencyA/inputDataExceptionMask",
            "science/LSAR/GCOV/grids/frequencyA/HHHH",
            "science/LSAR/GCOV/grids/frequencyA/HVHV",
            "science/LSAR/GCOV/grids/frequencyA/rtcGammaToSigmaFactor",
        ],
        "gcov_secondary": [
            "science/LSAR/GCOV/grids/frequencyA/mask",
            "science/LSAR/GCOV/grids/frequencyA/inputDataExceptionMask",
            "science/LSAR/GCOV/grids/frequencyA/HHHH",
            "science/LSAR/GCOV/grids/frequencyA/HVHV",
            "science/LSAR/GCOV/grids/frequencyA/rtcGammaToSigmaFactor",
        ],
    }

    auth = earthaccess.login(strategy="netrc")
    if not auth.authenticated:
        raise RuntimeError("Earthdata netrc did not authenticate")
    fs = earthaccess.get_fsspec_https_session()
    output: dict[str, Any] = {"products": {}}
    for role, product_id in products.items():
        row = catalog[product_id]
        with fs.open(row["https_url"], "rb", block_size=BLOCK, cache_type="blockcache") as remote:
            with h5py.File(remote, "r") as handle:
                identification: dict[str, Any] = {}
                for name, obj in handle["science/LSAR/identification"].items():
                    if isinstance(obj, h5py.Dataset) and obj.size <= 100:
                        identification[name] = scalar(obj[()])
                quality: dict[str, Any] = {}
                for path in quality_paths[role]:
                    dataset = handle[path]
                    quality[path] = {
                        "shape": list(dataset.shape),
                        "dtype": str(dataset.dtype),
                        "chunks": list(dataset.chunks) if dataset.chunks else None,
                        "compression": dataset.compression,
                        "attrs": {
                            str(key): scalar(value)
                            for key, value in dataset.attrs.items()
                            if str(key) in {"_FillValue", "description", "units", "grid_mapping", "valid_min"}
                        },
                    }
            output["products"][role] = {
                "product_id": product_id,
                "concept_id": row["concept_id"],
                "catalog_file_size_bytes": int(row["size_bytes"]),
                "identification": identification,
                "quality_layers": quality,
                "range_access": {
                    "remote_size_bytes": int(remote.size),
                    "range_bytes_requested": int(remote.cache.total_requested_bytes),
                    "cache_misses": int(remote.cache.miss_count),
                    "fraction_requested": float(remote.cache.total_requested_bytes / remote.size),
                },
            }
    path = OUT / "selected_identification.json"
    path.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({
        "output": str(path),
        "products": {
            role: {
                "crid": data["identification"].get("compositeReleaseId"),
                "product_version": data["identification"].get("productVersion"),
                "processing_datetime": data["identification"].get("processingDateTime"),
                "range_bytes": data["range_access"]["range_bytes_requested"],
            }
            for role, data in output["products"].items()
        },
    }, indent=2))


if __name__ == "__main__":
    main()
