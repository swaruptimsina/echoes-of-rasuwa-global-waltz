#!/usr/bin/env python3
"""Condense subset metrics into a review-friendly machine output."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"


def main() -> None:
    report = json.loads((OUT / "subset_summary.json").read_text())
    findings: dict = {
        "regions": report["regions"],
        "region_note": report["region_note"],
        "range_access": report["range_access_conclusion"],
        "pairs": {},
        "qa": {
            "sidecars_inspected": len(report["qa_sidecars"]),
            "products_with_failures": sum(bool(row["failures"]) for row in report["qa_sidecars"]),
            "failure_checks": [
                {"product_id": row["product_id"], "product": row["product"], "failures": row["failures"]}
                for row in report["qa_sidecars"] if row["failures"]
            ],
        },
    }
    for pair_name, pair in report["pairs"].items():
        compact = {
            "dates": [pair["reference_date"], pair["secondary_date"]],
            "maturity": pair["maturity"],
            "crid": pair["crid"],
            "products": {
                key: {
                    "product_id": value["product_id"],
                    "file_size_bytes": value["file_size_bytes"],
                    "product_version": value["product_version"],
                }
                for key, value in pair["products"].items()
            },
            "regions": {},
            "source_minus_null_diagnostics": pair["source_minus_null_diagnostics"],
        }
        for region_name, region in pair["regions"].items():
            gunw = region["gunw"]["quality"]
            goff = region["goff"]["quality"]
            gcov = region["gcov"]["quality"]
            compact["regions"][region_name] = {
                "gunw_shape": region["gunw"]["shape"],
                "goff_shape": region["goff"]["shape"],
                "gcov_shape": region["gcov"]["shape"],
                "gunw": {
                    "sample_valid_pixels": gunw["sample_valid_pixels"],
                    "sample_valid_fraction": gunw["sample_valid_fraction"],
                    "phase_valid_pixels": gunw["phase_valid_pixels"],
                    "phase_valid_fraction": gunw["phase_valid_fraction"],
                    "connected_component_counts": gunw["connected_component_counts"],
                    "encoded_mask_counts": gunw["encoded_mask_counts"],
                    "coherence_median": gunw["coherence"]["median"],
                    "coherence_p05": gunw["coherence"]["p05"],
                    "coherence_fraction_ge_0_3": gunw["coherence_fraction_ge_0_3"],
                    "coherence_fraction_ge_0_5": gunw["coherence_fraction_ge_0_5"],
                    "phase_median_rad": gunw["unwrapped_phase_rad"]["median"],
                    "phase_plane_residual_mad_rad": gunw["unwrapped_phase_plane_residual_mad_rad"],
                    "ionosphere_interpolated_fraction": gunw["ionosphere_interpolated_fraction_of_sample_valid"],
                    "ionosphere_uncertainty_median_rad": gunw["ionosphere_phase_uncertainty_rad"]["median"],
                    "blended_along_track_offset_median_m": gunw["blended_along_track_offset_m"]["median"],
                    "blended_slant_range_offset_median_m": gunw["blended_slant_range_offset_m"]["median"],
                    "blended_offset_correlation_median": gunw["blended_offset_correlation_peak"]["median"],
                },
                "goff": {
                    "sample_valid_fraction": goff["sample_valid_fraction"],
                    "layers_are_raw_unculled_unfiltered": goff["layers_are_raw_unculled_unfiltered"],
                    "layers": {
                        f"layer{layer}": {
                            "along_track_median_m": goff[f"layer{layer}"]["along_track_offset_m"]["median"],
                            "along_track_p05_m": goff[f"layer{layer}"]["along_track_offset_m"]["p05"],
                            "along_track_p95_m": goff[f"layer{layer}"]["along_track_offset_m"]["p95"],
                            "slant_range_median_m": goff[f"layer{layer}"]["slant_range_offset_m"]["median"],
                            "slant_range_p05_m": goff[f"layer{layer}"]["slant_range_offset_m"]["p05"],
                            "slant_range_p95_m": goff[f"layer{layer}"]["slant_range_offset_m"]["p95"],
                            "correlation_median": goff[f"layer{layer}"]["correlation_peak"]["median"],
                            "correlation_fraction_ge_0_5": goff[f"layer{layer}"]["correlation_fraction_ge_0_5"],
                            "snr_median": goff[f"layer{layer}"]["snr"]["median"],
                        }
                        for layer in (1, 2, 3)
                    },
                },
                "gcov": {
                    "common_valid_fraction": gcov["common_valid_fraction"],
                    "hhhh_change_db": {
                        key: gcov["hhhh_post_minus_pre_db"][key]
                        for key in ("valid_pixels", "p05", "median", "mean", "p95", "stddev")
                    },
                    "hvhv_change_db": {
                        key: gcov["hvhv_post_minus_pre_db"][key]
                        for key in ("valid_pixels", "p05", "median", "mean", "p95", "stddev")
                    },
                    "observable": gcov["observable"],
                },
            }
        findings["pairs"][pair_name] = compact

    quiet_source = findings["pairs"]["quiet"]["regions"]["source"]
    event_source = findings["pairs"]["event"]["regions"]["source"]
    quiet_null = findings["pairs"]["quiet"]["regions"]["null"]
    event_null = findings["pairs"]["event"]["regions"]["null"]
    findings["feasibility_diagnosis"] = {
        "source_phase_valid_fraction_quiet": quiet_source["gunw"]["phase_valid_fraction"],
        "source_phase_valid_fraction_event": event_source["gunw"]["phase_valid_fraction"],
        "event_source_phase_valid_pixels": event_source["gunw"]["phase_valid_pixels"],
        "event_source_total_80m_pixels": event_source["gunw_shape"][0] * event_source["gunw_shape"][1],
        "event_source_coherence_median": event_source["gunw"]["coherence_median"],
        "event_null_phase_valid_fraction": event_null["gunw"]["phase_valid_fraction"],
        "event_null_coherence_median": event_null["gunw"]["coherence_median"],
        "quiet_null_phase_valid_fraction": quiet_null["gunw"]["phase_valid_fraction"],
        "quiet_null_coherence_median": quiet_null["gunw"]["coherence_median"],
        "event_source_ionosphere_interpolated_fraction": event_source["gunw"]["ionosphere_interpolated_fraction"],
        "event_null_ionosphere_interpolated_fraction": event_null["gunw"]["ionosphere_interpolated_fraction"],
        "phase_subtle_change_ready": False,
        "phase_blocker": "Event-pair source unwrapping coverage is too small and coherence too low; ionosphere interpolation flags and unapplied corrections add uncertainty.",
        "goff_subtle_change_ready": False,
        "goff_blocker": "GOFF is raw, unculled/unfiltered; source offset distributions contain extreme outliers and are not a sub-meter subtle-change estimator without culling/modeling.",
        "gcov_change_ready_as_observable": True,
        "gcov_limit": "GCOV provides range-readable calibrated gamma-0 change, but the output is backscatter change, not displacement or event attribution.",
        "null_validation_limit": "The null was selected using these same two pairs and is not independently demonstrated stable; it is an exploratory control, not a confirmatory null.",
    }
    for product in ("gunw", "goff", "gcov"):
        structure = json.loads((OUT / f"hdf5_structure_{product}.json").read_text())
        findings.setdefault("structures", {})[product] = {
            "product_id": structure["product_id"],
            "dataset_count": structure["structure"]["dataset_count"],
            "root_groups": structure["structure"]["root_groups"],
        }

    path = OUT / "subset_findings.json"
    path.write_text(json.dumps(findings, indent=2) + "\n")
    print(json.dumps({
        "output": str(path),
        "diagnosis": findings["feasibility_diagnosis"],
        "structures": findings["structures"],
        "range_access": findings["range_access"],
    }, indent=2))


if __name__ == "__main__":
    main()
