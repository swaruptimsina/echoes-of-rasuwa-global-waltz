#!/usr/bin/env python3
"""Validate the minimal Sentinel-1D event/null HyP3 jobs without charge."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import hyp3_sdk

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "raw"
API = "https://hyp3-api.asf.alaska.edu"

QUIET = [
    "S1_180590_IW2_20260804T122147_VV_F90B-BURST",
    "S1_180590_IW2_20260816T122147_VV_0444-BURST",
]
EVENT = [
    "S1_180590_IW2_20260816T122147_VV_0444-BURST",
    "S1_180590_IW2_20260828T122148_VV_93F8-BURST",
]
JOBS = [
    {
        "name": "rasuwa-s1d-p085-quiet-null-int80-20260804-20260816",
        "job_type": "INSAR_ISCE_BURST",
        "job_parameters": {
            "granules": QUIET,
            "looks": "20x4",
            "apply_water_mask": True,
        },
    },
    {
        "name": "rasuwa-s1d-p085-event-int80-20260816-20260828",
        "job_type": "INSAR_ISCE_BURST",
        "job_parameters": {
            "granules": EVENT,
            "looks": "20x4",
            "apply_water_mask": True,
        },
    },
]


def remove_identifiers(value):
    if isinstance(value, dict):
        return {
            key: remove_identifiers(item)
            for key, item in value.items()
            if key not in {"user_id"}
        }
    if isinstance(value, list):
        return [remove_identifiers(item) for item in value]
    return value


def main() -> None:
    RAW.mkdir(parents=True, exist_ok=True)
    hyp3 = hyp3_sdk.HyP3(API)
    before_info = hyp3.my_info()
    before_jobs = hyp3.find_jobs()
    costs = hyp3.costs()
    expected_each = costs["INSAR_ISCE_BURST"]["cost"]

    plan = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "api": API,
        "selection": {
            "relative_orbit": 85,
            "direction": "ASCENDING",
            "full_burst_id": "085_180590_IW2",
            "polarization": "VV",
            "reason": "The 12-day event pair has the first post-event S1D acquisition (2.395486 days after the event), a 5 m pair-relative perpendicular baseline, and the same immediately preceding 12-day pair provides a matched null. The burst covers the source and 96.8307% of the fixed catalog AOI.",
        },
        "parameters": {
            "looks": "20x4",
            "nominal_pixel_spacing_m": 80,
            "apply_water_mask": True,
            "reason": "80 m posting matches the NISAR GUNW unwrapped-phase posting and minimizes cost; identical water masking is used for event and null unwrapping. Coherence remains an independent output.",
        },
        "jobs": JOBS,
        "expected_credit_cost_each": expected_each,
        "expected_credit_cost_total": expected_each * len(JOBS),
        "expected_outputs": [
            "normalized coherence GeoTIFF (0-1)",
            "wrapped phase GeoTIFF",
            "unwrapped phase GeoTIFF",
            "connected components GeoTIFF",
            "look-vector theta and phi GeoTIFFs",
            "DEM GeoTIFF",
            "water-mask GeoTIFF",
            "native range-Doppler wrapped interferogram, look vectors, latitude, and longitude files",
            "browse image, metadata, and README",
        ],
        "interpretation_limit": "Single-pair C-band coherence loss and unwrapped phase are observables, not unique avalanche extent or displacement cause. Low coherence, layover/shadow, atmosphere, DEM residuals, glacier motion, snow/moisture, and phase-unwrapping errors must be screened.",
    }
    (ROOT / "job_plan.json").write_text(json.dumps(plan, indent=2, sort_keys=True) + "\n")

    request_payload = {"validate_only": True, "jobs": JOBS}
    (RAW / "hyp3_validate_request.json").write_text(
        json.dumps(request_payload, indent=2, sort_keys=True) + "\n"
    )
    response = hyp3.session.post(f"{API}/jobs", json=request_payload, timeout=180)
    response.raise_for_status()
    validation = remove_identifiers(response.json())
    (RAW / "hyp3_validate_response.json").write_text(
        json.dumps(validation, indent=2, sort_keys=True) + "\n"
    )

    after_info = hyp3.my_info()
    after_jobs = hyp3.find_jobs()
    check = {
        "validated_utc": datetime.now(timezone.utc).isoformat(),
        "http_status": response.status_code,
        "validated_job_count": len(validation.get("jobs", [])),
        "returned_job_types": [job.get("job_type") for job in validation.get("jobs", [])],
        "returned_credit_costs": [job.get("credit_cost") for job in validation.get("jobs", [])],
        "returned_status_codes": [job.get("status_code") for job in validation.get("jobs", [])],
        "credits_before": before_info.get("remaining_credits"),
        "credits_after": after_info.get("remaining_credits"),
        "job_count_before": len(before_jobs),
        "job_count_after": len(after_jobs),
        "no_credits_consumed": before_info.get("remaining_credits") == after_info.get("remaining_credits"),
        "no_jobs_created": len(before_jobs) == len(after_jobs),
        "s1d_inputs_accepted": response.status_code == 200 and len(validation.get("jobs", [])) == len(JOBS),
    }
    if not check["no_credits_consumed"] or not check["no_jobs_created"]:
        raise RuntimeError(f"validate_only changed account state: {check}")
    if not check["s1d_inputs_accepted"]:
        raise RuntimeError(f"S1D validate_only failed: {check}")
    (RAW / "hyp3_validate_check.json").write_text(
        json.dumps(check, indent=2, sort_keys=True) + "\n"
    )
    print(json.dumps(check, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
