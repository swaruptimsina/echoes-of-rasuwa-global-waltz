#!/usr/bin/env python3
"""Compare delivered C-band layers with actual NISAR GUNW quality needs."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
NISAR_ROOT = Path("/home/safal0715/Documents/research/_subagents2/nisar")


def main() -> None:
    c = json.loads((ROOT / "analysis" / "coherence_comparison.json").read_text())
    c_jobs = json.loads((ROOT / "job_status_final.json").read_text())
    n_findings = json.loads((NISAR_ROOT / "outputs" / "subset_findings.json").read_text())
    n_tracks = json.loads((NISAR_ROOT / "outputs" / "track_comparison.json").read_text())
    n_ident = json.loads((NISAR_ROOT / "outputs" / "selected_identification.json").read_text())

    c_det_quiet = c["quiet"]["regions"]["detachment"]
    c_det_event = c["event"]["regions"]["detachment"]
    c_pair_det = c["paired_on_event_grid"]["regions"]["detachment"]
    c_pair_ring = c["paired_on_event_grid"]["regions"]["local_control_ring_approx_0.3_to_1.5_km"]
    n_event_source = n_findings["pairs"]["event"]["regions"]["source"]["gunw"]
    n_quiet_source = n_findings["pairs"]["quiet"]["regions"]["source"]["gunw"]

    comparison = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Layer/quality comparison, not a claim that C- and L-band coherence magnitudes are interchangeable.",
        "c_band_delivered": {
            "sensor": "Sentinel-1D C-band",
            "job_type": "INSAR_ISCE_BURST",
            "relative_orbit": 85,
            "direction": "ASCENDING",
            "polarization": "VV",
            "full_burst_id": "085_180590_IW2",
            "event_dates": ["2026-08-16", "2026-08-28"],
            "quiet_dates": ["2026-08-04", "2026-08-16"],
            "posting_m": 80,
            "event_baseline_m": -4.509283423674989,
            "quiet_baseline_m": -32.28723328384977,
            "job_ids": c_jobs["job_ids"],
            "detachment_metrics": {
                "quiet_coherence_median": c_det_quiet["coherence"]["median"],
                "event_coherence_median": c_det_event["coherence"]["median"],
                "quiet_coherence_valid_fraction_of_land": c_det_quiet["coherence_valid_fraction_of_land"],
                "event_coherence_valid_fraction_of_land": c_det_event["coherence_valid_fraction_of_land"],
                "quiet_unwrapped_valid_fraction_of_land": c_det_quiet["unwrapped_valid_fraction_of_land"],
                "event_unwrapped_valid_fraction_of_land": c_det_event["unwrapped_valid_fraction_of_land"],
                "paired_median_event_minus_quiet_coherence": c_pair_det["event_minus_quiet_coherence"]["median"],
                "local_control_median_event_minus_quiet_coherence": c_pair_ring["event_minus_quiet_coherence"]["median"],
                "detachment_minus_local_control_change": (
                    c_pair_det["event_minus_quiet_coherence"]["median"]
                    - c_pair_ring["event_minus_quiet_coherence"]["median"]
                ),
            },
            "quality_limit": "HyP3 supplies water mask and connected components but no NISAR-style encoded subswath/input-anomaly/ionosphere mask or atmospheric-correction layers. No explicit layover/shadow mask was found in the bundle.",
        },
        "nisar_gunw_actual": {
            "sensor": "NISAR L-band",
            "polarization": "HH",
            "maturity": n_findings["pairs"]["event"]["maturity"],
            "crid": n_findings["pairs"]["event"]["crid"],
            "acquisition_matched_track_48": {
                "product_id": n_tracks["tracks"]["48"]["product_id"],
                "event_dates": ["2026-08-16", "2026-08-28"],
                "time_after_c_band_reference_seconds": 2184,
                "time_after_c_band_secondary_seconds": 2183,
                "source_sample_valid_fraction": n_tracks["tracks"]["48"]["sample_valid_fraction"],
                "diagnosis": "Nearly time-matched to S1D, but the inspected source window has no samples passing the NISAR reference/secondary subswath validity mask.",
            },
            "usable_track_98": {
                "product_id": n_findings["pairs"]["event"]["products"]["gunw"]["product_id"],
                "event_dates": n_findings["pairs"]["event"]["dates"],
                "reference_after_c_band_seconds": 299850,
                "secondary_after_c_band_seconds": 299849,
                "source_sample_valid_pixels": n_event_source["sample_valid_pixels"],
                "source_phase_valid_pixels": n_event_source["phase_valid_pixels"],
                "source_phase_valid_fraction": n_event_source["phase_valid_fraction"],
                "source_coherence_median": n_event_source["coherence_median"],
                "quiet_dates": n_findings["pairs"]["quiet"]["dates"],
                "quiet_source_phase_valid_fraction": n_quiet_source["phase_valid_fraction"],
                "quiet_source_coherence_median": n_quiet_source["coherence_median"],
                "encoded_mask_counts": n_event_source["encoded_mask_counts"],
                "ionosphere_uncertainty_median_rad": n_event_source["ionosphere_uncertainty_median_rad"],
                "qa_note": "All eight inspected NISAR QA sidecars in the sibling analysis contain at least one failed identification-group check; this is not a clean mission-QA pass.",
            },
            "observed_quality_layer_paths": sorted(n_ident["products"]["gunw"]["quality_layers"]),
        },
        "layer_parity": [
            {
                "layer_or_requirement": "12-day co-polarized nearest-neighbor pair",
                "sentinel1d_hyp3": "Yes: VV, 12 days",
                "nisar_gunw": "Yes: HH, 12 days",
                "comparison": "Temporal interval matches; polarization and wavelength do not.",
            },
            {
                "layer_or_requirement": "Normalized coherence magnitude",
                "sentinel1d_hyp3": "Yes, geocoded 80 m, 0-1",
                "nisar_gunw": "Yes, 20 m and 80 m, 0-1",
                "comparison": "Use the NISAR 80 m layer on a common grid; compare within-sensor event-minus-null change, not absolute C-vs-L magnitude.",
            },
            {
                "layer_or_requirement": "Unwrapped phase",
                "sentinel1d_hyp3": "Yes, radians at 80 m",
                "nisar_gunw": "Yes, radians at 80 m",
                "comparison": "Require finite phase and connected component >0; independently re-reference each product before any displacement interpretation.",
            },
            {
                "layer_or_requirement": "Connected components",
                "sentinel1d_hyp3": "Yes, SNAPHU component GeoTIFF",
                "nisar_gunw": "Yes, uint16 component layer",
                "comparison": "Never compare/subtract unwrapped phase across disconnected components.",
            },
            {
                "layer_or_requirement": "Wrapped interferogram",
                "sentinel1d_hyp3": "Geocoded wrapped phase at 80 m plus native complex range-Doppler burst",
                "nisar_gunw": "Geocoded complex wrapped interferogram at 20 m",
                "comparison": "Not layer-equivalent; preserve native representations for reprocessing.",
            },
            {
                "layer_or_requirement": "Validity/anomaly mask",
                "sentinel1d_hyp3": "Binary water mask and raster nodata; no encoded input-anomaly/subswath mask",
                "nisar_gunw": "uint32 encoded water, reference/secondary subswath validity, input anomalies, and ionosphere interpolation mask",
                "comparison": "NISAR mask decoding is mandatory. For C-band, add independent terrain/layover-shadow screening before science claims.",
            },
            {
                "layer_or_requirement": "Ionosphere phase and uncertainty",
                "sentinel1d_hyp3": "Absent",
                "nisar_gunw": "Present",
                "comparison": "Do not treat raw C/L unwrapped-phase differences as comparable corrections.",
            },
            {
                "layer_or_requirement": "External correction lookup tables",
                "sentinel1d_hyp3": "Absent",
                "nisar_gunw": "Solid-Earth-tide and hydrostatic/wet-troposphere LUTs when available; not pre-applied",
                "comparison": "Apply and document correction choices consistently before deformation analysis.",
            },
            {
                "layer_or_requirement": "Sub-pixel offsets",
                "sentinel1d_hyp3": "Absent from delivered burst bundle",
                "nisar_gunw": "Along-track/slant-range offset layers included; GOFF adds multiscale offsets",
                "comparison": "Use NISAR offsets only with their correlation/SNR and culling requirements; no C-band counterpart was ordered.",
            },
        ],
        "cross_sensor_acceptance_gate": [
            "Use only event and quiet pairs with explicit acquisition IDs, same within-sensor geometry, and identical processing parameters.",
            "Reproject to a declared common 80 m grid without counting nodata, water, invalid subswaths, or anomaly-masked samples as low coherence.",
            "Report coherence and phase-valid coverage over the full reference footprint as well as statistics over valid pixels.",
            "Require connected-component continuity for every phase statistic and never bridge component boundaries.",
            "Compare event-minus-quiet coherence within each sensor first; treat C-vs-L absolute coherence differences as wavelength/polarization/look dependent.",
            "Screen steep-terrain geometry explicitly; the HyP3 bundle does not provide a NISAR-equivalent encoded quality mask.",
            "Treat ionosphere, troposphere, DEM residuals, snow/moisture, glacier motion, and phase reference as unresolved until corrected or controlled.",
        ],
        "source_artifacts": {
            "c_band": str((ROOT / "analysis" / "coherence_comparison.json")),
            "nisar_findings": str(NISAR_ROOT / "outputs" / "subset_findings.json"),
            "nisar_track_comparison": str(NISAR_ROOT / "outputs" / "track_comparison.json"),
            "nisar_identification": str(NISAR_ROOT / "outputs" / "selected_identification.json"),
        },
    }
    (ROOT / "nisar_comparison.json").write_text(json.dumps(comparison, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "c_band_detachment": comparison["c_band_delivered"]["detachment_metrics"],
        "nisar_track_48": comparison["nisar_gunw_actual"]["acquisition_matched_track_48"],
        "nisar_track_98": comparison["nisar_gunw_actual"]["usable_track_98"],
        "layer_rows": len(comparison["layer_parity"]),
    }, indent=2))


if __name__ == "__main__":
    main()
