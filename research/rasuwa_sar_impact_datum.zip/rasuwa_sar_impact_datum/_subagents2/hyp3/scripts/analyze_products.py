#!/usr/bin/env python3
"""Inspect the delivered event/null burst InSAR products conservatively."""
from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import rasterio
from pyproj import Transformer
from rasterio.enums import Resampling
from rasterio.features import rasterize
from rasterio.warp import reproject
from shapely.geometry import box, shape
from shapely.ops import transform as shapely_transform

ROOT = Path(__file__).resolve().parents[1]
EXTRACTED = ROOT / "products" / "extracted"
OUT = ROOT / "analysis"
REFERENCE = Path("/home/safal0715/Documents/research/data/inputs/validation/unosat_detachment.geojson")
SOURCE_LON_LAT = (85.528066, 28.291242)
AOI_BBOX = (85.34, 28.23, 85.55, 28.32)


def product_dir(token: str) -> Path:
    matches = [path for path in EXTRACTED.glob(f"*{token}*/*") if path.is_dir()]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one product directory matching {token}; got {matches}")
    return matches[0]


def layer(directory: Path, suffix: str) -> Path:
    matches = list(directory.glob(f"*{suffix}"))
    if len(matches) != 1:
        raise RuntimeError(f"Expected one {suffix} in {directory}; got {matches}")
    return matches[0]


def projected_geometry(geometry, crs):
    transformer = Transformer.from_crs("EPSG:4326", crs, always_xy=True)
    return shapely_transform(transformer.transform, geometry)


def geometry_mask(geometry, profile: dict) -> np.ndarray:
    return rasterize(
        [(geometry, 1)],
        out_shape=(profile["height"], profile["width"]),
        transform=profile["transform"],
        fill=0,
        all_touched=False,
        dtype="uint8",
    ).astype(bool)


def read_masked(path: Path):
    with rasterio.open(path) as source:
        return source.read(1, masked=True), source.profile.copy(), source.tags()


def align_float(path: Path, target_profile: dict, resampling=Resampling.bilinear) -> np.ndarray:
    destination = np.full(
        (target_profile["height"], target_profile["width"]), np.nan, dtype="float32"
    )
    with rasterio.open(path) as source:
        reproject(
            source=rasterio.band(source, 1),
            destination=destination,
            src_transform=source.transform,
            src_crs=source.crs,
            src_nodata=source.nodata,
            dst_transform=target_profile["transform"],
            dst_crs=target_profile["crs"],
            dst_nodata=np.nan,
            resampling=resampling,
        )
    return destination


def align_uint8(path: Path, target_profile: dict) -> np.ndarray:
    destination = np.full(
        (target_profile["height"], target_profile["width"]), 255, dtype="uint8"
    )
    with rasterio.open(path) as source:
        reproject(
            source=rasterio.band(source, 1),
            destination=destination,
            src_transform=source.transform,
            src_crs=source.crs,
            src_nodata=source.nodata,
            dst_transform=target_profile["transform"],
            dst_crs=target_profile["crs"],
            dst_nodata=255,
            resampling=Resampling.nearest,
        )
    return destination


def numeric_stats(values: np.ndarray) -> dict:
    values = np.asarray(values, dtype="float64")
    if values.size == 0:
        return {"count": 0}
    return {
        "count": int(values.size),
        "minimum": float(np.min(values)),
        "p05": float(np.percentile(values, 5)),
        "p25": float(np.percentile(values, 25)),
        "median": float(np.median(values)),
        "mean": float(np.mean(values)),
        "p75": float(np.percentile(values, 75)),
        "p95": float(np.percentile(values, 95)),
        "maximum": float(np.max(values)),
        "stddev": float(np.std(values)),
    }


def json_default(value):
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def product_region_stats(directory: Path, regions_wgs84: dict[str, object]) -> tuple[dict, dict]:
    corr, profile, corr_tags = read_masked(layer(directory, "_corr.tif"))
    phase, phase_profile, phase_tags = read_masked(layer(directory, "_unw_phase.tif"))
    components, component_profile, component_tags = read_masked(layer(directory, "_conncomp.tif"))
    water, water_profile, water_tags = read_masked(layer(directory, "_water_mask.tif"))
    signatures = {
        (item["crs"], item["transform"], item["height"], item["width"])
        for item in (profile, phase_profile, component_profile, water_profile)
    }
    if len(signatures) != 1:
        raise RuntimeError(f"Layer grid mismatch within {directory}")

    corr_data = corr.filled(np.nan).astype("float64")
    phase_data = phase.filled(np.nan).astype("float64")
    component_data = components.filled(0).astype("int32")
    land = (~np.ma.getmaskarray(water)) & (water.filled(255) == 1)
    corr_valid = (~np.ma.getmaskarray(corr)) & np.isfinite(corr_data)
    phase_valid = (~np.ma.getmaskarray(phase)) & np.isfinite(phase_data)
    component_valid = (~np.ma.getmaskarray(components)) & (component_data > 0)

    regions = {}
    for name, geometry_wgs84 in regions_wgs84.items():
        projected = projected_geometry(geometry_wgs84, profile["crs"])
        region = geometry_mask(projected, profile)
        denominator = region & land
        valid_corr = denominator & corr_valid
        valid_phase = denominator & phase_valid & component_valid
        labels, counts = np.unique(component_data[valid_phase], return_counts=True)
        label_counts = {
            str(int(label)): int(count)
            for label, count in zip(labels, counts)
            if label > 0
        }
        corr_values = corr_data[valid_corr]
        regions[name] = {
            "region_pixels": int(region.sum()),
            "land_pixels": int(denominator.sum()),
            "coherence_valid_pixels": int(valid_corr.sum()),
            "coherence_valid_fraction_of_land": (
                float(valid_corr.sum() / denominator.sum()) if denominator.any() else None
            ),
            "coherence": numeric_stats(corr_values),
            "coherence_fraction_below": {
                str(threshold): float(np.mean(corr_values < threshold)) if corr_values.size else None
                for threshold in (0.2, 0.3, 0.5)
            },
            "unwrapped_valid_pixels": int(valid_phase.sum()),
            "unwrapped_valid_fraction_of_land": (
                float(valid_phase.sum() / denominator.sum()) if denominator.any() else None
            ),
            "unwrapped_phase_radians": numeric_stats(phase_data[valid_phase]),
            "connected_component_count": len(label_counts),
            "connected_component_pixel_counts": label_counts,
            "dominant_component_fraction_of_unwrapped": (
                max(label_counts.values()) / valid_phase.sum() if label_counts else None
            ),
        }

    transformer = Transformer.from_crs("EPSG:4326", profile["crs"], always_xy=True)
    x, y = transformer.transform(*SOURCE_LON_LAT)
    row, col = rasterio.transform.rowcol(profile["transform"], x, y)
    point = {
        "row_col": [int(row), int(col)],
        "in_grid": 0 <= row < profile["height"] and 0 <= col < profile["width"],
    }
    if point["in_grid"]:
        point.update(
            {
                "coherence": None if not corr_valid[row, col] else float(corr_data[row, col]),
                "unwrapped_phase_radians": None if not phase_valid[row, col] else float(phase_data[row, col]),
                "connected_component": int(component_data[row, col]),
                "water_mask": int(water[row, col]),
            }
        )
    product = {
        "directory": str(directory.relative_to(ROOT)),
        "grid": {
            "crs": str(profile["crs"]),
            "shape": [profile["height"], profile["width"]],
            "pixel_spacing_m": [abs(float(profile["transform"].a)), abs(float(profile["transform"].e))],
            "bounds": [float(value) for value in rasterio.coords.BoundingBox(*profile_bounds(profile))],
            "nodata": profile["nodata"],
        },
        "tags": {
            "coherence": corr_tags,
            "unwrapped_phase": phase_tags,
            "connected_components": component_tags,
            "water_mask": water_tags,
        },
        "source_point": point,
        "regions": regions,
    }
    return product, profile


def profile_bounds(profile: dict):
    return rasterio.transform.array_bounds(profile["height"], profile["width"], profile["transform"])


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    quiet_dir = product_dir("20260804_20260816")
    event_dir = product_dir("20260816_20260828")

    reference = json.loads(REFERENCE.read_text())
    if len(reference.get("features", [])) != 1:
        raise RuntimeError("Expected exactly one detachment feature")
    detachment = shape(reference["features"][0]["geometry"])
    source_aoi = box(*AOI_BBOX)
    local_ring = detachment.buffer(0.015).difference(detachment.buffer(0.003))
    broad_control = source_aoi.difference(detachment.buffer(0.003))
    regions = {
        "detachment": detachment,
        "local_control_ring_approx_0.3_to_1.5_km": local_ring,
        "fixed_aoi_outside_approx_0.3_km_buffer": broad_control,
        "fixed_aoi": source_aoi,
    }

    quiet, quiet_profile = product_region_stats(quiet_dir, regions)
    event, event_profile = product_region_stats(event_dir, regions)
    if str(quiet_profile["crs"]) != str(event_profile["crs"]):
        raise RuntimeError("Event and quiet products have different CRSs")

    event_corr, _, _ = read_masked(layer(event_dir, "_corr.tif"))
    event_values = event_corr.filled(np.nan).astype("float32")
    quiet_aligned = align_float(layer(quiet_dir, "_corr.tif"), event_profile)
    event_water, _, _ = read_masked(layer(event_dir, "_water_mask.tif"))
    quiet_water_aligned = align_uint8(layer(quiet_dir, "_water_mask.tif"), event_profile)
    event_land = (~np.ma.getmaskarray(event_water)) & (event_water.filled(255) == 1)
    pair_valid = (
        (~np.ma.getmaskarray(event_corr))
        & np.isfinite(event_values)
        & np.isfinite(quiet_aligned)
        & event_land
        & (quiet_water_aligned == 1)
    )
    delta = np.full(event_values.shape, np.nan, dtype="float32")
    delta[pair_valid] = event_values[pair_valid] - quiet_aligned[pair_valid]

    paired_regions = {}
    for name, geometry_wgs84 in regions.items():
        region = geometry_mask(projected_geometry(geometry_wgs84, event_profile["crs"]), event_profile)
        valid = pair_valid & region
        paired_regions[name] = {
            "pair_valid_pixels": int(valid.sum()),
            "event_coherence": numeric_stats(event_values[valid]),
            "quiet_coherence_reprojected": numeric_stats(quiet_aligned[valid]),
            "event_minus_quiet_coherence": numeric_stats(delta[valid]),
            "fraction_event_lower_than_quiet": float(np.mean(delta[valid] < 0)) if valid.any() else None,
        }

    detachment_delta_median = paired_regions["detachment"]["event_minus_quiet_coherence"]["median"]
    paired_contrasts = {}
    for control_name in (
        "local_control_ring_approx_0.3_to_1.5_km",
        "fixed_aoi_outside_approx_0.3_km_buffer",
    ):
        control_delta_median = paired_regions[control_name]["event_minus_quiet_coherence"]["median"]
        paired_contrasts[f"detachment_minus_{control_name}"] = {
            "detachment_event_minus_quiet_median": detachment_delta_median,
            "control_event_minus_quiet_median": control_delta_median,
            "difference_of_median_changes": detachment_delta_median - control_delta_median,
            "interpretation": "Negative means the detachment's event-minus-quiet coherence change is lower than the control's; descriptive only, with spatially correlated pixels.",
        }

    comparison = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "observable": "Sentinel-1D VV normalized interferometric coherence and phase",
        "quiet": quiet,
        "event": event,
        "paired_on_event_grid": {
            "alignment": "Quiet coherence bilinearly reprojected to the event 80 m UTM grid; declared nodata excluded. Water-mask land required in both products.",
            "native_grid_relationship": {
                "same_crs": quiet_profile["crs"] == event_profile["crs"],
                "same_shape": (quiet_profile["height"], quiet_profile["width"]) == (event_profile["height"], event_profile["width"]),
                "same_transform": quiet_profile["transform"] == event_profile["transform"],
                "quiet_transform": list(quiet_profile["transform"]),
                "event_transform": list(event_profile["transform"]),
            },
            "regions": paired_regions,
            "descriptive_control_contrasts": paired_contrasts,
        },
        "reference": {
            "path": str(REFERENCE),
            "properties": reference["features"][0].get("properties", {}),
            "role": "Independent preliminary optical detachment polygon; not field ground truth.",
        },
        "limitations": [
            "No layover/shadow or local-incidence mask was supplied by the Burst InSAR bundle, so these descriptive metrics are not a final steep-terrain validation.",
            "Correlation nodata is censored, not counted as zero coherence; valid-fraction denominators are reported separately.",
            "The two interferograms have independent phase references, so their unwrapped-phase values are not subtracted.",
            "A single event-spanning pair cannot separate avalanche/flood disturbance from glacier motion, snow/moisture, atmosphere, DEM residuals, or other surface changes.",
            "The event and null pairs share the middle acquisition and 12-day interval, but have different perpendicular baselines and acquisition conditions.",
        ],
    }
    (OUT / "coherence_comparison.json").write_text(
        json.dumps(comparison, indent=2, sort_keys=True, default=json_default) + "\n"
    )

    output_profile = event_profile.copy()
    output_profile.update(driver="GTiff", count=1, dtype="float32", nodata=-9999.0, compress="DEFLATE", tiled=True, predictor=3)
    with rasterio.open(OUT / "coherence_event_minus_quiet.tif", "w", **output_profile) as destination:
        destination.write(np.nan_to_num(delta, nan=-9999.0).astype("float32"), 1)
        destination.update_tags(
            observable="event normalized coherence minus reprojected quiet normalized coherence",
            event_product=event_dir.name,
            quiet_product=quiet_dir.name,
            alignment="quiet bilinear to event grid",
            interpretation_limit="Descriptive difference; not a hazard class or unique event attribution.",
        )
    mask_profile = event_profile.copy()
    mask_profile.update(driver="GTiff", count=1, dtype="uint8", nodata=255, compress="DEFLATE", tiled=True)
    with rasterio.open(OUT / "coherence_pair_valid_mask.tif", "w", **mask_profile) as destination:
        destination.write(pair_valid.astype("uint8"), 1)
        destination.update_tags(meaning="1 pair-valid land coherence in event and aligned quiet products; 0 otherwise")

    rows = []
    for name, values in paired_regions.items():
        rows.append(
            {
                "region": name,
                "pair_valid_pixels": values["pair_valid_pixels"],
                "event_median_coherence": values["event_coherence"].get("median"),
                "quiet_median_coherence": values["quiet_coherence_reprojected"].get("median"),
                "median_event_minus_quiet": values["event_minus_quiet_coherence"].get("median"),
                "mean_event_minus_quiet": values["event_minus_quiet_coherence"].get("mean"),
                "fraction_event_lower_than_quiet": values["fraction_event_lower_than_quiet"],
            }
        )
    with (OUT / "coherence_region_summary.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    # Descriptive quicklook only: no calibrated hazard threshold or numerical color ticks beyond coherence/difference.
    extent = [
        event_profile["transform"].c,
        event_profile["transform"].c + event_profile["width"] * event_profile["transform"].a,
        event_profile["transform"].f + event_profile["height"] * event_profile["transform"].e,
        event_profile["transform"].f,
    ]
    detachment_projected = projected_geometry(detachment, event_profile["crs"])
    x, y = detachment_projected.exterior.xy
    figure, axes = plt.subplots(1, 3, figsize=(15, 5), constrained_layout=True)
    panels = [
        (quiet_aligned, "Quiet null coherence\n4–16 Aug", "gray", 0, 1),
        (event_values, "Event-spanning coherence\n16–28 Aug", "gray", 0, 1),
        (delta, "Event − quiet coherence\n(descriptive)", "RdBu_r", -0.5, 0.5),
    ]
    for axis, (array, title, cmap, low, high) in zip(axes, panels):
        image = axis.imshow(array, extent=extent, origin="upper", cmap=cmap, vmin=low, vmax=high)
        axis.plot(x, y, color="yellow", linewidth=1.2, label="UNOSAT detachment")
        axis.set_title(title)
        axis.set_aspect("equal")
        axis.legend(loc="lower right", fontsize=7)
        figure.colorbar(image, ax=axis, shrink=0.75)
    figure.suptitle("Sentinel-1D HyP3 Burst InSAR — path 85 VV, 80 m pixels")
    figure.savefig(OUT / "coherence_comparison.png", dpi=180)
    plt.close(figure)

    print(json.dumps({
        "quiet_source_point": quiet["source_point"],
        "event_source_point": event["source_point"],
        "paired_regions": paired_regions,
        "outputs": [
            "analysis/coherence_comparison.json",
            "analysis/coherence_region_summary.csv",
            "analysis/coherence_event_minus_quiet.tif",
            "analysis/coherence_pair_valid_mask.tif",
            "analysis/coherence_comparison.png",
        ],
    }, indent=2, default=json_default))


if __name__ == "__main__":
    main()
