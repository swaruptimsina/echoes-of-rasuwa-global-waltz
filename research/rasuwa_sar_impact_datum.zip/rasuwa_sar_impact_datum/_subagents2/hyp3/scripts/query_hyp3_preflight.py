#!/usr/bin/env python3
"""Query HyP3 account, costs, jobs, and live OpenAPI safely."""
from __future__ import annotations

import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import requests
import hyp3_sdk

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "raw"
API = "https://hyp3-api.asf.alaska.edu"


def main() -> None:
    RAW.mkdir(parents=True, exist_ok=True)
    hyp3 = hyp3_sdk.HyP3(API)

    info = hyp3.my_info()
    costs = hyp3.costs()
    jobs = hyp3.find_jobs()

    openapi_response = requests.get(f"{API}/openapi.json", timeout=120)
    openapi_response.raise_for_status()
    openapi = openapi_response.json()
    (RAW / "hyp3_openapi.json").write_text(json.dumps(openapi, indent=2, sort_keys=True) + "\n")

    job_statuses = Counter(job.status_code for job in jobs)
    job_types = Counter(job.job_type for job in jobs)
    summary = {
        "queried_utc": datetime.now(timezone.utc).isoformat(),
        "api": API,
        "api_version": openapi.get("info", {}).get("version"),
        "sdk_version": hyp3_sdk.__version__,
        "authenticated": True,
        "account_response_keys": sorted(info.keys()),
        "remaining_credits": info.get("remaining_credits"),
        "costs": costs,
        "existing_jobs": {
            "count": len(jobs),
            "status_counts": dict(sorted(job_statuses.items())),
            "job_type_counts": dict(sorted(job_types.items())),
            "total_recorded_credit_cost": sum(
                job.credit_cost for job in jobs if job.credit_cost is not None
            ),
        },
        "privacy": "Earthdata username, password, bearer tokens, cookies, and user ID are neither printed nor stored.",
    }
    (RAW / "hyp3_preflight.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")

    print(json.dumps({
        "api_version": summary["api_version"],
        "sdk_version": summary["sdk_version"],
        "authenticated": summary["authenticated"],
        "remaining_credits": summary["remaining_credits"],
        "costs": summary["costs"],
        "existing_jobs": summary["existing_jobs"],
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
