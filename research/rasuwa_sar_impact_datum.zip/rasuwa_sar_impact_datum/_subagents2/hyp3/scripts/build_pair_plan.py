#!/usr/bin/env python3
"""Build reproducible same-track Sentinel-1D event/null pair plans."""
from __future__ import annotations

import csv
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import asf_search
import requests
from asf_search.baseline.stack import get_baseline_from_stack
from shapely.geometry import Point, box, shape

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "raw"
EVENT = datetime.fromisoformat("2026-08-26T02:52:10+00:00")
SOURCE = Point(85.528066, 28.291242)
AOI = box(85.34, 28.23, 85.55, 28.32)
SEARCH_URL = "https://api.daac.asf.alaska.edu/services/search/param"
SEARCH_PARAMS = {
    "dataset": "SENTINEL-1",
    "processingLevel": "SLC",
    "intersectsWith": "POINT(85.528066 28.291242)",
    "start": "2026-07-01T00:00:00Z",
    "end": "2026-10-15T23:59:59Z",
    "maxResults": 500,
    "output": "geojson",
}


def parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def pair_baseline(older_id: str, newer_id: str) -> dict:
    """Calculate B-perp from live CMR state vectors via asf_search.

    asf_search 10.2.0 does not map the new SENTINEL-1D_SLC collection to its
    S1Product subclass, so we explicitly filter the science SLC records and
    cast them. This avoids the duplicate metadata-only records returned by
    granule_search and enables the package's state-vector baseline algorithm.
    """
    raw = asf_search.granule_search([older_id, newer_id])
    science = []
    for product in raw:
        if product.properties.get("processingLevel") == "SLC":
            science.append(asf_search.S1Product(args={"umm": product.umm, "meta": product.meta}))
    by_id = {product.properties["sceneName"]: product for product in science}
    if set(by_id) != {older_id, newer_id}:
        raise RuntimeError(f"Expected exactly two science SLCs, got {sorted(by_id)}")
    older = by_id[older_id]
    newer = by_id[newer_id]
    stack, warnings = get_baseline_from_stack(
        older, asf_search.ASFSearchResults([older, newer])
    )
    target = next(p for p in stack if p.properties["sceneName"] == newer_id)
    return {
        "temporal_baseline_days": target.properties["temporalBaseline"],
        "perpendicular_baseline_m": target.properties["perpendicularBaseline"],
        "baseline_warnings": warnings,
        "cmr_concept_ids": {
            p.properties["sceneName"]: p.meta["concept-id"] for p in science
        },
        "cmr_collection_concept_ids": {
            p.properties["sceneName"]: p.meta["collection-concept-id"] for p in science
        },
    }


def main() -> None:
    RAW.mkdir(parents=True, exist_ok=True)
    response = requests.get(SEARCH_URL, params=SEARCH_PARAMS, timeout=120)
    response.raise_for_status()
    catalog = response.json()
    (RAW / "asf_s1d_slc_live.geojson").write_text(
        json.dumps(catalog, indent=2, sort_keys=True) + "\n"
    )
    (RAW / "asf_s1d_slc_query.json").write_text(
        json.dumps(
            {
                "queried_utc": datetime.now(timezone.utc).isoformat(),
                "request_url": response.url,
                "status_code": response.status_code,
                "feature_count": len(catalog.get("features", [])),
            },
            indent=2,
            sort_keys=True,
        )
        + "\n"
    )

    groups: dict[tuple, list] = defaultdict(list)
    for feature in catalog["features"]:
        properties = feature["properties"]
        if properties.get("platform") != "Sentinel-1D":
            continue
        key = (
            properties["pathNumber"],
            properties["flightDirection"],
            properties["frameNumber"],
            properties["polarization"],
            properties["beamModeType"],
        )
        groups[key].append(feature)

    chains = []
    pair_rows = []
    for key, features in sorted(groups.items()):
        ordered = sorted(features, key=lambda f: f["properties"]["startTime"])
        times = [parse_time(f["properties"]["startTime"]) for f in ordered]
        bracket_index = next(
            (i for i in range(len(times) - 1) if times[i] < EVENT < times[i + 1]),
            None,
        )
        if bracket_index is None or bracket_index == 0:
            continue
        selected = ordered[bracket_index - 1 : bracket_index + 2]
        labels = ["quiet_pre", "event_pre", "event_post"]
        acquisitions = []
        for label, feature in zip(labels, selected):
            p = feature["properties"]
            footprint = shape(feature["geometry"])
            acquisitions.append(
                {
                    "label": label,
                    "scene_name": p["sceneName"],
                    "file_id": p["fileID"],
                    "start_utc": p["startTime"],
                    "stop_utc": p["stopTime"],
                    "event_offset_days": round(
                        (parse_time(p["startTime"]) - EVENT).total_seconds() / 86400.0, 6
                    ),
                    "path": p["pathNumber"],
                    "direction": p["flightDirection"],
                    "frame": p["frameNumber"],
                    "polarization": p["polarization"],
                    "beam_mode": p["beamModeType"],
                    "absolute_orbit": p["orbit"],
                    "platform": p["platform"],
                    "source_bytes": p["bytes"],
                    "source_point_covered": footprint.covers(SOURCE),
                    "aoi_coverage_fraction": round(
                        footprint.intersection(AOI).area / AOI.area, 6
                    ),
                }
            )

        pairs = []
        for pair_label, left, right in (
            ("quiet_null", acquisitions[0], acquisitions[1]),
            ("event", acquisitions[1], acquisitions[2]),
        ):
            baseline = pair_baseline(left["scene_name"], right["scene_name"])
            pair = {
                "pair_label": pair_label,
                "granules": [left["scene_name"], right["scene_name"]],
                "reference_start_utc": left["start_utc"],
                "secondary_start_utc": right["start_utc"],
                **baseline,
            }
            pairs.append(pair)
            pair_rows.append(
                {
                    "path": key[0],
                    "direction": key[1],
                    "frame": key[2],
                    "pair_label": pair_label,
                    "reference_granule": left["scene_name"],
                    "secondary_granule": right["scene_name"],
                    "reference_start_utc": left["start_utc"],
                    "secondary_start_utc": right["start_utc"],
                    "temporal_baseline_days": baseline["temporal_baseline_days"],
                    "perpendicular_baseline_m": baseline["perpendicular_baseline_m"],
                }
            )

        chains.append(
            {
                "path": key[0],
                "direction": key[1],
                "frame": key[2],
                "polarization": key[3],
                "beam_mode": key[4],
                "acquisitions": acquisitions,
                "pairs": pairs,
                "selection_logic": "Three consecutive same-geometry S1D IW SLCs: adjacent pre-event pair as quiet null and the next adjacent pair bracketing the event.",
            }
        )

    result = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "event_utc": EVENT.isoformat(),
        "source_lon_lat": [SOURCE.x, SOURCE.y],
        "aoi_bbox_wsen": list(AOI.bounds),
        "catalog_request_url": response.url,
        "catalog_feature_count": len(catalog["features"]),
        "asf_search_version": asf_search.__version__,
        "chain_count": len(chains),
        "chains": chains,
        "baseline_note": "Perpendicular baselines are rounded to metres by asf_search's state-vector algorithm and are pair-relative; signs depend on reference ordering.",
    }
    (ROOT / "pair_candidates.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    with (ROOT / "pair_candidates.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(pair_rows[0]))
        writer.writeheader()
        writer.writerows(pair_rows)

    print(json.dumps({
        "catalog_feature_count": result["catalog_feature_count"],
        "chain_count": result["chain_count"],
        "chains": [
            {
                "path": chain["path"],
                "direction": chain["direction"],
                "frame": chain["frame"],
                "acquisitions": [
                    [item["label"], item["start_utc"], item["scene_name"], item["event_offset_days"], item["source_point_covered"], item["aoi_coverage_fraction"]]
                    for item in chain["acquisitions"]
                ],
                "pairs": [
                    [pair["pair_label"], pair["temporal_baseline_days"], pair["perpendicular_baseline_m"]]
                    for pair in chain["pairs"]
                ],
            }
            for chain in chains
        ],
    }, indent=2))


if __name__ == "__main__":
    main()
