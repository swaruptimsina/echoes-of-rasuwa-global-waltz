#!/usr/bin/env python3
"""Inventory Sentinel-1D bursts and freeze the selected HyP3 pair."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import asf_search
from shapely.geometry import Point, box, shape

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "raw"
SOURCE = Point(85.528066, 28.291242)
AOI = box(85.34, 28.23, 85.55, 28.32)
SELECTED = {
    "S1_180590_IW2_20260804T122147_VV_F90B-BURST": "quiet_pre",
    "S1_180590_IW2_20260816T122147_VV_0444-BURST": "event_pre",
    "S1_180590_IW2_20260828T122148_VV_93F8-BURST": "event_post",
}


def main() -> None:
    options = {
        "dataset": "SLC-BURST",
        "processingLevel": "BURST",
        "intersectsWith": "POINT(85.528066 28.291242)",
        "start": "2026-08-01T00:00:00Z",
        "end": "2026-09-06T23:59:59Z",
        "maxResults": 500,
    }
    results = asf_search.geo_search(**options)
    RAW.mkdir(parents=True, exist_ok=True)
    (RAW / "asf_s1d_bursts_live.geojson").write_text(
        json.dumps(results.geojson(), indent=2, sort_keys=True) + "\n"
    )

    selected = []
    for product in results:
        file_id = product.properties["fileID"]
        if file_id not in SELECTED:
            continue
        geometry = shape(product.geometry)
        selected.append(
            {
                "role": SELECTED[file_id],
                "burst_id": file_id,
                "cmr_concept_id": product.meta.get("concept-id"),
                "cmr_collection_concept_id": product.meta.get("collection-concept-id"),
                "parent_group_id": product.properties.get("groupID"),
                "platform": product.properties.get("platform"),
                "relative_orbit": product.properties.get("pathNumber"),
                "flight_direction": product.properties.get("flightDirection"),
                "polarization": product.properties.get("polarization"),
                "start_utc": product.properties.get("startTime"),
                "stop_utc": product.properties.get("stopTime"),
                "absolute_orbit": product.properties.get("orbit"),
                "full_burst_id": product.properties.get("burst", {}).get("fullBurstID"),
                "relative_burst_id": product.properties.get("burst", {}).get("relativeBurstID"),
                "subswath": product.properties.get("burst", {}).get("subswath"),
                "burst_index": product.properties.get("burst", {}).get("burstIndex"),
                "source_bytes": int(product.properties.get("bytes")),
                "source_point_covered": geometry.covers(SOURCE),
                "aoi_coverage_fraction": round(geometry.intersection(AOI).area / AOI.area, 6),
                "footprint_bounds_wsen": [round(value, 6) for value in geometry.bounds],
            }
        )
    selected.sort(key=lambda item: item["start_utc"])
    if [item["role"] for item in selected] != ["quiet_pre", "event_pre", "event_post"]:
        raise RuntimeError(f"Selected burst chain incomplete: {selected}")
    if not all(item["platform"] == "SENTINEL-1D" for item in selected):
        raise RuntimeError("Selected chain is not entirely Sentinel-1D")
    if len({item["full_burst_id"] for item in selected}) != 1:
        raise RuntimeError("Selected chain does not use one stable full burst ID")

    plan = {
        "queried_utc": datetime.now(timezone.utc).isoformat(),
        "asf_search_version": asf_search.__version__,
        "query_options": options,
        "catalog_result_count": len(results),
        "catalog_search_complete": results.searchComplete,
        "source_lon_lat": [SOURCE.x, SOURCE.y],
        "aoi_bbox_wsen": list(AOI.bounds),
        "selected_acquisitions": selected,
        "pairs": {
            "quiet_null": [selected[0]["burst_id"], selected[1]["burst_id"]],
            "event": [selected[1]["burst_id"], selected[2]["burst_id"]],
        },
    }
    (ROOT / "burst_pair_plan.json").write_text(json.dumps(plan, indent=2, sort_keys=True) + "\n")
    print(json.dumps(plan, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
