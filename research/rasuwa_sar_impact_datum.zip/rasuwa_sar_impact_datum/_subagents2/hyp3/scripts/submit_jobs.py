#!/usr/bin/env python3
"""Submit exactly the validated minimal event/null HyP3 job set once."""
from __future__ import annotations

import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import hyp3_sdk

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "raw"
API = "https://hyp3-api.asf.alaska.edu"
SUBMISSION = ROOT / "submitted_jobs.json"


def remove_identifiers(value):
    if isinstance(value, dict):
        return {
            key: remove_identifiers(item)
            for key, item in value.items()
            if key not in {"user_id"}
        }
    if isinstance(value, list):
        return [remove_identifiers(item) for item in value]
    return value


def safe_job(job) -> dict:
    value = job.to_dict()
    value.pop("user_id", None)
    return value


def main() -> None:
    if SUBMISSION.exists():
        raise RuntimeError(f"Refusing duplicate submission; {SUBMISSION} already exists")

    plan = json.loads((ROOT / "job_plan.json").read_text())
    validated_request = json.loads((RAW / "hyp3_validate_request.json").read_text())
    validated_check = json.loads((RAW / "hyp3_validate_check.json").read_text())
    jobs = plan["jobs"]
    if validated_request != {"validate_only": True, "jobs": jobs}:
        raise RuntimeError("Planned jobs differ from validated jobs")
    if not validated_check.get("s1d_inputs_accepted"):
        raise RuntimeError("Validated check does not show S1D inputs accepted")
    if validated_check.get("returned_credit_costs") != [1, 1]:
        raise RuntimeError("Validated costs are not exactly [1, 1]")

    hyp3 = hyp3_sdk.HyP3(API)
    before_info = hyp3.my_info()
    before_jobs = hyp3.find_jobs()
    expected_total = plan["expected_credit_cost_total"]
    if before_info.get("remaining_credits", 0) < expected_total:
        raise RuntimeError("Insufficient credits")
    if any(job.name in {item["name"] for item in jobs} for job in before_jobs):
        raise RuntimeError("A job with a planned name already exists; refusing duplicate")

    request_payload = {"validate_only": False, "jobs": jobs}
    (RAW / "hyp3_submit_request.json").write_text(
        json.dumps(request_payload, indent=2, sort_keys=True) + "\n"
    )
    response = hyp3.session.post(f"{API}/jobs", json=request_payload, timeout=180)
    response.raise_for_status()
    submitted = remove_identifiers(response.json())
    (RAW / "hyp3_submit_response.json").write_text(
        json.dumps(submitted, indent=2, sort_keys=True) + "\n"
    )

    submitted_jobs = submitted.get("jobs", [])
    if len(submitted_jobs) != len(jobs):
        raise RuntimeError(f"Expected {len(jobs)} submitted jobs, got {len(submitted_jobs)}")
    ids = [job["job_id"] for job in submitted_jobs]

    # Exact readback from each resource is the success criterion, not the POST alone.
    readback = [safe_job(hyp3.get_job_by_id(job_id)) for job_id in ids]
    after_info = hyp3.my_info()
    after_jobs = hyp3.find_jobs()
    records_by_id = {job["job_id"]: job for job in readback}
    if set(records_by_id) != set(ids):
        raise RuntimeError("Submitted job IDs did not read back exactly")
    expected_by_name = {job["name"]: job for job in jobs}
    for job in readback:
        expected = expected_by_name.get(job.get("name"))
        if expected is None:
            raise RuntimeError(f"Unexpected readback job name: {job.get('name')}")
        for key in ("job_type", "job_parameters"):
            if job.get(key) != expected.get(key):
                raise RuntimeError(f"Readback mismatch for {job['job_id']} field {key}")
        if job.get("credit_cost") != 1:
            raise RuntimeError(f"Unexpected readback credit cost: {job}")

    credits_used = before_info.get("remaining_credits") - after_info.get("remaining_credits")
    if credits_used != expected_total:
        raise RuntimeError(
            f"Expected {expected_total} credits consumed, observed {credits_used}"
        )

    status = {
        "submitted_utc": datetime.now(timezone.utc).isoformat(),
        "api": API,
        "job_ids": ids,
        "jobs": readback,
        "credits_before": before_info.get("remaining_credits"),
        "credits_after": after_info.get("remaining_credits"),
        "credits_used": credits_used,
        "account_job_count_before": len(before_jobs),
        "account_job_count_after": len(after_jobs),
        "status_counts": dict(sorted(Counter(job["status_code"] for job in readback).items())),
        "readback_verified": True,
        "privacy": "Earthdata credentials, tokens, cookies, and user ID are neither printed nor stored.",
    }
    SUBMISSION.write_text(json.dumps(status, indent=2, sort_keys=True) + "\n")
    print(json.dumps({
        "job_ids": ids,
        "credits_before": status["credits_before"],
        "credits_after": status["credits_after"],
        "credits_used": status["credits_used"],
        "status_counts": status["status_counts"],
        "readback_verified": status["readback_verified"],
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
