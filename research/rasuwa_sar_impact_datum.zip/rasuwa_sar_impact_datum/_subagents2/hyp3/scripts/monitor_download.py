#!/usr/bin/env python3
"""Poll submitted HyP3 jobs, download products, and verify artifacts."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from zipfile import ZipFile

import hyp3_sdk

ROOT = Path(__file__).resolve().parents[1]
PRODUCTS = ROOT / "products"
API = "https://hyp3-api.asf.alaska.edu"


def safe_job(job) -> dict:
    data = job.to_dict()
    data.pop("user_id", None)
    return data


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def safe_extract(zip_path: Path, destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    root = destination.resolve()
    with ZipFile(zip_path) as archive:
        for member in archive.infolist():
            target = (destination / member.filename).resolve()
            if root != target and root not in target.parents:
                raise RuntimeError(f"Unsafe ZIP member: {member.filename}")
        archive.extractall(destination)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--timeout", type=int, default=1800)
    parser.add_argument("--interval", type=int, default=30)
    args = parser.parse_args()

    submission = json.loads((ROOT / "submitted_jobs.json").read_text())
    ids = submission["job_ids"]
    hyp3 = hyp3_sdk.HyP3(API)
    start = time.monotonic()
    last_statuses = None
    jobs = []

    while True:
        jobs = [hyp3.get_job_by_id(job_id) for job_id in ids]
        statuses = tuple(job.status_code for job in jobs)
        snapshot = {
            "queried_utc": datetime.now(timezone.utc).isoformat(),
            "job_ids": ids,
            "jobs": [safe_job(job) for job in jobs],
            "status_counts": dict(sorted(Counter(statuses).items())),
            "all_complete": all(job.complete() for job in jobs),
        }
        atomic_json(ROOT / "job_status_latest.json", snapshot)
        if statuses != last_statuses:
            print(datetime.now(timezone.utc).isoformat(), dict(Counter(statuses)), flush=True)
            last_statuses = statuses
        if snapshot["all_complete"]:
            break
        if time.monotonic() - start >= args.timeout:
            print("Polling timeout reached; latest status saved.", flush=True)
            return
        time.sleep(args.interval)

    account = hyp3.my_info()
    own_jobs = hyp3.find_jobs()
    final = {
        **snapshot,
        "remaining_credits": account.get("remaining_credits"),
        "account_job_count": len(own_jobs),
        "readback_verified": all(hyp3.get_job_by_id(job.job_id).job_id == job.job_id for job in jobs),
    }
    atomic_json(ROOT / "job_status_final.json", final)

    if not all(job.succeeded() for job in jobs):
        failures = []
        for job in jobs:
            if job.failed():
                failures.append({"job_id": job.job_id, "name": job.name, "logs": job.logs or []})
        atomic_json(ROOT / "job_failures.json", {"failures": failures})
        print(json.dumps({"result": "FAILED", "failures": failures}, indent=2), flush=True)
        return

    PRODUCTS.mkdir(parents=True, exist_ok=True)
    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "jobs": [],
    }
    for job in jobs:
        job_entry = {
            "job_id": job.job_id,
            "name": job.name,
            "status_code": job.status_code,
            "credit_cost": job.credit_cost,
            "request_time": job.request_time.isoformat(),
            "expiration_time": job.expiration_time.isoformat() if job.expiration_time else None,
            "files": [],
        }
        for product in job.files or []:
            output = PRODUCTS / product["filename"]
            expected_size = int(product["size"])
            if not output.exists() or output.stat().st_size != expected_size:
                partial = output.with_suffix(output.suffix + ".part")
                with hyp3.session.get(product["url"], stream=True, timeout=300) as response:
                    response.raise_for_status()
                    with partial.open("wb") as stream:
                        shutil.copyfileobj(response.raw, stream, length=1024 * 1024)
                if partial.stat().st_size != expected_size:
                    raise RuntimeError(
                        f"Size mismatch for {output.name}: {partial.stat().st_size} != {expected_size}"
                    )
                partial.replace(output)
            file_entry = {
                "filename": output.name,
                "path": str(output.relative_to(ROOT)),
                "bytes": output.stat().st_size,
                "expected_bytes": expected_size,
                "sha256": sha256(output),
                "source_url": product["url"],
            }
            if output.suffix.lower() == ".zip":
                extract_dir = PRODUCTS / "extracted" / output.stem
                safe_extract(output, extract_dir)
                extracted = sorted(path for path in extract_dir.rglob("*") if path.is_file())
                file_entry["extracted_files"] = [
                    {
                        "path": str(path.relative_to(ROOT)),
                        "bytes": path.stat().st_size,
                        "sha256": sha256(path),
                    }
                    for path in extracted
                ]
            job_entry["files"].append(file_entry)
        manifest["jobs"].append(job_entry)
    atomic_json(ROOT / "product_manifest.json", manifest)
    print(json.dumps({
        "result": "SUCCEEDED",
        "status_counts": final["status_counts"],
        "remaining_credits": final["remaining_credits"],
        "products": [
            {
                "job_id": job["job_id"],
                "name": job["name"],
                "files": [
                    {"filename": item["filename"], "bytes": item["bytes"], "sha256": item["sha256"]}
                    for item in job["files"]
                ],
            }
            for job in manifest["jobs"]
        ],
    }, indent=2), flush=True)


if __name__ == "__main__":
    main()
