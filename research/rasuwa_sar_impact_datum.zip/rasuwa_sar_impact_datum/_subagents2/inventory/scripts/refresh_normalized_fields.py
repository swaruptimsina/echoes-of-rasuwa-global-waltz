#!/usr/bin/env python3
"""Refresh polarization fields from retained exact CMR attributes.

Useful for an existing inventory after normalization-code changes; a full rebuild
produces the same fields directly.
"""

from __future__ import annotations

import csv
import importlib.util
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD_PATH = Path(__file__).with_name("build_inventory.py")


def load_build_module():
    spec = importlib.util.spec_from_file_location("rasuwa_build_inventory", BUILD_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {BUILD_PATH}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    build = load_build_module()
    source = ROOT / "inventory.csv"
    temporary = ROOT / "inventory.csv.refreshing"
    changed = 0
    with source.open(newline="", encoding="utf-8") as input_stream:
        reader = csv.DictReader(input_stream)
        if reader.fieldnames is None:
            raise RuntimeError("inventory.csv has no header")
        with temporary.open("w", newline="", encoding="utf-8") as output_stream:
            writer = csv.DictWriter(output_stream, fieldnames=reader.fieldnames)
            writer.writeheader()
            for row in reader:
                attrs = json.loads(row["additional_attributes_json"] or "{}")
                replacements = {
                    "polarization": build.normalize_polarization(
                        build.values(
                            attrs,
                            "POLARIZATION",
                            "Polarization",
                            "FREQUENCY_A_POLARIZATION_CONCAT",
                        )
                    ),
                    "main_band_polarization": build.normalize_polarization(
                        build.values(
                            attrs,
                            "FREQUENCY_A_POLARIZATION",
                            "FREQUENCY_A_POLARIZATION_CONCAT",
                        )
                    ),
                    "side_band_polarization": build.normalize_polarization(
                        build.values(
                            attrs,
                            "FREQUENCY_B_POLARIZATION",
                            "FREQUENCY_B_POLARIZATION_CONCAT",
                        )
                    ),
                }
                for field, value in replacements.items():
                    if row[field] != value:
                        row[field] = value
                        changed += 1
                writer.writerow(row)
    os.replace(temporary, source)
    print(json.dumps({"status": "ok", "polarization_fields_changed": changed}))


if __name__ == "__main__":
    main()
