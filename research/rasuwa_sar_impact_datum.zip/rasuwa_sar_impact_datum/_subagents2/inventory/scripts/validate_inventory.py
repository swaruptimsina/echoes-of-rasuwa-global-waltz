#!/usr/bin/env python3
"""Machine-validate the retained SAR inventory and every raw response."""

from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]

REQUIRED_SHORT_NAMES = {
    "SENTINEL-1A_SLC",
    "SENTINEL-1B_SLC",
    "SENTINEL-1C_SLC",
    "SENTINEL-1D_SLC",
    "ALOS2_L1_PSR2",
    "SAOCOM.data.products",
    "CWIC_REG_RCM",
    "OPERA_L2_RTC-S1_V1",
    "OPERA_L3_DSWX-S1_V1",
    "SENTINEL-1_BURSTS",
    "ARIA_S1_GUNW",
    "SPL1A_RO_003",
}
EXPECTED_UNSUPPORTED_ASF = {"saocom_probe", "rcm_probe"}


def read_csv(name: str) -> list[dict[str, str]]:
    with (ROOT / name).open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def parse_json(name: str) -> Any:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def fail(message: str) -> None:
    raise AssertionError(message)


def feature_key(feature: dict[str, Any]) -> tuple[str, str, str]:
    props = feature.get("properties", {}) or {}
    return (
        str(props.get("conceptID", props.get("collectionName", ""))),
        str(props.get("sceneName", "")),
        str(props.get("fileID", props.get("fileName", ""))),
    )


def main() -> int:
    queries = read_csv("queries.csv")
    collections = read_csv("collections.csv")
    discovered = read_csv("discovered_collections.csv")
    inventory = read_csv("inventory.csv")
    url_rows = read_csv("granule_urls.csv")
    asf_queries = read_csv("asf_queries.csv")
    crosswalk = read_csv("catalog_crosswalk.csv")
    archive_status = read_csv("archive_status.csv")
    summary = parse_json("summary.json")
    config = parse_json("config.json")

    if not queries:
        fail("queries.csv is empty")
    if not inventory:
        fail("inventory.csv is empty")

    # Raw body, hash, parser, and per-response count verification.
    parsed_by_query: dict[str, Any] = {}
    raw_bytes = 0
    for row in queries:
        path = ROOT / row["raw_path"]
        if not path.is_file():
            fail(f"missing raw response: {path}")
        body = path.read_bytes()
        raw_bytes += len(body)
        digest = hashlib.sha256(body).hexdigest()
        if digest != row["raw_sha256"]:
            fail(f"SHA-256 mismatch for {row['query_id']}: {digest} != {row['raw_sha256']}")
        if len(body) != int(row["raw_bytes"]):
            fail(f"byte-size mismatch for {row['query_id']}")
        parsed: Any
        if row["api"] == "asf_search_count":
            if row["http_status"] == "200":
                parsed = int(body.decode("utf-8").strip())
                if parsed != int(row["returned_count"]):
                    fail(f"ASF count manifest mismatch for {row['query_id']}")
            else:
                # Error bodies may be JSON validation records or plain gateway
                # text (the live SAOCOM/RCM probes returned HTTP 500 text).
                try:
                    parsed = json.loads(body) if body else {}
                except json.JSONDecodeError:
                    parsed = body.decode("utf-8", errors="replace")
        else:
            try:
                parsed = json.loads(body) if body else {}
            except json.JSONDecodeError as exc:
                fail(f"unparseable JSON raw response {row['query_id']}: {exc}")
            if row["api"].startswith("cmr"):
                actual = len(parsed.get("items", []))
                if actual != int(row["returned_count"] or 0):
                    fail(f"CMR page count mismatch for {row['query_id']} page {row['page_index']}")
            elif row["api"] == "asf_search_geojson":
                actual = len(parsed.get("features", []))
                if actual != int(row["returned_count"] or 0):
                    fail(f"ASF GeoJSON page count mismatch for {row['query_id']}")
        parsed_by_query[row["query_id"]] = parsed

    if raw_bytes != int(summary["raw_response_bytes"]):
        fail(f"raw byte total mismatch: {raw_bytes} != {summary['raw_response_bytes']}")

    # CMR Search-After chains: pages contiguous, tokens chained, no partials,
    # cumulative item count exactly equals CMR-Hits.
    cmr_groups: defaultdict[str, list[dict[str, str]]] = defaultdict(list)
    for row in queries:
        if row["api"].startswith("cmr"):
            cmr_groups[row["query_id"]].append(row)
    for query_id, rows in cmr_groups.items():
        rows.sort(key=lambda value: int(value["page_index"]))
        if [int(row["page_index"]) for row in rows] != list(range(1, len(rows) + 1)):
            fail(f"non-contiguous CMR pages for {query_id}")
        hits = {int(row["hits_reported"] or 0) for row in rows}
        if len(hits) != 1:
            fail(f"CMR-Hits changed across pages for {query_id}: {hits}")
        expected = next(iter(hits))
        returned = sum(int(row["returned_count"] or 0) for row in rows)
        if returned != expected:
            fail(f"CMR pagination incomplete for {query_id}: {returned} != {expected}")
        if any(str(row["cmr_timed_out"]).lower() == "true" for row in rows):
            fail(f"CMR timed out for {query_id}")
        for previous, current in zip(rows, rows[1:]):
            if not previous["cmr_search_after_out"]:
                fail(f"missing CMR-Search-After output before page {current['page_index']} of {query_id}")
            if current["cmr_search_after_in"] != previous["cmr_search_after_out"]:
                fail(f"CMR-Search-After chain mismatch for {query_id}")
        concepts: list[str] = []
        for row in rows:
            parsed = json.loads((ROOT / row["raw_path"]).read_text(encoding="utf-8"))
            concepts.extend(
                str(item.get("meta", {}).get("concept-id", ""))
                for item in parsed.get("items", [])
            )
        nonempty = [value for value in concepts if value]
        if len(nonempty) != len(set(nonempty)):
            fail(f"duplicate CMR concept IDs across pages for {query_id}")

    # ASF count endpoint versus retrieved GeoJSON feature sets. Partition unions
    # are deduplicated by exact ASF identifiers and checked against full counts.
    asf_manifest_by_spec: defaultdict[str, list[dict[str, str]]] = defaultdict(list)
    for row in queries:
        if row["spec_id"]:
            asf_manifest_by_spec[row["spec_id"]].append(row)
    asf_result_by_spec = {row["spec_id"]: row for row in asf_queries}
    for spec_id, result in asf_result_by_spec.items():
        rows = asf_manifest_by_spec.get(spec_id, [])
        full_counts = [
            row for row in rows if row["api"] == "asf_search_count" and row["count_scope"] == "full"
        ]
        if len(full_counts) != 1:
            fail(f"expected one full ASF count response for {spec_id}, got {len(full_counts)}")
        full_row = full_counts[0]
        if result["support_status"] == "unsupported_or_rejected":
            if full_row["http_status"] == "200":
                fail(f"{spec_id} marked unsupported despite HTTP 200")
            continue
        if full_row["http_status"] != "200":
            fail(f"supported ASF spec {spec_id} had HTTP {full_row['http_status']}")
        expected = int(result["count"] or 0)
        if int(full_row["returned_count"] or 0) != expected:
            fail(f"full ASF count mismatch for {spec_id}")
        geo_rows = [row for row in rows if row["api"] == "asf_search_geojson"]
        if not geo_rows:
            # Count-only NISAR L/S capability queries intentionally retain no
            # duplicate GeoJSON response.
            if spec_id not in {"nisar_joint_observation_true", "nisar_joint_observation_false"}:
                fail(f"supported ASF spec {spec_id} lacks GeoJSON response")
            continue
        features: dict[tuple[str, str, str], dict[str, Any]] = {}
        fallback_rows = [row for row in geo_rows if row["count_scope"] == "fallback_full"]
        rows_for_union = fallback_rows or geo_rows
        for row in rows_for_union:
            parsed = json.loads((ROOT / row["raw_path"]).read_text(encoding="utf-8"))
            for feature in parsed.get("features", []):
                key = feature_key(feature)
                if not any(key):
                    fail(f"ASF feature without stable identifier in {row['query_id']}")
                features[key] = feature
        if len(features) != expected:
            fail(f"ASF unique feature union mismatch for {spec_id}: {len(features)} != {expected}")

    unsupported_specs = {
        row["spec_id"] for row in asf_queries if row["support_status"] == "unsupported_or_rejected"
    }
    if not EXPECTED_UNSUPPORTED_ASF.issubset(unsupported_specs):
        fail(f"SAOCOM/RCM capability probes were not both rejected: {unsupported_specs}")

    # Canonical inventory identity and exact CMR membership.
    inventory_ids = [row["inventory_id"] for row in inventory]
    if len(inventory_ids) != len(set(inventory_ids)):
        fail("duplicate inventory_id values")
    cmr_rows = [row for row in inventory if row["granule_concept_id"]]
    cmr_ids = [row["granule_concept_id"] for row in cmr_rows]
    if len(cmr_ids) != len(set(cmr_ids)):
        fail("duplicate CMR granule concept IDs in inventory")
    if any(not re.match(r"^G\d+-[A-Za-z0-9_]+$", value) for value in cmr_ids):
        bad = [value for value in cmr_ids if not re.match(r"^G\d+-[A-Za-z0-9_]+$", value)]
        fail(f"malformed CMR granule concept IDs: {bad[:5]}")

    raw_selected_ids: set[str] = set()
    raw_selected_producers: dict[str, str] = {}
    selected_query_rows = [
        row for row in queries if row["query_kind"] == "selected_collection_granules"
    ]
    for row in selected_query_rows:
        parsed = json.loads((ROOT / row["raw_path"]).read_text(encoding="utf-8"))
        for item in parsed.get("items", []):
            cid = str(item.get("meta", {}).get("concept-id", ""))
            raw_selected_ids.add(cid)
            umm = item.get("umm", {})
            producer = str(umm.get("GranuleUR", ""))
            for identifier in umm.get("DataGranule", {}).get("Identifiers", []) or []:
                if identifier.get("IdentifierType") == "ProducerGranuleId":
                    producer = str(identifier.get("Identifier", producer))
                    break
            raw_selected_producers[cid] = producer
    if raw_selected_ids != set(cmr_ids):
        fail(
            f"CMR raw/inventory ID set mismatch: missing={len(raw_selected_ids-set(cmr_ids))} extra={len(set(cmr_ids)-raw_selected_ids)}"
        )
    inventory_by_cmr = {row["granule_concept_id"]: row for row in cmr_rows}
    producer_mismatches = [
        cid
        for cid, producer in raw_selected_producers.items()
        if inventory_by_cmr[cid]["producer_granule_id"] != producer
    ]
    if producer_mismatches:
        fail(f"producer granule IDs not preserved exactly: {producer_mismatches[:5]}")

    if len(inventory) != int(summary["inventory_rows"]):
        fail("inventory row total disagrees with summary")
    if len(cmr_rows) != int(summary["cmr_granule_rows"]):
        fail("CMR inventory total disagrees with summary")
    if len(set(cmr_ids)) != int(summary["unique_cmr_granule_concept_ids"]):
        fail("unique CMR ID total disagrees with summary")

    # Required metadata fields and temporal intersection.
    window_start = parse_time(config["window_utc"]["start"])
    window_end = parse_time(config["window_utc"]["end"])
    missing_required_fields: defaultdict[str, list[str]] = defaultdict(list)
    for row in inventory:
        for field in (
            "producer_granule_id",
            "collection_concept_id",
            "collection_short_name",
            "mission",
            "platform",
            "band",
            "product_type",
            "metadata_access",
            "data_access",
            "access_notes",
        ):
            if not row[field]:
                missing_required_fields[field].append(row["inventory_id"])
        if row["login_required"] not in {"Earthdata Login", "unknown", "n/a"}:
            fail(f"unexpected login classification for {row['inventory_id']}: {row['login_required']}")
        beginning = row["acquisition_begin_utc"]
        ending = row["acquisition_end_utc"] or beginning
        if not beginning:
            missing_required_fields["acquisition_begin_utc"].append(row["inventory_id"])
        else:
            if parse_time(beginning) > window_end or parse_time(ending) < window_start:
                fail(f"inventory temporal extent outside requested window: {row['inventory_id']}")
        if row["granule_concept_id"] and row["granule_concept_id"] not in row["cmr_record_url"]:
            fail(f"CMR record URL does not preserve concept ID: {row['inventory_id']}")
    if missing_required_fields:
        rendered = {key: values[:5] for key, values in missing_required_fields.items()}
        fail(f"inventory required-field gaps: {rendered}")

    # URL-table referential integrity and declared counts.
    url_counts = Counter(row["inventory_id"] for row in url_rows)
    data_url_counts = Counter(row["inventory_id"] for row in url_rows if row["url_class"] == "data")
    inventory_id_set = set(inventory_ids)
    orphan_urls = [row for row in url_rows if row["inventory_id"] not in inventory_id_set]
    if orphan_urls:
        fail(f"orphan URL rows: {orphan_urls[:3]}")
    for row in inventory:
        if int(row["url_count"] or 0) != url_counts[row["inventory_id"]]:
            fail(f"URL count mismatch for {row['inventory_id']}")
        if int(row["data_url_count"] or 0) != data_url_counts[row["inventory_id"]]:
            fail(f"data URL count mismatch for {row['inventory_id']}")
        if row["data_access"] == "earthdata_login_required" and data_url_counts[row["inventory_id"]] == 0:
            fail(f"Earthdata-login row has no retained data URL: {row['inventory_id']}")

    # Collection coverage, per-collection raw counts, NISAR levels/maturities,
    # Sentinel platform variants, and honest zero/unsupported reporting.
    collection_names = {row["short_name"] for row in collections}
    if not REQUIRED_SHORT_NAMES.issubset(collection_names):
        fail(f"required selected collections missing: {sorted(REQUIRED_SHORT_NAMES-collection_names)}")
    if any(row["selected"] != "yes" for row in collections):
        fail("collections.csv contains an unselected row")
    counts_by_collection = Counter(row["collection_short_name"] for row in cmr_rows)
    for row in collections:
        expected = int(row["aoi_window_granule_count"] or 0)
        if counts_by_collection[row["short_name"]] != expected:
            fail(
                f"collection count mismatch for {row['short_name']}: {counts_by_collection[row['short_name']]} != {expected}"
            )

    nisar_collections = [row for row in collections if row["mission"] == "NISAR"]
    nisar_maturities = {row["maturity"] for row in nisar_collections}
    if not {"Beta", "Provisional", "Validated", "Urgent Response"}.issubset(nisar_maturities):
        fail(f"NISAR maturity coverage incomplete: {nisar_maturities}")
    nisar_levels = {row["processing_level"] for row in nisar_collections}
    if not {"0", "1", "2", "3"}.issubset(nisar_levels):
        fail(f"NISAR processing-level collection coverage incomplete: {nisar_levels}")
    sentinel_scl = {
        row["short_name"]
        for row in collections
        if re.match(r"^SENTINEL-1[ABCD]_SLC$", row["short_name"])
    }
    if sentinel_scl != {
        "SENTINEL-1A_SLC",
        "SENTINEL-1B_SLC",
        "SENTINEL-1C_SLC",
        "SENTINEL-1D_SLC",
    }:
        fail(f"Sentinel-1 SLC spacecraft coverage incomplete: {sentinel_scl}")
    grd_spacecraft = {
        match.group(1)
        for row in collections
        if (match := re.match(r"^SENTINEL-1([ABCD])_(?:DP|SP)_GRD_", row["short_name"]))
    }
    if grd_spacecraft != {"A", "B", "C", "D"}:
        fail(f"Sentinel-1 GRD spacecraft collection coverage incomplete: {grd_spacecraft}")

    status_by_product = defaultdict(list)
    for row in archive_status:
        status_by_product[row["mission_product"]].append(row)
    for product in ("SAOCOM.data.products", "CWIC_REG_RCM"):
        rows = status_by_product[product]
        if not rows or rows[0]["support_status"] != "collection_stub_zero_global_granules":
            fail(f"{product} CMR zero-global status not recorded honestly")
    s_band_rows = status_by_product["NISAR S-band product files"]
    if not s_band_rows or s_band_rows[0]["support_status"] != "not_distributed_by_asf_cmr":
        fail("NISAR S-band archive limitation missing")

    # Crosswalk exact identifiers are unique; ambiguity is a warning rather than
    # fabricated reconciliation.
    crosswalk_keys = [
        (row["asf_collection_concept_id"], row["asf_scene_name"], row["asf_file_id"])
        for row in crosswalk
    ]
    if len(crosswalk_keys) != len(set(crosswalk_keys)):
        fail("duplicate ASF feature identities in catalog_crosswalk.csv")
    crosswalk_status = Counter(row["match_status"] for row in crosswalk)

    http_statuses = Counter(row["http_status"] for row in queries)
    warnings: list[str] = []
    if crosswalk_status.get("asf_only"):
        warnings.append(
            f"{crosswalk_status['asf_only']} ASF features lacked an exact selected-CMR match and remain explicit ASF-only rows."
        )
    if crosswalk_status.get("ambiguous_no_merge"):
        warnings.append(
            f"{crosswalk_status['ambiguous_no_merge']} ASF features had ambiguous CMR matches and were not silently merged."
        )

    result = {
        "status": "ok",
        "validated_at_utc": datetime.now(timezone.utc).isoformat(),
        "window_utc": config["window_utc"],
        "bbox_wgs84": config["aoi"]["bbox_wgs84"],
        "wkt_wgs84": config["aoi"]["wkt_wgs84"],
        "query_response_count": len(queries),
        "query_http_status_counts": dict(sorted(http_statuses.items())),
        "raw_response_count_parsed": len(queries),
        "raw_response_bytes_hashed": raw_bytes,
        "cmr_paginated_query_count": len(cmr_groups),
        "cmr_multi_page_query_count": sum(1 for rows in cmr_groups.values() if len(rows) > 1),
        "selected_collection_count": len(collections),
        "discovered_collection_count": len(discovered),
        "inventory_rows": len(inventory),
        "cmr_inventory_rows": len(cmr_rows),
        "unique_cmr_granule_concept_ids": len(set(cmr_ids)),
        "asf_crosswalk_rows": len(crosswalk),
        "crosswalk_status_counts": dict(sorted(crosswalk_status.items())),
        "granule_url_rows": len(url_rows),
        "expected_unsupported_asf_specs": sorted(EXPECTED_UNSUPPORTED_ASF),
        "actual_unsupported_asf_specs": sorted(unsupported_specs),
        "required_collection_checks": len(REQUIRED_SHORT_NAMES),
        "all_raw_hashes_match": True,
        "all_reported_counts_match_raw": True,
        "cmr_search_after_chains_valid": True,
        "asf_count_feature_sets_valid": True,
        "inventory_deduplicated": True,
        "exact_granule_ids_preserved": True,
        "url_referential_integrity": True,
        "warnings": warnings,
    }
    (ROOT / "validation.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
