#!/usr/bin/env python3
"""Create compact report statistics from the validated inventory CSV."""

from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read_csv(name: str) -> list[dict[str, str]]:
    with (ROOT / name).open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def values(rows: list[dict[str, str]], field: str) -> list[str]:
    return sorted({row[field] for row in rows if row.get(field)})


def main() -> None:
    inventory = read_csv("inventory.csv")
    collections = read_csv("collections.csv")
    asf_queries = read_csv("asf_queries.csv")
    groups: defaultdict[str, list[dict[str, str]]] = defaultdict(list)
    for row in inventory:
        groups[row["collection_short_name"]].append(row)

    completeness: list[dict] = []
    for short_name in sorted(groups):
        rows = groups[short_name]
        count = len(rows)
        completeness.append(
            {
                "collection_short_name": short_name,
                "rows": count,
                "platform_present": sum(bool(row["platform"]) for row in rows),
                "band_present": sum(bool(row["band"]) for row in rows),
                "polarization_present": sum(bool(row["polarization"] or row["main_band_polarization"]) for row in rows),
                "orbit_present": sum(bool(row["orbit_number"]) for row in rows),
                "track_path_present": sum(bool(row["track_path"]) for row in rows),
                "direction_present": sum(bool(row["direction"]) for row in rows),
                "acquisition_time_present": sum(bool(row["acquisition_begin_utc"]) for row in rows),
                "data_url_present": sum(bool(row["primary_data_url"]) for row in rows),
                "asf_cross_catalog_match": sum("ASF" in row["source_catalogs"].split("|") for row in rows),
                "platform_values": "|".join(values(rows, "platform")),
                "band_values": "|".join(values(rows, "band")),
                "polarization_values": "|".join(values(rows, "polarization")),
                "track_direction_values_json": json.dumps(
                    sorted(
                        {
                            (row["track_path"], row["direction"])
                            for row in rows
                            if row["track_path"] or row["direction"]
                        }
                    ),
                    separators=(",", ":"),
                ),
            }
        )
    write_csv(
        ROOT / "field_completeness.csv",
        completeness,
        [
            "collection_short_name",
            "rows",
            "platform_present",
            "band_present",
            "polarization_present",
            "orbit_present",
            "track_path_present",
            "direction_present",
            "acquisition_time_present",
            "data_url_present",
            "asf_cross_catalog_match",
            "platform_values",
            "band_values",
            "polarization_values",
            "track_direction_values_json",
        ],
    )

    collection_count = {row["short_name"]: int(row["aoi_window_granule_count"] or 0) for row in collections}
    nisar = [row for row in inventory if row["mission"] == "NISAR"]
    sentinel = [row for row in inventory if row["mission"] == "Sentinel-1"]
    opera = [row for row in inventory if row["mission"] == "OPERA"]
    stats = {
        "inventory_rows": len(inventory),
        "counts_by_mission": dict(sorted(Counter(row["mission"] for row in inventory).items())),
        "requested_and_discovered_products": {
            "nisar_all_levels_maturities": len(nisar),
            "sentinel1_slc": sum(row["product_type"] == "SLC" for row in sentinel),
            "sentinel1_grd": sum(row["product_type"].startswith("GRD_") for row in sentinel),
            "sentinel1_raw_additional": sum(row["product_type"] == "RAW" for row in sentinel),
            "sentinel1_slc_bursts_additional": collection_count.get("SENTINEL-1_BURSTS", 0),
            "alos2_scansar": collection_count.get("ALOS2_L1_PSR2", 0),
            "opera_rtc": collection_count.get("OPERA_L2_RTC-S1_V1", 0),
            "opera_dswx": collection_count.get("OPERA_L3_DSWX-S1_V1", 0),
            "opera_dist_alert_additional": collection_count.get("OPERA_L3_DIST-ALERT-S1_V1", 0),
            "aria_s1_gunw_additional": collection_count.get("ARIA_S1_GUNW", 0),
            "smap_receive_only_additional": collection_count.get("SPL1A_RO_003", 0),
            "saocom_cmr": collection_count.get("SAOCOM.data.products", 0),
            "rcm_cmr": collection_count.get("CWIC_REG_RCM", 0),
        },
        "nisar": {
            "granules": len(nisar),
            "by_product_type": dict(sorted(Counter(row["product_type"] for row in nisar).items())),
            "by_maturity": dict(sorted(Counter(row["maturity"] for row in nisar).items())),
            "by_level": dict(sorted(Counter(row["processing_level"] for row in nisar).items())),
            "actual_instruments": dict(sorted(Counter(row["instrument"] for row in nisar).items())),
            "joint_observation": dict(sorted(Counter(row["joint_observation"] for row in nisar).items())),
        },
        "sentinel1": {
            "granules": len(sentinel),
            "by_platform": dict(sorted(Counter(row["platform"] for row in sentinel).items())),
            "by_product_type": dict(sorted(Counter(row["product_type"] for row in sentinel).items())),
        },
        "opera": {
            "granules": len(opera),
            "by_product_type": dict(sorted(Counter(row["product_type"] for row in opera).items())),
        },
        "zero_selected_collections": sorted(
            row["short_name"] for row in collections if int(row["aoi_window_granule_count"] or 0) == 0
        ),
        "asf_zero_result_specs": sorted(
            row["spec_id"] for row in asf_queries if row["support_status"] == "supported_zero_results"
        ),
        "asf_unsupported_specs": sorted(
            row["spec_id"] for row in asf_queries if row["support_status"] == "unsupported_or_rejected"
        ),
        "field_completeness_rows": len(completeness),
    }
    (ROOT / "report_stats.json").write_text(
        json.dumps(stats, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(stats, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
