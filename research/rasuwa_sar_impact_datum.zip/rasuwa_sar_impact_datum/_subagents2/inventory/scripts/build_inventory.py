#!/usr/bin/env python3
"""Build a paginated CMR + ASF SAR metadata inventory for broad Rasuwa.

This script performs metadata-only, unauthenticated catalog searches. It never
reads or sends Earthdata credentials. Every HTTP response body is retained,
hashed, normalized, and checked against catalog-reported counts.
"""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
import math
import re
import shutil
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Iterable

ROOT = Path(__file__).resolve().parents[1]
RAW_CMR = ROOT / "raw" / "cmr"
RAW_ASF = ROOT / "raw" / "asf"

USER_AGENT = "Hermes-Rasuwa-all-SAR-inventory/2.0 (metadata-only; no credentials)"
CMR_COLLECTIONS = "https://cmr.earthdata.nasa.gov/search/collections.umm_json"
CMR_GRANULES = "https://cmr.earthdata.nasa.gov/search/granules.umm_json"
ASF_SEARCH = "https://api.daac.asf.alaska.edu/services/search/param"

WINDOW_START = "2024-11-15T00:00:00Z"
WINDOW_END = "2026-11-15T23:59:59Z"

# Deliberately broad connected-system AOI. It encloses the Purepu/upper-Lhende
# source area, Langtang Lirung and Rasuwa, and the downstream Trishuli corridor
# through the Narayani transition. Catalog intersection can therefore admit
# products whose footprints extend well outside the river corridor.
BBOX = (84.30, 27.50, 85.75, 28.50)  # west, south, east, north (WGS84)
BBOX_STR = ",".join(f"{value:.2f}" for value in BBOX)
WKT = (
    "POLYGON((84.30 27.50,85.75 27.50,85.75 28.50,"
    "84.30 28.50,84.30 27.50))"
)
CMR_PAGE_SIZE = 200
CMR_DISCOVERY_PAGE_SIZE = 50
ASF_PARTITION_THRESHOLD = 750

ANCHOR_POINTS = {
    "purepu_2025_source": [85.6469, 28.4043],
    "langtang_lirung_2026_source": [85.528066, 28.291242],
    "usgs_2026_mass_movement": [85.515, 28.271],
    "rasuwagadhi": [85.3777, 28.2774],
    "timure": [85.3702, 28.2555],
}

# Extra open SAR/SAR-derived products selected after broad CMR discovery.
EXTRA_SELECTED_SHORT_NAMES = {
    "ALOS2_L1_PSR2",
    "SAOCOM.data.products",
    "CWIC_REG_RCM",
    "OPERA_L2_RTC-S1_V1",
    "OPERA_L3_DSWX-S1_V1",
    "SENTINEL-1_BURSTS",
    "ARIA_S1_GUNW",
    "OPERA_L2_CSLC-S1_V1",
    "OPERA_L3_DISP-S1_V1",
    "OPERA_L3_DIST-ALERT-S1_V1",
    "SPL1A_RO_003",
}

MANDATORY_SHORT_NAMES = {
    "SENTINEL-1A_SLC",
    "SENTINEL-1B_SLC",
    "SENTINEL-1C_SLC",
    "SENTINEL-1D_SLC",
    "ALOS2_L1_PSR2",
    "SAOCOM.data.products",
    "CWIC_REG_RCM",
    "OPERA_L2_RTC-S1_V1",
    "OPERA_L3_DSWX-S1_V1",
}

# SearchAPI probes include requested products, cross-catalog products, and every
# documented open ASF SAR dataset that could plausibly return a window hit.
ASF_SPECS: list[dict[str, Any]] = [
    *[
        {
            "spec_id": f"nisar_{level.lower()}",
            "label": f"NISAR {level}",
            "params": [("dataset", "NISAR"), ("processingLevel", level)],
            "include_in_inventory": True,
        }
        for level in (
            "L0B",
            "RSLC",
            "RIFG",
            "RUNW",
            "ROFF",
            "GSLC",
            "GCOV",
            "GUNW",
            "GOFF",
            "SME2",
        )
    ],
    {
        "spec_id": "nisar_joint_observation_true",
        "label": "NISAR products flagged as simultaneous L/S observations",
        "params": [("dataset", "NISAR"), ("jointObservation", "True")],
        "include_in_inventory": False,
        "count_only": True,
    },
    {
        "spec_id": "nisar_joint_observation_false",
        "label": "NISAR products not flagged as simultaneous L/S observations",
        "params": [("dataset", "NISAR"), ("jointObservation", "False")],
        "include_in_inventory": False,
        "count_only": True,
    },
    {
        "spec_id": "sentinel1_slc",
        "label": "Sentinel-1 SLC",
        "params": [("dataset", "SENTINEL-1"), ("processingLevel", "SLC")],
        "include_in_inventory": True,
    },
    {
        "spec_id": "sentinel1_grd",
        "label": "Sentinel-1 GRD (all documented resolutions/polarizations)",
        "params": [
            ("dataset", "SENTINEL-1"),
            ("processingLevel", "GRD_HS,GRD_HD,GRD_MS,GRD_MD,GRD_FD"),
        ],
        "include_in_inventory": True,
    },
    {
        "spec_id": "sentinel1_raw",
        "label": "Sentinel-1 RAW (additional open SAR discovered)",
        "params": [("dataset", "SENTINEL-1"), ("processingLevel", "RAW")],
        "include_in_inventory": True,
    },
    {
        "spec_id": "sentinel1_bursts",
        "label": "Sentinel-1 SLC bursts (additional open SAR discovered)",
        "params": [("dataset", "SLC-BURST"), ("processingLevel", "BURST")],
        "include_in_inventory": True,
    },
    {
        "spec_id": "opera_rtc",
        "label": "OPERA RTC-S1",
        "params": [("dataset", "OPERA-S1"), ("processingLevel", "RTC")],
        "include_in_inventory": True,
    },
    {
        "spec_id": "opera_cslc",
        "label": "OPERA CSLC-S1 (additional open SAR discovered)",
        "params": [("dataset", "OPERA-S1"), ("processingLevel", "CSLC")],
        "include_in_inventory": True,
    },
    {
        "spec_id": "aria_s1_gunw",
        "label": "ARIA Sentinel-1 GUNW (additional open SAR discovered)",
        "params": [("dataset", "ARIA S1 GUNW")],
        "include_in_inventory": True,
    },
    {
        "spec_id": "smap_receive_only",
        "label": "SMAP L1A radar receive-only (additional open L-band radar)",
        "params": [("dataset", "SMAP"), ("processingLevel", "L1A_Radar_RO_HDF5")],
        "include_in_inventory": True,
    },
    {
        "spec_id": "alos2_probe",
        "label": "ALOS-2 SearchAPI alias probe",
        "params": [("dataset", "ALOS-2")],
        "include_in_inventory": True,
    },
    {
        "spec_id": "alos_palsar",
        "label": "ALOS PALSAR documented ASF dataset",
        "params": [("dataset", "ALOS PALSAR")],
        "include_in_inventory": True,
    },
    {
        "spec_id": "saocom_probe",
        "label": "SAOCOM unsupported-dataset probe",
        "params": [("dataset", "SAOCOM")],
        "include_in_inventory": False,
    },
    {
        "spec_id": "rcm_probe",
        "label": "RCM unsupported-dataset probe",
        "params": [("dataset", "RCM")],
        "include_in_inventory": False,
    },
    {
        "spec_id": "opera_dswx_probe",
        "label": "OPERA DSWx-S1 SearchAPI capability probe",
        "params": [("dataset", "OPERA-S1"), ("processingLevel", "DSWX")],
        "include_in_inventory": False,
    },
    {
        "spec_id": "opera_disp_probe",
        "label": "OPERA DISP-S1 SearchAPI capability probe",
        "params": [("dataset", "OPERA-S1"), ("processingLevel", "DISP")],
        "include_in_inventory": False,
    },
    *[
        {
            "spec_id": f"other_{dataset.lower().replace(' ', '_').replace('-', '_')}",
            "label": f"Documented ASF open SAR dataset: {dataset}",
            "params": [("dataset", dataset)],
            "include_in_inventory": True,
        }
        for dataset in (
            "UAVSAR",
            "RADARSAT-1",
            "ERS",
            "JERS-1",
            "AIRSAR",
            "SEASAT",
            "SIR-C",
        )
    ],
]

QUERY_FIELDS = [
    "query_id",
    "api",
    "query_kind",
    "spec_id",
    "collection_concept_id",
    "collection_short_name",
    "page_index",
    "partition_start",
    "partition_end",
    "count_scope",
    "request_method",
    "url",
    "cmr_search_after_in",
    "http_status",
    "hits_reported",
    "returned_count",
    "cmr_search_after_out",
    "cmr_timed_out",
    "retrieved_at_utc",
    "raw_path",
    "raw_sha256",
    "raw_bytes",
    "error",
]

INVENTORY_FIELDS = [
    "inventory_id",
    "source_catalogs",
    "mission",
    "platform",
    "band",
    "instrument",
    "collection_concept_id",
    "collection_short_name",
    "collection_version",
    "collection_title",
    "provider_id",
    "granule_concept_id",
    "granule_revision_id",
    "producer_granule_id",
    "granule_ur",
    "asf_scene_name",
    "asf_file_id",
    "product_type",
    "processing_level",
    "maturity",
    "production_configuration",
    "product_version",
    "pge_version",
    "acquisition_begin_utc",
    "acquisition_end_utc",
    "reference_begin_utc",
    "reference_end_utc",
    "secondary_begin_utc",
    "secondary_end_utc",
    "production_datetime_utc",
    "cmr_insert_datetime_utc",
    "cmr_update_datetime_utc",
    "orbit_number",
    "track_path",
    "frame",
    "cycle",
    "direction",
    "look_direction",
    "beam_mode",
    "swath",
    "polarization",
    "main_band_polarization",
    "side_band_polarization",
    "range_bandwidth_mhz",
    "joint_observation",
    "frame_coverage",
    "group_stack_burst_id",
    "mgrs_tile_id",
    "urgent_request_id",
    "center_lat",
    "center_lon",
    "metadata_access",
    "data_access",
    "login_required",
    "access_notes",
    "primary_data_url",
    "cmr_record_url",
    "asf_data_url",
    "data_urls_json",
    "browse_urls_json",
    "url_count",
    "data_url_count",
    "cmr_query_id",
    "asf_query_ids",
    "additional_attributes_json",
    "spatial_extent_json",
    "notes",
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_slug(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9._-]+", "_", value.strip())
    return value.strip("_") or "query"


def encode_url(base: str, params: Iterable[tuple[str, str]]) -> str:
    return base + "?" + urllib.parse.urlencode(list(params), doseq=True)


def compact_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: "" if row.get(key) is None else row.get(key) for key in fieldnames})


def http_get(
    url: str,
    *,
    accept: str = "application/json",
    extra_headers: dict[str, str] | None = None,
    timeout: int = 240,
    max_attempts: int = 5,
) -> tuple[int | None, dict[str, str], bytes, str]:
    headers = {"User-Agent": USER_AGENT, "Accept": accept}
    if extra_headers:
        # Only non-secret pagination headers are ever accepted by this script.
        headers.update(extra_headers)
    last_error = ""
    for attempt in range(1, max_attempts + 1):
        request = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return (
                    response.status,
                    {key.lower(): value for key, value in response.headers.items()},
                    response.read(),
                    "",
                )
        except urllib.error.HTTPError as exc:
            body = exc.read()
            response_headers = {key.lower(): value for key, value in exc.headers.items()}
            last_error = f"HTTP {exc.code}: {exc.reason}"
            if exc.code == 429 or 500 <= exc.code < 600:
                if attempt < max_attempts:
                    wait = float(response_headers.get("retry-after", 2 ** (attempt - 1)))
                    time.sleep(min(max(wait, 0.25), 30.0))
                    continue
            return exc.code, response_headers, body, last_error
        except Exception as exc:  # transport failure: retry, never synthesize a body
            last_error = f"{type(exc).__name__}: {exc}"
            if attempt < max_attempts:
                time.sleep(min(2 ** (attempt - 1), 20))
                continue
    return None, {}, b"", last_error


def save_raw(query_id: str, api: str, filename: str, body: bytes) -> tuple[str, str, int]:
    base = RAW_CMR if api.startswith("cmr") else RAW_ASF
    path = base / safe_slug(query_id) / filename
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(body)
    return str(path.relative_to(ROOT)), hashlib.sha256(body).hexdigest(), len(body)


def query_row(
    *,
    query_id: str,
    api: str,
    query_kind: str,
    url: str,
    status: int | None,
    response_headers: dict[str, str],
    body: bytes,
    raw_info: tuple[str, str, int],
    page_index: int = 1,
    spec_id: str = "",
    collection_concept_id: str = "",
    collection_short_name: str = "",
    partition_start: str = "",
    partition_end: str = "",
    count_scope: str = "",
    search_after_in: str = "",
    returned_count: int | str = "",
    error: str = "",
) -> dict[str, Any]:
    raw_path, digest, size = raw_info
    return {
        "query_id": query_id,
        "api": api,
        "query_kind": query_kind,
        "spec_id": spec_id,
        "collection_concept_id": collection_concept_id,
        "collection_short_name": collection_short_name,
        "page_index": page_index,
        "partition_start": partition_start,
        "partition_end": partition_end,
        "count_scope": count_scope,
        "request_method": "GET",
        "url": url,
        "cmr_search_after_in": search_after_in,
        "http_status": "" if status is None else status,
        "hits_reported": response_headers.get("cmr-hits", ""),
        "returned_count": returned_count,
        "cmr_search_after_out": response_headers.get("cmr-search-after", ""),
        "cmr_timed_out": response_headers.get("cmr-timed-out", response_headers.get("cmr-time-out", "")),
        "retrieved_at_utc": utc_now(),
        "raw_path": raw_path,
        "raw_sha256": digest,
        "raw_bytes": size,
        "error": error,
    }


def cmr_search_after(
    *,
    query_id: str,
    endpoint: str,
    params: list[tuple[str, str]],
    query_kind: str,
    manifest: list[dict[str, Any]],
    page_size: int,
    collection_concept_id: str = "",
    collection_short_name: str = "",
) -> tuple[list[dict[str, Any]], int]:
    params = [(key, value) for key, value in params if key not in {"page_num", "offset", "scroll"}]
    if not any(key == "page_size" for key, _ in params):
        params.append(("page_size", str(page_size)))
    url = encode_url(endpoint, params)
    items: list[dict[str, Any]] = []
    expected_hits: int | None = None
    search_after = ""
    seen_tokens: set[str] = set()
    page_index = 0
    while True:
        page_index += 1
        extra_headers = {"CMR-Search-After": search_after} if search_after else {}
        status, headers, body, error = http_get(
            url,
            accept="application/vnd.nasa.cmr.umm_results+json, application/json",
            extra_headers=extra_headers,
        )
        raw = save_raw(query_id, "cmr", f"page_{page_index:04d}.json", body)
        parsed: Any = None
        parse_error = ""
        try:
            parsed = json.loads(body) if body else {}
        except json.JSONDecodeError as exc:
            parse_error = f"JSONDecodeError: {exc}"
        page_items = parsed.get("items", []) if isinstance(parsed, dict) else []
        combined_error = "; ".join(part for part in (error, parse_error) if part)
        manifest.append(
            query_row(
                query_id=query_id,
                api="cmr_collections" if endpoint == CMR_COLLECTIONS else "cmr_granules",
                query_kind=query_kind,
                url=url,
                status=status,
                response_headers=headers,
                body=body,
                raw_info=raw,
                page_index=page_index,
                collection_concept_id=collection_concept_id,
                collection_short_name=collection_short_name,
                search_after_in=search_after,
                returned_count=len(page_items),
                error=combined_error,
            )
        )
        if status != 200 or combined_error:
            raise RuntimeError(f"CMR query {query_id} failed on page {page_index}: {combined_error or status}")
        timed_out = headers.get("cmr-timed-out", headers.get("cmr-time-out", "")).lower()
        if timed_out == "true":
            raise RuntimeError(f"CMR query {query_id} timed out and returned a partial page")
        page_hits = int(headers.get("cmr-hits", parsed.get("hits", 0) if isinstance(parsed, dict) else 0))
        if expected_hits is None:
            expected_hits = page_hits
        elif page_hits != expected_hits:
            raise RuntimeError(
                f"CMR hit count changed during {query_id}: {expected_hits} -> {page_hits}"
            )
        items.extend(page_items)
        next_token = headers.get("cmr-search-after", "")
        if len(items) >= expected_hits:
            break
        if not next_token:
            raise RuntimeError(
                f"CMR query {query_id} stopped at {len(items)} of {expected_hits} without search-after token"
            )
        if next_token in seen_tokens:
            raise RuntimeError(f"CMR query {query_id} repeated search-after token")
        seen_tokens.add(next_token)
        search_after = next_token
        time.sleep(0.05)
    if len(items) != (expected_hits or 0):
        raise RuntimeError(f"CMR query {query_id}: collected {len(items)} != hits {expected_hits}")
    concept_ids = [item.get("meta", {}).get("concept-id", "") for item in items]
    nonempty = [value for value in concept_ids if value]
    if len(nonempty) != len(set(nonempty)):
        raise RuntimeError(f"CMR query {query_id} returned duplicate concept IDs across pages")
    return items, expected_hits or 0


def collection_platforms(umm: dict[str, Any]) -> tuple[str, str]:
    platforms: list[str] = []
    instruments: list[str] = []
    for platform in umm.get("Platforms", []) or []:
        if platform.get("ShortName"):
            platforms.append(str(platform["ShortName"]))
        for instrument in platform.get("Instruments", []) or []:
            if instrument.get("ShortName"):
                instruments.append(str(instrument["ShortName"]))
    return "|".join(dict.fromkeys(platforms)), "|".join(dict.fromkeys(instruments))


def processing_level_id(umm: dict[str, Any]) -> str:
    value = umm.get("ProcessingLevel", {})
    if isinstance(value, dict):
        return str(value.get("Id", ""))
    return str(value or "")


def select_collection(meta: dict[str, Any], umm: dict[str, Any]) -> tuple[bool, str]:
    short_name = str(umm.get("ShortName", ""))
    provider = str(meta.get("provider-id", ""))
    if provider == "ASF" and (
        re.match(r"^NISAR_L(?:0B|1|2|3)_", short_name)
        or re.match(r"^NISAR_UR_L(?:0B|1|2)(?:_|$)", short_name)
    ):
        return True, "requested NISAR science product level/maturity"
    if provider == "ASF" and re.match(r"^SENTINEL-1[ABCD]_SLC$", short_name):
        return True, "requested Sentinel-1 SLC"
    if provider == "ASF" and re.match(
        r"^SENTINEL-1[ABCD]_(?:DP|SP)_GRD_(?:HIGH|MEDIUM|FULL)$", short_name
    ):
        return True, "requested Sentinel-1 GRD variant"
    if provider == "ASF" and re.match(r"^SENTINEL-1[ABCD]_RAW$", short_name):
        return True, "additional open Sentinel-1 RAW discovered"
    if short_name in EXTRA_SELECTED_SHORT_NAMES:
        return True, "requested or additional open SAR/SAR-derived collection"
    return False, exclusion_reason(meta, umm)


def exclusion_reason(meta: dict[str, Any], umm: dict[str, Any]) -> str:
    short_name = str(umm.get("ShortName", ""))
    title = str(umm.get("EntryTitle", ""))
    text = f"{short_name} {title}".upper()
    if "_META_" in short_name or " METADATA" in text:
        return "metadata companion collection; data collection selected instead"
    if "STATIC" in text:
        return "static/non-acquisition layer excluded from acquisition inventory"
    if "OCEAN" in text or short_name.endswith("_OCN"):
        return "ocean product outside connected terrestrial-system scope"
    if any(term in text for term in ("ALTIMETER", "SCATTEROMETER", "OCEAN WIND", "LIDAR")):
        return "not imaging SAR (altimetry/scatterometry/lidar false keyword match)"
    if int(meta.get("granule-count") or 0) == 0:
        return "collection discovery record has zero catalog granules"
    return "outside selected direct or clearly SAR-derived acquisition scope"


def mission_for(short_name: str, umm: dict[str, Any] | None = None) -> str:
    upper = short_name.upper()
    if upper.startswith("NISAR_"):
        return "NISAR"
    if upper.startswith("SENTINEL-1"):
        return "Sentinel-1"
    if upper.startswith("OPERA_"):
        return "OPERA"
    if upper.startswith("ARIA_"):
        return "ARIA / Sentinel-1"
    if upper.startswith("ALOS2"):
        return "ALOS-2"
    if "SAOCOM" in upper:
        return "SAOCOM"
    if upper == "CWIC_REG_RCM" or "RCM" in upper:
        return "RCM"
    if upper.startswith("SPL") or "SMAP" in upper:
        return "SMAP"
    if umm:
        platforms, _ = collection_platforms(umm)
        return platforms
    return ""


def maturity_for(short_name: str) -> str:
    upper = short_name.upper()
    if "_BETA_" in upper:
        return "Beta"
    if "_PROVISIONAL_" in upper:
        return "Provisional"
    if upper.startswith("NISAR_UR_"):
        return "Urgent Response"
    if upper.startswith("NISAR_L") and upper.endswith("_V1"):
        return "Validated"
    if upper.startswith("OPERA_"):
        return "Validated"
    return "Archive"


def band_from_values(platform: str, instruments: str, short_name: str) -> str:
    text = f"{platform}|{instruments}|{short_name}".upper()
    bands: list[str] = []
    if any(term in text for term in ("L-SAR", "PALSAR", "SAOCOM", "SMAP")):
        bands.append("L")
    if "S-SAR" in text:
        bands.append("S")
    if any(term in text for term in ("C-SAR", "SENTINEL-1", "OPERA", "ARIA", "RCM")):
        bands.append("C")
    return "|".join(dict.fromkeys(bands))


def attrs_map(umm: dict[str, Any]) -> dict[str, list[Any]]:
    result: dict[str, list[Any]] = {}
    for attribute in umm.get("AdditionalAttributes", []) or []:
        name = str(attribute.get("Name", ""))
        values = attribute.get("Values", [])
        if name:
            result[name] = values if isinstance(values, list) else [values]
    return result


def values(attrs: dict[str, list[Any]], *names: str) -> list[Any]:
    for name in names:
        value = attrs.get(name)
        if value not in (None, [], ""):
            return value if isinstance(value, list) else [value]
    return []


def joined(attrs: dict[str, list[Any]], *names: str, separator: str = "|") -> str:
    return separator.join(str(item) for item in values(attrs, *names) if item not in (None, ""))


def decode_jsonish(value: Any) -> Any:
    current = value
    for _ in range(5):
        if not isinstance(current, str):
            break
        text = current.strip()
        if not text:
            break
        try:
            current = json.loads(text)
            continue
        except (json.JSONDecodeError, TypeError):
            pass
        try:
            current = ast.literal_eval(text)
            continue
        except (ValueError, SyntaxError):
            break
    if isinstance(current, list) and current and all(
        isinstance(item, str) and len(item) == 1 for item in current
    ):
        joined_chars = "".join(current)
        try:
            return ast.literal_eval(joined_chars)
        except (ValueError, SyntaxError):
            return joined_chars
    return current


def normalize_polarization(raw_values: list[Any]) -> str:
    decoded: list[str] = []

    def walk(value: Any) -> None:
        value = decode_jsonish(value)
        if isinstance(value, (list, tuple, set)):
            for item in value:
                walk(item)
        elif value not in (None, ""):
            decoded.append(str(value).upper())

    walk(raw_values)
    tokens: list[str] = []
    for text in decoded:
        tokens.extend(re.findall(r"(?<![A-Z])(HH|HV|VH|VV|LH|LV|RH|RV)(?![A-Z])", text))
        if "+" in text:
            tokens.extend(part for part in text.split("+") if part in {"HH", "HV", "VH", "VV", "LH", "LV", "RH", "RV"})
    if not tokens:
        letters = "".join(part for part in decoded if part in {"H", "V", "L", "R"})
        tokens.extend(letters[index : index + 2] for index in range(0, len(letters) - 1, 2))
    return "|".join(dict.fromkeys(token for token in tokens if len(token) == 2))


def producer_id(umm: dict[str, Any]) -> str:
    for identifier in umm.get("DataGranule", {}).get("Identifiers", []) or []:
        if identifier.get("IdentifierType") == "ProducerGranuleId":
            return str(identifier.get("Identifier", ""))
    return str(umm.get("GranuleUR", ""))


def provider_date(umm: dict[str, Any], kind: str) -> str:
    for item in umm.get("ProviderDates", []) or []:
        if str(item.get("Type", "")).lower() == kind.lower():
            return str(item.get("Date", ""))
    return ""


def platform_data(umm: dict[str, Any], attrs: dict[str, list[Any]]) -> tuple[str, str, str]:
    platforms: list[str] = []
    instruments: list[str] = []
    look = joined(attrs, "LOOK_DIRECTION")
    for platform in umm.get("Platforms", []) or []:
        if platform.get("ShortName"):
            platforms.append(str(platform["ShortName"]))
        for instrument in platform.get("Instruments", []) or []:
            if instrument.get("ShortName"):
                instruments.append(str(instrument["ShortName"]))
            for characteristic in instrument.get("Characteristics", []) or []:
                if characteristic.get("Name") == "LookDirection" and not look:
                    look = str(characteristic.get("Value", ""))
    if not platforms:
        fallback = joined(attrs, "ASF_PLATFORM", "SpacecraftName")
        if fallback:
            platforms.append(fallback)
    return (
        "|".join(dict.fromkeys(platforms)),
        "|".join(dict.fromkeys(instruments)),
        look,
    )


def range_times(umm: dict[str, Any]) -> tuple[str, str]:
    temporal = umm.get("TemporalExtent", {}) or {}
    value = temporal.get("RangeDateTime", {}) or {}
    if value:
        return str(value.get("BeginningDateTime", "")), str(value.get("EndingDateTime", ""))
    single = temporal.get("SingleDateTime", "")
    return str(single), str(single)


def orbit_numbers(umm: dict[str, Any]) -> str:
    result: list[str] = []
    for domain in umm.get("OrbitCalculatedSpatialDomains", []) or []:
        if domain.get("OrbitNumber") not in (None, ""):
            result.append(str(domain["OrbitNumber"]))
    return "|".join(dict.fromkeys(result))


def access_for_urls(urls: list[dict[str, Any]]) -> tuple[str, str, str, str]:
    data_urls = [
        str(item.get("URL", ""))
        for item in urls
        if str(item.get("Type", "")).startswith("GET DATA")
        or str(item.get("Type", "")) == "USE SERVICE API"
    ]
    if not data_urls:
        return (
            "public_no_login",
            "no_data_url_in_granule_metadata",
            "unknown",
            "Catalog metadata are public; no downloadable granule URL is exposed in this record.",
        )
    return (
        "public_no_login",
        "earthdata_login_required",
        "Earthdata Login",
        "Metadata search is public. NASA/ASF/PO.DAAC file retrieval redirects to Earthdata Login; direct S3 links require temporary in-region credentials where offered.",
    )


def url_class(item_type: str) -> str:
    upper = item_type.upper()
    if upper.startswith("GET DATA") or upper == "USE SERVICE API":
        return "data"
    if "VISUALIZATION" in upper or "BROWSE" in upper:
        return "browse"
    if "METADATA" in upper:
        return "metadata"
    return "related"


def normalize_cmr_granule(
    item: dict[str, Any],
    collection: dict[str, Any],
    query_id: str,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    meta = item.get("meta", {})
    umm = item.get("umm", {})
    attrs = attrs_map(umm)
    beginning, ending = range_times(umm)
    platform, instruments, look = platform_data(umm, attrs)
    short_name = str(collection.get("short_name", umm.get("CollectionReference", {}).get("ShortName", "")))
    related = umm.get("RelatedUrls", []) or []
    data_urls = [
        str(entry.get("URL", ""))
        for entry in related
        if str(entry.get("Type", "")).startswith("GET DATA")
        or str(entry.get("Type", "")) == "USE SERVICE API"
    ]
    browse_urls = [
        str(entry.get("URL", ""))
        for entry in related
        if url_class(str(entry.get("Type", ""))) == "browse"
    ]
    metadata_access, data_access, login_required, access_notes = access_for_urls(related)
    polarization = normalize_polarization(
        values(attrs, "POLARIZATION", "Polarization", "FREQUENCY_A_POLARIZATION_CONCAT")
    )
    main_pol = normalize_polarization(
        values(attrs, "FREQUENCY_A_POLARIZATION", "FREQUENCY_A_POLARIZATION_CONCAT")
    )
    side_pol = normalize_polarization(
        values(attrs, "FREQUENCY_B_POLARIZATION", "FREQUENCY_B_POLARIZATION_CONCAT")
    )
    product_type = joined(attrs, "PRODUCT_TYPE", "ProductType", "PROCESSING_TYPE") or short_name
    processing_level = joined(attrs, "PROCESSING_LEVEL", "ProductLevel") or str(
        collection.get("processing_level", "")
    )
    pge = umm.get("PGEVersionClass", {}) or {}
    production = umm.get("DataGranule", {}).get("ProductionDateTime", "")
    groups = []
    for name in (
        "GROUP_ID",
        "STACK_ID",
        "BURST_ID_FULL",
        "OPERA_BURST_ID",
        "INSAR_STACK_ID",
    ):
        groups.extend(str(value) for value in attrs.get(name, []) if value not in (None, "", "-1"))
    notes: list[str] = ["AOI/temporal catalog intersection; footprint may extend beyond the connected corridor."]
    joint = joined(attrs, "JOINT_OBSERVATION")
    if short_name.startswith("NISAR_"):
        if "S-SAR" not in instruments.upper():
            if joint.upper() == "TRUE":
                notes.append(
                    "L-SAR granule flagged as a joint observation; companion NISAR S-band data are not distributed by ASF/CMR."
                )
            else:
                notes.append("ASF/CMR NISAR science granule is L-SAR; no dedicated S-band file is exposed.")
    if short_name == "SENTINEL-1_BURSTS":
        notes.append("Burst-level child product, not an independent full Sentinel-1 scene.")
    if short_name == "SPL1A_RO_003":
        notes.append(
            "SMAP receive-only swath has near-global geometry; intersection is not proof of localized Rasuwa imaging."
        )
    if short_name == "OPERA_L3_DSWX-S1_V1" and not orbit_numbers(umm):
        notes.append("PO.DAAC DSWx-S1 UMM-G record does not expose orbit/track/direction fields.")
    granule_concept_id = str(meta.get("concept-id", ""))
    producer = producer_id(umm)
    cmr_record_url = encode_url(CMR_GRANULES, [("concept_id", granule_concept_id), ("page_size", "1")])
    row = {
        "inventory_id": f"CMR:{granule_concept_id}",
        "source_catalogs": "CMR",
        "mission": mission_for(short_name),
        "platform": platform,
        "band": band_from_values(platform, instruments, short_name),
        "instrument": instruments,
        "collection_concept_id": str(meta.get("collection-concept-id", collection.get("collection_concept_id", ""))),
        "collection_short_name": short_name,
        "collection_version": str(collection.get("version", umm.get("CollectionReference", {}).get("Version", ""))),
        "collection_title": str(collection.get("entry_title", "")),
        "provider_id": str(meta.get("provider-id", collection.get("provider_id", ""))),
        "granule_concept_id": granule_concept_id,
        "granule_revision_id": str(meta.get("revision-id", "")),
        "producer_granule_id": producer,
        "granule_ur": str(umm.get("GranuleUR", "")),
        "asf_scene_name": "",
        "asf_file_id": "",
        "product_type": product_type,
        "processing_level": processing_level,
        "maturity": maturity_for(short_name),
        "production_configuration": joined(attrs, "PRODUCTION_PIPELINE", "PRODUCTION_CONFIGURATION"),
        "product_version": joined(attrs, "PRODUCT_VERSION", "VERSION"),
        "pge_version": str(pge.get("PGEVersion", "")),
        "acquisition_begin_utc": beginning,
        "acquisition_end_utc": ending,
        "reference_begin_utc": joined(attrs, "REFERENCE_ZERO_DOPPLER_START_TIME"),
        "reference_end_utc": joined(attrs, "REFERENCE_ZERO_DOPPLER_END_TIME"),
        "secondary_begin_utc": joined(attrs, "SECONDARY_ZERO_DOPPLER_START_TIME"),
        "secondary_end_utc": joined(attrs, "SECONDARY_ZERO_DOPPLER_END_TIME"),
        "production_datetime_utc": str(production),
        "cmr_insert_datetime_utc": provider_date(umm, "Insert"),
        "cmr_update_datetime_utc": provider_date(umm, "Update"),
        "orbit_number": orbit_numbers(umm),
        "track_path": joined(attrs, "PATH_NUMBER", "TRACK_NUMBER"),
        "frame": joined(attrs, "FRAME_NUMBER"),
        "cycle": joined(attrs, "CYCLE_NUMBER"),
        "direction": joined(attrs, "ASCENDING_DESCENDING"),
        "look_direction": look,
        "beam_mode": joined(attrs, "BEAM_MODE", "Sensor"),
        "swath": joined(attrs, "SUBSWATH_NAME", "SWATH"),
        "polarization": polarization,
        "main_band_polarization": main_pol,
        "side_band_polarization": side_pol,
        "range_bandwidth_mhz": joined(
            attrs,
            "RANGE_BANDWIDTH_CONCAT",
            "FREQUENCY_A_RANGE_BANDWIDTH",
        ),
        "joint_observation": joint,
        "frame_coverage": joined(attrs, "FULL_FRAME", "FRAME_COVERAGE"),
        "group_stack_burst_id": "|".join(dict.fromkeys(groups)),
        "mgrs_tile_id": joined(attrs, "MGRS_TILE_ID"),
        "urgent_request_id": joined(attrs, "URGENT_REQUEST_ID"),
        "center_lat": joined(attrs, "CENTER_LAT"),
        "center_lon": joined(attrs, "CENTER_LON"),
        "metadata_access": metadata_access,
        "data_access": data_access,
        "login_required": login_required,
        "access_notes": access_notes,
        "primary_data_url": data_urls[0] if data_urls else "",
        "cmr_record_url": cmr_record_url,
        "asf_data_url": "",
        "data_urls_json": compact_json(data_urls),
        "browse_urls_json": compact_json(browse_urls),
        "url_count": 0,
        "data_url_count": 0,
        "cmr_query_id": query_id,
        "asf_query_ids": "",
        "additional_attributes_json": compact_json(attrs),
        "spatial_extent_json": compact_json(umm.get("SpatialExtent", {})),
        "notes": " ".join(notes),
    }
    url_rows: list[dict[str, Any]] = []
    for entry in related:
        url = str(entry.get("URL", ""))
        if not url:
            continue
        url_rows.append(
            {
                "inventory_id": row["inventory_id"],
                "granule_concept_id": granule_concept_id,
                "producer_granule_id": producer,
                "source_catalog": "CMR",
                "url_class": url_class(str(entry.get("Type", ""))),
                "url_type": str(entry.get("Type", "")),
                "url_subtype": str(entry.get("Subtype", "")),
                "format": str(entry.get("Format", "")),
                "description": str(entry.get("Description", "")),
                "url": url,
                "login_required": "Earthdata Login" if url_class(str(entry.get("Type", ""))) == "data" else "varies",
            }
        )
    return row, url_rows


def iso_z(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def parse_z(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def split_interval(start: str, end: str) -> tuple[tuple[str, str], tuple[str, str]]:
    start_dt = parse_z(start)
    end_dt = parse_z(end)
    midpoint_date = start_dt.date() + timedelta(days=max(1, (end_dt.date() - start_dt.date()).days // 2))
    midpoint = datetime.combine(midpoint_date, datetime.min.time(), tzinfo=timezone.utc)
    if midpoint <= start_dt or midpoint >= end_dt:
        midpoint = start_dt + (end_dt - start_dt) / 2
    # Inclusive overlap at one instant is intentional; exact feature deduplication
    # removes a boundary record while preventing a sub-second gap.
    return (start, iso_z(midpoint)), (iso_z(midpoint), end)


def quarter_intervals(start: str, end: str, days: int = 90) -> list[tuple[str, str]]:
    """Return small, count-checkable ASF temporal pages.

    Adjacent pages overlap at exactly one timestamp. Scene-key deduplication
    removes any boundary duplicate, and the unique union is checked against the
    full-window count endpoint.
    """
    start_dt = parse_z(start)
    end_dt = parse_z(end)
    result: list[tuple[str, str]] = []
    current = start_dt
    while current < end_dt:
        following = min(current + timedelta(days=days), end_dt)
        result.append((iso_z(current), iso_z(following)))
        if following == end_dt:
            break
        current = following
    return result


def asf_feature_key(feature: dict[str, Any]) -> tuple[str, str, str]:
    props = feature.get("properties", {}) or {}
    return (
        str(props.get("conceptID", props.get("collectionName", ""))),
        str(props.get("sceneName", "")),
        str(props.get("fileID", props.get("fileName", ""))),
    )


def asf_count(
    *,
    spec: dict[str, Any],
    start: str,
    end: str,
    scope: str,
    part_index: int,
    manifest: list[dict[str, Any]],
) -> tuple[int | None, int | None, str]:
    params = list(spec["params"]) + [
        ("intersectsWith", WKT),
        ("start", start),
        ("end", end),
        ("output", "count"),
    ]
    url = encode_url(ASF_SEARCH, params)
    query_id = f"asf_{spec['spec_id']}_count_{scope}_{part_index:03d}"
    status, headers, body, error = http_get(url, accept="text/plain, application/json")
    raw = save_raw(query_id, "asf", "response.txt", body)
    count: int | None = None
    parse_error = ""
    if status == 200:
        try:
            count = int(body.decode("utf-8").strip())
        except ValueError as exc:
            parse_error = f"invalid count response: {exc}"
    combined_error = "; ".join(part for part in (error, parse_error) if part)
    manifest.append(
        query_row(
            query_id=query_id,
            api="asf_search_count",
            query_kind="asf_count",
            spec_id=spec["spec_id"],
            url=url,
            status=status,
            response_headers=headers,
            body=body,
            raw_info=raw,
            page_index=part_index,
            partition_start=start,
            partition_end=end,
            count_scope=scope,
            returned_count="" if count is None else count,
            error=combined_error,
        )
    )
    return status, count, combined_error


def asf_geojson(
    *,
    spec: dict[str, Any],
    start: str,
    end: str,
    expected_count: int,
    scope: str,
    part_index: int,
    manifest: list[dict[str, Any]],
) -> tuple[int | None, list[dict[str, Any]], str, str]:
    params = list(spec["params"]) + [
        ("intersectsWith", WKT),
        ("start", start),
        ("end", end),
        ("maxResults", str(max(expected_count, 1))),
        ("output", "geojson"),
    ]
    url = encode_url(ASF_SEARCH, params)
    query_id = f"asf_{spec['spec_id']}_geojson_{scope}_{part_index:03d}"
    status, headers, body, error = http_get(url, accept="application/geo+json, application/json")
    raw = save_raw(query_id, "asf", "response.geojson", body)
    parsed: Any = None
    parse_error = ""
    try:
        parsed = json.loads(body) if body else {}
    except json.JSONDecodeError as exc:
        parse_error = f"JSONDecodeError: {exc}"
    features = parsed.get("features", []) if isinstance(parsed, dict) else []
    combined_error = "; ".join(part for part in (error, parse_error) if part)
    manifest.append(
        query_row(
            query_id=query_id,
            api="asf_search_geojson",
            query_kind="asf_geojson",
            spec_id=spec["spec_id"],
            url=url,
            status=status,
            response_headers=headers,
            body=body,
            raw_info=raw,
            page_index=part_index,
            partition_start=start,
            partition_end=end,
            count_scope=scope,
            returned_count=len(features),
            error=combined_error,
        )
    )
    return status, features, combined_error, query_id


def fetch_asf_spec(
    spec: dict[str, Any], manifest: list[dict[str, Any]]
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    status, full_count, count_error = asf_count(
        spec=spec,
        start=WINDOW_START,
        end=WINDOW_END,
        scope="full",
        part_index=1,
        manifest=manifest,
    )
    result = {
        "spec_id": spec["spec_id"],
        "label": spec["label"],
        "params_json": compact_json(spec["params"]),
        "http_status": status,
        "count": "" if full_count is None else full_count,
        "support_status": "",
        "error": count_error,
        "partition_count": 0,
        "retrieved_feature_count": 0,
        "unique_feature_count": 0,
        "include_in_inventory": bool(spec.get("include_in_inventory")),
    }
    if status != 200 or full_count is None:
        result["support_status"] = "unsupported_or_rejected"
        return [], result

    result["support_status"] = "supported_results" if full_count else "supported_zero_results"
    if spec.get("count_only"):
        result["partition_count"] = 0
        result["retrieved_feature_count"] = 0
        result["unique_feature_count"] = 0
        result["partition_reported_sum"] = full_count
        return [], result

    intervals = [(WINDOW_START, WINDOW_END)]
    scope = "full"
    if full_count > ASF_PARTITION_THRESHOLD:
        intervals = quarter_intervals(WINDOW_START, WINDOW_END)
        scope = "partition"

    feature_map: dict[tuple[str, str, str], dict[str, Any]] = {}
    raw_retrieved = 0
    partition_counts: list[int] = []
    query_ids_by_key: defaultdict[tuple[str, str, str], set[str]] = defaultdict(set)
    for part_index, (start, end) in enumerate(intervals, start=1):
        if scope == "partition":
            part_status, expected, part_error = asf_count(
                spec=spec,
                start=start,
                end=end,
                scope=scope,
                part_index=part_index,
                manifest=manifest,
            )
            if part_status != 200 or expected is None:
                raise RuntimeError(
                    f"ASF partition count failed for {spec['spec_id']} {start}..{end}: {part_error or part_status}"
                )
        else:
            expected = full_count
        partition_counts.append(expected)
        geo_status, features, geo_error, geo_query_id = asf_geojson(
            spec=spec,
            start=start,
            end=end,
            expected_count=expected,
            scope=scope,
            part_index=part_index,
            manifest=manifest,
        )
        if geo_status != 200 or geo_error:
            raise RuntimeError(
                f"ASF GeoJSON failed for {spec['spec_id']} {start}..{end}: {geo_error or geo_status}"
            )
        if len(features) != expected:
            raise RuntimeError(
                f"ASF {spec['spec_id']} partition returned {len(features)} features; count endpoint said {expected}"
            )
        raw_retrieved += len(features)
        for feature in features:
            key = asf_feature_key(feature)
            if not any(key):
                raise RuntimeError(f"ASF {spec['spec_id']} returned feature without stable identifiers")
            feature_map.setdefault(key, feature)
            query_ids_by_key[key].add(geo_query_id)
        time.sleep(0.05)

    # Temporal pagination can overlap a product spanning the split instant. The
    # union, not the arithmetic sum of partition counts, must equal full count.
    if len(feature_map) != full_count:
        if scope == "partition":
            geo_status, features, geo_error, geo_query_id = asf_geojson(
                spec=spec,
                start=WINDOW_START,
                end=WINDOW_END,
                expected_count=full_count,
                scope="fallback_full",
                part_index=1,
                manifest=manifest,
            )
            if geo_status == 200 and not geo_error and len(features) == full_count:
                feature_map.clear()
                query_ids_by_key.clear()
                raw_retrieved += len(features)
                for feature in features:
                    key = asf_feature_key(feature)
                    feature_map[key] = feature
                    query_ids_by_key[key].add(geo_query_id)
            else:
                raise RuntimeError(
                    f"ASF {spec['spec_id']} unique partition union {len(feature_map)} != full count {full_count}"
                )
        else:
            raise RuntimeError(
                f"ASF {spec['spec_id']} retrieved {len(feature_map)} unique != full count {full_count}"
            )

    decorated: list[dict[str, Any]] = []
    for key, feature in feature_map.items():
        copy = dict(feature)
        copy["_inventory"] = {
            "spec_ids": [spec["spec_id"]],
            "query_ids": sorted(query_ids_by_key[key]),
            "include_in_inventory": bool(spec.get("include_in_inventory")),
        }
        decorated.append(copy)
    result["partition_count"] = len(intervals)
    result["retrieved_feature_count"] = raw_retrieved
    result["unique_feature_count"] = len(feature_map)
    result["partition_reported_sum"] = sum(partition_counts)
    return decorated, result


def id_tokens(value: str) -> set[str]:
    if not value:
        return set()
    result = {value}
    current = value
    for extension in (".zip", ".h5", ".nc", ".tif", ".tiff", ".xml"):
        if current.lower().endswith(extension):
            current = current[: -len(extension)]
            result.add(current)
    for suffix in (
        "-SLC",
        "-RAW",
        "-GRD_HD",
        "-GRD_HS",
        "-GRD_MD",
        "-GRD_MS",
        "-GRD_FD",
        "-BURST",
    ):
        if current.endswith(suffix):
            result.add(current[: -len(suffix)])
    return {token for token in result if token}


def merge_asf_features(
    inventory: list[dict[str, Any]],
    url_rows: list[dict[str, Any]],
    asf_features: list[dict[str, Any]],
    collections_by_id: dict[str, dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    by_collection_token: defaultdict[tuple[str, str], set[int]] = defaultdict(set)
    by_token: defaultdict[str, set[int]] = defaultdict(set)
    for index, row in enumerate(inventory):
        cid = str(row.get("collection_concept_id", ""))
        tokens = id_tokens(str(row.get("producer_granule_id", ""))) | id_tokens(
            str(row.get("granule_ur", ""))
        )
        for token in tokens:
            by_collection_token[(cid, token)].add(index)
            by_token[token].add(index)

    crosswalk: list[dict[str, Any]] = []
    matched = 0
    asf_only = 0
    ambiguous = 0
    for feature in asf_features:
        props = feature.get("properties", {}) or {}
        info = feature.get("_inventory", {}) or {}
        cid = str(props.get("conceptID", ""))
        candidates = (
            id_tokens(str(props.get("sceneName", "")))
            | id_tokens(str(props.get("fileID", "")))
            | id_tokens(str(props.get("fileName", "")))
        )
        matches: set[int] = set()
        for token in candidates:
            matches.update(by_collection_token.get((cid, token), set()))
        if not matches:
            for token in candidates:
                matches.update(by_token.get(token, set()))
        matched_index: int | None = None
        status = ""
        if len(matches) == 1:
            matched_index = next(iter(matches))
            status = "matched_cmr"
            matched += 1
        elif len(matches) > 1:
            # Collection concept is the tie-breaker; otherwise retain an ASF-only
            # record instead of silently choosing a granule.
            same_collection = [
                index for index in matches if inventory[index].get("collection_concept_id") == cid
            ]
            if len(same_collection) == 1:
                matched_index = same_collection[0]
                status = "matched_cmr_collection_tiebreak"
                matched += 1
            else:
                status = "ambiguous_no_merge"
                ambiguous += 1
        else:
            status = "asf_only"

        if matched_index is not None:
            row = inventory[matched_index]
            catalogs = set(str(row.get("source_catalogs", "")).split("|"))
            catalogs.add("ASF")
            row["source_catalogs"] = "|".join(sorted(value for value in catalogs if value))
            row["asf_scene_name"] = str(props.get("sceneName", ""))
            row["asf_file_id"] = str(props.get("fileID", ""))
            row["asf_data_url"] = str(props.get("url", ""))
            row["asf_query_ids"] = "|".join(sorted(info.get("query_ids", [])))
            if not row.get("primary_data_url") and props.get("url"):
                row["primary_data_url"] = str(props["url"])
            inventory_id = str(row["inventory_id"])
            granule_concept_id = str(row.get("granule_concept_id", ""))
            producer = str(row.get("producer_granule_id", ""))
        elif info.get("include_in_inventory"):
            collection = collections_by_id.get(cid, {})
            short_name = str(props.get("collectionName", collection.get("short_name", "")))
            platform = str(props.get("platform", ""))
            instrument = str(props.get("sensor", ""))
            scene = str(props.get("sceneName", props.get("fileID", "")))
            inventory_id = "ASF:" + hashlib.sha256(
                "|".join(asf_feature_key(feature)).encode("utf-8")
            ).hexdigest()[:24]
            producer = scene
            data_url = str(props.get("url", ""))
            browse = props.get("browse", []) or []
            if isinstance(browse, str):
                browse = [browse]
            notes = [
                "ASF SearchAPI result had no exact selected CMR granule match at retrieval time.",
                "AOI/temporal catalog intersection; footprint may extend beyond the connected corridor.",
            ]
            row = {
                key: "" for key in INVENTORY_FIELDS
            }
            row.update(
                {
                    "inventory_id": inventory_id,
                    "source_catalogs": "ASF",
                    "mission": mission_for(short_name),
                    "platform": platform,
                    "band": band_from_values(platform, instrument, short_name),
                    "instrument": instrument,
                    "collection_concept_id": cid,
                    "collection_short_name": short_name,
                    "collection_version": str(collection.get("version", "")),
                    "collection_title": str(collection.get("entry_title", "")),
                    "provider_id": "ASF",
                    "producer_granule_id": scene,
                    "granule_ur": str(props.get("fileID", "")),
                    "asf_scene_name": str(props.get("sceneName", "")),
                    "asf_file_id": str(props.get("fileID", "")),
                    "product_type": str(props.get("processingLevel", "")),
                    "processing_level": str(props.get("processingLevel", "")),
                    "maturity": maturity_for(short_name),
                    "production_configuration": str(props.get("productionConfiguration", "")),
                    "product_version": str(props.get("crid", "")),
                    "pge_version": str(props.get("pgeVersion", "")),
                    "acquisition_begin_utc": str(props.get("startTime", "")),
                    "acquisition_end_utc": str(props.get("stopTime", "")),
                    "production_datetime_utc": str(props.get("processingDate", "")),
                    "orbit_number": str(props.get("orbit", "")),
                    "track_path": str(props.get("pathNumber", "")),
                    "frame": str(props.get("frameNumber", "")),
                    "direction": str(props.get("flightDirection", "")),
                    "beam_mode": str(props.get("beamModeType", "")),
                    "polarization": normalize_polarization(props.get("polarization", []) or []),
                    "main_band_polarization": normalize_polarization(
                        props.get("mainBandPolarization", []) or []
                    ),
                    "side_band_polarization": normalize_polarization(
                        props.get("sideBandPolarization", []) or []
                    ),
                    "range_bandwidth_mhz": "|".join(
                        str(value) for value in (props.get("rangeBandwidth", []) or [])
                    )
                    if isinstance(props.get("rangeBandwidth"), list)
                    else str(props.get("rangeBandwidth", "")),
                    "joint_observation": str(props.get("jointObservation", "")),
                    "frame_coverage": str(props.get("frameCoverage", "")),
                    "group_stack_burst_id": str(props.get("groupID", "")),
                    "center_lat": str(props.get("centerLat", "")),
                    "center_lon": str(props.get("centerLon", "")),
                    "metadata_access": "public_no_login",
                    "data_access": "earthdata_login_required" if data_url else "no_data_url",
                    "login_required": "Earthdata Login" if data_url else "unknown",
                    "access_notes": "ASF metadata are public; ASF file retrieval requires Earthdata Login.",
                    "primary_data_url": data_url,
                    "asf_data_url": data_url,
                    "data_urls_json": compact_json([data_url] if data_url else []),
                    "browse_urls_json": compact_json(browse),
                    "asf_query_ids": "|".join(sorted(info.get("query_ids", []))),
                    "spatial_extent_json": compact_json(feature.get("geometry", {})),
                    "notes": " ".join(notes),
                }
            )
            inventory.append(row)
            matched_index = len(inventory) - 1
            asf_only += 1
            granule_concept_id = ""
        else:
            inventory_id = ""
            granule_concept_id = ""
            producer = str(props.get("sceneName", ""))

        if matched_index is not None:
            props_url_groups = [
                ("data", "ASF_DATA", props.get("url")),
                ("browse", "ASF_BROWSE", props.get("browse", [])),
                ("related", "ASF_ADDITIONAL", props.get("additionalUrls", [])),
                ("data", "ASF_S3", props.get("s3Urls", [])),
            ]
            for url_class_value, url_type, url_value in props_url_groups:
                values_list = url_value if isinstance(url_value, list) else [url_value]
                for url in values_list:
                    if not url:
                        continue
                    url_rows.append(
                        {
                            "inventory_id": inventory_id,
                            "granule_concept_id": granule_concept_id,
                            "producer_granule_id": producer,
                            "source_catalog": "ASF",
                            "url_class": url_class_value,
                            "url_type": url_type,
                            "url_subtype": "",
                            "format": "",
                            "description": "",
                            "url": str(url),
                            "login_required": "Earthdata Login" if url_class_value == "data" else "varies",
                        }
                    )

        crosswalk.append(
            {
                "spec_ids": "|".join(sorted(info.get("spec_ids", []))),
                "asf_query_ids": "|".join(sorted(info.get("query_ids", []))),
                "asf_collection_concept_id": cid,
                "asf_collection_name": str(props.get("collectionName", "")),
                "asf_scene_name": str(props.get("sceneName", "")),
                "asf_file_id": str(props.get("fileID", "")),
                "match_status": status,
                "inventory_id": inventory_id,
                "cmr_granule_concept_id": granule_concept_id,
                "cmr_producer_granule_id": producer if matched_index is not None else "",
            }
        )

    return inventory, crosswalk, {
        "matched_features": matched,
        "asf_only_features": asf_only,
        "ambiguous_features": ambiguous,
    }


def merge_duplicate_asf_features(features: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], int]:
    merged: dict[tuple[str, str, str], dict[str, Any]] = {}
    duplicates = 0
    for feature in features:
        key = asf_feature_key(feature)
        if key not in merged:
            merged[key] = feature
            continue
        duplicates += 1
        existing_info = merged[key].setdefault("_inventory", {})
        incoming_info = feature.get("_inventory", {}) or {}
        existing_info["spec_ids"] = sorted(
            set(existing_info.get("spec_ids", [])) | set(incoming_info.get("spec_ids", []))
        )
        existing_info["query_ids"] = sorted(
            set(existing_info.get("query_ids", [])) | set(incoming_info.get("query_ids", []))
        )
        existing_info["include_in_inventory"] = bool(
            existing_info.get("include_in_inventory") or incoming_info.get("include_in_inventory")
        )
    return list(merged.values()), duplicates


def bbox_dimensions_km() -> tuple[float, float]:
    west, south, east, north = BBOX
    radius = 6371.0088
    mid_lat = math.radians((south + north) / 2)
    width = radius * math.cos(mid_lat) * math.radians(east - west)
    height = radius * math.radians(north - south)
    return width, height


def collection_row(item: dict[str, Any], discovery_queries: set[str] | None = None) -> dict[str, Any]:
    meta = item.get("meta", {})
    umm = item.get("umm", {})
    platforms, instruments = collection_platforms(umm)
    selected, reason = select_collection(meta, umm)
    temporal = umm.get("TemporalExtents", []) or []
    related = umm.get("RelatedUrls", []) or []
    return {
        "collection_concept_id": str(meta.get("concept-id", "")),
        "provider_id": str(meta.get("provider-id", "")),
        "short_name": str(umm.get("ShortName", "")),
        "version": str(umm.get("Version", "")),
        "entry_title": str(umm.get("EntryTitle", "")),
        "mission": mission_for(str(umm.get("ShortName", "")), umm),
        "platforms": platforms,
        "instruments": instruments,
        "bands": band_from_values(platforms, instruments, str(umm.get("ShortName", ""))),
        "processing_level": processing_level_id(umm),
        "maturity": maturity_for(str(umm.get("ShortName", ""))),
        "global_granule_count": int(meta.get("granule-count") or 0),
        "has_granules": str(meta.get("has-granules", "")),
        "temporal_extents_json": compact_json(temporal),
        "collection_related_urls_json": compact_json(related),
        "selected": "yes" if selected else "no",
        "selection_reason": reason,
        "discovery_query_ids": "|".join(sorted(discovery_queries or set())),
    }


def build_archive_status(
    collections: list[dict[str, Any]],
    cmr_counts: dict[str, int],
    cmr_query_ids: dict[str, str],
    asf_results: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for collection in collections:
        cid = collection["collection_concept_id"]
        count = cmr_counts.get(cid, 0)
        global_count = int(collection.get("global_granule_count") or 0)
        if count > 0:
            status = "supported_results"
            interpretation = "CMR exposed exact granule metadata intersecting the AOI/window."
        elif global_count == 0:
            status = "collection_stub_zero_global_granules"
            interpretation = "CMR collection exists but reports zero global granules; not proof of no mission acquisition."
        else:
            status = "supported_zero_window_results"
            interpretation = "CMR collection is populated globally but returned zero AOI/window granules."
        rows.append(
            {
                "archive": "CMR",
                "mission_product": collection["short_name"],
                "query_id": cmr_query_ids.get(cid, ""),
                "http_status": 200,
                "support_status": status,
                "result_count": count,
                "global_collection_granule_count": global_count,
                "interpretation": interpretation,
            }
        )
    for result in asf_results:
        count = result.get("count", "")
        status = result.get("support_status", "")
        if status == "unsupported_or_rejected":
            interpretation = "SearchAPI rejected the dataset/product parameter; this is unsupported, not a zero-result search."
        elif int(count or 0) == 0:
            interpretation = "SearchAPI accepted the query and returned zero AOI/window results."
        else:
            interpretation = "SearchAPI accepted the query and exposed exact metadata results."
        rows.append(
            {
                "archive": "ASF SearchAPI",
                "mission_product": result["label"],
                "query_id": f"asf_{result['spec_id']}_count_full_001",
                "http_status": result.get("http_status", ""),
                "support_status": status,
                "result_count": count,
                "global_collection_granule_count": "",
                "interpretation": interpretation,
            }
        )
    rows.append(
        {
            "archive": "CMR + ASF",
            "mission_product": "NISAR S-band product files",
            "query_id": "nisar_s_band_capability_assessment",
            "http_status": "n/a",
            "support_status": "not_distributed_by_asf_cmr",
            "result_count": 0,
            "global_collection_granule_count": "",
            "interpretation": "CMR collection metadata names L-SAR/S-SAR at mission level and L-granules may carry jointObservation=true, but ASF granule sensor metadata are L-SAR; ASF documentation routes S-band data to ISRO Bhoonidhi.",
        }
    )
    return rows


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--keep-raw", action="store_true", help="Do not clear existing raw response directories")
    args = parser.parse_args()

    if not args.keep_raw:
        shutil.rmtree(RAW_CMR, ignore_errors=True)
        shutil.rmtree(RAW_ASF, ignore_errors=True)
    RAW_CMR.mkdir(parents=True, exist_ok=True)
    RAW_ASF.mkdir(parents=True, exist_ok=True)

    manifest: list[dict[str, Any]] = []
    discovery_specs = [
        ("nisar", [("keyword", "NISAR")]),
        ("sentinel1", [("keyword", "Sentinel-1")]),
        ("alos2", [("keyword", "PALSAR-2")]),
        ("saocom", [("keyword", "SAOCOM")]),
        ("rcm", [("keyword", "RADARSAT Constellation Mission")]),
        ("opera", [("keyword", "OPERA")]),
        ("smap", [("keyword", "SMAP radar")]),
        (
            "sar_spatiotemporal",
            [
                ("keyword", "SAR"),
                ("bounding_box", BBOX_STR),
                ("temporal", f"{WINDOW_START},{WINDOW_END}"),
            ],
        ),
    ]
    discovery_items: dict[str, dict[str, Any]] = {}
    discovery_queries_by_cid: defaultdict[str, set[str]] = defaultdict(set)
    for key, extra in discovery_specs:
        query_id = f"cmr_discovery_{key}"
        params = extra + [
            ("include_has_granules", "true"),
            ("include_granule_counts", "true"),
            ("sort_key", "entry_title"),
        ]
        items, _ = cmr_search_after(
            query_id=query_id,
            endpoint=CMR_COLLECTIONS,
            params=params,
            query_kind="collection_discovery",
            manifest=manifest,
            page_size=CMR_DISCOVERY_PAGE_SIZE,
        )
        for item in items:
            cid = str(item.get("meta", {}).get("concept-id", ""))
            if cid:
                # Prefer a global-count result over the spatial-count discovery result.
                if cid not in discovery_items or key != "sar_spatiotemporal":
                    discovery_items[cid] = item
                discovery_queries_by_cid[cid].add(query_id)
        time.sleep(0.05)

    discovered_rows = [
        collection_row(item, discovery_queries_by_cid[cid])
        for cid, item in discovery_items.items()
    ]
    selected_ids = sorted(
        row["collection_concept_id"] for row in discovered_rows if row["selected"] == "yes"
    )
    selected_names = {row["short_name"] for row in discovered_rows if row["selected"] == "yes"}
    missing_required = sorted(MANDATORY_SHORT_NAMES - selected_names)
    if missing_required:
        raise RuntimeError(f"mandatory collections not discovered: {missing_required}")
    if not any(name.startswith("NISAR_L0B_") for name in selected_names):
        raise RuntimeError("NISAR L0B collections were not discovered")
    if not any("_BETA_" in name for name in selected_names):
        raise RuntimeError("NISAR beta collections were not discovered")
    if not any("_PROVISIONAL_" in name for name in selected_names):
        raise RuntimeError("NISAR provisional collections were not discovered")
    if not any(name.startswith("NISAR_UR_") for name in selected_names):
        raise RuntimeError("NISAR urgent-response collections were not discovered")

    # Re-fetch exact selected collection records in concept-ID batches so global
    # counts and metadata are authoritative and not inherited from keyword hits.
    exact_collection_items: dict[str, dict[str, Any]] = {}
    for batch_index in range(0, len(selected_ids), 25):
        batch = selected_ids[batch_index : batch_index + 25]
        params: list[tuple[str, str]] = [
            ("concept_id[]", cid) for cid in batch
        ] + [
            ("include_has_granules", "true"),
            ("include_granule_counts", "true"),
            ("sort_key", "entry_title"),
        ]
        items, _ = cmr_search_after(
            query_id=f"cmr_selected_collections_batch_{batch_index // 25 + 1:03d}",
            endpoint=CMR_COLLECTIONS,
            params=params,
            query_kind="selected_collection_metadata",
            manifest=manifest,
            page_size=50,
        )
        for item in items:
            cid = str(item.get("meta", {}).get("concept-id", ""))
            exact_collection_items[cid] = item
    if set(exact_collection_items) != set(selected_ids):
        raise RuntimeError(
            f"exact selected collection fetch mismatch: missing {sorted(set(selected_ids)-set(exact_collection_items))}"
        )

    selected_collections: list[dict[str, Any]] = []
    collections_by_id: dict[str, dict[str, Any]] = {}
    for cid in selected_ids:
        row = collection_row(exact_collection_items[cid], discovery_queries_by_cid[cid])
        row["selected"] = "yes"
        selected_collections.append(row)
        collections_by_id[cid] = row

    inventory: list[dict[str, Any]] = []
    url_rows: list[dict[str, Any]] = []
    cmr_counts: dict[str, int] = {}
    cmr_query_ids: dict[str, str] = {}
    cmr_seen: set[str] = set()
    cmr_duplicate_count = 0
    for collection in selected_collections:
        cid = collection["collection_concept_id"]
        short_name = collection["short_name"]
        query_id = f"cmr_granules_{safe_slug(short_name).lower()}_{cid.lower()}"
        cmr_query_ids[cid] = query_id
        params = [
            ("collection_concept_id", cid),
            ("bounding_box", BBOX_STR),
            ("temporal", f"{WINDOW_START},{WINDOW_END}"),
            ("sort_key", "start_date"),
        ]
        items, count = cmr_search_after(
            query_id=query_id,
            endpoint=CMR_GRANULES,
            params=params,
            query_kind="selected_collection_granules",
            manifest=manifest,
            page_size=CMR_PAGE_SIZE,
            collection_concept_id=cid,
            collection_short_name=short_name,
        )
        cmr_counts[cid] = count
        for item in items:
            row, rows_for_urls = normalize_cmr_granule(item, collection, query_id)
            concept_id = row["granule_concept_id"]
            if concept_id in cmr_seen:
                cmr_duplicate_count += 1
                continue
            cmr_seen.add(concept_id)
            inventory.append(row)
            url_rows.extend(rows_for_urls)
        time.sleep(0.05)

    # Global zero checks distinguish an empty federated collection from a local
    # zero result. These response bodies are also retained.
    for short_name in ("SAOCOM.data.products", "CWIC_REG_RCM"):
        collection = next(row for row in selected_collections if row["short_name"] == short_name)
        cmr_search_after(
            query_id=f"cmr_context_global_{safe_slug(short_name).lower()}",
            endpoint=CMR_GRANULES,
            params=[
                ("collection_concept_id", collection["collection_concept_id"]),
                ("sort_key", "start_date"),
            ],
            query_kind="global_zero_context",
            manifest=manifest,
            page_size=1,
            collection_concept_id=collection["collection_concept_id"],
            collection_short_name=short_name,
        )

    asf_results: list[dict[str, Any]] = []
    all_asf_features: list[dict[str, Any]] = []
    for spec in ASF_SPECS:
        features, result = fetch_asf_spec(spec, manifest)
        asf_results.append(result)
        all_asf_features.extend(features)
        time.sleep(0.05)

    unique_asf_features, asf_duplicate_count = merge_duplicate_asf_features(all_asf_features)
    inventory, crosswalk, merge_stats = merge_asf_features(
        inventory, url_rows, unique_asf_features, collections_by_id
    )

    # URL rows are a normalized lossless link table. Exact duplicate links from
    # the same source are removed; CMR and ASF provenance is retained separately.
    deduped_url_rows: list[dict[str, Any]] = []
    seen_urls: set[tuple[str, str, str, str]] = set()
    for row in url_rows:
        key = (
            str(row.get("inventory_id", "")),
            str(row.get("source_catalog", "")),
            str(row.get("url_type", "")),
            str(row.get("url", "")),
        )
        if key in seen_urls:
            continue
        seen_urls.add(key)
        deduped_url_rows.append(row)
    url_rows = deduped_url_rows
    urls_by_inventory: defaultdict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in url_rows:
        urls_by_inventory[str(row["inventory_id"])].append(row)
    for row in inventory:
        rows = urls_by_inventory.get(str(row["inventory_id"]), [])
        row["url_count"] = len(rows)
        row["data_url_count"] = sum(1 for value in rows if value.get("url_class") == "data")

    inventory.sort(
        key=lambda row: (
            str(row.get("acquisition_begin_utc", "")),
            str(row.get("mission", "")),
            str(row.get("collection_short_name", "")),
            str(row.get("producer_granule_id", "")),
            str(row.get("granule_concept_id", "")),
        )
    )
    crosswalk.sort(
        key=lambda row: (
            row["asf_collection_name"],
            row["asf_scene_name"],
            row["asf_file_id"],
        )
    )
    selected_collections.sort(key=lambda row: (row["mission"], row["short_name"]))
    discovered_rows.sort(key=lambda row: (row["provider_id"], row["short_name"], row["collection_concept_id"]))

    archive_status = build_archive_status(
        selected_collections, cmr_counts, cmr_query_ids, asf_results
    )

    write_csv(ROOT / "queries.csv", manifest, QUERY_FIELDS)
    write_csv(
        ROOT / "discovered_collections.csv",
        discovered_rows,
        [
            "collection_concept_id",
            "provider_id",
            "short_name",
            "version",
            "entry_title",
            "mission",
            "platforms",
            "instruments",
            "bands",
            "processing_level",
            "maturity",
            "global_granule_count",
            "has_granules",
            "temporal_extents_json",
            "collection_related_urls_json",
            "selected",
            "selection_reason",
            "discovery_query_ids",
        ],
    )
    for row in selected_collections:
        cid = row["collection_concept_id"]
        row["aoi_window_granule_count"] = cmr_counts.get(cid, 0)
        row["granule_query_id"] = cmr_query_ids.get(cid, "")
        row["metadata_access"] = "public_no_login"
        row["data_access"] = (
            "no_cmr_granules" if cmr_counts.get(cid, 0) == 0 else "earthdata_login_required"
        )
        row["login_required"] = "Earthdata Login" if cmr_counts.get(cid, 0) else "n/a"
    write_csv(
        ROOT / "collections.csv",
        selected_collections,
        [
            "collection_concept_id",
            "provider_id",
            "short_name",
            "version",
            "entry_title",
            "mission",
            "platforms",
            "instruments",
            "bands",
            "processing_level",
            "maturity",
            "global_granule_count",
            "aoi_window_granule_count",
            "has_granules",
            "temporal_extents_json",
            "collection_related_urls_json",
            "selected",
            "selection_reason",
            "granule_query_id",
            "metadata_access",
            "data_access",
            "login_required",
        ],
    )
    write_csv(ROOT / "inventory.csv", inventory, INVENTORY_FIELDS)
    write_csv(
        ROOT / "granule_urls.csv",
        url_rows,
        [
            "inventory_id",
            "granule_concept_id",
            "producer_granule_id",
            "source_catalog",
            "url_class",
            "url_type",
            "url_subtype",
            "format",
            "description",
            "url",
            "login_required",
        ],
    )
    write_csv(
        ROOT / "asf_queries.csv",
        asf_results,
        [
            "spec_id",
            "label",
            "params_json",
            "http_status",
            "count",
            "support_status",
            "error",
            "partition_count",
            "partition_reported_sum",
            "retrieved_feature_count",
            "unique_feature_count",
            "include_in_inventory",
        ],
    )
    write_csv(
        ROOT / "catalog_crosswalk.csv",
        crosswalk,
        [
            "spec_ids",
            "asf_query_ids",
            "asf_collection_concept_id",
            "asf_collection_name",
            "asf_scene_name",
            "asf_file_id",
            "match_status",
            "inventory_id",
            "cmr_granule_concept_id",
            "cmr_producer_granule_id",
        ],
    )
    write_csv(
        ROOT / "archive_status.csv",
        archive_status,
        [
            "archive",
            "mission_product",
            "query_id",
            "http_status",
            "support_status",
            "result_count",
            "global_collection_granule_count",
            "interpretation",
        ],
    )

    width_km, height_km = bbox_dimensions_km()
    config = {
        "window_utc": {"start": WINDOW_START, "end": WINDOW_END},
        "aoi": {
            "crs": "EPSG:4326",
            "bbox_wgs84": list(BBOX),
            "wkt_wgs84": WKT,
            "approx_width_km": round(width_km, 3),
            "approx_height_km": round(height_km, 3),
            "anchor_points_lon_lat": ANCHOR_POINTS,
            "rationale": "Broad rectangle covering Purepu/upper Lhende and Bhote Koshi, Langtang Lirung/Rasuwa, and the downstream Trishuli corridor through the Narayani transition.",
        },
        "cmr": {
            "pagination": "CMR-Search-After response/request header",
            "granule_page_size": CMR_PAGE_SIZE,
            "discovery_page_size": CMR_DISCOVERY_PAGE_SIZE,
        },
        "asf": {
            "pagination": "count-validated temporal partitioning for result sets above threshold",
            "partition_threshold": ASF_PARTITION_THRESHOLD,
        },
        "credentials": "none; metadata-only unauthenticated requests",
    }
    (ROOT / "config.json").write_text(compact_json(config) + "\n", encoding="utf-8")
    aoi_geojson = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {
                    "name": "Broad Rasuwa connected system SAR inventory AOI",
                    "window_start_utc": WINDOW_START,
                    "window_end_utc": WINDOW_END,
                    "bbox_wgs84": list(BBOX),
                    "wkt_wgs84": WKT,
                },
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [[
                        [BBOX[0], BBOX[1]],
                        [BBOX[2], BBOX[1]],
                        [BBOX[2], BBOX[3]],
                        [BBOX[0], BBOX[3]],
                        [BBOX[0], BBOX[1]],
                    ]],
                },
            }
        ],
    }
    (ROOT / "aoi.geojson").write_text(
        json.dumps(aoi_geojson, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    query_statuses = Counter(str(row["http_status"]) for row in manifest)
    mission_counts = Counter(str(row["mission"]) for row in inventory)
    collection_counts = Counter(str(row["collection_short_name"]) for row in inventory)
    product_counts = Counter(str(row["product_type"]) for row in inventory)
    maturity_counts = Counter(str(row["maturity"]) for row in inventory)
    band_counts = Counter(str(row["band"]) for row in inventory)
    source_counts = Counter(str(row["source_catalogs"]) for row in inventory)
    nisar_rows = [row for row in inventory if row["mission"] == "NISAR"]
    nisar_instruments = Counter(str(row["instrument"]) for row in nisar_rows)
    nisar_joint = Counter(str(row["joint_observation"]).upper() for row in nisar_rows)
    nisar_level_maturity = Counter(
        (str(row["processing_level"]), str(row["maturity"])) for row in nisar_rows
    )
    raw_bytes = sum(int(row["raw_bytes"] or 0) for row in manifest)
    unsupported = [row for row in archive_status if row["support_status"] in {"unsupported_or_rejected", "not_distributed_by_asf_cmr"}]
    zero_results = [
        row
        for row in archive_status
        if row["support_status"] in {"supported_zero_results", "supported_zero_window_results", "collection_stub_zero_global_granules"}
    ]
    summary = {
        "generated_at_utc": utc_now(),
        "window_utc": config["window_utc"],
        "aoi": config["aoi"],
        "selected_collection_count": len(selected_collections),
        "discovered_unique_collection_count": len(discovered_rows),
        "query_response_count": len(manifest),
        "query_http_status_counts": dict(sorted(query_statuses.items())),
        "raw_response_bytes": raw_bytes,
        "inventory_rows": len(inventory),
        "unique_inventory_ids": len({row["inventory_id"] for row in inventory}),
        "cmr_granule_rows": sum(1 for row in inventory if row["granule_concept_id"]),
        "unique_cmr_granule_concept_ids": len(
            {row["granule_concept_id"] for row in inventory if row["granule_concept_id"]}
        ),
        "asf_only_rows": sum(1 for row in inventory if not row["granule_concept_id"]),
        "url_rows": len(url_rows),
        "counts_by_mission": dict(sorted(mission_counts.items())),
        "counts_by_collection": dict(sorted(collection_counts.items())),
        "counts_by_product_type": dict(sorted(product_counts.items())),
        "counts_by_maturity": dict(sorted(maturity_counts.items())),
        "counts_by_band": dict(sorted(band_counts.items())),
        "counts_by_source_catalogs": dict(sorted(source_counts.items())),
        "cmr_collection_window_counts": {
            collections_by_id[cid]["short_name"]: count
            for cid, count in sorted(cmr_counts.items(), key=lambda item: collections_by_id[item[0]]["short_name"])
        },
        "asf_query_results": asf_results,
        "catalog_merge": merge_stats,
        "deduplication": {
            "cmr_duplicate_concept_rows_removed": cmr_duplicate_count,
            "asf_duplicate_features_across_specs_or_partitions_merged": asf_duplicate_count,
            "duplicate_url_rows_removed": len(url_rows) - len(seen_urls),
        },
        "nisar": {
            "inventory_rows": len(nisar_rows),
            "actual_granule_instruments": dict(sorted(nisar_instruments.items())),
            "joint_observation_flags": dict(sorted(nisar_joint.items())),
            "actual_s_sar_granule_rows": sum(
                1 for row in nisar_rows if "S-SAR" in str(row["instrument"]).upper()
            ),
            "level_maturity_counts": [
                {"processing_level": key[0], "maturity": key[1], "count": count}
                for key, count in sorted(nisar_level_maturity.items())
            ],
            "s_band_archive_status": "not distributed by ASF/CMR; jointObservation is an L-granule companion flag, not an S-band file",
        },
        "unsupported_archive_rows": unsupported,
        "zero_result_archive_rows": zero_results,
        "outputs": {
            "inventory_csv": "inventory.csv",
            "collections_csv": "collections.csv",
            "discovered_collections_csv": "discovered_collections.csv",
            "granule_urls_csv": "granule_urls.csv",
            "queries_csv": "queries.csv",
            "asf_queries_csv": "asf_queries.csv",
            "catalog_crosswalk_csv": "catalog_crosswalk.csv",
            "archive_status_csv": "archive_status.csv",
            "raw_cmr_directory": "raw/cmr",
            "raw_asf_directory": "raw/asf",
        },
    }
    (ROOT / "summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (ROOT / "dedupe_log.json").write_text(
        json.dumps(summary["deduplication"], indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    print(
        json.dumps(
            {
                "selected_collections": len(selected_collections),
                "queries": len(manifest),
                "http_statuses": dict(query_statuses),
                "inventory_rows": len(inventory),
                "cmr_rows": summary["cmr_granule_rows"],
                "asf_only_rows": summary["asf_only_rows"],
                "url_rows": len(url_rows),
                "raw_response_bytes": raw_bytes,
                "merge": merge_stats,
            },
            indent=2,
        )
    )
    unexpected_errors = [
        row
        for row in manifest
        if row["error"]
        and not (
            row["api"] == "asf_search_count"
            and row["spec_id"]
            in {"saocom_probe", "rcm_probe", "opera_dswx_probe", "opera_disp_probe"}
            and str(row["http_status"]).isdigit()
            and int(str(row["http_status"])) >= 400
        )
    ]
    return 1 if unexpected_errors else 0


if __name__ == "__main__":
    sys.exit(main())
