# Site selection for subtle-change scouting

**Decision:** keep **R1, the Langtang Lirung north-face failure source**, as the primary Rasuwa story. Retain R5 Upper Trishuli-1/Hakubesi–Mailung as the exposure-focused secondary Rasuwa site and A2 Chamoli only as a future blind method benchmark. The 2026 source location is independently specified by the Government of Nepal assessment, rather than chosen from the SAR result.[2]

All event, exposure, ground-reference, and literature evidence behind the nine-candidate shortlist is quote-backed in `data/scouting/site_scout/REPORT.md`, with raw catalog results in the same directory. This document adds the completed 24-month connected-system inventory and the processed NISAR/HyP3 quality evidence.

## Final scoring rule

Six dimensions are scored 0–5: **D** data density, **C** measured coherence/geometry quality, **H** documented hazard/event, **G** independent ground truth, **X** exposed people/infrastructure, and **N** novelty/additive value. A score of **C=0 means “not measured,” not “bad coherence.”** R1 receives C=2 because two matched 12-day pairs were processed, but the preregistered three-pair seasonal protocol was not completed; the score is capped rather than extrapolated from wavelength.

| ID | Candidate | D | C | H | G | X | N | Total / 30 | Evidence status |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| **R1** | **Langtang Lirung north-face source** | 5 | 2 | 5 | 4 | 5 | 5 | **26** | Real S1D and NISAR subsets processed; optical detachment reference available.[20] |
| **R5** | **Upper Trishuli-1 / Hakubesi–Mailung corridor** | 4 | 0 | 5 | 5 | 5 | 5 | **24** | High exposure relevance; pixel coherence not measured. |
| R2 | Purepu Glacier supraglacial-lake source | 5 | 0 | 5 | 4 | 5 | 4 | 23 | Same river system and independently documented 2025 lake-drainage comparator.[8] |
| R3 | Rasuwagadhi–Timure border/bridge/dry-port reach | 5 | 0 | 5 | 4 | 5 | 4 | 23 | Dense catalog coverage; coherence not measured. |
| A2 | Chamoli Ronti Peak 2021 source | 5 | 0 | 5 | 5 | 5 | 3 | 23 | Strong external benchmark; no pixels processed in this run. |
| A3 | South Lhonak Lake 2023 source | 4 | 0 | 5 | 5 | 5 | 3 | 22 | Useful GLOF comparator; no pixels processed in this run. |
| R4 | Syabrubesi confluence/gauge/bridge reach | 4 | 0 | 5 | 4 | 4 | 4 | 21 | Corridor relevance; coherence not measured. |
| R6 | Published Trishuli slow-landslide cluster A–F | 4 | 0 | 4 | 5 | 4 | 4 | 21 | Scientifically attractive, but the historical study window differs from the 2026 event. |
| A1 | Gongbatongsha Lake / upper Bhote Koshi 2016 cascade | 4 | 0 | 5 | 5 | 4 | 3 | 21 | Process analogue; only five Sentinel-1 acquisitions occurred in its 90-day event window. |

## Why R1 remains primary

1. **It is the event source, not a substitute site.** The government assessment places the collapse at 28.291242°N, 85.528066°E and describes the cascading path into the Bhote Koshi–Trishuli system.[2]
2. **The 24-month inventory is dense enough to test, not merely illustrate.** Across the connected system, the exact-AOI inventory contains 140 Sentinel-1A and 35 Sentinel-1D SLC dates; the longest same-geometry SLC chains are 48 and 12 dates at a 12-day median adjacent baseline. NISAR GUNW contributes 54 observation dates with a longest same-geometry chain of 28 dates at a 12-day median baseline. These are source-date counts, not product-granule counts (`data/scouting/inventory/subarea_sensor_stats.csv`).
3. **Independent validation exists.** The UNOSAT polygon is preliminary optical mapping rather than field truth, but it is independent of the radar processing.[20]
4. **The result is useful even where phase fails.** NISAR GUNW is an 80 m coherence/unwrapped-phase product,[24] yet only 9 of 528 source pixels retained connected phase in the event pair. That diagnosed steep-terrain/seasonal observability failure is a planning result rather than a reason to replace Rasuwa.
5. **Maturity is explicit.** The August NISAR products used here are provisional; ASF describes provisional products as calibrated but validated only at a limited set of sites.[23]

## Data-richness decision

Rasuwa is **not data-thin in catalog coverage**: Sentinel-1, OPERA, and post-release NISAR provide long same-geometry chains. It is **quality-thin for event-source deformation**: the processed L-band event interferogram decorrelated, the alternate NISAR look had no source pixels passing both subswath-validity conditions, and the available C-band bundle lacks an explicit layover/shadow mask. Therefore the primary deliverable is a validated event-spanning coherence-change observable plus diagnosed displacement/offset failures—not a pre-event velocity claim.

The external alternatives remain method-development reserves. None replaces Rasuwa in the main story because none was processed here, and catalog density alone cannot supply a coherence score.

## Exact follow-up gate

Promote any candidate beyond screening only after: (1) at least three matched pairs in dry and monsoon conditions; (2) an explicit per-acquisition layover/shadow mask; (3) a stable, independently chosen reference; (4) a second look or sensor; and (5) false-alarm counts over the full observable footprint.

## Sources

[2] https://giwmscdnone.gov.np/media/pdf_upload/1_Situation_Report_Bhotekoshi%20Flood_2026_CHWRR_hnmns6o.pdf — Government of Nepal CHWRR Assessment Report II: Rasuwa-Bhote Koshi Flood Event, 2026
    > "An extreme and rapid-onset flood occurred in the Lhende Khola–Bhote Koshi–Trishuli–Narayani river system on 10 Bhadra 2083 (26 August 2026)."
    > "Study of available satellite images (Landsat 9, Planet Labs) shows that a hanging glacier located on the northern side of Langtang-Lirung mountain in Rasuwa district, at an elevation of approximately 5200 masl (approximately 28.291242°N, 85.528066°E), collapsed, causing a huge ice–rock avalanche which fell onto a debris-covered glacier located approximately 3800 masl."
    > "However, no rainfall was recorded around the slope failure area or flood-initiated area during the time of the flood These observations indicate that the extreme flood was likely generated as a cascading consequence of the ice-rock avalanche and subsequent displacement of the debris mass, rather than by rainfall-induced runoff."
[8] https://www.icimod.org/kyirong-rasuwa-flood-2026-nepal-china-border — Gyirong-Rasuwa flood 2026
    > "On 26 August, there was no lake found at the origin point, but rather the collapse of a mountain face."
    > "On 8 July 2025, a lake that had formed on top of the Purepu Glacier in Tibet, about 36 km north of the border, drained suddenly and sent a flood down the same Lhende–Bhotekoshi channel."
[20] https://unosat.org/products/4259 — UNOSAT Rasuwa-Nuwakot impact assessment 4259
    > "This map illustrates the cumulative satellite-detected mudflow/rockflow extent derived from Sentinel-2 imagery acquired on 27 August 2026 and PlanetScope imagery acquired on 26 August 2026."
[23] https://nisar-docs.asf.alaska.edu/availability-overview — Available NISAR Data
    > "NISAR PROVISIONAL datasets were released July 20, 2026. These products are fully calibrated and have undergone validation at a limited set of sites around the world."
[24] https://nisar-docs.asf.alaska.edu/gunw — NISAR Geocoded Unwrapped Interferogram guide
    > "The GUNW product is an L2 product derived from the RIFG and RUNW products by geocoding the unwrapped phase and associated data layers (i.e., coherence magnitude, ionospheric phase screen) on a geographical grid at 80 m posting."
