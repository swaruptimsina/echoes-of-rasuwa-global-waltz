# Ranked falsifiable questions

These questions were fixed after Phase 0 source/catalog verification and before the final three-track run. Exploratory catalog and access probes had already established feasibility; they were not treated as confirmatory tests.

## Ranking

### Q1 — Acquisition and archive availability (**rank 1; highest feasibility**)

**Question.** What were the nearest pre- and post-event acquisitions over the source AOI for Sentinel-1, NISAR, OPERA RTC, OPERA DSWx, ALOS-2, SAOCOM and RCM, and when did the corresponding records enter their archives?

- **Method:** replay exact CMR queries over a fixed bbox and event window; preserve producer/granule IDs, acquisition time, track/direction and provider insertion time; distinguish acquisition offset from archive availability.
- **Data needed:** CMR UMM-JSON and ASF SearchAPI metadata.
- **Supports usefulness:** at least one same-geometry pair brackets the event and has an explicit, reproducible record.
- **Refutes usefulness:** no pair exists, geometry changes, or the derived product entered the archive too late for the proposed retrospective task.
- **Validation:** live query replay; unique concept-ID check; comparison with ASF catalog for Sentinel-1/NISAR/OPERA families.
- **Already answered?** Mission revisit and latency are documented generally, but the event-specific acquisition/archive timeline was not found in the opened literature.

### Q2 — Terrain-screened OPERA amplitude change (**rank 2; high feasibility**)

**Question.** Does a stable-reference-calibrated OPERA RTC-S1 VV/VH change statistic identify part of the independently mapped Langtang Lirung detachment in event-spanning pairs, while the same method does not identify it in matched pre-event quiet pairs?

- **Method:** three same-burst 12-day time series (paths 19, 85, 121); 3×3 median filter; OPERA per-acquisition validity masks; Copernicus DEM slope screen; robust median/MAD calibration outside a 300 m reference buffer; `k=3.0`; 25-pixel MMU (0.0225 km²); require change in at least two valid radar views.
- **Data needed:** nine OPERA RTC VV/VH/mask products, Copernicus GLO-30, UNOSAT detachment polygon.
- **Supports detection:** event consensus intersects the independently mapped polygon, quiet consensus does not, and outside-reference false-positive rate stays below 2%.
- **Refutes detection:** event and quiet intervals behave alike, intersection is zero, or flags are dominated by terrain-invalid pixels.
- **Validation:** independent optical/UNOSAT geometry, two additional radar viewing geometries, a matched temporal null, threshold sensitivity (`k=2.5–4.0`), explicit false alarms.
- **Already answered?** Agencies mapped the event with optical imagery and published broader SAR findings, but this exact open OPERA burst-level null test was not found.[7][20]

### Q3 — OPERA DSWx event usability (**rank 3; high feasibility**)

**Question.** Is there a DSWx-S1 acquisition close enough to 26 August 2026 to test event-time open-water detection in the upper gorge?

- **Method:** query full DSWx history around the event and require a product between 1 August and 11 September; preserve exact IDs and sensor/track.
- **Data needed:** CMR `OPERA_L3_DSWX-S1_V1` records.
- **Supports a test:** at least one pre/post pair with matched track and a short enough interval to isolate the event.
- **Refutes a test:** a catalog gap, long seasonal interval, spacecraft/geometry switch, or absent valid pixels.
- **Validation:** separate pre-history and post-history CMR queries.
- **Already answered?** DSWx design limits are documented—30 m output with a target domain of open water over 3 ha and 200 m width—but the Rasuwa event-time catalog gap was not.[13][14]

### Q4 — Immediate rainfall context (**rank 4; feasible, contextual**)

**Question.** Do native half-hourly IMERG Early/Late estimates indicate intense precipitation at the nearest grid cell during the event half-hour?

- **Method:** authenticated download of the exact 02:30–02:59 UTC V07C granules; nearest-cell extraction with quality/random-error fields; compare with POWER and Nepal CHWRR context.
- **Support for intense-rain context:** nonzero, unusually high event-half-hour rate corroborated by nearby gauge/official analysis.
- **Refutation:** low/zero rate in both runs and official station analysis inconsistent with an intense local rain pulse.
- **Limit:** a 0.1° satellite cell cannot diagnose slope-scale rain, snow, or pore pressure; orographic underestimation is possible.[17][18]

### Q5 — Precursor InSAR reproduction (**rank 5; scientifically important, lowest feasibility here**)

**Question.** Is the reported pre-event LOS displacement stable to independent processing, reference area, atmosphere, geometry and null-slope choices?

- **Method needed:** exact multi-epoch Sentinel-1/NISAR acquisition list, phase/coherence/connected components, atmospheric/ionospheric corrections, ascending/descending controls and neighboring glaciated null slopes.
- **Support:** progressive source-tied signal across independent interferograms and sensors, robust to corrections and absent from controls.
- **Refutation:** signal follows atmosphere/elevation, low coherence, phase-unwrapping boundaries or glacier motion rather than the future detachment.
- **Already answered?** ICIMOD reports up to 40 cm Sentinel-1 LOS change but calls the physical interpretation unresolved.[9][11] Event-period NISAR products are provisional.[23]
- **Decision/outcome:** promoted into the data-richness follow-up and tested with real NISAR subsets. Event-source phase coverage collapsed to 9/528 pixels and the alternate look had no source pixels passing both subswath-validity conditions; no displacement or precursor result survived. See `FINDINGS.md` and `data/processed/nisar_lband/outputs/subset_findings.json`.

## Data-richness follow-up questions

These follow-up tests were frozen after the whole-system inventory and before interpreting the final NISAR/HyP3 pixel summaries.

### S1 — Where is same-geometry SAR coverage actually dense?

- **Question:** for each connected-system subarea and sensor/product, how many unique source dates exist, what is the longest same-geometry sequence, its median adjacent baseline, and its pre/post-event monsoon coverage?
- **Support:** multiple repeat geometries with event-adjacent dates and explicit product/quality fields.
- **Refutation:** footprint-only scenes, isolated dates, missing geometry identifiers, or unsupported archives.
- **Outcome:** catalog-rich across all six subareas, with important archive gaps and unsupported S-band/RCM/SAOCOM routes. See `inventory.csv` and `data/scouting/inventory/subarea_sensor_stats.csv`.

### S2 — Is event-spanning coherence loss localized relative to controls?

- **Question:** within each sensor, is event-minus-quiet coherence lower at the independently mapped source/detachment than in a spatial control?
- **Method:** same-burst 12-day Sentinel-1D pairs and same-track NISAR pairs; preserve masks, connected components and separate valid-pixel denominators. Calibrate a C-band screen to the control 5th percentile and four-pixel MMU.
- **Support:** negative target-versus-control contrast, independent optical overlap, temporal null separation and reported false alarms.
- **Refutation:** target and control behave alike, valid coverage is absent, or the result depends on unconnected phase.
- **Outcome:** descriptive coherence loss supported in both bands; only C band produced a control-calibrated screening result. Absolute L/C coherence was not ranked.

### S3 — Can NISAR phase or offsets support subtle motion?

- **Question:** do connected, quality-screened GUNW phase or culled GOFF offsets support a stable source motion estimate relative to a control and alternate look?
- **Support:** coherent connected phase or high-correlation offsets across a multi-epoch network, robust to masks/corrections and absent from controls.
- **Refutation:** event decorrelation, invalid subswaths, outlier-dominated offsets, QA failures or unstable reference.
- **Outcome:** diagnosed failure for both phase displacement and raw subtle offsets; calibrated GCOV backscatter change remains exploratory.

## Stop-condition mapping

| Question | Outcome required | Final status location |
|---|---|---|
| Q1 | Validated result or diagnosed failure | `FINDINGS.md`, `data/acquisition_timeline.csv` |
| Q2 | Validated result or diagnosed failure | `FINDINGS.md`, `data/processed/opera_change/analysis_summary.json` |
| Q3 | Validated result or diagnosed failure | `FINDINGS.md`, `negative_results.md` |
| S1 | Validated inventory result or catalog failure | `site_selection.md`, `data/scouting/inventory/subarea_sensor_stats.csv` |
| S2 | Validated coherence result or diagnosed failure | `FINDINGS.md`, `data/scouting/impact/l_vs_c_coherence.json` |
| S3 | Validated motion result or diagnosed failure | `FINDINGS.md`, `data/scouting/impact/subtle_change_results.json` |

## Sources

[7] https://www.usgs.gov/programs/landslide-hazards/science/2026-nepal-debris-avalanche-and-flash-flood — 2026 Nepal Debris Avalanche and Flash Flood
    > "USGS geologists are mapping the inundation boundary of the debris flow and flood by using satellite imagery. By comparing images taken before and after the event, geologists can identify newly affected areas, trace the limits of inundation, and disturbed surfaces from undisturbed terrain."
[9] https://www.icimod.org/press-releases/second-major-himalayan-flood-in-seven-weeks-raises-new-questions-about-mountain-risk — Second major Himalayan flood in seven weeks raises alarm over compounding mountain hazards
    > "Sentinel-1 satellite radar detected up to 40 cm of ground deformation between 7 July and 24 August 2026, during the 48 day before the collapse."
[11] https://doi.org/10.53055/ICIMOD.1150 — Understanding the Gyirong–Rasuwa disaster of 26 August 2026: A preliminary synthesis
    > "The source of the event was a bedrock failure that sheared away part of a hanging glacier; this has been established through seismic, satellite, and drone evidence."
[13] https://podaac.jpl.nasa.gov/dataset/OPERA_L3_DSWX-S1_V1 — OPERA Dynamic Surface Water Extent from Sentinel-1
    > "Using Sentinel-1 radar observations, DSWx-S1 maps open inland water bodies greater than 3 hectares and 200 meters in width, irrespective of cloud conditions and daylight illumination that often pose challenges to optical sensors."
[14] https://archive.podaac.earthdata.nasa.gov/podaac-ops-cumulus-docs/web-misc/opera/D-108761_OPERA_DSWx_S1AB_ProductSpec_Rev_A.pdf — OPERA DSWx-S1 Product Specification
    > "Invalid data classes (HAND masked, layover/shadow masked and fill value) are also provided to indicate areas in which the binary classification does not provide water/not water classification."
[17] https://www.earthdata.nasa.gov/data/catalog/ges-disc-gpm-3imerghhe-07 — GPM IMERG Early V07 catalog
    > "The precipitation estimates from the various precipitation-relevant satellite passive microwave (PMW) sensors comprising the GPM constellation are computed using the 2021 version of the Goddard Profiling Algorithm (GPROF2021), then gridded, intercalibrated to the GPM Combined Ku Radar-Radiometer Algorithm (CORRA) product, and merged into half-hourly 0.1°x0.1° (roughly 10x10 km) fields."
[18] https://gpm.nasa.gov/sites/default/files/2025-02/FAQ%20for%20IMERG%20V07%20Applications%20Users_202502.pdf — IMERG V07 Applications FAQ
    > "Greater uncertainty near orographic regions may lead to underestimated precipitation rates."
[20] https://unosat.org/products/4259 — UNOSAT Rasuwa-Nuwakot impact assessment 4259
    > "This map illustrates the cumulative satellite-detected mudflow/rockflow extent derived from Sentinel-2 imagery acquired on 27 August 2026 and PlanetScope imagery acquired on 26 August 2026."
[23] https://nisar-docs.asf.alaska.edu/availability-overview — Available NISAR Data
    > "NISAR PROVISIONAL datasets were released July 20, 2026. These products are fully calibrated and have undergone validation at a limited set of sites around the world."
