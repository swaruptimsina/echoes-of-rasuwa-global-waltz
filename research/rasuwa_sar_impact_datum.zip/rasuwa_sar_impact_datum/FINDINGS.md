# FINDINGS

## Primary result — Rasuwa is catalog-rich but event-source phase-poor

**OBSERVATION.** The canonical connected-system AOI contains a 4,774.048 km² HydroBASINS upstream catchment plus a separate non-catchment Devighat corridor supplement. Exact spatial post-filtering retained **6,803** of **12,931** CMR granules from the 24-month rectangular discovery search. Counts collapse to long source-date chains: one Sentinel-1A SLC geometry has **48 dates**, Sentinel-1D has **12**, and NISAR GUNW has **28**, each with a **12-day median adjacent baseline** (`data/scouting/inventory/subarea_sensor_stats.csv`).

**INTERPRETATION.** Rasuwa is not data-thin in catalog coverage. It is quality-thin for deformation at the steep source: abundant footprints do not guarantee geometry-valid, coherent, connected phase.

## Validated result 1 — localized Sentinel-1D event-spanning coherence loss

**OBSERVATION.** Two real 12-day, same-burst Sentinel-1D HyP3 interferograms were processed at 80 m. Inside the independent preliminary UNOSAT detachment polygon, median normalized coherence changed from **0.5129** for 4–16 August to **0.3950** for 16–28 August; the paired-pixel median change was **−0.1313**. A 0.3–1.5 km local control ring changed by **+0.1841**. UNOSAT’s reference is independent optical/Planet-derived mapping, but it is preliminary rather than field truth.[20]

A threshold fixed at the lower 5th percentile of the valid control distribution (**−0.12616**) and a four-pixel/**0.0256 km²** minimum mapping unit flagged **158/307 target pixels (51.5%)**. It also flagged **1,225/30,161 control pixels (4.06%)**, reported as false alarms rather than hidden background.

**INTERPRETATION.** Localized event-spanning surface change is supported. **Confidence: medium-low**, because coherence loss has multiple possible causes and the HyP3 burst bundle supplied no explicit layover/shadow mask. This is not evidence of a precursor, unique cause, displacement, or prediction.

## Validated result 2 — independent OPERA amplitude change found only an observable subset

**OBSERVATION.** The earlier three-view OPERA RTC test used per-acquisition validity masks, DEM/slope screening, a stable-reference threshold of `k=3`, a 25-pixel MMU, and agreement in at least two views. It flagged **1.1871 km²**, overlapping **0.2745 km²** of the preliminary detachment; recall over the observable reference was **29.13%** and the outside-reference false-positive rate was **0.944%**. The matched quiet null flagged **0.1080 km²**, had **zero reference overlap**, and a **0.112%** outside-reference false-positive rate.

Only **0.9423 of 1.9568 km² (48.15%)** of the reference polygon was observable by the two-view consensus; invalid terrain is unknown, not unchanged. OPERA RTC is gamma-0 amplitude without a speckle filter, so the output remains **backscatter change**, not a complete debris/flood class.[25]

**INTERPRETATION.** **Confidence: medium** that amplitude detects a real subset of the event disturbance; **low** that the binary area is physically unique or complete.

## Diagnosed failure 1 — NISAR phase did not support displacement

**OBSERVATION.** Authenticated range reads opened eight provisional NISAR GUNW/GOFF/GCOV science files totaling **35.46 GB** without downloading a complete HDF5 file. In the source window, median L-band coherence changed from **0.2188** in a 14–26 July quiet pair to **0.1021** in a 19–31 August event pair; the exploratory control changed only from **0.8616** to **0.8464**. However, connected unwrapped phase coverage fell from **249/528** source pixels to **9/528 (1.70%)**; the control retained **420/420** in both pairs. A near-time-matched alternate NISAR look had no source pixels passing both subswath-validity conditions.

**DIAGNOSIS.** No LOS displacement, velocity, acceleration, or pre-event movement is reported. GUNW provides 80 m phase/coherence layers in principle,[24] but event-source decorrelation, mask failures, ionosphere flags, and provisional QA failures block a defensible deformation result. **Confidence: high for the failure diagnosis.**

## Diagnosed failure 2 — raw NISAR offsets were not a subtle-motion estimator

**OBSERVATION.** Event-source GOFF layer-1 correlation had a **0.2206** median and offset distributions with p05/p95 values extending over hundreds of metres, while the control correlation remained about **0.86**.

**DIAGNOSIS.** The raw, unculled layers cannot support a sub-metre claim without correlation culling, a stable-reference model, geometry corrections, and uncertainty propagation. **Confidence: high for the failure diagnosis.**

## Cross-band finding

Within-sensor target-minus-control contrasts were negative in both bands: **−0.1015** for NISAR L band and **−0.3155** for Sentinel-1D C band. Absolute L- and C-band coherence is **not** compared because dates, wavelength, polarization, look geometry, masks, and terrain observability differ. The result supports concordant localized decorrelation, not an L-band-versus-C-band performance ranking.

## Latency and mission gaps

The first Sentinel-1D image used here was acquired **2.395 days** after the event and inserted into CMR **3.254 days** after it. The matching OPERA RTC acquisition had a **2.396-day** offset but was inserted **46.379 days** after the event in this snapshot. The earliest NISAR post-event footprint was **2.421 days** after the event, but its track-48 GUNW phase was unusable at the source. Acquisition, production, archive insertion, and research processing are distinct clocks; none is warning time.

ALOS-2 had **11** exact-AOI ScanSAR granules, all from December 2024–March 2025; none was post-event in this snapshot. RCM and SAOCOM catalog probes were unsupported, not evidence of zero acquisition. NISAR S-band is not distributed through CMR/ASF, and a Bhoonidhi enumeration was not completed; its availability remains **UNVERIFIED**.

## What this means for communities—and what it does not

Useful outputs are a reproducible evidence trail, a terrain-censored change screen, explicit false alarms, and mission latency/availability records. Those can help universities and agencies decide where field checks, better masks, and denser acquisitions are worth investing. They do **not** show a validated precursor, complete hazard extent, failure probability, depth, velocity, volume, population at risk, evacuation need, or operational readiness.

## Plain-language hackathon summary

Rasuwa has plenty of radar scenes, but the steep source was too decorrelated for a defensible NISAR displacement map. Sentinel-1D coherence and an independent OPERA amplitude method both found localized event-related change, with explicit control false alarms and large terrain-coverage limits. The game should let players discover that honest result—satellites can narrow a field search and expose data gaps, but they did not predict this collapse.

## Sources

[20] https://unosat.org/products/4259 — UNOSAT Rasuwa-Nuwakot impact assessment 4259
    > "This map illustrates the cumulative satellite-detected mudflow/rockflow extent derived from Sentinel-2 imagery acquired on 27 August 2026 and PlanetScope imagery acquired on 26 August 2026."
[24] https://nisar-docs.asf.alaska.edu/gunw — NISAR Geocoded Unwrapped Interferogram guide
    > "The GUNW product is an L2 product derived from the RIFG and RUNW products by geocoding the unwrapped phase and associated data layers (i.e., coherence magnitude, ionospheric phase screen) on a geographical grid at 80 m posting."
[25] https://hyp3-docs.asf.alaska.edu/guides/opera_rtc_product_guide — ASF OPERA RTC-S1 product guide
    > "The pixel values of the products represent gamma-0 power. The pixel spacing is 30 meters, and no speckle filter has been applied."
    > "For investigating the layover/shadow impacts for a specific RTC product, users will generally be better served by using the validity mask delivered with that product rather than the mask available as a static layer."
